"""Native macOS presentation helpers without a PyObjC dependency.

Qt's ``showFullScreen`` creates a dedicated macOS Space.  Nexora instead uses
an ordinary borderless window sized to the complete display and asks AppKit to
hide the host Dock/menu bar.  This keeps the shell in the current Space and
prevents the desktop/Mission Control flash visible when the pointer reaches the
bottom edge.
"""
from __future__ import annotations

import atexit
import ctypes
import ctypes.util
import logging
import sys

_LOG = logging.getLogger(__name__)
_ACTIVE = False

# NSApplicationPresentationOptions
_AUTO_HIDE_DOCK = 1 << 0
_HIDE_DOCK = 1 << 1
_AUTO_HIDE_MENU_BAR = 1 << 2
_HIDE_MENU_BAR = 1 << 3

# NSWindowCollectionBehavior
_CAN_JOIN_ALL_SPACES = 1 << 0
_FULL_SCREEN_AUXILIARY = 1 << 8


def _runtime():
    if sys.platform != "darwin":
        return None
    objc_path = ctypes.util.find_library("objc")
    if not objc_path:
        return None
    objc = ctypes.cdll.LoadLibrary(objc_path)
    objc.objc_getClass.restype = ctypes.c_void_p
    objc.objc_getClass.argtypes = [ctypes.c_char_p]
    objc.sel_registerName.restype = ctypes.c_void_p
    objc.sel_registerName.argtypes = [ctypes.c_char_p]
    return objc


def _send(objc, receiver: int, selector: str, *, restype=ctypes.c_void_p, argtypes=(), args=()):
    if not receiver:
        return 0
    fn = objc.objc_msgSend
    fn.restype = restype
    fn.argtypes = [ctypes.c_void_p, ctypes.c_void_p, *argtypes]
    return fn(ctypes.c_void_p(receiver), objc.sel_registerName(selector.encode("utf-8")), *args)


def _application(objc) -> int:
    cls = objc.objc_getClass(b"NSApplication")
    return int(_send(objc, cls, "sharedApplication") or 0)


def apply_borderless_desktop(widget) -> bool:
    """Hide host chrome and configure a QWidget as a non-Space desktop.

    ``QWidget.winId()`` is an ``NSView*`` under Qt 6.  The containing NSWindow
    is retrieved through ``-[NSView window]`` and configured in place.
    """
    global _ACTIVE
    if sys.platform != "darwin":
        return False
    try:
        objc = _runtime()
        if objc is None:
            return False
        app = _application(objc)
        if not app:
            return False

        # AppKit forbids combining a Hide* option with its AutoHide*
        # counterpart. Use the explicit hide pair so the host chrome stays
        # fully hidden while Nexora is active, without entering a fullscreen
        # Space.
        options = _HIDE_DOCK | _HIDE_MENU_BAR
        _send(
            objc,
            app,
            "setPresentationOptions:",
            restype=None,
            argtypes=(ctypes.c_ulong,),
            args=(ctypes.c_ulong(options),),
        )

        view = int(widget.winId())
        window = int(_send(objc, view, "window") or 0)
        if window:
            behavior = _CAN_JOIN_ALL_SPACES | _FULL_SCREEN_AUXILIARY
            _send(
                objc,
                window,
                "setCollectionBehavior:",
                restype=None,
                argtypes=(ctypes.c_ulong,),
                args=(ctypes.c_ulong(behavior),),
            )
            # Place the window above normal application windows.  Hiding the
            # menu bar/Dock via presentation options means an extreme window
            # level is unnecessary and would interfere with native dialogs.
            _send(
                objc,
                window,
                "setLevel:",
                restype=None,
                argtypes=(ctypes.c_long,),
                args=(ctypes.c_long(3),),
            )
            _send(
                objc,
                window,
                "setHidesOnDeactivate:",
                restype=None,
                argtypes=(ctypes.c_bool,),
                args=(ctypes.c_bool(False),),
            )
        _send(
            objc,
            app,
            "activateIgnoringOtherApps:",
            restype=None,
            argtypes=(ctypes.c_bool,),
            args=(ctypes.c_bool(True),),
        )
        _ACTIVE = True
        return True
    except Exception:
        _LOG.exception("Could not configure native macOS desktop window")
        return False


def restore_host_chrome() -> None:
    global _ACTIVE
    if not _ACTIVE or sys.platform != "darwin":
        return
    try:
        objc = _runtime()
        if objc is None:
            return
        app = _application(objc)
        if app:
            _send(
                objc,
                app,
                "setPresentationOptions:",
                restype=None,
                argtypes=(ctypes.c_ulong,),
                args=(ctypes.c_ulong(0),),
            )
    except Exception:
        _LOG.debug("Could not restore macOS presentation options", exc_info=True)
    finally:
        _ACTIVE = False


atexit.register(restore_host_chrome)
