from .adapters import CapabilityResult, PlatformAdapter
__all__=["CapabilityResult","PlatformAdapter"]
