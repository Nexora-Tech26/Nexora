"""Capability-aware and timeout-safe platform integration facade."""
from __future__ import annotations

import platform
import shutil
import subprocess
from dataclasses import dataclass
from typing import Sequence


@dataclass(frozen=True)
class CapabilityResult:
    available: bool
    success: bool = False
    message: str = ""
    command: tuple[str, ...] = ()


class PlatformAdapter:
    def __init__(self):
        self.system = platform.system().lower()

    def capabilities(self):
        return {
            "wifi": self._has_settings_backend("wifi"),
            "bluetooth": self._has_settings_backend("bluetooth"),
            "brightness": True,
            "volume": True,
            "airplane_mode": self.system in {"windows", "darwin"},
            "screen_recording": self._has_settings_backend("recording"),
            "audio_devices": self._has_settings_backend("audio"),
            "display_settings": self._has_settings_backend("display"),
        }

    def _run(self, args: Sequence[str], timeout=4):
        command = tuple(str(value) for value in args)
        if not command or shutil.which(command[0]) is None:
            return CapabilityResult(False, False, f"Required command is unavailable: {command[0] if command else 'unknown'}", command)
        try:
            completed = subprocess.run(command, capture_output=True, text=True, timeout=timeout, check=False)
            detail = (completed.stderr or completed.stdout).strip()
            return CapabilityResult(True, completed.returncode == 0, detail, command)
        except (OSError, subprocess.TimeoutExpired) as exc:
            return CapabilityResult(True, False, str(exc), command)

    def _linux_backend(self, feature: str) -> tuple[str, ...] | None:
        options = {
            "wifi": (("nm-connection-editor",), ("gnome-control-center", "wifi")),
            "bluetooth": (("blueman-manager",), ("gnome-control-center", "bluetooth")),
            "display": (("gnome-control-center", "display"), ("systemsettings5", "kcm_kscreen")),
            "audio": (("pavucontrol",), ("gnome-control-center", "sound")),
            "recording": (("gnome-screenshot", "-i"), ("spectacle",)),
        }
        for command in options.get(feature, ()):
            if shutil.which(command[0]):
                return command
        return None

    def _has_settings_backend(self, feature: str) -> bool:
        if self.system in {"darwin", "windows"}:
            return True
        return self._linux_backend(feature) is not None

    def _open_feature(self, feature: str) -> CapabilityResult:
        if self.system == "darwin":
            targets = {
                "wifi": "x-apple.systempreferences:com.apple.wifi-settings-extension",
                "bluetooth": "x-apple.systempreferences:com.apple.BluetoothSettings",
                "display": "x-apple.systempreferences:com.apple.Displays-Settings.extension",
                "audio": "x-apple.systempreferences:com.apple.Sound-Settings.extension",
                "airplane": "x-apple.systempreferences:com.apple.Network-Settings.extension",
            }
            if feature == "recording":
                return self._run(("open", "-a", "Screenshot"))
            target = targets.get(feature)
            return self._run(("open", target)) if target else CapabilityResult(False, False, "Unsupported capability")
        if self.system == "windows":
            targets = {
                "wifi": "ms-settings:network-wifi",
                "bluetooth": "ms-settings:bluetooth",
                "display": "ms-settings:display",
                "audio": "ms-settings:sound",
                "airplane": "ms-settings:network-airplanemode",
                "recording": "ms-gamebar:",
            }
            target = targets.get(feature)
            return self._run(("explorer.exe", target)) if target else CapabilityResult(False, False, "Unsupported capability")
        command = self._linux_backend(feature)
        if command is None:
            return CapabilityResult(False, False, f"No {feature} settings backend was detected on this Linux desktop")
        return self._run(command)

    def open_wifi_settings(self): return self._open_feature("wifi")
    def open_bluetooth_settings(self): return self._open_feature("bluetooth")
    def open_display_settings(self): return self._open_feature("display")
    def open_audio_settings(self): return self._open_feature("audio")
    def open_airplane_settings(self): return self._open_feature("airplane")
    def open_screen_recording(self): return self._open_feature("recording")
