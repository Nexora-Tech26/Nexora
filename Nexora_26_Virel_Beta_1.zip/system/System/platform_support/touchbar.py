"""Responsive native Touch Bar integration for Intel MacBook Pro."""
from __future__ import annotations
import os, sys, weakref
from ctypes import c_void_p
from typing import Callable
from PySide6.QtCore import QEvent, QObject, QTimer
from PySide6.QtWidgets import QApplication, QAbstractButton, QLineEdit

class _FocusWatcher(QObject):
    def __init__(self, controller): super().__init__(); self.controller=controller
    def eventFilter(self, obj, event):
        if event.type() in (QEvent.WindowActivate, QEvent.FocusIn, QEvent.Show):
            QTimer.singleShot(20, lambda o=obj: self.controller._focus_changed(o))
        return False

class TouchBarController:
    def __init__(self, desktop):
        self.desktop=weakref.proxy(desktop); self.active_window=None; self.available=False
        self._delegate=self._bar=self._native_window=None; self._signature=()
        if sys.platform!='darwin' or os.environ.get('NEXORA_ENABLE_TOUCHBAR') != '1': return
        app=QApplication.instance()
        if app is None or app.platformName().casefold()=='offscreen': return
        try:
            import objc
            from AppKit import NSApplication, NSButton, NSColor, NSCustomTouchBarItem, NSImage, NSTouchBar
            from Foundation import NSObject
        except Exception as exc:
            print(f'Nexora Touch Bar unavailable: {exc}'); return
        controller=self
        class Delegate(NSObject):
            def init(self):
                self=objc.super(Delegate,self).init(); self.actions={} if self is not None else None; return self
            def touchBar_makeItemForIdentifier_(self,touchbar,identifier):
                key=str(identifier); title,symbol,color,callback=self.actions.get(key,('Nexora','sparkles','#6C7CFF',None))
                item=NSCustomTouchBarItem.alloc().initWithIdentifier_(identifier)
                image=None
                try: image=NSImage.imageWithSystemSymbolName_accessibilityDescription_(symbol,title)
                except Exception: pass
                button=(NSButton.buttonWithImage_target_action_(image,self,'performAction:') if image is not None else NSButton.buttonWithTitle_target_action_(title,self,'performAction:'))
                button.setIdentifier_(identifier); button.setToolTip_(title)
                try:
                    from AppKit import NSColor
                    button.setBezelColor_(NSColor.colorWithRed_green_blue_alpha_(*controller._rgb(color),0.92))
                except Exception: pass
                item.setView_(button); return item
            def performAction_(self,sender):
                entry=self.actions.get(str(sender.identifier()))
                if entry and entry[3]: QTimer.singleShot(0,entry[3])
        self._objc=objc; self._NSApplication=NSApplication; self._NSTouchBar=NSTouchBar
        self._delegate=Delegate.alloc().init(); self.available=True
        self._watcher=_FocusWatcher(self); app.installEventFilter(self._watcher)
        self._refresh_timer=QTimer(self._watcher); self._refresh_timer.setInterval(700); self._refresh_timer.timeout.connect(self.refresh); self._refresh_timer.start()
        QTimer.singleShot(120,self._attach)
    @staticmethod
    def _rgb(value):
        value=value.lstrip('#'); return tuple(int(value[i:i+2],16)/255 for i in (0,2,4))
    def _focus_changed(self,obj):
        window=obj.window() if hasattr(obj,'window') else None
        if window and window is not self.desktop: self.set_active_window(window)
        else: self.refresh()
    def _resolve_native_window(self):
        app=self._NSApplication.sharedApplication(); window=app.keyWindow() or app.mainWindow()
        if window is not None:return window
        try:
            native=self._objc.objc_object(c_void_p=int(self.desktop.winId())); return native.window() if hasattr(native,'window') else native
        except Exception:return None
    def _attach(self):
        if not self.available:return
        window=self._resolve_native_window()
        if window is None: QTimer.singleShot(350,self._attach); return
        if window is not self._native_window: self._native_window=window; self._signature=()
        self.refresh(force=True)
    def set_active_window(self,window):
        self.active_window=weakref.ref(window) if window is not None else None; self.refresh(force=True)
    def _current_window(self): return self.active_window() if self.active_window else None
    @staticmethod
    def _find_button(window,words):
        if window is None:return None
        words=tuple(w.casefold() for w in words)
        for button in window.findChildren(QAbstractButton):
            hay=f'{button.text()} {button.toolTip()} {button.objectName()}'.casefold()
            if button.isVisible() and button.isEnabled() and any(w in hay for w in words): return button
    def _trigger(self,*words):
        b=self._find_button(self._current_window(),words)
        if b:b.animateClick()
    def _focus_search(self):
        w=self._current_window(); fields=w.findChildren(QLineEdit) if w else []
        target=next((f for f in fields if 'search' in f.placeholderText().casefold()),fields[0] if fields else None)
        if target: target.setFocus(); target.selectAll()
        else:
            try:self.desktop.toggle_start()
            except Exception:pass
    def _control_center(self):
        try:self.desktop.toggle_control_center()
        except Exception:pass
    def _items(self):
        w=self._current_window(); title=str(getattr(w,'title',getattr(w,'windowTitle',lambda:'Nexora')())).casefold() if w else 'nexora'
        common=[('com.nexora.search','Search','magnifyingglass','#4EA1FF',self._focus_search),('com.nexora.controls','Controls','slider.horizontal.3','#8B6CFF',self._control_center)]
        if not w:return common
        if 'files' in title:return [('files.back','Back','chevron.left','#4EA1FF',lambda:self._trigger('back','previous')),('files.forward','Forward','chevron.right','#4EA1FF',lambda:self._trigger('forward','next')),('files.folder','New folder','folder.badge.plus','#FFC64D',lambda:self._trigger('new folder','create folder')),('files.view','View','square.grid.2x2','#65D5B2',lambda:self._trigger('view','list','icons')),('files.trash','Trash','trash','#FF6B6B',lambda:self._trigger('delete','trash'))]
        if any(x in title for x in ('notepad','notes','editor')):return [('note.save','Save','square.and.arrow.down','#4EA1FF',lambda:self._trigger('save')),('note.undo','Undo','arrow.uturn.backward','#8B6CFF',lambda:self._trigger('undo')),('note.redo','Redo','arrow.uturn.forward','#8B6CFF',lambda:self._trigger('redo')),('note.find','Find','magnifyingglass','#65D5B2',self._focus_search)]
        if 'browser' in title:return [('browser.back','Back','chevron.left','#4EA1FF',lambda:self._trigger('back')),('browser.forward','Forward','chevron.right','#4EA1FF',lambda:self._trigger('forward')),('browser.reload','Reload','arrow.clockwise','#65D5B2',lambda:self._trigger('refresh','reload')),('browser.tab','New tab','plus.square','#8B6CFF',lambda:self._trigger('new tab','+'))]
        if 'terminal' in title:return [('term.stop','Stop','stop.fill','#FF6B6B',lambda:self._trigger('interrupt','stop','cancel')),('term.clear','Clear','trash','#FFC64D',lambda:self._trigger('clear')),('term.tab','New tab','plus.square','#4EA1FF',lambda:self._trigger('new tab','+'))]
        return [('app.back','Back','chevron.left','#4EA1FF',lambda:self._trigger('back','previous')),('app.search','Search','magnifyingglass','#65D5B2',self._focus_search),('app.refresh','Refresh','arrow.clockwise','#8B6CFF',lambda:self._trigger('refresh','reload')),('app.controls','Controls','slider.horizontal.3','#FF8A5B',self._control_center)]
    def refresh(self,force=False):
        if not self.available:return
        native=self._resolve_native_window()
        if native is not None and native is not self._native_window:self._native_window=native; force=True
        if self._native_window is None:return
        items=self._items(); signature=tuple((a,b,c,d) for a,b,c,d,_ in items)
        if not force and signature==self._signature:return
        self._signature=signature; self._rebuild(items)
    def _rebuild(self,items):
        try:
            self._delegate.actions={i:(t,s,c,cb) for i,t,s,c,cb in items}
            bar=self._NSTouchBar.alloc().init(); ids=[i for i,*_ in items]
            bar.setDelegate_(self._delegate); bar.setDefaultItemIdentifiers_(ids); bar.setCustomizationIdentifier_('com.nexora.virel.touchbar'); bar.setCustomizationAllowedItemIdentifiers_(ids)
            self._bar=bar; self._native_window.setTouchBar_(bar)
            try:self._native_window.makeTouchBar()
            except Exception:pass
        except Exception as exc: print(f'Nexora Touch Bar refresh failed: {exc}')
