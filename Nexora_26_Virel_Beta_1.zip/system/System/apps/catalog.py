"""Visible, launchable application catalog for Nexora 26."""
from __future__ import annotations
from pathlib import Path
from System.settings.store import load_settings

CORE_FILES = (
    "Files.py", "Settings.py", "Browser.py", "Terminal.py", "Notepad.py",
    "Calculator.py", "Calendar.py", "Gallery.py", "Maps.py", "Screenshot.py", "Weather.py",
    "Task_Manager.py", "AboutPC.py", "Continuum.py", "Widgets.py", "Welcome.py",
)

OPTIONAL_DAILY_FILES = (
    "Documents.py", "Sheets.py", "Presentations.py", "Mail.py", "Clock.py",
    "Paint.py", "PDF_Viewer.py", "Recorder.py",
)

def visible_app_paths(apps_dir: Path, *_unused) -> list[Path]:
    disabled = {str(x) for x in load_settings().get("disabled_apps", [])}
    names = list(CORE_FILES) + [name for name in OPTIONAL_DAILY_FILES if Path(name).stem not in disabled]
    return [(apps_dir / filename).resolve() for filename in names if (apps_dir / filename).is_file()]
