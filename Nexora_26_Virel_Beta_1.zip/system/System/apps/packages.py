"""Validated local package installation for Nexora Store.

Package format: a ZIP (usually ``.nexora.zip``) containing ``manifest.json`` at
its root. Installation never executes code. Launching a Python entrypoint is an
explicit user action from Store and uses ``sys.executable`` with an argument
list, never shell command concatenation.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any


class PackageError(ValueError):
    pass


@dataclass(frozen=True)
class PackageManifest:
    app_id: str
    name: str
    version: str
    description: str
    category: str
    entrypoint: str | None = None
    icon: str | None = None
    schema_version: int = 1

    @classmethod
    def from_mapping(cls, value: dict[str, Any]) -> "PackageManifest":
        if not isinstance(value, dict):
            raise PackageError("manifest.json must contain an object")
        required = ("id", "name", "version", "description", "category")
        missing = [key for key in required if not isinstance(value.get(key), str) or not value[key].strip()]
        if missing:
            raise PackageError("Missing or invalid fields: " + ", ".join(missing))
        app_id = value["id"].strip().lower()
        if not re.fullmatch(r"[a-z0-9][a-z0-9._-]{1,63}", app_id):
            raise PackageError("Package id must use 2-64 lowercase letters, digits, dots, dashes or underscores")
        version = value["version"].strip()
        if not re.fullmatch(r"\d+(?:\.\d+){0,3}(?:[-+][A-Za-z0-9.-]+)?", version):
            raise PackageError("Unsupported version format")
        schema = value.get("schema_version", 1)
        if schema != 1:
            raise PackageError(f"Unsupported package schema: {schema}")
        entrypoint = value.get("entrypoint")
        icon = value.get("icon")
        for label, candidate in (("entrypoint", entrypoint), ("icon", icon)):
            if candidate is not None:
                if not isinstance(candidate, str) or not candidate.strip():
                    raise PackageError(f"Invalid {label}")
                _validate_member_name(candidate)
        return cls(
            app_id=app_id,
            name=value["name"].strip()[:80],
            version=version,
            description=value["description"].strip()[:600],
            category=value["category"].strip()[:40],
            entrypoint=entrypoint,
            icon=icon,
            schema_version=1,
        )

    def to_mapping(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "id": self.app_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "category": self.category,
            "entrypoint": self.entrypoint,
            "icon": self.icon,
        }


def _validate_member_name(name: str) -> PurePosixPath:
    normalized = name.replace("\\", "/")
    path = PurePosixPath(normalized)
    if path.is_absolute() or ".." in path.parts or not path.parts:
        raise PackageError(f"Unsafe package path: {name}")
    if any(part in {"", "."} for part in path.parts):
        raise PackageError(f"Invalid package path: {name}")
    return path


def _version_key(version: str) -> tuple:
    main = version.split("-", 1)[0].split("+", 1)[0]
    return tuple(int(part) for part in main.split("."))


class PackageManager:
    MAX_FILES = 1200
    MAX_FILE_SIZE = 128 * 1024 * 1024
    MAX_TOTAL_SIZE = 512 * 1024 * 1024

    def __init__(self, root: Path):
        self.root = Path(root)
        self.installed_dir = self.root / "installed_packages"
        self.trash_dir = self.root / "package_trash"
        self.installed_dir.mkdir(parents=True, exist_ok=True)
        self.trash_dir.mkdir(parents=True, exist_ok=True)

    def inspect(self, archive: Path) -> PackageManifest:
        archive = Path(archive)
        if not archive.is_file() or not zipfile.is_zipfile(archive):
            raise PackageError("Select a valid ZIP package")
        with zipfile.ZipFile(archive) as bundle:
            infos = bundle.infolist()
            self._validate_infos(infos)
            try:
                raw = bundle.read("manifest.json")
            except KeyError as exc:
                raise PackageError("Package has no root manifest.json") from exc
            if len(raw) > 256 * 1024:
                raise PackageError("Manifest is too large")
            try:
                mapping = json.loads(raw.decode("utf-8"))
            except (UnicodeError, json.JSONDecodeError) as exc:
                raise PackageError("Manifest is not valid UTF-8 JSON") from exc
            manifest = PackageManifest.from_mapping(mapping)
            names = {info.filename for info in infos if not info.is_dir()}
            for label, candidate in (("entrypoint", manifest.entrypoint), ("icon", manifest.icon)):
                if candidate and candidate not in names:
                    raise PackageError(f"Manifest {label} does not exist in package")
            return manifest

    def install(self, archive: Path) -> PackageManifest:
        archive = Path(archive)
        manifest = self.inspect(archive)
        destination = self.installed_dir / manifest.app_id
        with tempfile.TemporaryDirectory(prefix="nexora-package-", dir=str(self.root)) as temp_name:
            staging = Path(temp_name) / manifest.app_id
            staging.mkdir(parents=True)
            with zipfile.ZipFile(archive) as bundle:
                self._safe_extract(bundle, staging)
            # Re-parse the extracted manifest before the atomic replacement.
            extracted = PackageManifest.from_mapping(json.loads((staging / "manifest.json").read_text(encoding="utf-8")))
            if extracted != manifest:
                raise PackageError("Package changed while installing")
            backup = destination.with_name(destination.name + ".previous")
            if backup.exists():
                shutil.rmtree(backup)
            if destination.exists():
                os.replace(destination, backup)
            os.replace(staging, destination)
            if backup.exists():
                shutil.rmtree(backup, ignore_errors=True)
        return manifest

    def uninstall(self, app_id: str) -> Path:
        app_id = app_id.strip().lower()
        if not re.fullmatch(r"[a-z0-9][a-z0-9._-]{1,63}", app_id):
            raise PackageError("Invalid package id")
        target = self.installed_dir / app_id
        if not target.is_dir():
            raise PackageError("Package is not installed")
        destination = self.trash_dir / app_id
        suffix = 2
        while destination.exists():
            destination = self.trash_dir / f"{app_id}-{suffix}"
            suffix += 1
        os.replace(target, destination)
        return destination

    def installed(self) -> list[PackageManifest]:
        result: list[PackageManifest] = []
        for manifest_path in sorted(self.installed_dir.glob("*/manifest.json")):
            try:
                result.append(PackageManifest.from_mapping(json.loads(manifest_path.read_text(encoding="utf-8"))))
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                continue
        return result

    def package_dir(self, app_id: str) -> Path:
        target = (self.installed_dir / app_id).resolve()
        try:
            target.relative_to(self.installed_dir.resolve())
        except ValueError as exc:
            raise PackageError("Invalid package location") from exc
        return target

    def entrypoint(self, manifest: PackageManifest) -> Path | None:
        if not manifest.entrypoint:
            return None
        path = (self.package_dir(manifest.app_id) / manifest.entrypoint).resolve()
        try:
            path.relative_to(self.package_dir(manifest.app_id))
        except ValueError as exc:
            raise PackageError("Entrypoint escaped package directory") from exc
        return path if path.is_file() else None

    def updates_from(self, folder: Path) -> list[tuple[PackageManifest, Path]]:
        current = {item.app_id: item for item in self.installed()}
        updates = []
        for archive in Path(folder).glob("*.zip"):
            try:
                candidate = self.inspect(archive)
            except PackageError:
                continue
            existing = current.get(candidate.app_id)
            if existing and _version_key(candidate.version) > _version_key(existing.version):
                updates.append((candidate, archive))
        return sorted(updates, key=lambda pair: pair[0].name.casefold())

    def _validate_infos(self, infos: list[zipfile.ZipInfo]) -> None:
        if len(infos) > self.MAX_FILES:
            raise PackageError("Package contains too many files")
        total = 0
        for info in infos:
            _validate_member_name(info.filename.rstrip("/"))
            if info.file_size > self.MAX_FILE_SIZE:
                raise PackageError(f"Package member is too large: {info.filename}")
            total += info.file_size
            if total > self.MAX_TOTAL_SIZE:
                raise PackageError("Package expands beyond the allowed size")
            # Reject UNIX symlinks; they can escape after extraction.
            mode = (info.external_attr >> 16) & 0o170000
            if mode == 0o120000:
                raise PackageError(f"Symbolic links are not allowed: {info.filename}")

    def _safe_extract(self, bundle: zipfile.ZipFile, destination: Path) -> None:
        for info in bundle.infolist():
            member = _validate_member_name(info.filename.rstrip("/"))
            target = destination.joinpath(*member.parts)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with bundle.open(info) as source, target.open("wb") as output:
                shutil.copyfileobj(source, output, length=128 * 1024)
