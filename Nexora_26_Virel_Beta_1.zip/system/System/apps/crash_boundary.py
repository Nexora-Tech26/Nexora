"""Per-application error containment."""
from __future__ import annotations

import traceback
from dataclasses import dataclass
from typing import Callable


@dataclass(frozen=True)
class AppCrash:
    app_name: str
    error_type: str
    message: str
    traceback_text: str


class AppCrashBoundary:
    """Run one application builder without allowing it to terminate the shell."""

    def __init__(self, app_name: str, logger=None, crash_center=None, session_id: str = ""):
        self.app_name = app_name
        self.logger = logger
        self.crash_center = crash_center
        self.session_id = session_id
        self.failed = False
        self.last_crash: AppCrash | None = None

    def run(self, callback: Callable, on_error: Callable[[AppCrash], None]):
        self.failed = False
        self.last_crash = None
        try:
            return callback()
        except Exception as exc:
            crash = AppCrash(self.app_name, type(exc).__name__, str(exc), traceback.format_exc())
            self.failed = True
            self.last_crash = crash
            if self.logger is not None:
                self.logger.error("App %s crashed\n%s", self.app_name, crash.traceback_text)
            if self.crash_center is not None:
                try:
                    self.crash_center.record(self.app_name, crash.error_type, crash.message, session_id=self.session_id)
                except (OSError, TypeError, ValueError):
                    if self.logger is not None:
                        self.logger.debug("Could not persist crash record", exc_info=True)
            on_error(crash)
            return None
