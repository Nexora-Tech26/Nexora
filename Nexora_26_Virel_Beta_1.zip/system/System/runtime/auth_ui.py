"""Minimal authentication and first-run setup for Nexora 26 Beta 1."""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import psutil
from PySide6.QtCore import (
    QEasingCurve,
    QObject,
    QPoint,
    QParallelAnimationGroup,
    QPropertyAnimation,
    QRunnable,
    QSequentialAnimationGroup,
    QSize,
    Qt,
    QThreadPool,
    QTimer,
    Signal,
)
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFrame,
    QGraphicsBlurEffect,
    QGraphicsDropShadowEffect,
    QGraphicsOpacityEffect,
    QGraphicsScene,
    QGraphicsPixmapItem,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QScrollArea,
    QSlider,
    QStackedWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from System.gui.components import (
    GlassFrame,
    NexoraButton,
    NexoraGlassSurface,
    NexoraIconButton,
    NexoraSlider,
    NexoraTextField,
    NexoraToggle,
)
from System.gui.shared import (
    ACCENT,
    BORDER,
    DATA_DIR,
    MUTED,
    SYSTEM_ROOT,
    TEXT,
    WALLPAPER,
    current_wallpaper_path,
    font,
    load_settings,
    install_interaction_animations,
    save_settings,
)
from System.foundation.i18n import LANGUAGES, localize_widget_tree, set_language, tr

AUTH_TEXT = "#FFFFFF"
AUTH_MUTED = "rgba(255,255,255,205)"
SETUP_TEXT = "#17191F"
SETUP_MUTED = "#596170"

LICENSE_TEXT = """NEXORA LOCAL SOFTWARE LICENSE — VERSION 26 BETA 1

1. Scope. Nexora is a local desktop environment that runs on top of the host
operating system. It does not replace firmware, disk encryption, user accounts
or security controls provided by macOS, Windows or Linux.

2. Local data. User profiles, settings, session layouts, notification history,
widget positions and optional usage history are stored locally in the Nexora
System/data directory. Passwords are never stored in plain text. Password-based
accounts use a salted PBKDF2-SHA256 digest.

3. Host integrations. Features such as volume, brightness, sleep, restart,
shutdown, web browsing and file operations may call supported host APIs or
commands. Unsupported integrations remain disabled and must not pretend to have
changed the host system.

4. Optional diagnostics. Diagnostic data, application usage history, search
history, sound effects and session restoration are independent options. They are
not required to accept this license and may be changed later in Settings.

5. Files and packages. Nexora may read and modify files selected by the user.
Optional application packages are validated before installation. Keep backups
of important files and review destructive actions before confirming them.

6. No warranty. The software is provided for testing and personal use without a
warranty that every host integration is available on every device. Individual
Nexora applications are isolated where possible so one application failure does
not terminate the whole desktop.

7. Acceptance. Selecting “I accept the local software license” confirms that
you understand the local-data model and the relationship between Nexora and the
host operating system.
"""


class GradientLabel(QLabel):
    """Text label painted with a real horizontal gradient."""

    def __init__(self, text: str = "", parent: QWidget | None = None):
        super().__init__(text, parent)
        self.setAttribute(Qt.WA_TranslucentBackground, True)

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        gradient = QLinearGradient(0, 0, max(1, self.width()), 0)
        gradient.setColorAt(0.0, QColor("#FFFFFF"))
        gradient.setColorAt(0.48, QColor("#DCEBFF"))
        gradient.setColorAt(1.0, QColor("#8DB8FF"))
        painter.setPen(QPen(gradient, 1))
        painter.setFont(self.font())
        painter.drawText(self.rect(), self.alignment(), self.text())


class WallpaperScreen(QWidget):
    """Sharp wallpaper layer with cached cover scaling and no per-frame blur."""

    def __init__(self, title: str):
        super().__init__()
        self.setWindowTitle(title)
        self.setWindowFlag(Qt.FramelessWindowHint)
        self.setMinimumSize(900, 600)
        self._wallpaper_path = current_wallpaper_path()
        self._wallpaper = QPixmap(str(self._wallpaper_path))
        if self._wallpaper.isNull():
            self._wallpaper = QPixmap(str(WALLPAPER))
        self._scaled_wallpaper = QPixmap()
        self._scaled_size = QSize()
        self.wallpaper_layer = QLabel(self)
        self.wallpaper_layer.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.blur_layer = QLabel(self)
        self.blur_layer.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.blur_layer.setStyleSheet("background:transparent;")
        self._blur_radius = 60
        self._blurred_wallpaper = QPixmap()
        self.tint_layer = QFrame(self)
        self.tint_layer.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.tint_layer.setStyleSheet(
            "background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
            "stop:0 rgba(10,16,27,86),stop:.55 rgba(12,18,29,102),stop:1 rgba(4,8,14,142));border:none;"
        )
        self.ui = QWidget(self)
        self.ui.setStyleSheet("background:transparent;")
        self._animations: list[QObject] = []

    def resizeEvent(self, event):
        rect = self.rect()
        self.wallpaper_layer.setGeometry(rect)
        self.blur_layer.setGeometry(rect.adjusted(-24, -24, 24, 24))
        self.tint_layer.setGeometry(rect)
        self.ui.setGeometry(rect)
        if rect.size() != self._scaled_size and not self._wallpaper.isNull():
            self._scaled_wallpaper = self._wallpaper.scaled(
                rect.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation
            )
            self._scaled_size = QSize(rect.size())
            self.wallpaper_layer.setPixmap(self._scaled_wallpaper)
            source = self._scaled_wallpaper.scaled(
                self.blur_layer.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation
            )
            self._blurred_wallpaper = self._make_blurred_pixmap(source, self._blur_radius)
            self.blur_layer.setPixmap(self._blurred_wallpaper)
        self.wallpaper_layer.lower()
        self.blur_layer.raise_()
        self.tint_layer.raise_()
        self.ui.raise_()
        super().resizeEvent(event)


    @staticmethod
    def _make_blurred_pixmap(source: QPixmap, radius: int) -> QPixmap:
        if source.isNull() or radius <= 0:
            return source
        scene = QGraphicsScene()
        item = QGraphicsPixmapItem(source)
        effect = QGraphicsBlurEffect()
        effect.setBlurRadius(float(radius))
        effect.setBlurHints(QGraphicsBlurEffect.QualityHint)
        item.setGraphicsEffect(effect)
        scene.addItem(item)
        result = QPixmap(source.size())
        result.fill(Qt.transparent)
        painter = QPainter(result)
        scene.render(painter, target=source.rect(), source=source.rect())
        painter.end()
        return result

    def shutdown(self) -> None:
        for animation in tuple(self._animations):
            try:
                animation.stop()
            except RuntimeError:
                pass
        self._animations.clear()
        for timer in self.findChildren(QTimer):
            timer.stop()

    def _keep_animation(self, animation: QObject) -> None:
        self._animations.append(animation)

        def release() -> None:
            if animation in self._animations:
                self._animations.remove(animation)

        if hasattr(animation, "finished"):
            animation.finished.connect(release)


class _TaskSignals(QObject):
    finished = Signal(object)


class LoginTask(QRunnable):
    def __init__(self, password: str, user_id: str):
        super().__init__()
        self.password = password
        self.user_id = user_id
        self.signals = _TaskSignals()

    def run(self) -> None:
        from user_handle import verify_password

        self.signals.finished.emit(bool(verify_password(self.password, self.user_id)))


class HardwareTask(QRunnable):
    def __init__(self):
        super().__init__()
        self.signals = _TaskSignals()

    def run(self) -> None:
        battery = None
        try:
            info = psutil.sensors_battery()
            if info is not None:
                battery = f"{round(info.percent)}%"
        except (AttributeError, OSError):
            battery = None
        disk_root = Path.home().anchor or "/"
        try:
            disk = psutil.disk_usage(disk_root)
            disk_text = f"{disk.total / (1024 ** 3):.0f} GB"
        except OSError:
            disk_text = "Unavailable"
        gpu = "Integrated / host managed"
        if platform.system() == "Darwin":
            gpu = "Apple/Intel graphics (host)"
        elif platform.system() == "Windows":
            gpu = "Windows display adapter"
        elif platform.system() == "Linux":
            gpu = "Linux display adapter"
        result = {
            "CPU": platform.processor() or platform.machine() or "Unknown",
            "RAM": f"{psutil.virtual_memory().total / (1024 ** 3):.1f} GB",
            "GPU": gpu,
            "Disk": disk_text,
            "Host": f"{platform.system()} {platform.release()}",
            "Architecture": platform.machine() or "Unknown",
            "Battery": battery or "Not available",
        }
        self.signals.finished.emit(result)


class UserPopup(NexoraGlassSurface):
    userSelected = Signal(str)

    def __init__(self, parent: QWidget, users: list[dict], selected_id: str | None):
        super().__init__(parent, radius=25, alpha=92, gradient=False)
        self.setFixedWidth(270)
        self.setAttribute(Qt.WA_StyledBackground, False)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(5)
        title = QLabel("Users")
        title.setFont(font(11, True))
        title.setStyleSheet("color:white;background:transparent;padding:5px 8px;")
        layout.addWidget(title)
        for user in users:
            button = QPushButton()
            button.setCheckable(True)
            button.setChecked(user.get("id") == selected_id)
            status = "Password" if user.get("password_hash") else "No password"
            button.setText(f"{str(user.get('username', 'User'))[:1].upper()}   {user.get('username', 'User')}\n     {status}")
            button.setMinimumHeight(56)
            button.setCursor(Qt.PointingHandCursor)
            button.setStyleSheet(
                "QPushButton{text-align:left;background:rgba(255,255,255,18);border:none;border-radius:24px;"
                "padding:7px 10px;color:white;}QPushButton:hover{background:rgba(255,255,255,42);}"
                "QPushButton:checked{background:rgba(63,140,255,105);}"
            )
            button.clicked.connect(lambda _checked=False, uid=str(user.get("id")): self.userSelected.emit(uid))
            layout.addWidget(button)
        self.adjustSize()
        self.hide()

    def show_animated(self) -> None:
        self.show()
        self.raise_()
        effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(effect)
        animation = QPropertyAnimation(effect, b"opacity", self)
        animation.setDuration(170)
        animation.setStartValue(0.0)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.OutCubic)
        animation.finished.connect(lambda: self.setGraphicsEffect(None))
        animation.start(QPropertyAnimation.DeleteWhenStopped)


class LoginScreen(WallpaperScreen):
    authenticated = Signal()

    def __init__(self):
        super().__init__("Nexora 26 Beta 1 Login")
        from user_handle import get_last_user_id, list_users

        self.users = list_users()
        self.selected_user_id = get_last_user_id() or (self.users[0]["id"] if self.users else None)
        self._pool = QThreadPool.globalInstance()
        self._login_task: LoginTask | None = None
        self._build()
        # performance build: no global interaction overlays
        if self.selected_user_id:
            self.select_user(self.selected_user_id, animate=False)

    def _build(self) -> None:
        # No large card: the cluster is a transparent child placed 84 px above the bottom.
        self.login_cluster = QWidget(self.ui)
        self.login_cluster.setFixedWidth(360)
        self.login_cluster.setStyleSheet("background:transparent;")
        layout = QVBoxLayout(self.login_cluster)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        self.avatar = QLabel("U")
        self.avatar.setAlignment(Qt.AlignCenter)
        self.avatar.setFixedSize(66, 66)
        self.avatar.setFont(font(23, True))
        self.avatar.setStyleSheet(
            "background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #2B7FFF,stop:1 #8B5CF6);color:white;border:none;border-radius:33px;"
        )
        layout.addWidget(self.avatar, 0, Qt.AlignHCenter)

        self.username = QLabel("User")
        self.username.setAlignment(Qt.AlignCenter)
        self.username.setFont(font(13, True))
        self.username.setStyleSheet("color:white;background:transparent;")
        layout.addWidget(self.username)

        credentials = QHBoxLayout()
        credentials.setContentsMargins(24, 0, 24, 0)
        credentials.setSpacing(8)
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setPlaceholderText("Password")
        self.password.setFixedHeight(34)
        self.password.setStyleSheet(
            "QLineEdit{background:rgba(242,247,251,205);border:none;"
            "border-radius:17px;padding:4px 12px;color:#17191F;}"
            "QLineEdit:focus{background:rgba(250,252,254,155);border:none;}"
        )
        self.password.returnPressed.connect(self.login)
        credentials.addWidget(self.password, 1)
        self.login_button = QPushButton("➜")
        self.login_button.setFixedSize(46, 34)
        self.login_button.setCursor(Qt.PointingHandCursor)
        self.login_button.setStyleSheet(
            "QPushButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #2B7FFF,stop:1 #8B5CF6);border:none;"
            "border-radius:17px;color:white;font-weight:bold;font-size:15px;}"
            "QPushButton:hover{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #91CAFF,stop:1 #A77DE9);}"
        )
        self.login_button.clicked.connect(self.login)
        credentials.addWidget(self.login_button)
        layout.addLayout(credentials)

        self.error = QLabel()
        self.error.setAlignment(Qt.AlignCenter)
        self.error.setFixedHeight(18)
        self.error.setStyleSheet("color:#FFD0D0;background:transparent;font-size:11px;")
        layout.addWidget(self.error)

        self.left_actions = QWidget(self.ui)
        left = QHBoxLayout(self.left_actions)
        left.setContentsMargins(0, 0, 0, 0)
        left.setSpacing(0)
        login_actions = (
            ("◐", "Accessibility", self._toggle_accessibility, "#3B82F6", "#22C1C3"),
            ("☾", "Sleep", lambda: self._power_action("sleep"), "#6366F1", "#8B5CF6"),
            ("↻", "Restart", lambda: self._power_action("restart"), "#F59E0B", "#F97316"),
            ("⏻", "Shut down", lambda: self._power_action("shutdown"), "#EF4444", "#BE123C"),
        )
        for action_index, (symbol, tooltip, callback, start_color, end_color) in enumerate(login_actions):
            button = QPushButton(symbol)
            button.setToolTip(tooltip)
            button.setFixedSize(42, 38)
            button.setCursor(Qt.PointingHandCursor)
            left_radius = 12 if action_index == 0 else 0
            right_radius = 12 if action_index == len(login_actions) - 1 else 0
            button.setStyleSheet(
                f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {start_color},stop:1 {end_color});border:none;"
                f"border-top-left-radius:{left_radius}px;border-bottom-left-radius:{left_radius}px;"
                f"border-top-right-radius:{right_radius}px;border-bottom-right-radius:{right_radius}px;"
                "color:white;font-size:14px;outline:none;padding:0;margin:0;}"
                f"QPushButton:hover{{background:{end_color};border:none;outline:none;padding:0;}}"
                f"QPushButton:pressed{{background:{start_color};border:none;outline:none;padding:0;}}"
            )
            button.clicked.connect(callback)
            left.addWidget(button)

        self.other_user = QPushButton("Users  ⌃", self.ui)
        self.other_user.setCursor(Qt.PointingHandCursor)
        self.other_user.setMinimumSize(126, 40)
        self.other_user.setStyleSheet(
            "QPushButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 rgba(16,185,129,220),stop:1 rgba(43,127,255,220));border:none;"
            "border-radius:20px;padding:7px 16px;color:white;font-weight:700;}QPushButton:hover{background:rgba(255,255,255,55);}"
        )
        self.other_user.clicked.connect(self._toggle_user_popup)
        self.user_popup = UserPopup(self.ui, self.users, self.selected_user_id)
        self.user_popup.userSelected.connect(self._choose_user)

        self.clock = QLabel(self.ui)
        self.clock.setAlignment(Qt.AlignCenter)
        self.clock.setFont(font(38, True))
        self.clock.setStyleSheet("color:rgba(255,255,255,230);background:transparent;")
        self.date = QLabel(self.ui)
        self.date.setAlignment(Qt.AlignCenter)
        self.date.setFont(font(10, True))
        self.date.setStyleSheet("color:rgba(255,255,255,188);background:transparent;")
        self.clock_timer = QTimer(self)
        self.clock_timer.setInterval(1000)
        self.clock_timer.timeout.connect(self._update_clock)
        self.clock_timer.start()
        self._update_clock()

    def showEvent(self, event) -> None:
        super().showEvent(event)
        QTimer.singleShot(0, self._animate_entrance)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        width, height = self.width(), self.height()
        self.login_cluster.adjustSize()
        cluster_h = self.login_cluster.height()
        self.login_cluster.move((width - self.login_cluster.width()) // 2, max(70, height - cluster_h - 84))
        self.left_actions.adjustSize()
        self.left_actions.move(22, height - self.left_actions.height() - 22)
        self.other_user.adjustSize()
        self.other_user.move(width - self.other_user.width() - 22, height - self.other_user.height() - 22)
        self.user_popup.adjustSize()
        self.user_popup.move(
            width - self.user_popup.width() - 22,
            max(20, self.other_user.y() - self.user_popup.height() - 10),
        )
        self.clock.setGeometry(0, 28, width, 58)
        self.date.setGeometry(0, 82, width, 24)

    def _animate_entrance(self) -> None:
        if getattr(self, "_entrance_started", False):
            return
        self._entrance_started = True
        end = self.login_cluster.pos()
        self.login_cluster.move(end + QPoint(0, 24))
        effect = QGraphicsOpacityEffect(self.login_cluster)
        self.login_cluster.setGraphicsEffect(effect)
        fade = QPropertyAnimation(effect, b"opacity", self.login_cluster)
        fade.setDuration(520)
        fade.setStartValue(0.0)
        fade.setEndValue(1.0)
        move = QPropertyAnimation(self.login_cluster, b"pos", self.login_cluster)
        move.setDuration(520)
        move.setStartValue(end + QPoint(0, 24))
        move.setEndValue(end)
        for animation in (fade, move):
            animation.setEasingCurve(QEasingCurve.OutCubic)
        group = QParallelAnimationGroup(self.login_cluster)
        group.addAnimation(fade)
        group.addAnimation(move)
        group.finished.connect(lambda: self.login_cluster.setGraphicsEffect(None))
        self._keep_animation(group)
        group.start()

    def _update_clock(self) -> None:
        now = datetime.now()
        self.clock.setText(now.strftime("%H:%M"))
        self.date.setText(now.strftime("%A, %d %B %Y"))

    def _toggle_user_popup(self) -> None:
        if len(self.users) <= 1:
            return
        if self.user_popup.isVisible():
            self.user_popup.hide()
        else:
            self.user_popup.show_animated()

    def _choose_user(self, user_id: str) -> None:
        self.user_popup.hide()
        self.select_user(user_id, animate=True)

    def select_user(self, user_id: str, *, animate: bool = True) -> None:
        from user_handle import user_requires_password

        user = next((entry for entry in self.users if entry.get("id") == user_id), None)
        if user is None:
            return
        self.selected_user_id = user_id
        requires_password = user_requires_password(user_id)

        def apply_user() -> None:
            self.username.setText(str(user.get("username", "User")))
            self.avatar.setText(str(user.get("username", "U"))[:1].upper())
            color = str(user.get("avatar_color", "#3F8CFF"))
            self.avatar.setStyleSheet(
                f"background:{color};color:white;border:none;border-radius:33px;"
            )
            self.password.setVisible(requires_password)
            self.password.clear()
            self.error.clear()
            self.login_button.setEnabled(True)
            self.password.setEnabled(True)
            self.login_button.setText("➜")
            if requires_password:
                QTimer.singleShot(0, self.password.setFocus)
            else:
                self.login_button.setFocus()

        if not animate:
            apply_user()
            return
        effect = QGraphicsOpacityEffect(self.login_cluster)
        self.login_cluster.setGraphicsEffect(effect)
        out = QPropertyAnimation(effect, b"opacity", self.login_cluster)
        out.setDuration(110)
        out.setStartValue(1.0)
        out.setEndValue(0.0)
        incoming = QPropertyAnimation(effect, b"opacity", self.login_cluster)
        incoming.setDuration(170)
        incoming.setStartValue(0.0)
        incoming.setEndValue(1.0)
        out.finished.connect(apply_user)
        sequence = QSequentialAnimationGroup(self.login_cluster)
        sequence.addAnimation(out)
        sequence.addAnimation(incoming)
        sequence.finished.connect(lambda: self.login_cluster.setGraphicsEffect(None))
        self._keep_animation(sequence)
        sequence.start()

    def login(self) -> None:
        if not self.selected_user_id or self._login_task is not None:
            return
        self.error.clear()
        self.login_button.setEnabled(False)
        self.password.setEnabled(False)
        self.login_button.setText("…")
        task = LoginTask(self.password.text(), self.selected_user_id)
        task.signals.finished.connect(self._login_finished)
        self._login_task = task
        self._pool.start(task)

    def _login_finished(self, result: object) -> None:
        self._login_task = None
        ok = bool(result)
        if ok:
            effect = QGraphicsOpacityEffect(self.ui)
            self.ui.setGraphicsEffect(effect)
            fade = QPropertyAnimation(effect, b"opacity", self.ui)
            fade.setDuration(210)
            fade.setStartValue(1.0)
            fade.setEndValue(0.0)
            fade.setEasingCurve(QEasingCurve.OutCubic)
            fade.finished.connect(self.authenticated.emit)
            self._keep_animation(fade)
            fade.start()
            return
        self.error.setText(tr("Incorrect password."))
        self.password.setEnabled(True)
        self.login_button.setEnabled(True)
        self.login_button.setText("➜")
        self.password.selectAll()
        self.password.setFocus()
        self._shake_credentials()

    def _shake_credentials(self) -> None:
        origin = self.login_cluster.pos()
        sequence = QSequentialAnimationGroup(self.login_cluster)
        for offset in (-7, 12, -10, 7, -2, 0):
            animation = QPropertyAnimation(self.login_cluster, b"pos", self.login_cluster)
            animation.setDuration(42)
            animation.setEndValue(origin + QPoint(offset, 0))
            sequence.addAnimation(animation)
        sequence.finished.connect(lambda: self.login_cluster.move(origin))
        self._keep_animation(sequence)
        sequence.start()

    def _toggle_accessibility(self) -> None:
        settings = load_settings()
        settings["high_contrast"] = not bool(settings.get("high_contrast", False))
        settings["large_text"] = bool(settings["high_contrast"])
        settings["reduce_motion"] = bool(settings["high_contrast"])
        save_settings(settings)
        self.error.setText("Accessibility mode on" if settings["high_contrast"] else "Accessibility mode off")

    @staticmethod
    def _power_action(action: str) -> None:
        system = platform.system()
        commands: dict[str, dict[str, list[str]]] = {
            "Darwin": {
                "sleep": ["pmset", "sleepnow"],
                "restart": ["osascript", "-e", 'tell application "System Events" to restart'],
                "shutdown": ["osascript", "-e", 'tell application "System Events" to shut down'],
            },
            "Windows": {
                "sleep": ["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"],
                "restart": ["shutdown", "/r", "/t", "0"],
                "shutdown": ["shutdown", "/s", "/t", "0"],
            },
            "Linux": {
                "sleep": ["systemctl", "suspend"],
                "restart": ["systemctl", "reboot"],
                "shutdown": ["systemctl", "poweroff"],
            },
        }
        command = commands.get(system, {}).get(action)
        if not command:
            return
        try:
            subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError:
            return

    def keyPressEvent(self, event) -> None:
        if event.key() in (Qt.Key_Return, Qt.Key_Enter) and not self.user_popup.isVisible():
            self.login()
            event.accept()
            return
        if event.key() == Qt.Key_Escape:
            if self.user_popup.isVisible():
                self.user_popup.hide()
            else:
                QApplication.quit()
            event.accept()
            return
        super().keyPressEvent(event)


@dataclass
class AccountDraft:
    username: str = ""
    password: str = ""
    passwordless: bool = False
    avatar_color: str = "#3F8CFF"
    avatar_path: str = ""


class SetupScreen(WallpaperScreen):
    completed = Signal()
    NAMES = (
        "Language",
        "Region",
        "License",
        "User",
        "Password",
        "Avatar",
        "Privacy",
        "Appearance",
        "Device",
        "Summary",
    )

    def __init__(self):
        super().__init__("Nexora 26 Beta 1 Setup")
        set_language("en")
        saved_style = str(load_settings().get("ui_style", "cloud_light"))
        self.account_theme = saved_style if saved_style in {"cloud_light", "cosmic_dark"} else "cloud_light"
        self.step = 0
        self.account = AccountDraft()
        self.hardware: dict[str, str] = {}
        self._pool = QThreadPool.globalInstance()
        self._hardware_task: HardwareTask | None = None
        self._build()
        # performance build: no global interaction overlays
        self._show_welcome()

    def _build(self) -> None:
        self.welcome_label = GradientLabel("Welcome", self.ui)
        self.welcome_label.setAlignment(Qt.AlignCenter)
        self.welcome_label.setFont(QFont(QApplication.font().family(), 48, QFont.Weight.DemiBold))
        self.welcome_label.setStyleSheet("background:transparent;")

        self.setup_host = QWidget(self.ui)
        self.setup_host.setObjectName("SetupHost")
        self.setup_host.setAttribute(Qt.WA_StyledBackground, True)
        self.setup_host.setStyleSheet(
            "QWidget#SetupHost{background:rgba(246,249,252,242);"
            "border:none;border-radius:20px;}"
        )
        host_layout = QHBoxLayout(self.setup_host)
        host_layout.setContentsMargins(0, 0, 0, 0)
        host_layout.setSpacing(0)

        self.progress_rail = QWidget()
        self.progress_rail.setObjectName("SetupRail")
        self.progress_rail.setAttribute(Qt.WA_StyledBackground, True)
        self.progress_rail.setStyleSheet(
            "QWidget#SetupRail{background:rgba(224,233,244,235);"
            "border:none;border-right:none;"
            "border-top-left-radius:20px;border-bottom-left-radius:20px;}"
        )
        self.progress_rail.setFixedWidth(218)
        rail = QVBoxLayout(self.progress_rail)
        rail.setContentsMargins(18, 24, 18, 22)
        rail.setSpacing(6)
        self.brand = QLabel("NEXORA\nVIREL 26")
        self.brand.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.brand.setFont(font(14, True))
        self.brand.setStyleSheet("color:#263142;background:transparent;letter-spacing:1px;")
        rail.addWidget(self.brand)
        rail.addSpacing(16)
        self.step_labels: list[QLabel] = []
        for index, name in enumerate(self.NAMES):
            label = QLabel(f"{index + 1:02d}   {name}")
            label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            label.setToolTip(name)
            label.setFixedHeight(34)
            self.step_labels.append(label)
            rail.addWidget(label)
        rail.addStretch()
        host_layout.addWidget(self.progress_rail)

        self.content_surface = QFrame()
        self.content_surface.setObjectName("SetupContent")
        self.content_surface.setStyleSheet(
            "QFrame#SetupContent{background:transparent;border:none;}"
            "QLabel{color:#202938;background:transparent;border:none;}"
            "QComboBox{background:#FFFFFF;border:none;"
            "border-radius:12px;padding:9px 12px;color:#202938;min-height:24px;}"
            "QComboBox:focus{border:none;}"
            "QListWidget{background:#FFFFFF;border:none;border-radius:24px;}"
        )
        self.content_surface.setMinimumWidth(500)
        content_layout = QVBoxLayout(self.content_surface)
        content_layout.setContentsMargins(38, 30, 38, 28)
        content_layout.setSpacing(13)
        self.eyebrow = QLabel("NEXORA 26 BETA 1")
        self.eyebrow.setStyleSheet(f"color:{ACCENT};background:transparent;font-weight:700;letter-spacing:1px;")
        content_layout.addWidget(self.eyebrow)
        self.title = QLabel()
        self.title.setFont(font(28, True))
        self.title.setStyleSheet(f"color:{SETUP_TEXT};background:transparent;")
        content_layout.addWidget(self.title)
        self.description = QLabel()
        self.description.setWordWrap(True)
        self.description.setStyleSheet(f"color:{SETUP_MUTED};background:transparent;")
        content_layout.addWidget(self.description)
        content_layout.addSpacing(6)
        self.stack = QStackedWidget()
        self.stack.setStyleSheet("background:transparent;border:none;")
        content_layout.addWidget(self.stack, 1)
        self.validation = QLabel()
        self.validation.setWordWrap(True)
        self.validation.setFixedHeight(22)
        self.validation.setStyleSheet("color:#B13B3B;background:transparent;")
        content_layout.addWidget(self.validation)
        nav = QHBoxLayout()
        nav.setSpacing(0)
        self.back = NexoraButton("←  Back")
        self.next = NexoraButton("Continue  →", primary=True)
        self.next.setMinimumWidth(170)
        self.next.setMinimumHeight(46)
        self.back.setMinimumWidth(128)
        self.back.setMinimumHeight(46)
        self.back.setStyleSheet(
            "QPushButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #F87171,stop:1 #EC4899);color:white;border:none;"
            "border-top-left-radius:12px;border-bottom-left-radius:12px;border-top-right-radius:0;border-bottom-right-radius:0;padding:8px 16px;font-weight:700;outline:none;}"
            "QPushButton:hover{background:#F05286;border:none;outline:none;}QPushButton:pressed{padding:8px 16px;}"
        )
        self.next.setStyleSheet(
            "QPushButton{background:#397DDF;color:white;border:none;"
            "border-top-left-radius:0;border-bottom-left-radius:0;border-top-right-radius:12px;border-bottom-right-radius:12px;padding:8px 18px;font-weight:700;}"
            "QPushButton:hover{background:#4B8DEA;border:none;}QPushButton:pressed{padding:8px 18px;}"
        )
        self.back.clicked.connect(self.previous)
        self.next.clicked.connect(self.advance)
        nav.addStretch()
        nav.addWidget(self.back)
        nav.addWidget(self.next)
        content_layout.addLayout(nav)
        host_layout.addWidget(self.content_surface, 1)

        self._create_pages()
        for toggle in self.findChildren(QCheckBox):
            toggle.setStyleSheet(
                "QCheckBox{spacing:10px;background:transparent;border:none;padding:5px 0;}"
                "QCheckBox::indicator{width:38px;height:22px;border:none;border-radius:11px;background:rgba(84,96,116,80);}"
                "QCheckBox::indicator:hover{background:rgba(84,96,116,112);}"
                "QCheckBox::indicator:checked{background:#4B8DFF;border:none;border-radius:11px;}"
            )
        self._apply_setup_theme(self.account_theme)
        self.setup_host.hide()
        self._sync(animate=False)

    @staticmethod
    def _apply_control_shadow(widget) -> None:
        return

    def _apply_setup_shadow(self) -> None:
        return

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self.welcome_label.setGeometry(self.rect())
        width = min(1040, max(760, self.width() - 112))
        height = min(680, max(540, self.height() - 112))
        self.setup_host.setGeometry((self.width() - width) // 2, (self.height() - height) // 2, width, height)

    def _show_welcome(self) -> None:
        self.welcome_label.show()
        self.setup_host.hide()
        effect = QGraphicsOpacityEffect(self.welcome_label)
        self.welcome_label.setGraphicsEffect(effect)
        fade_in = QPropertyAnimation(effect, b"opacity", self.welcome_label)
        fade_in.setDuration(620)
        fade_in.setStartValue(0.0)
        fade_in.setEndValue(1.0)
        hold = QPropertyAnimation(effect, b"opacity", self.welcome_label)
        hold.setDuration(1050)
        hold.setStartValue(1.0)
        hold.setEndValue(1.0)
        fade_out = QPropertyAnimation(effect, b"opacity", self.welcome_label)
        fade_out.setDuration(320)
        fade_out.setStartValue(1.0)
        fade_out.setEndValue(0.0)
        sequence = QSequentialAnimationGroup(self.welcome_label)
        sequence.addAnimation(fade_in)
        sequence.addAnimation(hold)
        sequence.addAnimation(fade_out)
        sequence.finished.connect(self._reveal_setup)
        self._keep_animation(sequence)
        sequence.start()

    def _reveal_setup(self) -> None:
        self.welcome_label.hide()
        self.welcome_label.setGraphicsEffect(None)
        self.setup_host.show()
        effect = QGraphicsOpacityEffect(self.setup_host)
        self.setup_host.setGraphicsEffect(effect)
        animation = QPropertyAnimation(effect, b"opacity", self.setup_host)
        animation.setDuration(460)
        animation.setStartValue(0.0)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.OutCubic)
        animation.finished.connect(self._finish_setup_reveal)
        self._keep_animation(animation)
        animation.start()

    def _finish_setup_reveal(self) -> None:
        self.setup_host.setGraphicsEffect(None)
        self._apply_setup_shadow()

    def _page(self) -> tuple[QWidget, QVBoxLayout]:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(11)
        return page, layout

    def _create_pages(self) -> None:
        # Language
        page, layout = self._page()
        self.language = QComboBox()
        for label, code in LANGUAGES:
            self.language.addItem(label, code)
        self.language.setCurrentIndex(max(0, self.language.findData("en")))
        self.language.currentIndexChanged.connect(self._language_changed)
        layout.addWidget(QLabel("Interface language"))
        layout.addWidget(self.language)
        layout.addStretch()
        self.stack.addWidget(page)

        # Region
        page, layout = self._page()
        self.region = QComboBox()
        for region in ("Poland", "United Kingdom", "United States", "Germany", "France", "Spain", "Italy", "Other"):
            self.region.addItem(region)
        self.region.setCurrentText("Poland")
        self.clock_24h = NexoraToggle("Use 24-hour clock")
        self.clock_24h.setChecked(True)
        layout.addWidget(QLabel("Region"))
        layout.addWidget(self.region)
        layout.addWidget(self.clock_24h)
        layout.addStretch()
        self.stack.addWidget(page)

        # License
        page, layout = self._page()
        self.license_view = QTextBrowser()
        self.license_view.setPlainText(LICENSE_TEXT)
        self.license_view.setStyleSheet(
            "QTextBrowser{background:rgba(255,255,255,30);border:none;border-radius:16px;padding:12px;color:#20242D;}"
        )
        self.accept_license = NexoraToggle("I accept the local software license")
        layout.addWidget(self.license_view, 1)
        layout.addWidget(self.accept_license)
        self.stack.addWidget(page)

        # User
        page, layout = self._page()
        self.user_name = NexoraTextField("User name")
        self.user_name.setMaxLength(40)
        layout.addWidget(QLabel("Local account name"))
        layout.addWidget(self.user_name)
        note = QLabel("Additional users can be added later without a fixed account limit in Settings.")
        note.setWordWrap(True)
        note.setStyleSheet(f"color:{SETUP_MUTED};background:transparent;")
        layout.addWidget(note)
        layout.addStretch()
        self.stack.addWidget(page)

        # Password
        page, layout = self._page()
        self.passwordless = NexoraToggle("Use this account without a password")
        self.user_password = NexoraTextField("Password — at least 10 characters")
        self.user_password.setEchoMode(QLineEdit.Password)
        self.confirm_password = NexoraTextField("Repeat password")
        self.confirm_password.setEchoMode(QLineEdit.Password)
        self.passwordless.toggled.connect(self._toggle_password_fields)
        layout.addWidget(self.passwordless)
        layout.addWidget(self.user_password)
        layout.addWidget(self.confirm_password)
        layout.addStretch()
        self.stack.addWidget(page)

        # Avatar
        page, layout = self._page()
        self.avatar_preview = QLabel("U")
        self.avatar_preview.setAlignment(Qt.AlignCenter)
        self.avatar_preview.setFixedSize(64, 64)
        self.avatar_preview.setFont(font(22, True))
        self.avatar_preview.setStyleSheet("background:#3F8CFF;color:white;border-radius:32px;")
        layout.addWidget(self.avatar_preview, 0, Qt.AlignHCenter)
        palette = QHBoxLayout()
        for color in ("#3F8CFF", "#B876E8", "#45C4B0", "#FFB84D", "#F06FA7", "#6D7CFF"):
            button = QPushButton()
            button.setFixedSize(40, 40)
            button.setCursor(Qt.PointingHandCursor)
            button.setStyleSheet(f"background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {color},stop:1 rgba(255,255,255,95));border:none;border-radius:24px;")
            button.clicked.connect(lambda _checked=False, value=color: self._set_avatar_color(value))
            palette.addWidget(button)
        layout.addLayout(palette)
        custom = NexoraButton("Choose image…")
        custom.clicked.connect(self._choose_avatar_image)
        layout.addWidget(custom, 0, Qt.AlignHCenter)
        layout.addStretch()
        self.stack.addWidget(page)

        # Privacy
        page, layout = self._page()
        self.diagnostics = NexoraToggle("Share local diagnostic reports")
        self.usage_history = NexoraToggle("Store application usage history")
        self.system_sounds = NexoraToggle("Play system sounds")
        self.session_restore = NexoraToggle("Restore the previous session")
        self.search_history = NexoraToggle("Save search history")
        self.session_restore.setChecked(True)
        self.search_history.setChecked(True)
        for control in (
            self.diagnostics,
            self.usage_history,
            self.system_sounds,
            self.session_restore,
            self.search_history,
        ):
            layout.addWidget(control)
        layout.addStretch()
        self.stack.addWidget(page)

        # Appearance
        page, layout = self._page()
        theme_row = QHBoxLayout()
        self.light_mode = NexoraButton("Cloud Light", primary=True)
        self.dark_mode = NexoraButton("Space Dark")
        self.light_mode.clicked.connect(lambda: self._select_theme("cloud_light"))
        self.dark_mode.clicked.connect(lambda: self._select_theme("cosmic_dark"))
        theme_row.addWidget(self.light_mode)
        theme_row.addWidget(self.dark_mode)
        layout.addLayout(theme_row)
        self.transparency = NexoraSlider()
        self.transparency.setRange(0, 100)
        self.transparency.setValue(52)
        self.blur = NexoraSlider()
        self.blur.setRange(0, 80)
        self.blur.setValue(0)
        layout.addWidget(QLabel("Visual transparency"))
        layout.addWidget(self.transparency)
        layout.addWidget(QLabel("Blur"))
        layout.addWidget(self.blur)
        layout.addStretch()
        self.stack.addWidget(page)

        # Hardware
        page, layout = self._page()
        self.hardware_label = QLabel("Detecting hardware…")
        self.hardware_label.setWordWrap(True)
        self.hardware_label.setStyleSheet(
            "background:rgba(255,255,255,30);border:none;border-radius:16px;padding:16px;color:#20242D;"
        )
        layout.addWidget(self.hardware_label)
        layout.addStretch()
        self.stack.addWidget(page)

        # Summary
        page, layout = self._page()
        self.summary = QLabel()
        self.summary.setWordWrap(True)
        self.summary.setStyleSheet(
            "background:rgba(255,255,255,30);border:none;border-radius:16px;padding:16px;color:#20242D;"
        )
        layout.addWidget(self.summary)
        layout.addStretch()
        self.stack.addWidget(page)

    def _language_changed(self) -> None:
        language = self.language.currentData() or "en"
        set_language(language)
        localize_widget_tree(self, language)
        self._sync(animate=False)

    def _toggle_password_fields(self, enabled: bool) -> None:
        self.user_password.clear()
        self.confirm_password.clear()
        self.user_password.setVisible(not enabled)
        self.confirm_password.setVisible(not enabled)

    def _set_avatar_color(self, color: str) -> None:
        self.account.avatar_color = color
        self.account.avatar_path = ""
        self.avatar_preview.setPixmap(QPixmap())
        self.avatar_preview.setText((self.user_name.text().strip() or "U")[:1].upper())
        self.avatar_preview.setStyleSheet(f"background:{color};color:white;border-radius:32px;")

    def _choose_avatar_image(self) -> None:
        path, _filter = QFileDialog.getOpenFileName(self, "Choose avatar", str(Path.home()), "Images (*.png *.jpg *.jpeg *.webp)")
        if not path:
            return
        pixmap = QPixmap(path)
        if pixmap.isNull():
            self.validation.setText("The selected image could not be loaded.")
            return
        self.account.avatar_path = path
        self.avatar_preview.setText("")
        self.avatar_preview.setPixmap(pixmap.scaled(64, 64, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation))

    def _select_theme(self, mode: str) -> None:
        if mode == self.account_theme:
            return
        self.account_theme = mode
        self.transparency.setValue(52 if mode == "cloud_light" else 48)
        self.blur.setValue(0)
        self.light_mode.setProperty("nexoraPrimary", mode == "cloud_light")
        self.dark_mode.setProperty("nexoraPrimary", mode == "cosmic_dark")
        self.light_mode.style().unpolish(self.light_mode)
        self.light_mode.style().polish(self.light_mode)
        self.dark_mode.style().unpolish(self.dark_mode)
        self.dark_mode.style().polish(self.dark_mode)
        self._animate_setup_theme(mode)

    def _animate_setup_theme(self, mode: str) -> None:
        """Cross-fade OOBE chrome while swapping its complete color system."""
        self.setup_host.setGraphicsEffect(None)
        effect = QGraphicsOpacityEffect(self.setup_host)
        effect.setOpacity(1.0)
        self.setup_host.setGraphicsEffect(effect)
        sequence = QSequentialAnimationGroup(self.setup_host)
        fade_out = QPropertyAnimation(effect, b"opacity", sequence)
        fade_out.setDuration(135)
        fade_out.setStartValue(1.0)
        fade_out.setEndValue(0.58)
        fade_out.setEasingCurve(QEasingCurve.OutCubic)
        fade_in = QPropertyAnimation(effect, b"opacity", sequence)
        fade_in.setDuration(230)
        fade_in.setStartValue(0.58)
        fade_in.setEndValue(1.0)
        fade_in.setEasingCurve(QEasingCurve.OutCubic)
        fade_out.finished.connect(lambda: self._apply_setup_theme(mode))
        sequence.addAnimation(fade_out)
        sequence.addAnimation(fade_in)
        def finish():
            self.setup_host.setGraphicsEffect(None)
            self._apply_setup_shadow()
        sequence.finished.connect(finish)
        self._keep_animation(sequence)
        sequence.start()

    def _apply_setup_theme(self, mode: str) -> None:
        dark = mode == "cosmic_dark"
        accent = "#9B7CFF" if dark else "#4B8DFF"
        text = "#F6F8FF" if dark else "#17243A"
        muted = "#B8C2D9" if dark else "#596A7E"
        host = "rgba(10,16,34,148)" if dark else "rgba(241,248,255,140)"
        rail = "rgba(13,21,46,104)" if dark else "rgba(211,229,246,88)"
        border = "rgba(151,128,255,150)" if dark else "rgba(255,255,255,205)"
        input_bg = "rgba(20,29,55,132)" if dark else "rgba(255,255,255,112)"
        self.setup_host.setStyleSheet(
            f"QWidget#SetupHost{{background:{host};border:none;border-radius:20px;}}"
        )
        self.progress_rail.setStyleSheet(
            f"QWidget#SetupRail{{background:{rail};border:none;border-right:none;"
            "border-top-left-radius:20px;border-bottom-left-radius:20px;}"
        )
        self.content_surface.setStyleSheet(
            f"QFrame#SetupContent{{background:transparent;border:none;}}"
            f"QLabel{{color:{text};background:transparent;border:none;}}"
            f"QComboBox{{background:{input_bg};border:none;border-radius:22px;"
            f"padding:9px 12px;color:{text};min-height:24px;}}"
            f"QComboBox:focus{{border:none;}}"
            f"QListWidget{{background:{input_bg};color:{text};border:none;border-radius:24px;}}"
        )
        self.brand.setStyleSheet(f"color:{text};background:transparent;letter-spacing:1px;")
        self.eyebrow.setStyleSheet(f"color:{accent};background:transparent;font-weight:700;letter-spacing:1px;")
        self.title.setStyleSheet(f"color:{text};background:transparent;")
        self.description.setStyleSheet(f"color:{muted};background:transparent;")
        self.validation.setStyleSheet("color:#FF7C8C;background:transparent;" if dark else "color:#B13B3B;background:transparent;")
        self.back.setStyleSheet(
            "QPushButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #F87171,stop:1 #EC4899);color:white;border:none;"
            "border-radius:12px;padding:8px 16px;font-weight:700;outline:none;}"
            "QPushButton:hover{background:#F05286;border:none;outline:none;border-radius:12px;}QPushButton:pressed{padding:8px 16px;}"
        )
        self.next.setStyleSheet(
            f"QPushButton{{background:{accent};color:white;border:none;"
            "border-radius:12px;padding:8px 18px;font-weight:700;}"
            "QPushButton:hover{background:rgba(126,151,255,235);}"
        )
        panel_bg = "rgba(18,27,52,118)" if dark else "rgba(255,255,255,80)"
        self.light_mode.setProperty("nexoraPrimary", not dark)
        self.dark_mode.setProperty("nexoraPrimary", dark)
        for button in (self.light_mode, self.dark_mode):
            button.style().unpolish(button)
            button.style().polish(button)
        for widget_name in ("license_view", "hardware_label", "summary"):
            widget = getattr(self, widget_name, None)
            if widget is not None:
                widget.setStyleSheet(
                    f"background:{panel_bg};border:none;border-radius:16px;padding:12px;color:{text};"
                )
        self.tint_layer.setStyleSheet(
            "background:qlineargradient(x1:0,y1:0,x2:0,y2:1,"
            + ("stop:0 rgba(4,7,20,78),stop:.55 rgba(8,10,28,112),stop:1 rgba(2,4,13,148));"
               if dark else "stop:0 rgba(196,224,255,32),stop:.55 rgba(114,160,215,48),stop:1 rgba(12,30,52,82));")
            + "border:none;"
        )
        self._sync(animate=False)

    def _sync(self, *, animate: bool = True) -> None:
        self.stack.setCurrentIndex(self.step)
        self.title.setText(tr(self.NAMES[self.step]))
        descriptions = (
            "Choose the language used by Nexora.",
            "Set regional formats and the clock style.",
            "Review the local software license. Optional privacy choices are separate.",
            "Create the primary local account.",
            "Use a password or explicitly choose passwordless sign-in.",
            "Choose simple initials, a colour or your own image.",
            "Decide which optional local histories and services are enabled.",
            "Start with light One UI-inspired glass and tune it immediately.",
            "Hardware detection runs away from the interface thread.",
            "Review the configuration before opening the login screen.",
        )
        self.description.setText(tr(descriptions[self.step]))
        self.back.setVisible(self.step > 0)
        self.next.setText((tr("Finish") + "  ✓") if self.step == len(self.NAMES) - 1 else (tr("Continue") + "  →"))
        self.validation.clear()
        for index, label in enumerate(self.step_labels):
            active = index == self.step
            dark = self.account_theme == "cosmic_dark"
            active_color = "#9B7CFF" if dark else "#397DDF"
            active_border = "#8062E6" if dark else "#2F6FCB"
            idle_color = "#B8C2D9" if dark else "#5B6778"
            label.setStyleSheet(
                f"color:white;background:{active_color};border:none;border-radius:22px;padding:0 10px;font-weight:700;"
                if active
                else f"color:{idle_color};background:transparent;border:none;border-radius:22px;padding:0 10px;"
            )
        if self.step == 8 and not self.hardware:
            self._load_hardware()
        if self.step == 9:
            self._refresh_summary()
        if animate:
            self._animate_page()

    def _animate_page(self) -> None:
        page = self.stack.currentWidget()
        effect = QGraphicsOpacityEffect(page)
        page.setGraphicsEffect(effect)
        animation = QPropertyAnimation(effect, b"opacity", page)
        animation.setDuration(190)
        animation.setStartValue(0.0)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.OutCubic)
        animation.finished.connect(lambda: page.setGraphicsEffect(None))
        self._keep_animation(animation)
        animation.start()

    def _load_hardware(self) -> None:
        if self._hardware_task is not None:
            return
        task = HardwareTask()
        task.signals.finished.connect(self._hardware_finished)
        self._hardware_task = task
        self._pool.start(task)

    def _hardware_finished(self, result: object) -> None:
        self._hardware_task = None
        if isinstance(result, dict):
            self.hardware = {str(key): str(value) for key, value in result.items()}
        screen = QApplication.primaryScreen()
        if screen is not None:
            size = screen.size()
            self.hardware["Display"] = f"{size.width()} × {size.height()}"
        self.hardware_label.setText("\n".join(f"{key}: {value}" for key, value in self.hardware.items()))

    def _refresh_summary(self) -> None:
        username = self.user_name.text().strip() or "—"
        password = "No password" if self.passwordless.isChecked() else "Password protected"
        style_key = getattr(self, "account_theme", "cloud_light")
        mode = "Cloud Light" if style_key == "cloud_light" else "Space Dark"
        self.summary.setText(
            f"User: {username}\n"
            f"Sign-in: {password}\n"
            f"Language: {self.language.currentText()}\n"
            f"Region: {self.region.currentText()}\n"
            f"Appearance: {mode}, {self.transparency.value()}% transparency, blur {self.blur.value()}\n"
            f"Session restore: {'On' if self.session_restore.isChecked() else 'Off'}\n"
            f"Diagnostics: {'On' if self.diagnostics.isChecked() else 'Off'}"
        )

    def previous(self) -> None:
        if self.step > 0:
            self.step -= 1
            self._sync()

    def _validate_current(self) -> bool:
        if self.step == 2 and not self.accept_license.isChecked():
            self.validation.setText("Accept the license to continue.")
            return False
        if self.step == 3 and not self.user_name.text().strip():
            self.validation.setText("Enter a user name.")
            return False
        if self.step == 4 and not self.passwordless.isChecked():
            if len(self.user_password.text()) < 10:
                self.validation.setText("The password must contain at least 10 characters.")
                return False
            if self.user_password.text() != self.confirm_password.text():
                self.validation.setText("The passwords do not match.")
                return False
        return True

    def advance(self) -> None:
        self.validation.clear()
        if not self._validate_current():
            return
        if self.step < len(self.NAMES) - 1:
            self.step += 1
            self._sync()
            return
        self._finish_setup()

    def _finish_setup(self) -> None:
        from user_handle import create_users

        password = "" if self.passwordless.isChecked() else self.user_password.text()
        self.next.setEnabled(False)
        try:
            users = create_users(
                [{
                    "username": self.user_name.text().strip(),
                    "password": password,
                    "avatar_color": self.account.avatar_color,
                    "avatar_path": self.account.avatar_path,
                }]
            )
            settings = load_settings()
            settings.update({
                "language": self.language.currentData() or "en",
                "region": self.region.currentText(),
                "clock_24h": self.clock_24h.isChecked(),
                "ui_style": getattr(self, "account_theme", "cloud_light"),
                "theme_mode": "dark" if getattr(self, "account_theme", "cloud_light") == "cosmic_dark" else "light",
                "accent_color": "#8A7CFF" if getattr(self, "account_theme", "cloud_light") == "cosmic_dark" else "#55A7FF",
                "glass_transparency": 48,
                "blur_radius": 48,
                "material_saturation": 128 if getattr(self, "account_theme", "cloud_light") == "cosmic_dark" else 112,
                "surface_brightness": 92 if getattr(self, "account_theme", "cloud_light") == "cosmic_dark" else 104,
                "window_radius": 16,
                "panel_radius": 18,
                "shadow_strength": 0,
                "telemetry": self.diagnostics.isChecked(),
                "start_recent_apps": self.usage_history.isChecked(),
                "sound_effects": self.system_sounds.isChecked(),
                "restore_session": self.session_restore.isChecked(),
                "start_history": self.search_history.isChecked(),
                "oobe_completed": True,
            })
            save_settings(settings)
        except (OSError, ValueError) as error:
            self.validation.setText(str(error))
            self.next.setEnabled(True)
            return
        self.completed.emit()

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key_Escape:
            if self.step > 0:
                self.previous()
            else:
                QApplication.quit()
            event.accept()
            return
        super().keyPressEvent(event)
