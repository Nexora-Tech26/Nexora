"""Authentication, desktop entry facades and isolated runtime processes."""
