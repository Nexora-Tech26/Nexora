"""Compatibility facade; new code should import from :mod:`gui`."""
from gui.shared import *
import logging

os.environ.setdefault("QT_MAC_DONT_USE_NATIVE_DIALOGS", "1")
from gui.search import NexoraSearchWorker
from gui.components import *
from gui.app_window import AppWindow
from gui.start_menu import StartMenu
from gui.desktop_widget import DesktopWidget
from gui.desktop import Desktop
from gui.auth import Login, OOBE
def _enter_kiosk_presentation(window):
    """Present Nexora over the current macOS Space without native fullscreen."""
    window.setWindowFlag(Qt.FramelessWindowHint, True)
    screen = window.screen() or QApplication.primaryScreen()
    if screen is not None:
        window.setGeometry(screen.geometry().adjusted(0, 0, 3, 3))
    window.show()
    QApplication.processEvents()
    try:
        from System.platform_support.macos_window import apply_borderless_desktop
        apply_borderless_desktop(window)
    except Exception:
        logging.getLogger(__name__).exception(
            "Could not apply native macOS borderless presentation"
        )

def run(mode: str) -> int:
    if QApplication.instance() is None:
        QApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)
    app=QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Nexora")
    app.setApplicationVersion(NEXORA_VERSION)
    app.setStyle("Fusion")
    try:
        QApplication.setAttribute(Qt.AA_DontUseNativeDialogs, True)
    except (AttributeError, RuntimeError):
        pass
    app.setStyleSheet("""
        QMenu, QComboBox QAbstractItemView {
            background: rgba(232,239,246,248);
            color: #17191F;
            border: none;
            border-radius:22px;
            padding: 7px;
            outline: none;
            selection-background-color: rgba(63,140,255,92);
            selection-color: #17191F;
        }
        QComboBox {
            background: rgba(245,249,252,82);
            color: #17191F;
            border: none;
            border-radius:22px;
            padding: 8px 32px 8px 12px;
            min-height: 22px;
        }
        QComboBox::drop-down { border: none; width: 28px; }
        QComboBox::down-arrow { image: none; }
        QMenu::item { border: none; border-radius:18px; padding: 8px 16px; }
        QMenu::item:selected { background: rgba(63,140,255,74); }
        QToolTip { background: rgba(232,239,246,246); color:#17191F; border:none; border-radius:10px; padding:7px 10px; }
        QPushButton:focus, QToolButton:focus, QLineEdit:focus, QComboBox:focus { border:none; outline:none; }
    """)
    if mode == "desktop":
        window = Desktop()
        if os.environ.get("NEXORA_WINDOWED") == "1":
            window.resize(1280, 800)
            window.show()
        else:
            if sys.platform == "darwin":
                _enter_kiosk_presentation(window)
            else:
                window.showFullScreen()
    elif mode == "login":
        from System.runtime.auth_ui import LoginScreen
        window = LoginScreen()
        if os.environ.get("NEXORA_WINDOWED") == "1":
            window.resize(1280, 800)
            window.show()
        else:
            if sys.platform == "darwin":
                _enter_kiosk_presentation(window)
            else:
                window.showFullScreen()
    elif mode == "oobe":
        from System.runtime.auth_ui import SetupScreen
        window = SetupScreen()
        if os.environ.get("NEXORA_WINDOWED") == "1":
            window.resize(1280, 800)
            window.show()
        else:
            if sys.platform == "darwin":
                _enter_kiosk_presentation(window)
            else:
                window.showFullScreen()
    else:
        raise ValueError(mode)
    return app.exec()
