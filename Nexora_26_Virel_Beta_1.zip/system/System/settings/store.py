"""Versioned, atomic and cached settings storage for Nexora 26 Beta 1."""
from __future__ import annotations

import json
import os
import shutil
import threading
import time
from copy import deepcopy
from pathlib import Path
from typing import Any, Callable, Mapping

SCHEMA_VERSION = 27

DEFAULTS: dict[str, Any] = {
    "schema_version": SCHEMA_VERSION,
    "animations": True,
    "reduce_motion": False,
    "high_contrast": False,
    "disable_transparency": False,
    "underline_buttons": False,
    "large_text": False,
    "ui_scale": 1.0,
    "widget_gap": 12,
    "widget_refresh": 5,
    "weather_city": "Warsaw",
    "clock_24h": True,
    "show_seconds": False,
    "taskbar_size": 36,
    "dock_position": "bottom",
    "dock_autohide": False,
    "dock_magnification": 100,
    "dock_recent_apps": True,
    "dock_show_trash": True,
    "start_layout": "compact",
    "start_search_files": True,
    "start_search_settings": True,
    "start_history": True,
    "start_recommended": True,
    "start_recent_apps": True,
    "files_show_hidden": False,
    "confirm_shutdown": True,
    "browser_home": "https://www.google.com",
    "browser_search": "https://www.google.com/search?q={query}",
    "notifications": True,
    "notification_history": True,
    "do_not_disturb": False,
    "sound_effects": False,
    "ui_sound_volume": 55,
    "volume": 65,
    "language": "pl",
    "notification_location": "notch",
    "display_mode": "native",
    "brightness": 100,
    "ui_style": "cloud_light",
    "theme_mode": "light",
    "accent_color": "#2B7FFF",
    "automatic_accent": False,
    "glass_transparency": 76,
    "blur_radius": 28,
    "material_saturation": 126,
    "surface_brightness": 104,
    "text_contrast": 118,
    "window_radius": 28,
    "window_controls_style": "traffic_lights",
    "window_controls_position": "left",
    "window_controls_joined": True,
    "tiling_enabled": False,
    "panel_radius": 28,
    "border_width": 0,
    "shadow_strength": 52,
    "animation_speed": 0.7,
    "animation_easing": "out_cubic",
    "font_family": "system",
    "icon_style": "rounded",
    "icon_size": "medium",
    "desktop_auto_arrange": False,
    "desktop_align_grid": True,
    "desktop_free_placement": True,
    "desktop_show_icons": True,
    "desktop_show_widgets": False,
    "desktop_sort": "name",
    "performance_mode": "balanced",
    "snap_assist": True,
    "snap_enabled": True,
    "magnetic_windows": True,
    "focus_ring": True,
    "keyboard_navigation": True,
    "night_light": False,
    "night_light_strength": 28,
    "focus_mode": False,
    "wallpaper": "system/System/UI/Wallpapers/Blue Horizon 4K.jpg",
    "wallpaper_light": "system/System/UI/Wallpapers/Blue Horizon 4K.jpg",
    "wallpaper_dark": "system/System/UI/Wallpapers/Wolf Moon 4K.jpg",
    "wallpaper_variant": "light",
    "wallpaper_fit": "cover",
    "design_density": "comfortable",
    "dynamic_lighting": False,
    "parallax_effects": False,
    "cursor_effects": False,
    "elastic_scrolling": False,
    "adaptive_ui": False,
    "predictive_dock": False,
    "global_clipboard_sync": False,
    "gaming_mode": False,
    "creator_mode": False,
    "update_channel": "preview",
    "auto_updates": True,
    "telemetry": False,
    "privacy_mode": False,
    "backups_enabled": True,
    "snapshot_schedule": "weekly",
    "plugins_enabled": True,
    "developer_mode": False,
    "experimental_features": False,
    "disabled_apps": [],
    "automation_enabled": False,
    "workspace_switch_animation": False,
    "live_wallpaper": False,
    "battery_saver_threshold": 20,
}


class SettingsValidationError(ValueError):
    pass


def _coerce(key: str, value: Any) -> Any:
    default = DEFAULTS.get(key)
    if default is None:
        return value
    if isinstance(default, bool):
        if isinstance(value, str):
            normalized = value.strip().lower()
            if normalized in {"true", "1", "yes", "on"}:
                return True
            if normalized in {"false", "0", "no", "off", ""}:
                return False
        return bool(value)
    if isinstance(default, int) and not isinstance(default, bool):
        return int(value)
    if isinstance(default, float):
        return float(value)
    if isinstance(default, str):
        return str(value)
    return value


def validate_settings(values: Mapping[str, Any]) -> dict[str, Any]:
    result = deepcopy(DEFAULTS)
    for key, value in values.items():
        if not isinstance(key, str):
            raise SettingsValidationError("Settings keys must be strings")
        result[key] = _coerce(key, value)
    result["schema_version"] = SCHEMA_VERSION
    result["glass_transparency"] = max(0, min(100, int(result["glass_transparency"])))
    result["surface_brightness"] = max(65, min(135, int(result["surface_brightness"])))
    result["text_contrast"] = max(70, min(140, int(result["text_contrast"])))
    result["taskbar_size"] = max(36, min(44, int(result["taskbar_size"])))
    result["dock_magnification"] = max(100, min(135, int(result["dock_magnification"])))
    result["blur_radius"] = max(0, min(48, int(result["blur_radius"])))
    result["window_radius"] = max(10, min(40, int(result["window_radius"])))
    result["panel_radius"] = max(10, min(40, int(result["panel_radius"])))
    result["ui_scale"] = max(0.9, min(2.0, float(result["ui_scale"])))
    result["animation_speed"] = max(0.25, min(2.5, float(result["animation_speed"])))
    result["dock_position"] = result["dock_position"] if result["dock_position"] in {"bottom", "top"} else "bottom"
    result["performance_mode"] = result["performance_mode"] if result["performance_mode"] in {"quality", "balanced", "performance", "battery_saver"} else "balanced"
    result["icon_size"] = result["icon_size"] if result["icon_size"] in {"small", "medium", "large"} else "medium"
    result["start_layout"] = result["start_layout"] if result["start_layout"] in {"compact", "balanced", "grid"} else "balanced"
    result["desktop_sort"] = result["desktop_sort"] if result["desktop_sort"] in {"name", "type", "date", "usage"} else "name"
    result["theme_mode"] = result["theme_mode"] if result["theme_mode"] in {"light", "dark", "auto"} else "light"
    result["window_controls_style"] = result["window_controls_style"] if result["window_controls_style"] in {"traffic_lights", "gnome"} else "traffic_lights"
    result["window_controls_position"] = result["window_controls_position"] if result["window_controls_position"] in {"left", "right"} else "left"
    result["window_controls_joined"] = bool(result.get("window_controls_joined", True))
    result["tiling_enabled"] = bool(result.get("tiling_enabled", False))
    result["wallpaper_variant"] = result["wallpaper_variant"] if result["wallpaper_variant"] in {"light", "dark"} else "light"
    result["animation_easing"] = result["animation_easing"] if result["animation_easing"] in {"out_cubic", "in_out_cubic", "out_quart", "linear"} else "out_cubic"
    result["design_density"] = result["design_density"] if result["design_density"] in {"compact", "comfortable", "spacious"} else "comfortable"
    result["update_channel"] = result["update_channel"] if result["update_channel"] in {"stable", "preview", "developer"} else "preview"
    result["snapshot_schedule"] = result["snapshot_schedule"] if result["snapshot_schedule"] in {"off", "daily", "weekly", "monthly"} else "weekly"
    result["battery_saver_threshold"] = max(5, min(50, int(result["battery_saver_threshold"])))
    return result


def migrate_settings(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Migrate legacy settings into the stable Nexora 26 Beta 1 schema."""
    data = dict(raw)
    previous_schema = int(data.get("schema_version", 0) or 0)
    if previous_schema < 27:
        # Nexora 26 Beta 1 compact pass: previous builds rendered oversized controls.
        data["ui_scale"] = 1.0
        data["taskbar_size"] = 36
        data["design_density"] = "comfortable"
    data.setdefault("theme_mode", "light")
    old_wallpaper = str(data.get("wallpaper", ""))
    if "Horizon" in old_wallpaper or "Nexora Village" in old_wallpaper or data.get("wallpaper_variant") == "auto":
        variant = "dark" if str(data.get("theme_mode", "light")) == "dark" else "light"
        data["wallpaper_variant"] = variant
        data["wallpaper_light"] = "system/System/UI/Wallpapers/Blue Horizon 4K.jpg"
        data["wallpaper_dark"] = "system/System/UI/Wallpapers/Wolf Moon 4K.jpg"
        data["wallpaper"] = data[f"wallpaper_{variant}"]
    if str(data.get("window_controls_style", "traffic_lights")) == "nexora":
        data["window_controls_style"] = "traffic_lights"
    legacy_style = str(data.get("ui_style", "cloud_light"))
    if legacy_style in {"basic", "light", "dark", "nexora_glass", "one_ui"}:
        cosmic = str(data.get("theme_mode", "light")) == "dark" or legacy_style == "dark"
        data["ui_style"] = "cosmic_dark" if cosmic else "cloud_light"
        data["accent_color"] = "#9B7CFF" if cosmic else "#4B8DFF"
        data["glass_transparency"] = 72
        data["blur_radius"] = 60
        data["material_saturation"] = 128 if cosmic else 112
        data["surface_brightness"] = 92 if cosmic else 104
        data["window_radius"] = 16
        data["panel_radius"] = 18
        data["shadow_strength"] = 92 if cosmic else 76
    data.setdefault("dock_position", "bottom")
    data.setdefault("performance_mode", "balanced")
    data.setdefault("design_density", "comfortable")
    data.setdefault("tiling_enabled", False)
    data.setdefault("adaptive_ui", True)
    data.setdefault("predictive_dock", True)
    data.setdefault("update_channel", "preview")
    data.setdefault("auto_updates", True)
    data.setdefault("telemetry", False)
    data.setdefault("backups_enabled", True)
    data.setdefault("snapshot_schedule", "weekly")
    data.setdefault("plugins_enabled", True)
    data.setdefault("disabled_apps", [])
    data.setdefault("automation_enabled", True)
    # Preserve user-selected visual values. Defaults are added only when missing.
    data.setdefault("glass_transparency", 76)
    data.setdefault("blur_radius", 28)
    data.setdefault("disable_transparency", False)
    return validate_settings(data)


class SettingsStore:
    """Load once, keep in memory and save atomically with debounce."""

    def __init__(self, path: Path, *, debounce_ms: int = 220):
        self.path = Path(path)
        self.backup_path = self.path.with_suffix(self.path.suffix + ".bak")
        self.debounce_ms = max(0, int(debounce_ms))
        self._lock = threading.RLock()
        self._timer: threading.Timer | None = None
        self._listeners: list[Callable[[dict[str, Any], set[str]], None]] = []
        self._data = self._load()

    def _load(self) -> dict[str, Any]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                raise SettingsValidationError("Root settings value must be an object")
            return migrate_settings(raw)
        except (OSError, json.JSONDecodeError, SettingsValidationError, TypeError, ValueError):
            if self.path.exists():
                corrupt = self.path.with_name(f"{self.path.stem}.corrupt-{int(time.time())}{self.path.suffix}")
                try:
                    shutil.copy2(self.path, corrupt)
                except OSError:
                    pass
            return deepcopy(DEFAULTS)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return deepcopy(self._data)

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return deepcopy(self._data.get(key, default))

    def subscribe(self, listener: Callable[[dict[str, Any], set[str]], None]) -> Callable[[], None]:
        with self._lock:
            self._listeners.append(listener)
        def unsubscribe() -> None:
            with self._lock:
                if listener in self._listeners:
                    self._listeners.remove(listener)
        return unsubscribe

    def update(self, values: Mapping[str, Any], *, save: bool = True) -> dict[str, Any]:
        with self._lock:
            merged = dict(self._data)
            merged.update(values)
            validated = validate_settings(merged)
            changed = {key for key, value in validated.items() if self._data.get(key) != value}
            self._data = validated
            listeners = list(self._listeners)
        if changed:
            snapshot = self.snapshot()
            for listener in listeners:
                try:
                    listener(snapshot, changed)
                except Exception:
                    continue
            if save:
                self.schedule_save()
        return self.snapshot()

    def replace(self, values: Mapping[str, Any], *, save: bool = True) -> dict[str, Any]:
        validated = validate_settings(values)
        with self._lock:
            changed = {key for key in set(self._data) | set(validated) if self._data.get(key) != validated.get(key)}
            self._data = validated
        if changed and save:
            self.schedule_save()
        return self.snapshot()

    def schedule_save(self) -> None:
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(self.debounce_ms / 1000.0, self.flush)
            self._timer.daemon = True
            self._timer.start()

    def flush(self) -> None:
        with self._lock:
            data = deepcopy(self._data)
            self._timer = None
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + f".{os.getpid()}.tmp")
        payload = json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True)
        if self.path.exists():
            try:
                shutil.copy2(self.path, self.backup_path)
            except OSError:
                pass
        tmp.write_text(payload, encoding="utf-8")
        # Validate the exact bytes that will replace the live file.
        candidate = json.loads(tmp.read_text(encoding="utf-8"))
        validate_settings(candidate)
        with tmp.open("rb") as handle:
            os.fsync(handle.fileno())
        os.replace(tmp, self.path)

    def close(self) -> None:
        with self._lock:
            timer = self._timer
            self._timer = None
        if timer is not None:
            timer.cancel()
        self.flush()


_STORE: SettingsStore | None = None

def get_settings_store(path: Path | None = None) -> SettingsStore:
    global _STORE
    if _STORE is None:
        if path is None:
            from nexora.paths import DATA_DIR, ensure_runtime_paths
            ensure_runtime_paths(legacy_data=Path(__file__).resolve().parents[1] / "data")
            path = DATA_DIR / "settings.json"
        _STORE = SettingsStore(path)
    return _STORE

def load_settings(path: Path | None = None) -> dict[str, Any]:
    """Return a cached, migrated settings snapshot without importing the GUI layer."""
    return get_settings_store(path).snapshot()


def save_settings(values: Mapping[str, Any], path: Path | None = None) -> dict[str, Any]:
    """Validate settings, update the shared store and schedule an atomic save."""
    return get_settings_store(path).replace(values, save=True)

