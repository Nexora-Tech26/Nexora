from __future__ import annotations

from PySide6.QtWidgets import QLabel, QAbstractButton, QLineEdit, QComboBox, QWidget

LANGUAGES = [
    ("English", "en"), ("Polski", "pl"), ("Deutsch", "de"), ("Français", "fr"),
    ("Español", "es"), ("Italiano", "it"), ("Português", "pt"), ("Nederlands", "nl"),
    ("Čeština", "cs"), ("Slovenčina", "sk"), ("Українська", "uk"), ("日本語", "ja"),
    ("한국어", "ko"), ("中文", "zh"),
]

# English is the canonical source language. Unknown strings intentionally remain English.
T = {
"pl": {"System setup":"Konfiguracja systemu","Welcome":"Witamy","Agreement":"Umowa","Language & display":"Język i ekran","Users":"Użytkownicy","Ready":"Gotowe","NEXORA SETUP":"KONFIGURACJA NEXORA","Welcome to Nexora":"Witamy w Nexora","Set up local accounts, language and display comfort. You can change these settings later in Settings.":"Skonfiguruj lokalne konta, język i komfort ekranu. Ustawienia można później zmienić w Settings.","Private • Local • Consistent":"Prywatny • Lokalny • Spójny","Terms of use":"Warunki korzystania","Profiles are stored locally and passwords are stored only as secure hashes.":"Profile są przechowywane lokalnie, a hasła wyłącznie jako bezpieczne skróty.","I accept the Nexora local profile terms":"Akceptuję warunki lokalnego profilu Nexora","Choose the interface language and Nexora brightness. You can change these settings later in Settings.":"Wybierz język interfejsu oraz jasność Nexory. Ustawienia można później zmienić w Settings.","Interface language":"Język interfejsu","Nexora brightness":"Jasność Nexory","Create users":"Utwórz użytkowników","The first account is required. A second account is optional, and more can be added later in Settings.":"Pierwsze konto jest wymagane. Drugie jest opcjonalne, a kolejne można dodać później w Settings.","First user name":"Nazwa pierwszego użytkownika","No password — clicking the account signs in immediately":"Bez hasła — kliknięcie konta od razu loguje","Password — minimum 4 characters":"Hasło — minimum 4 znaki","Repeat password":"Powtórz hasło","Add a second user":"Dodaj drugiego użytkownika","Second user name":"Nazwa drugiego użytkownika","Second user password":"Hasło drugiego użytkownika","All set":"Wszystko gotowe","After saving the accounts, the login screen with user selection will open.":"Po zapisaniu kont otworzy się ekran logowania z wyborem użytkownika.","Back":"Wstecz","Next":"Dalej","Finish":"Zakończ","Accept the terms.":"Zaakceptuj warunki.","Enter the first user's name.":"Wpisz nazwę pierwszego użytkownika.","The first user's password must contain at least 4 characters.":"Hasło pierwszego użytkownika musi mieć co najmniej 4 znaki.","The first user's passwords do not match.":"Hasła pierwszego użytkownika nie są identyczne.","Enter the second user's name.":"Wpisz nazwę drugiego użytkownika.","User names must be different.":"Nazwy użytkowników muszą być różne.","The second user's password must contain at least 4 characters.":"Hasło drugiego użytkownika musi mieć co najmniej 4 znaki.","The second user's passwords do not match.":"Hasła drugiego użytkownika nie są identyczne.","User accounts":"Użytkownicy","Language":"Język","Brightness":"Jasność","Choose a user":"Wybierz użytkownika","Password":"Hasło","SIGN IN":"ZALOGUJ","ENTER":"WEJDŹ","Choose an account, enter the password and press Enter":"Wybierz konto, wpisz hasło i naciśnij Enter","Enter the password and press Enter":"Wpisz hasło i naciśnij Enter","This account does not require a password":"To konto nie wymaga hasła","No users found.":"Brak użytkowników.","Incorrect password.":"Nieprawidłowe hasło.","Settings":"Ustawienia","Open":"Otwórz","Save":"Zapisz","Cancel":"Anuluj","Apply changes":"Zastosuj zmiany","Create":"Utwórz","Remove":"Usuń","Refresh":"Odśwież","Search":"Szukaj","Power":"Zasilanie","Shut down":"Wyłącz"},
"de": {"Welcome":"Willkommen","Agreement":"Vereinbarung","Language & display":"Sprache und Anzeige","Users":"Benutzer","Ready":"Fertig","System setup":"Systemeinrichtung","Welcome to Nexora":"Willkommen bei Nexora","Terms of use":"Nutzungsbedingungen","Interface language":"Oberflächensprache","Nexora brightness":"Nexora-Helligkeit","Create users":"Benutzer erstellen","All set":"Alles bereit","Back":"Zurück","Next":"Weiter","Finish":"Fertigstellen","Password":"Passwort","SIGN IN":"ANMELDEN","Settings":"Einstellungen","Open":"Öffnen","Save":"Speichern","Cancel":"Abbrechen","Apply changes":"Änderungen anwenden","Remove":"Entfernen","Refresh":"Aktualisieren","Shut down":"Herunterfahren"},
"fr": {"Welcome":"Bienvenue","Agreement":"Accord","Language & display":"Langue et affichage","Users":"Utilisateurs","Ready":"Prêt","System setup":"Configuration du système","Welcome to Nexora":"Bienvenue dans Nexora","Terms of use":"Conditions d’utilisation","Interface language":"Langue de l’interface","Nexora brightness":"Luminosité de Nexora","Create users":"Créer des utilisateurs","All set":"Tout est prêt","Back":"Retour","Next":"Suivant","Finish":"Terminer","Password":"Mot de passe","SIGN IN":"SE CONNECTER","Settings":"Paramètres","Open":"Ouvrir","Save":"Enregistrer","Cancel":"Annuler","Apply changes":"Appliquer","Remove":"Supprimer","Refresh":"Actualiser","Shut down":"Éteindre"},
"es": {"Welcome":"Bienvenido","Agreement":"Acuerdo","Language & display":"Idioma y pantalla","Users":"Usuarios","Ready":"Listo","System setup":"Configuración del sistema","Welcome to Nexora":"Bienvenido a Nexora","Terms of use":"Términos de uso","Interface language":"Idioma de la interfaz","Nexora brightness":"Brillo de Nexora","Create users":"Crear usuarios","All set":"Todo listo","Back":"Atrás","Next":"Siguiente","Finish":"Finalizar","Password":"Contraseña","SIGN IN":"INICIAR SESIÓN","Settings":"Configuración","Open":"Abrir","Save":"Guardar","Cancel":"Cancelar","Apply changes":"Aplicar cambios","Remove":"Eliminar","Refresh":"Actualizar","Shut down":"Apagar"},
"it": {"Welcome":"Benvenuto","Agreement":"Accordo","Language & display":"Lingua e schermo","Users":"Utenti","Ready":"Pronto","System setup":"Configurazione del sistema","Welcome to Nexora":"Benvenuto in Nexora","Terms of use":"Condizioni d’uso","Interface language":"Lingua dell’interfaccia","Nexora brightness":"Luminosità Nexora","Create users":"Crea utenti","All set":"Tutto pronto","Back":"Indietro","Next":"Avanti","Finish":"Fine","Password":"Password","SIGN IN":"ACCEDI","Settings":"Impostazioni","Open":"Apri","Save":"Salva","Cancel":"Annulla","Apply changes":"Applica modifiche","Remove":"Rimuovi","Refresh":"Aggiorna","Shut down":"Spegni"},
"pt": {"Welcome":"Bem-vindo","Agreement":"Acordo","Language & display":"Idioma e ecrã","Users":"Utilizadores","Ready":"Pronto","System setup":"Configuração do sistema","Welcome to Nexora":"Bem-vindo ao Nexora","Terms of use":"Termos de utilização","Interface language":"Idioma da interface","Nexora brightness":"Brilho do Nexora","Create users":"Criar utilizadores","All set":"Tudo pronto","Back":"Voltar","Next":"Seguinte","Finish":"Concluir","Password":"Palavra-passe","SIGN IN":"ENTRAR","Settings":"Definições","Open":"Abrir","Save":"Guardar","Cancel":"Cancelar","Apply changes":"Aplicar alterações","Remove":"Remover","Refresh":"Atualizar","Shut down":"Desligar"},
"nl": {"Welcome":"Welkom","Agreement":"Overeenkomst","Language & display":"Taal en beeldscherm","Users":"Gebruikers","Ready":"Gereed","System setup":"Systeemconfiguratie","Welcome to Nexora":"Welkom bij Nexora","Terms of use":"Gebruiksvoorwaarden","Interface language":"Interfacetaal","Nexora brightness":"Nexora-helderheid","Create users":"Gebruikers maken","All set":"Alles gereed","Back":"Terug","Next":"Volgende","Finish":"Voltooien","Password":"Wachtwoord","SIGN IN":"AANMELDEN","Settings":"Instellingen","Open":"Openen","Save":"Opslaan","Cancel":"Annuleren","Apply changes":"Wijzigingen toepassen","Remove":"Verwijderen","Refresh":"Vernieuwen","Shut down":"Afsluiten"},
"cs": {"Welcome":"Vítejte","Agreement":"Souhlas","Language & display":"Jazyk a obrazovka","Users":"Uživatelé","Ready":"Hotovo","System setup":"Nastavení systému","Welcome to Nexora":"Vítejte v Nexora","Terms of use":"Podmínky použití","Interface language":"Jazyk rozhraní","Nexora brightness":"Jas Nexora","Create users":"Vytvořit uživatele","All set":"Vše je připraveno","Back":"Zpět","Next":"Další","Finish":"Dokončit","Password":"Heslo","SIGN IN":"PŘIHLÁSIT","Settings":"Nastavení","Open":"Otevřít","Save":"Uložit","Cancel":"Zrušit","Apply changes":"Použít změny","Remove":"Odebrat","Refresh":"Obnovit","Shut down":"Vypnout"},
"sk": {"Welcome":"Vitajte","Agreement":"Súhlas","Language & display":"Jazyk a obrazovka","Users":"Používatelia","Ready":"Hotovo","System setup":"Nastavenie systému","Welcome to Nexora":"Vitajte v Nexora","Terms of use":"Podmienky používania","Interface language":"Jazyk rozhrania","Nexora brightness":"Jas Nexora","Create users":"Vytvoriť používateľov","All set":"Všetko je pripravené","Back":"Späť","Next":"Ďalej","Finish":"Dokončiť","Password":"Heslo","SIGN IN":"PRIHLÁSIŤ","Settings":"Nastavenia","Open":"Otvoriť","Save":"Uložiť","Cancel":"Zrušiť","Apply changes":"Použiť zmeny","Remove":"Odstrániť","Refresh":"Obnoviť","Shut down":"Vypnúť"},
"uk": {"Welcome":"Ласкаво просимо","Agreement":"Угода","Language & display":"Мова й екран","Users":"Користувачі","Ready":"Готово","System setup":"Налаштування системи","Welcome to Nexora":"Ласкаво просимо до Nexora","Terms of use":"Умови використання","Interface language":"Мова інтерфейсу","Nexora brightness":"Яскравість Nexora","Create users":"Створити користувачів","All set":"Усе готово","Back":"Назад","Next":"Далі","Finish":"Завершити","Password":"Пароль","SIGN IN":"УВІЙТИ","Settings":"Налаштування","Open":"Відкрити","Save":"Зберегти","Cancel":"Скасувати","Apply changes":"Застосувати зміни","Remove":"Видалити","Refresh":"Оновити","Shut down":"Вимкнути"},
"ja": {"Welcome":"ようこそ","Agreement":"同意","Language & display":"言語と画面","Users":"ユーザー","Ready":"準備完了","System setup":"システム設定","Welcome to Nexora":"Nexoraへようこそ","Terms of use":"利用規約","Interface language":"表示言語","Nexora brightness":"Nexoraの明るさ","Create users":"ユーザーを作成","All set":"準備完了","Back":"戻る","Next":"次へ","Finish":"完了","Password":"パスワード","SIGN IN":"サインイン","Settings":"設定","Open":"開く","Save":"保存","Cancel":"キャンセル","Apply changes":"変更を適用","Remove":"削除","Refresh":"更新","Shut down":"シャットダウン"},
"ko": {"Welcome":"환영합니다","Agreement":"동의","Language & display":"언어 및 화면","Users":"사용자","Ready":"준비 완료","System setup":"시스템 설정","Welcome to Nexora":"Nexora에 오신 것을 환영합니다","Terms of use":"이용 약관","Interface language":"인터페이스 언어","Nexora brightness":"Nexora 밝기","Create users":"사용자 만들기","All set":"모두 준비됨","Back":"뒤로","Next":"다음","Finish":"완료","Password":"비밀번호","SIGN IN":"로그인","Settings":"설정","Open":"열기","Save":"저장","Cancel":"취소","Apply changes":"변경 적용","Remove":"제거","Refresh":"새로고침","Shut down":"종료"},
"zh": {"Welcome":"欢迎","Agreement":"协议","Language & display":"语言与显示","Users":"用户","Ready":"就绪","System setup":"系统设置","Welcome to Nexora":"欢迎使用 Nexora","Terms of use":"使用条款","Interface language":"界面语言","Nexora brightness":"Nexora 亮度","Create users":"创建用户","All set":"一切就绪","Back":"返回","Next":"下一步","Finish":"完成","Password":"密码","SIGN IN":"登录","Settings":"设置","Open":"打开","Save":"保存","Cancel":"取消","Apply changes":"应用更改","Remove":"移除","Refresh":"刷新","Shut down":"关机"},
}

_current_language = "en"

def set_language(code: str) -> None:
    global _current_language
    _current_language = code if code in {c for _, c in LANGUAGES} else "en"

def current_language() -> str:
    return _current_language

def tr(text: str, code: str | None = None) -> str:
    lang = code or _current_language
    if lang == "en": return text
    return T.get(lang, {}).get(text, text)

def _source(obj, attr: str, value: str) -> str:
    key = f"_nexora_i18n_{attr}"
    if not hasattr(obj, key): setattr(obj, key, value)
    return getattr(obj, key)

def localize_widget_tree(root: QWidget, code: str | None = None) -> None:
    lang = code or _current_language
    widgets = [root] + root.findChildren(QWidget)
    for w in widgets:
        if isinstance(w, (QLabel, QAbstractButton)):
            source = _source(w, "text", w.text())
            w.setText(tr(source, lang))
        if isinstance(w, QLineEdit):
            source = _source(w, "placeholder", w.placeholderText())
            w.setPlaceholderText(tr(source, lang))
        if isinstance(w, QComboBox):
            for i in range(w.count()):
                source = _source(w, f"item_{i}", w.itemText(i))
                # Language names stay native; all other known items are translated.
                if w.itemData(i) not in {c for _, c in LANGUAGES}:
                    w.setItemText(i, tr(source, lang))
    source_title = _source(root, "window_title", root.windowTitle())
    root.setWindowTitle(tr(source_title, lang))
