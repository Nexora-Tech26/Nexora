"""Cross-platform host integration used by Nexora.

Every operation returns an explicit success/unknown result. Unsupported controls do
not pretend to be enabled and never expose credentials in logs.
"""
from __future__ import annotations

import ctypes
import json
import os
import platform
import shutil
import socket
import subprocess
from pathlib import Path

SYSTEM = platform.system()
IS_MAC = SYSTEM == "Darwin"
IS_WINDOWS = SYSTEM == "Windows"
IS_LINUX = SYSTEM == "Linux"


def run(args, timeout=12, input_text=None):
    try:
        process = subprocess.run(
            args, input=input_text, capture_output=True, text=True,
            timeout=timeout, check=False,
        )
        return process.returncode, process.stdout.strip(), process.stderr.strip()
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 127, "", str(exc)


def online(timeout=2.0):
    for host, port in (("1.1.1.1", 53), ("8.8.8.8", 53), ("example.com", 443)):
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except OSError:
            continue
    return False



def capabilities():
    """Return explicit host-integration capabilities for the current platform."""
    return {
        "wifi_toggle": IS_MAC or (IS_LINUX and bool(shutil.which("nmcli"))) or IS_WINDOWS,
        "wifi_scan": IS_MAC or (IS_LINUX and bool(shutil.which("nmcli"))) or IS_WINDOWS,
        "wifi_connect": IS_MAC or (IS_LINUX and bool(shutil.which("nmcli"))),
        "bluetooth_toggle": (IS_MAC and bool(shutil.which("blueutil"))) or (IS_LINUX and bool(shutil.which("bluetoothctl"))),
        "bluetooth_settings": True,
        "volume": IS_MAC or (IS_LINUX and bool(shutil.which("pactl"))) or IS_WINDOWS,
        "brightness": (IS_LINUX and bool(shutil.which("brightnessctl"))) or (IS_MAC and bool(shutil.which("brightness"))) or IS_WINDOWS,
    }


def open_wifi_settings():
    """Open the native network settings without pretending direct control exists."""
    try:
        if IS_MAC:
            subprocess.Popen(["open", "x-apple.systempreferences:com.apple.wifi-settings-extension"])
        elif IS_WINDOWS:
            os.startfile("ms-settings:network-wifi")
        elif IS_LINUX:
            tool = shutil.which("gnome-control-center") or shutil.which("systemsettings")
            if not tool:
                return False
            subprocess.Popen([tool, "wifi"] if "gnome-control-center" in tool else [tool])
        else:
            return False
    except OSError:
        return False
    return True

def wifi_device():
    if IS_MAC:
        code, out, _ = run(["networksetup", "-listallhardwareports"])
        lines = out.splitlines() if code == 0 else []
        for i, line in enumerate(lines):
            if line.strip() in {"Hardware Port: Wi-Fi", "Hardware Port: AirPort"} and i + 1 < len(lines):
                return lines[i + 1].split(":", 1)[-1].strip()
    if IS_LINUX and shutil.which("nmcli"):
        code, out, _ = run(["nmcli", "-t", "-f", "DEVICE,TYPE", "device"])
        if code == 0:
            for line in out.splitlines():
                device, _, kind = line.partition(":")
                if kind == "wifi":
                    return device
    if IS_WINDOWS:
        return "wlan"
    return None


def wifi_power():
    if IS_MAC:
        dev = wifi_device()
        if not dev: return None
        code, out, _ = run(["networksetup", "-getairportpower", dev])
        return code == 0 and out.lower().endswith(": on")
    if IS_LINUX and shutil.which("nmcli"):
        code, out, _ = run(["nmcli", "radio", "wifi"])
        return out.strip().lower() == "enabled" if code == 0 else None
    if IS_WINDOWS:
        code, out, _ = run(["netsh", "interface", "show", "interface"])
        return any("wireless" in line.lower() and "enabled" in line.lower() for line in out.splitlines()) if code == 0 else None
    return None


def set_wifi_power(enabled):
    if IS_MAC:
        dev = wifi_device()
        if not dev: return False, "Wi-Fi adapter was not found."
        code, _, err = run(["networksetup", "-setairportpower", dev, "on" if enabled else "off"])
    elif IS_LINUX and shutil.which("nmcli"):
        code, _, err = run(["nmcli", "radio", "wifi", "on" if enabled else "off"])
    elif IS_WINDOWS:
        code, _, err = run(["netsh", "interface", "set", "interface", "name=Wi-Fi", f"admin={'enabled' if enabled else 'disabled'}"])
    else:
        return False, "Wi-Fi control is unavailable on this system."
    return code == 0, err or ("Wi-Fi enabled." if enabled else "Wi-Fi disabled.")


def current_wifi():
    if IS_MAC:
        dev = wifi_device()
        code, out, _ = run(["networksetup", "-getairportnetwork", dev]) if dev else (1, "", "")
        return out.split(":", 1)[1].strip() if code == 0 and ":" in out and "not associated" not in out.lower() else None
    if IS_LINUX and shutil.which("nmcli"):
        code, out, _ = run(["nmcli", "-t", "-f", "ACTIVE,SSID", "dev", "wifi"])
        return next((line.split(":", 1)[1] for line in out.splitlines() if line.startswith("yes:")), None) if code == 0 else None
    if IS_WINDOWS:
        code, out, _ = run(["netsh", "wlan", "show", "interfaces"])
        for line in out.splitlines():
            if line.strip().lower().startswith("ssid") and not line.strip().lower().startswith("bssid"):
                return line.split(":", 1)[1].strip()
    return None


def scan_wifi():
    networks = []
    if IS_LINUX and shutil.which("nmcli"):
        code, out, _ = run(["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "dev", "wifi", "list"], 20)
        if code == 0:
            for line in out.splitlines():
                parts = line.rsplit(":", 2)
                if len(parts) == 3 and parts[0]:
                    networks.append({"ssid": parts[0], "rssi": int(parts[1] or 0) - 100, "security": parts[2]})
    elif IS_WINDOWS:
        code, out, _ = run(["netsh", "wlan", "show", "networks", "mode=bssid"], 20)
        if code == 0:
            for line in out.splitlines():
                if line.strip().lower().startswith("ssid") and ":" in line:
                    ssid = line.split(":", 1)[1].strip()
                    if ssid: networks.append({"ssid": ssid, "rssi": -60, "security": ""})
    elif IS_MAC:
        candidates = [
            "/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport",
            "/System/Library/PrivateFrameworks/Apple80211.framework/Versions/A/Resources/airport",
        ]
        airport = next((p for p in candidates if Path(p).exists()), None)
        code, out, _ = run([airport, "-s"], 20) if airport else (1, "", "")
        if code == 0:
            for line in out.splitlines()[1:]:
                parts = line.split()
                idx = next((i for i, part in enumerate(parts) if part.count(":") == 5), None)
                if idx and idx + 1 < len(parts):
                    try: rssi = int(parts[idx + 1])
                    except ValueError: rssi = -100
                    networks.append({"ssid": " ".join(parts[:idx]), "rssi": rssi, "security": " ".join(parts[idx + 6:])})
    dedup = {}
    for item in networks:
        if item["ssid"] and (item["ssid"] not in dedup or item["rssi"] > dedup[item["ssid"]]["rssi"]):
            dedup[item["ssid"]] = item
    return sorted(dedup.values(), key=lambda item: item["rssi"], reverse=True)


def connect_wifi(ssid, password=""):
    if not ssid: return False, "Network name is required."
    if IS_MAC:
        dev = wifi_device()
        if not dev: return False, "Wi-Fi adapter was not found."
        args = ["networksetup", "-setairportnetwork", dev, ssid]
        if password: args.append(password)
        code, out, err = run(args, 30)
    elif IS_LINUX and shutil.which("nmcli"):
        args = ["nmcli", "dev", "wifi", "connect", ssid]
        if password: args.extend(["password", password])
        code, out, err = run(args, 30)
    elif IS_WINDOWS:
        return False, "Use Windows Wi-Fi Settings to enter credentials securely."
    else:
        return False, "Wi-Fi connection is unavailable on this system."
    return code == 0, (f"Connected to {ssid}." if code == 0 else err or out or "Connection failed.")


def bluetooth_tool():
    return shutil.which("blueutil") if IS_MAC else shutil.which("bluetoothctl") if IS_LINUX else None


def bluetooth_power():
    tool = bluetooth_tool()
    if IS_MAC and tool:
        code, out, _ = run([tool, "-p"]); return out == "1" if code == 0 else None
    if IS_LINUX and tool:
        code, out, _ = run([tool, "show"]); return "Powered: yes" in out if code == 0 else None
    return None


def set_bluetooth_power(enabled):
    tool = bluetooth_tool()
    if IS_MAC and tool: code, _, err = run([tool, "-p", "1" if enabled else "0"])
    elif IS_LINUX and tool: code, _, err = run([tool, "power", "on" if enabled else "off"])
    else: return False, "Bluetooth control is unavailable; open system settings instead."
    return code == 0, err or ("Bluetooth enabled." if enabled else "Bluetooth disabled.")


def bluetooth_devices():
    tool = bluetooth_tool(); devices = []
    if IS_MAC and tool:
        code, out, _ = run([tool, "--paired", "--format", "json"], 15)
        if code == 0:
            try:
                return [{"name": x.get("name") or x.get("address", "Bluetooth device"), "address": x.get("address", ""), "connected": bool(x.get("connected"))} for x in json.loads(out)]
            except (ValueError, TypeError): pass
    if IS_LINUX and tool:
        code, out, _ = run([tool, "devices", "Paired"], 15)
        if code == 0:
            for line in out.splitlines():
                parts = line.split(maxsplit=2)
                if len(parts) >= 3: devices.append({"name": parts[2], "address": parts[1], "connected": False})
    return devices


def connect_bluetooth(address):
    tool = bluetooth_tool()
    if IS_MAC and tool and address: code, _, err = run([tool, "--connect", address], 25)
    elif IS_LINUX and tool and address: code, _, err = run([tool, "connect", address], 25)
    else: return False, "Direct Bluetooth connection is unavailable."
    return code == 0, err or "Bluetooth device connected."


def open_bluetooth_settings():
    try:
        if IS_MAC: subprocess.Popen(["open", "x-apple.systempreferences:com.apple.Bluetooth-Settings"])
        elif IS_WINDOWS: os.startfile("ms-settings:bluetooth")
        elif IS_LINUX: subprocess.Popen([shutil.which("gnome-control-center") or "blueman-manager", "bluetooth"])
    except OSError:
        return False
    return True


def _windows_volume_key(key_code: int, presses: int) -> None:
    user32 = ctypes.windll.user32
    for _ in range(max(0, presses)):
        user32.keybd_event(key_code, 0, 0, 0)
        user32.keybd_event(key_code, 0, 2, 0)


def set_volume(value):
    value = max(0, min(100, int(value)))
    if IS_MAC:
        code, _, err = run(["osascript", "-e", f"set volume output volume {value}"])
    elif IS_LINUX and shutil.which("pactl"):
        code, _, err = run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{value}%"])
    elif IS_WINDOWS:
        try:
            # Windows has no stable stdlib API for absolute Core Audio volume.
            # Reset to zero then step up in ~2% media-key increments.
            _windows_volume_key(0xAE, 50)  # VK_VOLUME_DOWN
            _windows_volume_key(0xAF, round(value / 2))  # VK_VOLUME_UP
            return True, ""
        except (AttributeError, OSError) as exc:
            return False, str(exc)
    else:
        return False, "System volume control is unavailable on this platform."
    return code == 0, err


def set_brightness(value):
    value = max(0, min(100, int(value)))
    if IS_LINUX and shutil.which("brightnessctl"):
        code, _, err = run(["brightnessctl", "set", f"{value}%"]); return code == 0, err
    if IS_MAC and shutil.which("brightness"):
        code, _, err = run(["brightness", str(value / 100)]); return code == 0, err
    if IS_WINDOWS:
        script = (
            "$m=(Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightnessMethods);"
            f"if($m){{$m.WmiSetBrightness(1,{value})}}else{{exit 2}}"
        )
        code, _, err = run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], 12)
        return code == 0, err or ("Display brightness is not exposed by this device." if code == 2 else "")
    return False, "Physical brightness control is unavailable; simulated brightness remains active."
