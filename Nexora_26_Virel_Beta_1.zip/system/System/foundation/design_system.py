"""Semantic design tokens for Nexora 26 Beta 1.

This module is the single source of truth for geometry, spacing, colour,
material opacity and motion.  Runtime widgets consume these semantic values
instead of embedding unrelated pixel values throughout the project.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class DesignTokens:
    primary: str
    secondary: str
    accent: str
    danger: str
    warning: str
    success: str
    glass: str
    sidebar: str
    text: str
    subtext: str
    border: str
    hover: str
    pressed: str
    selection: str
    highlight: str
    animation_fast_ms: int
    animation_normal_ms: int
    animation_slow_ms: int
    blur_strength: int
    transparency: int
    corner_radius: int
    window_radius: int
    popup_radius: int
    control_radius: int
    avatar_radius: int
    spacing_xs: int
    spacing_sm: int
    spacing_md: int
    spacing_lg: int
    control_height: int
    compact_control_height: int
    icon_size: int
    sidebar_width: int
    titlebar_height: int
    dock_size: int
    shadow: int
    focus_width: int
    font_scale: float
    density: str

    @property
    def animation_speed_ms(self) -> int:
        """Compatibility alias used by older modules."""
        return self.animation_normal_ms

    @property
    def spacing(self) -> int:
        return self.spacing_md

    @property
    def padding(self) -> int:
        return self.spacing_md

    @property
    def opacity(self) -> int:
        return max(0, min(100, 100 - self.transparency))

    @property
    def depth(self) -> int:
        return max(0, self.shadow // 8)

    @property
    def glow(self) -> int:
        return max(0, self.shadow // 2)

    @property
    def taskbar_height(self) -> int:
        return self.dock_size

    @property
    def widget_radius(self) -> int:
        return self.popup_radius

    @property
    def notification_radius(self) -> int:
        return self.popup_radius

    def to_mapping(self) -> dict[str, Any]:
        return asdict(self)


BASE_GEOMETRY = {
    "corner_radius": 25,
    "window_radius": 25,
    "popup_radius": 25,
    "control_radius": 13,
    "control_height": 42,
    "compact_control_height": 34,
    "titlebar_height": 48,
    "sidebar_width": 220,
    "icon_size": 24,
    "dock_size": 44,
    "spacing_xs": 4,
    "spacing_sm": 8,
    "spacing_md": 12,
    "spacing_lg": 20,
}


def from_theme(theme, settings: Mapping[str, Any]) -> DesignTokens:
    density = str(settings.get("design_density", "comfortable"))
    density_factor = {"compact": 0.88, "comfortable": 1.0, "spacious": 1.14}.get(density, 1.0)
    motion_factor = max(0.25, min(2.5, float(settings.get("animation_speed", 1.0))))
    reduce_motion = bool(settings.get("reduce_motion", False)) or not bool(settings.get("animations", True))

    def scaled(name: str, minimum: int = 1) -> int:
        return max(minimum, round(BASE_GEOMETRY[name] * density_factor))

    normal = max(1, round(int(getattr(theme, "animation_ms", 260)) / motion_factor))
    if reduce_motion:
        normal = min(normal, 90)
    accent = str(getattr(theme, "accent", "#3F8CFF"))
    surface = str(getattr(theme, "surface", "#EEF3F8"))
    sidebar = str(getattr(theme, "sidebar", "#E4ECF4"))
    transparency = max(0, min(100, int(getattr(theme, "transparency", settings.get("glass_transparency", 48)))))
    if settings.get("disable_transparency"):
        transparency = 0

    return DesignTokens(
        primary=accent,
        secondary=surface,
        accent=accent,
        danger="#FF5F57",
        warning="#FEBC2E",
        success="#28C840",
        glass=surface,
        sidebar=sidebar,
        text=str(getattr(theme, "text", "#17191F")),
        subtext=str(getattr(theme, "muted", "#596170")),
        border=str(getattr(theme, "border", "#FFFFFF")),
        hover=accent,
        pressed=accent,
        selection=accent,
        highlight="#FFFFFF",
        animation_fast_ms=max(1, round(normal * 0.65)),
        animation_normal_ms=normal,
        animation_slow_ms=max(normal, round(normal * 1.45)),
        blur_strength=max(0, min(80, int(getattr(theme, "blur", settings.get("blur_radius", 48))))),
        transparency=transparency,
        corner_radius=scaled("corner_radius", 12),
        window_radius=max(12, int(settings.get("window_radius", scaled("window_radius", 12)))),
        popup_radius=max(12, int(settings.get("panel_radius", scaled("popup_radius", 12)))),
        control_radius=scaled("control_radius", 8),
        avatar_radius=999,
        spacing_xs=scaled("spacing_xs", 2),
        spacing_sm=scaled("spacing_sm", 4),
        spacing_md=scaled("spacing_md", 6),
        spacing_lg=scaled("spacing_lg", 10),
        control_height=scaled("control_height", 32),
        compact_control_height=scaled("compact_control_height", 28),
        icon_size=scaled("icon_size", 18),
        sidebar_width=max(176, int(getattr(theme, "sidebar_width", settings.get("sidebar_width", scaled("sidebar_width", 176))))),
        titlebar_height=max(38, int(getattr(theme, "titlebar_height", scaled("titlebar_height", 38)))),
        dock_size=max(32, int(getattr(theme, "dock_size", settings.get("taskbar_size", scaled("dock_size", 32))))),
        shadow=max(0, int(getattr(theme, "shadow_strength", settings.get("shadow_strength", 40)))),
        focus_width=2 if bool(settings.get("focus_ring", True)) else 0,
        font_scale=max(0.75, min(2.0, float(settings.get("ui_scale", 1.0)))) * (1.12 if settings.get("large_text") else 1.0),
        density=density,
    )


def default_tokens(*, dark: bool = False) -> DesignTokens:
    """Return stable fallback tokens for screens created before ThemeEngine."""
    class _Theme:
        accent = "#3F8CFF"
        surface = "#242A34" if dark else "#EEF3F8"
        sidebar = "#202630" if dark else "#E4ECF4"
        text = "#F7F8FC" if dark else "#17191F"
        muted = "#B7BFCC" if dark else "#596170"
        border = "#FFFFFF"
        animation_ms = 260
        blur = 60
        transparency = 20
        shadow_strength = 38
        sidebar_width = 220
        titlebar_height = 48
        dock_size = 44

    return from_theme(_Theme(), {
        "design_density": "comfortable",
        "animations": True,
        "animation_speed": 1.0,
        "window_radius": 25,
        "panel_radius": 25,
        "glass_transparency": 72,
        "blur_radius": 60,
    })
