"""Central version metadata for Nexora."""

VERSION = "26.0.0-beta.1"
NEXORA_VERSION = VERSION
CODENAME = "Beta 1"
DISPLAY_NAME = "Nexora 26 Beta 1"
BUILD = "26000.101"

__all__ = [
    "VERSION",
    "NEXORA_VERSION",
    "CODENAME",
    "DISPLAY_NAME",
    "BUILD",
    "__version__",
]

__version__ = VERSION
