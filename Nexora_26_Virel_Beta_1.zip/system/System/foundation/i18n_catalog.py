"""Stable-key Polish/English catalogue for newly migrated Nexora UI."""
from __future__ import annotations

CATALOG = {
    "en": {
        "common.open": "Open", "common.save": "Save", "common.cancel": "Cancel",
        "common.close": "Close", "common.retry": "Retry", "common.search": "Search",
        "palette.placeholder": "Type a command, app or setting…",
        "palette.no_results": "No matching actions",
        "crash.title": "Application stopped working",
        "crash.restart": "Restart application", "crash.clean_start": "Open without restoring document",
        "session.resume_all": "Resume everything", "session.resume_documents": "Resume documents only",
        "session.clean_desktop": "Start with a clean desktop",
        "settings.appearance.title": "Appearance", "settings.language.title": "Language",
        "files.new_folder": "New folder", "files.rename": "Rename", "files.move_to_trash": "Move to Trash",
    },
    "pl": {
        "common.open": "Otwórz", "common.save": "Zapisz", "common.cancel": "Anuluj",
        "common.close": "Zamknij", "common.retry": "Spróbuj ponownie", "common.search": "Szukaj",
        "palette.placeholder": "Wpisz polecenie, aplikację lub ustawienie…",
        "palette.no_results": "Brak pasujących akcji",
        "crash.title": "Aplikacja przestała działać",
        "crash.restart": "Uruchom aplikację ponownie", "crash.clean_start": "Otwórz bez przywracania dokumentu",
        "session.resume_all": "Wznów wszystko", "session.resume_documents": "Wznów tylko dokumenty",
        "session.clean_desktop": "Uruchom czysty pulpit",
        "settings.appearance.title": "Wygląd", "settings.language.title": "Język",
        "files.new_folder": "Nowy folder", "files.rename": "Zmień nazwę", "files.move_to_trash": "Przenieś do kosza",
    },
}


def tr_key(key: str, language: str = "en", **values: object) -> str:
    language = language if language in CATALOG else "en"
    text = CATALOG[language].get(key, CATALOG["en"].get(key, key))
    try:
        return text.format(**values)
    except (KeyError, ValueError):
        return text


def completeness(language: str) -> float:
    base = set(CATALOG["en"])
    translated = set(CATALOG.get(language, {}))
    return 1.0 if not base else len(base & translated) / len(base)
