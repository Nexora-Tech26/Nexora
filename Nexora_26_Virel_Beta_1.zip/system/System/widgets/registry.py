"""Desktop widget registry and refresh policy."""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Callable

class WidgetSize(str,Enum):
    SMALL="small"; MEDIUM="medium"; LARGE="large"; WIDE="wide"

@dataclass(frozen=True)
class WidgetSpec:
    key:str; title:str; sizes:tuple[WidgetSize,...]; refresh_seconds:int=0; factory:Callable|None=None

class WidgetRegistry:
    def __init__(self): self._items={}
    def register(self,spec:WidgetSpec):
        if spec.key in self._items: raise ValueError(f"Widget already registered: {spec.key}")
        self._items[spec.key]=spec
    def get(self,key): return self._items[key]
    def all(self): return tuple(self._items.values())

DEFAULT_WIDGETS=(
    ("digital_clock","Digital clock",(WidgetSize.SMALL,WidgetSize.MEDIUM,WidgetSize.WIDE),1),
    ("analog_clock","Analog clock",(WidgetSize.SMALL,WidgetSize.LARGE),1),
    ("calendar","Calendar",(WidgetSize.MEDIUM,WidgetSize.LARGE),60),
    ("weather","Weather",(WidgetSize.MEDIUM,WidgetSize.LARGE,WidgetSize.WIDE),900),
    ("cpu","CPU",(WidgetSize.SMALL,WidgetSize.MEDIUM),2),
    ("ram","RAM",(WidgetSize.SMALL,WidgetSize.MEDIUM),2),
    ("disk","Disk",(WidgetSize.SMALL,WidgetSize.MEDIUM),10),
    ("battery","Battery",(WidgetSize.SMALL,WidgetSize.MEDIUM),10),
    ("network","Network",(WidgetSize.SMALL,WidgetSize.MEDIUM),2),
    ("notes","Quick notes",(WidgetSize.MEDIUM,WidgetSize.LARGE,WidgetSize.WIDE),0),
    ("tasks","Tasks",(WidgetSize.MEDIUM,WidgetSize.LARGE),0),
    ("recent_files","Recent files",(WidgetSize.MEDIUM,WidgetSize.LARGE),30),
    ("music","Music",(WidgetSize.MEDIUM,WidgetSize.WIDE),1),
    ("shortcuts","App shortcuts",(WidgetSize.MEDIUM,WidgetSize.LARGE),0),
    ("photos","Photos",(WidgetSize.MEDIUM,WidgetSize.LARGE),60),
    ("timer","Timer",(WidgetSize.SMALL,WidgetSize.MEDIUM),1),
    ("stopwatch","Stopwatch",(WidgetSize.SMALL,WidgetSize.MEDIUM),1),
    ("gpu","GPU",(WidgetSize.SMALL,WidgetSize.MEDIUM),3),
    ("wifi","Wi-Fi",(WidgetSize.SMALL,WidgetSize.MEDIUM),5),
    ("bluetooth","Bluetooth",(WidgetSize.SMALL,WidgetSize.MEDIUM),10),
    ("vpn","VPN",(WidgetSize.SMALL,WidgetSize.MEDIUM),10),
    ("clipboard","Clipboard",(WidgetSize.MEDIUM,WidgetSize.LARGE),2),
    ("quick_actions","Quick Actions",(WidgetSize.MEDIUM,WidgetSize.LARGE),0),
    ("terminal","Terminal",(WidgetSize.MEDIUM,WidgetSize.WIDE),0),
    ("github","GitHub",(WidgetSize.MEDIUM,WidgetSize.LARGE),60),
    ("discord","Discord",(WidgetSize.MEDIUM,WidgetSize.LARGE),60),
    ("spotify","Spotify",(WidgetSize.MEDIUM,WidgetSize.WIDE),10),
    ("steam","Steam",(WidgetSize.MEDIUM,WidgetSize.LARGE),60),
    ("news","News",(WidgetSize.MEDIUM,WidgetSize.LARGE,WidgetSize.WIDE),900),
    ("rss","RSS",(WidgetSize.MEDIUM,WidgetSize.LARGE,WidgetSize.WIDE),900),
    ("gallery","Gallery",(WidgetSize.MEDIUM,WidgetSize.LARGE),60),
    ("downloads","Downloads",(WidgetSize.MEDIUM,WidgetSize.LARGE),30),
    ("system_health","System Health",(WidgetSize.MEDIUM,WidgetSize.LARGE),30),
)

def create_default_registry():
    registry=WidgetRegistry()
    for key,title,sizes,refresh in DEFAULT_WIDGETS: registry.register(WidgetSpec(key,title,sizes,refresh))
    return registry
