"""Cancellable launcher search primitives."""
from __future__ import annotations

from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path

from PySide6.QtCore import QThread, Signal


@dataclass(frozen=True)
class LauncherResult:
    kind: str
    title: str
    subtitle: str
    payload: object
    score: float
    icon_name: str = ""


def fuzzy_score(query: str, text: str) -> float:
    query = query.casefold().strip()
    text = text.casefold().strip()
    if not query:
        return 0.0
    if text == query:
        return 100.0
    score = SequenceMatcher(None, query, text).ratio() * 58.0
    if text.startswith(query):
        score += 32.0
    elif query in text:
        score += 20.0
    words = text.replace("_", " ").replace("-", " ").split()
    if any(word.startswith(query) for word in words):
        score += 12.0
    return min(100.0, score)


class FileSearchThread(QThread):
    batchReady = Signal(int, list)
    complete = Signal(int)

    def __init__(self, generation: int, root: Path, query: str, *, show_hidden: bool = False, limit: int = 80, parent=None):
        super().__init__(parent)
        self.generation = generation
        self.root = Path(root)
        self.query = query.casefold().strip()
        self.show_hidden = show_hidden
        self.limit = max(1, int(limit))

    def run(self) -> None:
        if not self.query or not self.root.exists():
            self.complete.emit(self.generation)
            return
        batch: list[LauncherResult] = []
        emitted = 0
        try:
            for path in self.root.rglob("*"):
                if self.isInterruptionRequested():
                    break
                try:
                    relative = path.relative_to(self.root)
                except ValueError:
                    continue
                if not self.show_hidden and any(part.startswith(".") for part in relative.parts):
                    continue
                score = fuzzy_score(self.query, path.name)
                if score < 34:
                    continue
                try:
                    subtitle = str(relative.parent) if str(relative.parent) != "." else "Home"
                    if path.is_file():
                        subtitle += f" · {path.stat().st_size / 1024:.1f} KB"
                except OSError:
                    subtitle = str(relative.parent)
                batch.append(LauncherResult("file", path.name, subtitle, path, score, "Files"))
                emitted += 1
                if len(batch) >= 8:
                    self.batchReady.emit(self.generation, sorted(batch, key=lambda item: item.score, reverse=True))
                    batch = []
                if emitted >= self.limit:
                    break
        except OSError:
            pass
        if batch and not self.isInterruptionRequested():
            self.batchReady.emit(self.generation, sorted(batch, key=lambda item: item.score, reverse=True))
        self.complete.emit(self.generation)
