"""Central motion tokens for Nexora's premium desktop experience.

The values intentionally avoid long, theatrical transitions. They are tuned for
responsive desktop interaction and can be disabled through the existing
``reduce_motion`` setting.
"""
from __future__ import annotations

from dataclasses import dataclass

from PySide6.QtCore import QEasingCurve


@dataclass(frozen=True)
class MotionTokens:
    instant: int = 90
    fast: int = 145
    standard: int = 210
    emphasized: int = 280
    window_open: int = 230
    window_close: int = 175
    menu_open: int = 220
    menu_close: int = 175
    toast_in: int = 220
    toast_out: int = 170
    hover: int = 120


MOTION = MotionTokens()


def enter_curve() -> QEasingCurve:
    """Smooth deceleration similar to native desktop surface animations."""
    return QEasingCurve(QEasingCurve.OutQuart)


def exit_curve() -> QEasingCurve:
    """Faster acceleration for dismissing transient surfaces."""
    return QEasingCurve(QEasingCurve.InCubic)


def emphasized_curve() -> QEasingCurve:
    """Subtle overshoot for large surfaces without a cartoon-like bounce."""
    curve = QEasingCurve(QEasingCurve.BezierSpline)
    from PySide6.QtCore import QPointF
    curve.addCubicBezierSegment(QPointF(0.16, 1.0), QPointF(0.30, 1.0), QPointF(1.0, 1.0))
    return curve
