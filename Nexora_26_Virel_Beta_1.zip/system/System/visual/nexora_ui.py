"""Shared visual primitives for Nexora 29.

The module centralises gradients, glass surfaces and shadows so desktop,
applications and in-system dialogs use one consistent visual language.
"""
from __future__ import annotations

from PySide6.QtGui import QColor
from PySide6.QtWidgets import QGraphicsDropShadowEffect, QWidget


def rgba(hex_color: str, alpha: int) -> str:
    color = QColor(hex_color)
    return f"rgba({color.red()},{color.green()},{color.blue()},{max(0, min(255, alpha))})"


def apply_shadow(widget: QWidget, *, blur: int = 34, y: int = 10, alpha: int = 125) -> QGraphicsDropShadowEffect:
    """Attach one soft macOS-like shadow to a widget."""
    effect = QGraphicsDropShadowEffect(widget)
    effect.setBlurRadius(blur)
    effect.setOffset(0, y)
    effect.setColor(QColor(0, 0, 0, alpha))
    widget.setGraphicsEffect(effect)
    return effect


def glass_panel_style(*, light: bool, radius: int = 16, alpha: int = 36, border_alpha: int = 58) -> str:
    text = "#17191F" if light else "#F4F4F5"
    # Reference pastel glass: cool cyan, soft blush and lilac at low opacity.
    top = f"rgba(190,229,238,{alpha})" if light else f"rgba(18,21,29,{min(190, alpha + 66)})"
    bottom = f"rgba(224,218,246,{max(12, alpha - 4)})" if light else f"rgba(8,10,15,{min(205, alpha + 82)})"
    return (
        "background:qlineargradient(x1:0,y1:0,x2:1,y2:1,"
        f"stop:0 {top},stop:1 {bottom});"
        f"color:{text};border:none;"
        f"border-radius:{radius}px;"
    )


def gradient_button_style(primary: str, *, radius: int = 12, text: str = "#17191F") -> str:
    c = QColor(primary)
    secondary = c.lighter(124).name()
    hover = c.lighter(110).name()
    return (
        f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {primary},stop:1 {secondary});"
        f"color:{text};border:none;border-radius:{radius}px;padding:8px 12px;}}"
        f"QPushButton:hover{{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {hover},stop:1 {secondary});"
        "border:none;}}"
        f"QPushButton:pressed{{background:{c.darker(108).name()};}}"
    )


def dock_button_style(primary: str, *, radius: int = 12) -> str:
    """Stable dock tile style: running state is represented only by dots."""
    c = QColor(primary)
    a = c.lighter(128).name()
    b = c.lighter(146).name()
    hover_a = c.lighter(112).name()
    hover_b = c.lighter(128).name()
    return (
        f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {a},stop:1 {b});"
        f"border:none;border-radius:{radius}px;}}"
        f"QPushButton:hover{{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {hover_a},stop:1 {hover_b});"
        "border:none;}}"
        "QPushButton:pressed{padding-top:1px;}"
    )
