"""Shared visual primitives and motion definitions."""
