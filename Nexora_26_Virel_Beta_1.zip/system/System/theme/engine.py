"""Live theme definitions and interpolation for Nexora 26 Beta 1 ."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Mapping

from PySide6.QtCore import QObject, QEasingCurve, Signal, QVariantAnimation
from PySide6.QtGui import QColor


@dataclass(frozen=True)
class ThemeDefinition:
    key: str
    name: str
    mode: str = "light"
    accent: str = "#3F8CFF"
    background: str = "#DDE7F2"
    background_alt: str = "#EEF2F7"
    surface: str = "#E0E8F1"
    sidebar: str = "#D8E2ED"
    text: str = "#111318"
    muted: str = "#596170"
    border: str = "#FFFFFF"
    transparency: int = 48
    blur: int = 48
    saturation: int = 112
    window_radius: int = 32
    panel_radius: int = 36
    control_radius: int = 20
    border_width: int = 1
    shadow_strength: int = 0
    dock_position: str = "bottom"
    dock_size: int = 48
    sidebar_width: int = 220
    titlebar_height: int = 50
    font_family: str = "Gugi"
    font_scale: float = 1.0
    spacing_scale: float = 1.0
    animation_ms: int = 120
    easing: str = "out_cubic"
    hover_lift: int = 0
    minimal_effects: bool = True
    surface_brightness: int = 100
    text_contrast: int = 100


THEMES: dict[str, ThemeDefinition] = {
    "cloud_light": ThemeDefinition(
        "cloud_light", "Cloud Light", mode="light", accent="#55A7FF",
        background="#DDEEFF", background_alt="#F7FBFF", surface="#EDF7FF",
        sidebar="#D7EBFA", text="#14243A", muted="#627A91", border="#B9D8EF",
        transparency=48, blur=48, saturation=108, window_radius=18, panel_radius=20,
        control_radius=20, border_width=0, shadow_strength=20, dock_size=44, sidebar_width=228,
        animation_ms=120,
    ),
    "cosmic_dark": ThemeDefinition(
        "cosmic_dark", "Space Dark", mode="dark", accent="#8A7CFF",
        background="#0B1020", background_alt="#121933", surface="#18213D",
        sidebar="#111A31", text="#F5F7FF", muted="#A7B1D2", border="#39466E",
        transparency=48, blur=48, saturation=122, window_radius=18, panel_radius=20,
        control_radius=20, border_width=0, shadow_strength=28, dock_size=44, sidebar_width=228,
        animation_ms=180,
    ),
    "nexora_glass": ThemeDefinition("nexora_glass", "Nexora Glass"),
    "one_ui": ThemeDefinition("one_ui", "One UI", surface="#E7EBF0", sidebar="#E1E6EC", transparency=88, blur=28, window_radius=18, panel_radius=20, control_radius=20, sidebar_width=270, titlebar_height=66, font_scale=1.06, spacing_scale=1.12),
    "macos": ThemeDefinition("macos", "macOS", surface="#E6EDF4", sidebar="#DCE6EF", transparency=74, blur=50, window_radius=20, panel_radius=18, control_radius=11, dock_position="bottom", dock_size=54, sidebar_width=220, titlebar_height=50),
    "windows": ThemeDefinition("windows", "Windows", background="#DCE7F2", surface="#E8EEF5", sidebar="#DFE8F1", transparency=82, blur=36, window_radius=12, panel_radius=12, control_radius=8, dock_size=46, sidebar_width=232, titlebar_height=48),
    "graphite": ThemeDefinition("graphite", "Graphite", mode="dark", accent="#8EA4C7", background="#15181D", background_alt="#1D2229", surface="#252B33", sidebar="#20262D", text="#F5F7FA", muted="#ABB4C0", border="#56606D", transparency=42, blur=20, saturation=70, window_radius=16, panel_radius=14, control_radius=9, shadow_strength=48),
    "aurora": ThemeDefinition("aurora", "Aurora", mode="dark", accent="#8F7CFF", background="#111326", background_alt="#181A31", surface="#28304B", sidebar="#202843", text="#FFFFFF", muted="#C9CDE5", border="#8AB4F8", transparency=64, blur=54, saturation=135, window_radius=18, panel_radius=24, control_radius=16, shadow_strength=78, dock_size=58, animation_ms=410, hover_lift=4),
    "minimal": ThemeDefinition("minimal", "Minimal", surface="#EDF1F5", sidebar="#E8EDF2", transparency=96, blur=0, saturation=100, window_radius=12, panel_radius=10, control_radius=7, shadow_strength=10, animation_ms=180, hover_lift=0, minimal_effects=True),
}



def _adjust_color(value: str, brightness: int) -> str:
    """Adjust a color around 100 without destroying its hue."""
    color = QColor(value)
    amount = max(55, min(145, int(brightness)))
    if amount == 100:
        return color.name(QColor.HexArgb if color.alpha() != 255 else QColor.HexRgb)
    target = QColor("#FFFFFF" if amount > 100 else "#000000")
    strength = abs(amount - 100) / (45 if amount > 100 else 55)
    strength = max(0.0, min(0.82, strength * 0.72))
    mixed = QColor(
        round(color.red() + (target.red() - color.red()) * strength),
        round(color.green() + (target.green() - color.green()) * strength),
        round(color.blue() + (target.blue() - color.blue()) * strength),
        color.alpha(),
    )
    return mixed.name(QColor.HexArgb if mixed.alpha() != 255 else QColor.HexRgb)


def _contrast_color(value: str, contrast: int, *, dark: bool) -> str:
    color = QColor(value)
    amount = max(70, min(140, int(contrast)))
    target = QColor("#FFFFFF" if dark else "#000000")
    strength = max(0.0, min(0.58, (amount - 70) / 70 * 0.58))
    mixed = QColor(
        round(color.red() + (target.red() - color.red()) * strength),
        round(color.green() + (target.green() - color.green()) * strength),
        round(color.blue() + (target.blue() - color.blue()) * strength),
        color.alpha(),
    )
    return mixed.name(QColor.HexArgb if mixed.alpha() != 255 else QColor.HexRgb)

def _color_mix(a: str, b: str, t: float) -> str:
    ca, cb = QColor(a), QColor(b)
    return QColor(round(ca.red() + (cb.red() - ca.red()) * t), round(ca.green() + (cb.green() - ca.green()) * t), round(ca.blue() + (cb.blue() - ca.blue()) * t), round(ca.alpha() + (cb.alpha() - ca.alpha()) * t)).name(QColor.HexArgb if ca.alpha() != 255 or cb.alpha() != 255 else QColor.HexRgb)


class ThemeEngine(QObject):
    themeChanged = Signal(object)
    transitionFrame = Signal(object)
    transitionFinished = Signal(object)

    def __init__(self, settings_store, parent=None):
        super().__init__(parent)
        self.settings_store = settings_store
        self._animation: QVariantAnimation | None = None
        self._custom: ThemeDefinition | None = None
        self.current = self.resolve(settings_store.snapshot())

    @staticmethod
    def available() -> tuple[ThemeDefinition, ...]:
        return tuple(THEMES.values())

    def tokens(self, settings: Mapping[str, Any] | None = None):
        """Return semantic design tokens for the current or supplied settings."""
        from System.foundation.design_system import from_theme
        snapshot = dict(settings or self.settings_store.snapshot())
        return from_theme(self.resolve(snapshot), snapshot)

    def resolve(self, settings: Mapping[str, Any]) -> ThemeDefinition:
        key = str(settings.get("ui_style", "nexora_glass"))
        base = self._custom if key == "custom" and self._custom else THEMES.get(key, THEMES["nexora_glass"])
        profile = str(settings.get("performance_mode", "balanced"))
        blur = int(settings.get("blur_radius", base.blur))
        shadow = int(settings.get("shadow_strength", base.shadow_strength))
        animation_ms = round(base.animation_ms / max(0.25, float(settings.get("animation_speed", 1.0))))
        minimal = bool(base.minimal_effects)
        if profile == "performance":
            shadow, animation_ms, minimal = min(shadow, 24), min(animation_ms, 220), True
        elif profile == "battery_saver":
            blur, shadow, animation_ms, minimal = 0, 0, min(animation_ms, 140), True
        elif profile == "balanced":
            shadow = min(shadow, 68)
        if settings.get("disable_transparency"):
            blur = 0
        if settings.get("reduce_motion") or not settings.get("animations", True):
            animation_ms = 0
        mode = str(settings.get("theme_mode", base.mode))
        high_contrast = bool(settings.get("high_contrast"))
        dark = mode == "dark" or (mode == "auto" and base.mode == "dark")
        surface_brightness = max(65, min(135, int(settings.get("surface_brightness", 100))))
        text_contrast = max(70, min(140, int(settings.get("text_contrast", 100))))

        if high_contrast:
            background = "#08090B" if dark else "#FFFFFF"
            background_alt = "#101216" if dark else "#F5F6F8"
            surface = "#151820" if dark else "#FFFFFF"
            sidebar = "#0F1117" if dark else "#F0F2F5"
            text = "#FFFFFF" if dark else "#000000"
            muted = "#E1E5EC" if dark else "#30343B"
            border = "#FFFFFF" if dark else "#000000"
        elif dark and base.mode != "dark":
            background, background_alt = "#10151D", "#171D27"
            surface, sidebar = "#202A36", "#1B2530"
            text, muted, border = "#F4F7FB", "#A8B2C0", "#6F8197"
        elif not dark and base.mode == "dark":
            background, background_alt = "#E7EDF4", "#F3F6F9"
            surface, sidebar = "#E9EFF5", "#E1E9F1"
            text, muted, border = "#151920", "#5E6876", "#FFFFFF"
        else:
            background, background_alt = base.background, base.background_alt
            surface, sidebar = base.surface, base.sidebar
            text, muted, border = base.text, base.muted, base.border

        background = _adjust_color(background, surface_brightness)
        background_alt = _adjust_color(background_alt, surface_brightness)
        surface = _adjust_color(surface, surface_brightness)
        sidebar = _adjust_color(sidebar, surface_brightness)
        border = _adjust_color(border, min(125, surface_brightness + 5))
        text = _contrast_color(text, text_contrast, dark=dark)
        muted = _contrast_color(muted, max(75, text_contrast - 8), dark=dark)

        return replace(base,
            mode=mode,
            accent=str(settings.get("accent_color", base.accent)),
            background=background,
            background_alt=background_alt,
            surface=surface,
            sidebar=sidebar,
            text=text,
            muted=muted,
            border=border,
            transparency=88,
            blur=max(72, blur),
            saturation=int(settings.get("material_saturation", base.saturation)),
            window_radius=28,
            panel_radius=28,
            control_radius=max(20, min(26, int(settings.get("control_radius", getattr(base, "control_radius", 22))))),
            border_width=max(2 if high_contrast else 0, int(settings.get("border_width", base.border_width))),
            shadow_strength=shadow,
            dock_position=str(settings.get("dock_position", base.dock_position)),
            dock_size=int(settings.get("taskbar_size", base.dock_size)),
            font_family=str(settings.get("font_family", base.font_family)),
            font_scale=float(settings.get("ui_scale", 1.0)) * (1.15 if settings.get("large_text") else 1.0),
            animation_ms=max(0, animation_ms),
            minimal_effects=minimal,
            surface_brightness=surface_brightness,
            text_contrast=text_contrast,
        )

    def preview(self, settings: Mapping[str, Any], *, animate: bool = True) -> ThemeDefinition:
        """Preview settings without writing them to the SettingsStore."""
        target = self.resolve(settings)
        if not animate or settings.get("reduce_motion") or not settings.get("animations", True):
            self.current = target
            self.transitionFrame.emit(target)
            return target
        self._start_transition(target)
        return target

    def apply(self, key: str, *, animate: bool = True, overrides: Mapping[str, Any] | None = None) -> ThemeDefinition:
        values = {"ui_style": key}
        if overrides:
            values.update(overrides)
        snapshot = self.settings_store.update(values)
        target = self.resolve(snapshot)
        if not animate or snapshot.get("reduce_motion") or not snapshot.get("animations", True):
            self.current = target
            self.themeChanged.emit(target)
            self.transitionFinished.emit(target)
            return target
        self._start_transition(target)
        return target

    def _start_transition(self, target: ThemeDefinition) -> None:
        if self._animation is not None:
            self._animation.stop()
            self._animation.deleteLater()
        start = self.current
        animation = QVariantAnimation(self)
        animation.setStartValue(0.0)
        animation.setEndValue(1.0)
        animation.setDuration(max(250, min(450, int(target.animation_ms))))
        animation.setEasingCurve(QEasingCurve.OutCubic)
        def frame(value):
            t = float(value)
            mixed = replace(target,
                accent=_color_mix(start.accent, target.accent, t),
                background=_color_mix(start.background, target.background, t),
                background_alt=_color_mix(start.background_alt, target.background_alt, t),
                surface=_color_mix(start.surface, target.surface, t),
                sidebar=_color_mix(start.sidebar, target.sidebar, t),
                text=_color_mix(start.text, target.text, t),
                muted=_color_mix(start.muted, target.muted, t),
                border=_color_mix(start.border, target.border, t),
                transparency=round(start.transparency + (target.transparency-start.transparency)*t),
                blur=round(start.blur + (target.blur-start.blur)*t),
                window_radius=round(start.window_radius + (target.window_radius-start.window_radius)*t),
                panel_radius=round(start.panel_radius + (target.panel_radius-start.panel_radius)*t),
                surface_brightness=round(start.surface_brightness + (target.surface_brightness-start.surface_brightness)*t),
                text_contrast=round(start.text_contrast + (target.text_contrast-start.text_contrast)*t),
            )
            self.current = mixed
            self.transitionFrame.emit(mixed)
        def done():
            self.current = target
            self.themeChanged.emit(target)
            self.transitionFinished.emit(target)
            self._animation = None
        animation.valueChanged.connect(frame)
        animation.finished.connect(done)
        self._animation = animation
        animation.start()

    def export_theme(self, path: Path, theme: ThemeDefinition | None = None) -> Path:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        payload = {"schema": 1, "theme": asdict(theme or self.current)}
        tmp = target.with_suffix(target.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        tmp.replace(target)
        return target

    def load_theme(self, path: Path) -> ThemeDefinition:
        """Validate a theme file and load it as the in-memory Custom preset.

        Loading does not persist or apply settings, which lets Settings present
        a real preview with Apply/Revert semantics.
        """
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or payload.get("schema") != 1 or not isinstance(payload.get("theme"), dict):
            raise ValueError("Unsupported Nexora theme file")
        data = dict(payload["theme"])
        required = set(ThemeDefinition.__dataclass_fields__)
        if not required <= set(data):
            missing = ", ".join(sorted(required - set(data)))
            raise ValueError(f"Theme file is incomplete: {missing}")
        data["key"] = "custom"
        data["name"] = str(data.get("name") or "Custom")
        try:
            theme = ThemeDefinition(**{key: data[key] for key in required})
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Invalid Nexora theme: {exc}") from exc
        if theme.dock_position not in {"bottom", "top", "left", "right"}:
            raise ValueError("Theme dock_position is invalid")
        if not 0 <= int(theme.transparency) <= 100 or not 0 <= int(theme.blur) <= 80:
            raise ValueError("Theme transparency or blur is outside the supported range")
        self._custom = theme
        return theme

    def import_theme(self, path: Path, *, apply: bool = True) -> ThemeDefinition:
        theme = self.load_theme(path)
        if apply:
            self.apply("custom")
        return theme
