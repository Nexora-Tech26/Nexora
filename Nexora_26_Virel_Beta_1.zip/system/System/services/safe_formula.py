from __future__ import annotations

import ast
import math
import re
from dataclasses import dataclass
from typing import Callable, Iterable

CELL_RE = re.compile(r"^[A-Z]+[1-9][0-9]*$")
RANGE_RE = re.compile(r"^([A-Z]+[1-9][0-9]*):([A-Z]+[1-9][0-9]*)$")


class FormulaError(ValueError):
    """Raised when a spreadsheet formula is invalid or unsafe."""


@dataclass(frozen=True)
class CellAddress:
    row: int
    column: int


def column_to_index(name: str) -> int:
    result = 0
    for char in name.upper():
        if not ("A" <= char <= "Z"):
            raise FormulaError(f"Invalid column: {name}")
        result = result * 26 + (ord(char) - 64)
    return result - 1


def parse_cell(reference: str) -> CellAddress:
    match = re.fullmatch(r"([A-Z]+)([1-9][0-9]*)", reference.upper())
    if not match:
        raise FormulaError(f"Invalid cell reference: {reference}")
    return CellAddress(int(match.group(2)) - 1, column_to_index(match.group(1)))


def iter_range(reference: str) -> Iterable[str]:
    match = RANGE_RE.fullmatch(reference.upper())
    if not match:
        raise FormulaError(f"Invalid range: {reference}")
    start = parse_cell(match.group(1))
    end = parse_cell(match.group(2))
    r1, r2 = sorted((start.row, end.row))
    c1, c2 = sorted((start.column, end.column))
    for row in range(r1, r2 + 1):
        for column in range(c1, c2 + 1):
            n = column + 1
            letters = ""
            while n:
                n, remainder = divmod(n - 1, 26)
                letters = chr(65 + remainder) + letters
            yield f"{letters}{row + 1}"


class SafeFormulaEvaluator:
    """Small arithmetic formula engine without eval()."""

    FUNCTIONS = {"SUM", "AVERAGE", "MIN", "MAX", "COUNT"}

    def __init__(self, cell_value: Callable[[str], float], *, max_nodes: int = 256):
        self.cell_value = cell_value
        self.max_nodes = max_nodes

    def evaluate(self, formula: str) -> float:
        expression = formula.strip()
        if expression.startswith("="):
            expression = expression[1:].strip()
        if not expression:
            raise FormulaError("Formula is empty")
        self._ranges: dict[str, tuple[str, str]] = {}
        expression = self._replace_ranges(expression)
        expression = re.sub(
            r"\b([A-Za-z]+[1-9][0-9]*)\b",
            lambda match: f'CELL("{match.group(1).upper()}")',
            expression,
        )
        try:
            tree = ast.parse(expression, mode="eval")
        except SyntaxError as exc:
            raise FormulaError("Invalid formula syntax") from exc
        if sum(1 for _ in ast.walk(tree)) > self.max_nodes:
            raise FormulaError("Formula is too complex")
        value = self._visit(tree.body)
        if not math.isfinite(value):
            raise FormulaError("Formula returned a non-finite number")
        return value

    def _replace_ranges(self, expression: str) -> str:
        pattern = re.compile(r"\b(SUM|AVERAGE|MIN|MAX|COUNT)\s*\(\s*([A-Za-z]+[1-9][0-9]*:[A-Za-z]+[1-9][0-9]*)\s*\)", re.I)
        def replace(match):
            token = f"RANGEFUNC_{len(self._ranges)}"
            self._ranges[token] = (match.group(1).upper(), match.group(2).upper())
            return f"{token}()"
        return pattern.sub(replace, expression)

    def _visit(self, node: ast.AST) -> float:
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return float(node.value)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            value = self._visit(node.operand)
            return value if isinstance(node.op, ast.UAdd) else -value
        if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow)):
            left, right = self._visit(node.left), self._visit(node.right)
            if isinstance(node.op, ast.Add): return left + right
            if isinstance(node.op, ast.Sub): return left - right
            if isinstance(node.op, ast.Mult): return left * right
            if isinstance(node.op, ast.Div): return left / right
            if isinstance(node.op, ast.FloorDiv): return left // right
            if isinstance(node.op, ast.Mod): return left % right
            if abs(right) > 12:
                raise FormulaError("Exponent is too large")
            return left ** right
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            name = node.func.id.upper()
            if name == "CELL" and len(node.args) == 1 and isinstance(node.args[0], ast.Constant):
                return float(self.cell_value(str(node.args[0].value)))
            if name in self._ranges and not node.args:
                function_name, range_reference = self._ranges[name]
                values = [float(self.cell_value(ref)) for ref in iter_range(range_reference)]
                if function_name == "SUM": return sum(values)
                if function_name == "AVERAGE": return sum(values) / len(values) if values else 0.0
                if function_name == "MIN": return min(values) if values else 0.0
                if function_name == "MAX": return max(values) if values else 0.0
                return float(len(values))
        raise FormulaError("Unsupported formula operation")
