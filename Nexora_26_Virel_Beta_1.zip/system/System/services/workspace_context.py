"""Local Continuity Workspace snapshots with validation and recovery."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any


_ALLOWED_KEYS = {"open_apps", "documents", "windows", "tabs", "scroll", "workspace", "sidebars", "drafts"}


class WorkspaceContextStore:
    def __init__(self, data_dir: Path) -> None:
        self.path = Path(data_dir) / "workspace_context.json"
        self.backup = self.path.with_suffix(".bak")

    def save(self, context: dict[str, Any]) -> None:
        clean = {key: self._safe_value(value) for key, value in context.items() if key in _ALLOWED_KEYS}
        payload = {"schema": 1, "saved_at": time.time(), "context": clean}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        if self.path.exists():
            self.backup.write_bytes(self.path.read_bytes())
        os.replace(temp, self.path)

    def load(self) -> dict[str, Any]:
        for candidate in (self.path, self.backup):
            try:
                payload = json.loads(candidate.read_text(encoding="utf-8"))
            except (OSError, ValueError, TypeError):
                continue
            if isinstance(payload, dict) and payload.get("schema") == 1 and isinstance(payload.get("context"), dict):
                return {key: value for key, value in payload["context"].items() if key in _ALLOWED_KEYS}
        return {}

    def clear(self) -> None:
        for path in (self.path, self.backup):
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass

    @classmethod
    def _safe_value(cls, value: Any) -> Any:
        if value is None or isinstance(value, (bool, int, float, str)):
            return value
        if isinstance(value, list):
            return [cls._safe_value(item) for item in value[:500]]
        if isinstance(value, dict):
            return {str(k)[:100]: cls._safe_value(v) for k, v in list(value.items())[:500]}
        return str(value)
