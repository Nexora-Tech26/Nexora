from __future__ import annotations

import json
import os
import tempfile
import time
from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping


SENSITIVE_KEYS = {"password", "token", "secret", "api_key", "credential"}


class SettingsHistory:
    """Local, bounded Time Travel history for non-sensitive settings."""

    def __init__(self, path: Path, limit: int = 50):
        self.path = Path(path)
        self.limit = max(5, int(limit))

    def record(self, before: Mapping[str, Any], after: Mapping[str, Any], reason: str = "user") -> None:
        changes = {}
        for key in sorted(set(before) | set(after)):
            if any(fragment in key.lower() for fragment in SENSITIVE_KEYS):
                continue
            if before.get(key) != after.get(key):
                changes[key] = {"before": deepcopy(before.get(key)), "after": deepcopy(after.get(key))}
        if not changes:
            return
        history = self.load()
        history.insert(0, {"timestamp": time.time(), "reason": reason, "changes": changes})
        self._save(history[: self.limit])

    def load(self) -> list[dict[str, Any]]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            return raw if isinstance(raw, list) else []
        except (OSError, ValueError):
            return []

    def restore(self, current: Mapping[str, Any], index: int = 0) -> dict[str, Any]:
        history = self.load()
        if not 0 <= index < len(history):
            raise IndexError("Settings history entry does not exist")
        restored = dict(current)
        for key, values in history[index].get("changes", {}).items():
            restored[key] = deepcopy(values.get("before"))
        return restored

    def _save(self, history: list[dict[str, Any]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=self.path.name, suffix=".tmp", dir=self.path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(history, stream, ensure_ascii=False, indent=2)
                stream.flush(); os.fsync(stream.fileno())
            os.replace(temp_name, self.path)
        finally:
            try: os.unlink(temp_name)
            except FileNotFoundError: pass
