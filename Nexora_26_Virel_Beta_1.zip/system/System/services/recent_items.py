from __future__ import annotations

import json
import os
import tempfile
import time
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass
class RecentItem:
    kind: str
    target: str
    title: str
    opened_at: float
    pinned: bool = False


class RecentItemsStore:
    def __init__(self, path: Path, limit: int = 100):
        self.path = Path(path)
        self.limit = max(10, limit)

    def load(self) -> list[RecentItem]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            return [RecentItem(**item) for item in raw if isinstance(item, dict)]
        except (OSError, ValueError, TypeError):
            return []

    def add(self, kind: str, target: str, title: str | None = None) -> None:
        normalized = str(Path(target).expanduser()) if kind in {"file", "folder", "project"} else target
        items = [item for item in self.load() if not (item.kind == kind and item.target == normalized)]
        items.insert(0, RecentItem(kind, normalized, title or Path(normalized).name or normalized, time.time()))
        pinned = [item for item in items if item.pinned]
        regular = [item for item in items if not item.pinned][: self.limit]
        self._save(pinned + regular)

    def remove(self, kind: str, target: str) -> None:
        self._save([item for item in self.load() if not (item.kind == kind and item.target == target)])

    def clear(self, *, keep_pinned: bool = True) -> None:
        self._save([item for item in self.load() if item.pinned] if keep_pinned else [])

    def _save(self, items: list[RecentItem]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=self.path.name, suffix=".tmp", dir=self.path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump([asdict(item) for item in items], stream, ensure_ascii=False, indent=2)
                stream.flush(); os.fsync(stream.fileno())
            os.replace(temp_name, self.path)
        finally:
            try: os.unlink(temp_name)
            except FileNotFoundError: pass
