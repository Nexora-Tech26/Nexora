from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Callable


@dataclass
class Activity:
    title: str
    kind: str
    identifier: str = field(default_factory=lambda: uuid.uuid4().hex)
    progress: float | None = None
    status: str = "running"
    details: str = ""
    started_at: float = field(default_factory=time.time)


class ActivityService:
    """Thread-safe backing model for Nexora Activity Capsules."""

    def __init__(self):
        self._items: dict[str, Activity] = {}
        self._listeners: list[Callable[[list[Activity]], None]] = []
        self._lock = threading.RLock()

    def subscribe(self, listener: Callable[[list[Activity]], None]) -> Callable[[], None]:
        with self._lock: self._listeners.append(listener)
        listener(self.items())
        return lambda: self._unsubscribe(listener)

    def create(self, title: str, kind: str, details: str = "") -> Activity:
        activity = Activity(title=title, kind=kind, details=details)
        with self._lock: self._items[activity.identifier] = activity
        self._emit(); return activity

    def update(self, identifier: str, *, progress: float | None = None, status: str | None = None, details: str | None = None) -> None:
        with self._lock:
            item = self._items.get(identifier)
            if item is None: return
            if progress is not None: item.progress = max(0.0, min(1.0, float(progress)))
            if status is not None: item.status = status
            if details is not None: item.details = details
        self._emit()

    def remove(self, identifier: str) -> None:
        with self._lock: self._items.pop(identifier, None)
        self._emit()

    def items(self) -> list[Activity]:
        with self._lock: return sorted(self._items.values(), key=lambda item: item.started_at)

    def _unsubscribe(self, listener):
        with self._lock:
            if listener in self._listeners: self._listeners.remove(listener)

    def _emit(self):
        snapshot = self.items()
        for listener in tuple(self._listeners):
            try: listener(snapshot)
            except RuntimeError: continue
