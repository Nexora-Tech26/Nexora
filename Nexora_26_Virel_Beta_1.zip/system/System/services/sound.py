"""Cached non-overlapping UI sound playback."""
from __future__ import annotations
import time
import os
from pathlib import Path
from PySide6.QtCore import QObject, QUrl
try:
    from PySide6.QtMultimedia import QMediaDevices, QSoundEffect
except ImportError:
    QMediaDevices = None
    QSoundEffect = None

class SoundService(QObject):
    def __init__(self, settings_store, resource_dir: Path, parent=None):
        super().__init__(parent); self.settings_store=settings_store; self.resource_dir=Path(resource_dir); self._effects={}; self._last={}
        # The offscreen CI platform has no audio server and constructing
        # QMediaDevices can keep backend threads alive after QApplication tests.
        self._media_devices = QMediaDevices(self) if QMediaDevices is not None and os.environ.get("QT_QPA_PLATFORM") != "offscreen" else None
        if self._media_devices is not None:
            self._media_devices.audioInputsChanged.connect(self._device_changed)
            self._media_devices.audioOutputsChanged.connect(self._device_changed)

    def _device_changed(self):
        self.play("device")
    def reload(self):
        """Drop cached effects after a sound-theme or volume change."""
        for effect in self._effects.values():
            if effect.isPlaying():
                effect.stop()
        self._effects.clear()
        self._last.clear()

    def shutdown(self):
        """Stop playback and detach multimedia backends deterministically."""
        for effect in tuple(self._effects.values()):
            if effect.isPlaying():
                effect.stop()
            effect.setSource(QUrl())
            effect.deleteLater()
        self._effects.clear()
        self._last.clear()
        if self._media_devices is not None:
            try:
                self._media_devices.audioInputsChanged.disconnect(self._device_changed)
                self._media_devices.audioOutputsChanged.disconnect(self._device_changed)
            except (RuntimeError, TypeError):
                pass
            self._media_devices.deleteLater()
            self._media_devices = None

    def play(self,name:str):
        st=self.settings_store.snapshot()
        if not st.get("sound_effects") or QSoundEffect is None: return False
        now=time.monotonic()
        if now-self._last.get(name,0)<0.08: return False
        path=self.resource_dir/f"{name}.wav"
        if not path.exists(): return False
        effect=self._effects.get(name)
        if effect is None:
            effect=QSoundEffect(self); effect.setSource(QUrl.fromLocalFile(str(path))); self._effects[name]=effect
        effect.setVolume(max(0,min(100,int(st.get("ui_sound_volume",55))))/100.0)
        if effect.isPlaying(): effect.stop()
        effect.play(); self._last[name]=now; return True
