"""Persistent application usage ranking for Start, dock and desktop sorting."""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path


class UsageService:
    def __init__(self, path: Path):
        self.path = Path(path)
        self._lock = threading.RLock()
        self._data = self._load()

    def _load(self) -> dict:
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
            return payload if isinstance(payload, dict) else {}
        except (OSError, ValueError, json.JSONDecodeError):
            return {}

    def record_launch(self, app_path: Path) -> None:
        key = str(Path(app_path).resolve())
        with self._lock:
            entry = self._data.setdefault(key, {"count": 0, "last": 0.0})
            entry["count"] = max(0, int(entry.get("count", 0))) + 1
            entry["last"] = time.time()
            self._flush_locked()

    def score(self, app_path: Path) -> float:
        key = str(Path(app_path).resolve())
        with self._lock:
            entry = dict(self._data.get(key, {}))
        count = max(0, int(entry.get("count", 0)))
        last = float(entry.get("last", 0.0) or 0.0)
        age_hours = max(0.0, (time.time() - last) / 3600.0) if last else 100000.0
        recency = max(0.0, 24.0 - min(24.0, age_hours))
        return min(40.0, count * 2.5) + recency

    def top(self, app_paths, limit: int = 8) -> list[Path]:
        paths = [Path(path).resolve() for path in app_paths]
        return sorted(paths, key=self.score, reverse=True)[: max(0, int(limit))]

    def metadata(self, app_path: Path) -> dict:
        with self._lock:
            return dict(self._data.get(str(Path(app_path).resolve()), {}))

    def _flush_locked(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(self.path.suffix + f".{os.getpid()}.tmp")
        temp.write_text(json.dumps(self._data, indent=2, sort_keys=True), encoding="utf-8")
        os.replace(temp, self.path)
