from __future__ import annotations

from copy import deepcopy
from typing import Any, Mapping

PROFILES: dict[str, dict[str, Any]] = {
    "balanced": {"performance_mode": "balanced", "reduce_motion": False, "disable_transparency": False, "animation_speed": 0.7},
    "performance": {"performance_mode": "performance", "reduce_motion": True, "disable_transparency": True, "animation_speed": 0.35},
    "battery": {"performance_mode": "battery_saver", "reduce_motion": True, "disable_transparency": True, "animation_speed": 0.4, "dynamic_lighting": False},
    "presentation": {"performance_mode": "balanced", "focus_mode": True, "notification_popups": False, "desktop_show_icons": False},
    "accessibility": {"keyboard_navigation": True, "focus_ring": True, "reduce_motion": True, "disable_transparency": True, "ui_scale": 1.2},
}


def profile_changes(name: str, current: Mapping[str, Any]) -> dict[str, tuple[Any, Any]]:
    if name not in PROFILES:
        raise KeyError(f"Unknown session profile: {name}")
    return {key: (current.get(key), value) for key, value in PROFILES[name].items() if current.get(key) != value}


def apply_profile(name: str, current: Mapping[str, Any]) -> dict[str, Any]:
    result = deepcopy(dict(current))
    result.update(PROFILES[name])
    result["session_profile"] = name
    return result
