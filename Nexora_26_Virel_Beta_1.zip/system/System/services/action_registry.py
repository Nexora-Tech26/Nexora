"""Central registry for commands exposed by Nexora applications."""
from __future__ import annotations

from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Callable, Iterable


@dataclass(frozen=True)
class Action:
    action_id: str
    title: str
    callback: Callable[[], object]
    description: str = ""
    aliases: tuple[str, ...] = field(default_factory=tuple)
    shortcut: str = ""
    context: str = "global"
    enabled: Callable[[], bool] | None = None

    def is_enabled(self) -> bool:
        return True if self.enabled is None else bool(self.enabled())


class ActionRegistry:
    def __init__(self) -> None:
        self._actions: dict[str, Action] = {}

    def register(self, action: Action, *, replace: bool = False) -> None:
        if not action.action_id or "." not in action.action_id:
            raise ValueError("action_id must be a stable dotted identifier")
        if action.action_id in self._actions and not replace:
            raise KeyError(action.action_id)
        self._actions[action.action_id] = action

    def unregister(self, action_id: str) -> None:
        self._actions.pop(action_id, None)

    def get(self, action_id: str) -> Action | None:
        return self._actions.get(action_id)

    def all(self, *, context: str | None = None) -> tuple[Action, ...]:
        values = self._actions.values()
        if context is not None:
            values = (a for a in values if a.context in {"global", context})
        return tuple(sorted(values, key=lambda a: (a.context, a.title.casefold())))

    def search(self, query: str, *, context: str | None = None, limit: int = 30) -> tuple[Action, ...]:
        query = query.strip().casefold()
        scored: list[tuple[float, Action]] = []
        for action in self.all(context=context):
            if not action.is_enabled():
                continue
            haystack = " ".join((action.action_id, action.title, action.description, *action.aliases)).casefold()
            score = 1.0 if not query else max(
                1.0 if query in haystack else 0.0,
                SequenceMatcher(None, query, haystack).ratio(),
            )
            if not query or score >= 0.28:
                scored.append((score, action))
        scored.sort(key=lambda row: (-row[0], row[1].title.casefold()))
        return tuple(action for _, action in scored[: max(1, limit)])

    def execute(self, action_id: str) -> object:
        action = self._actions[action_id]
        if not action.is_enabled():
            raise RuntimeError(f"Action is disabled: {action_id}")
        return action.callback()

    def register_many(self, actions: Iterable[Action], *, replace: bool = False) -> None:
        for action in actions:
            self.register(action, replace=replace)
