"""Central wallpaper scaling, blur caching and coordinate mapping."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageEnhance, ImageFilter
from PySide6.QtCore import QObject, QPoint, QRect, QRectF, QSize, Signal, Qt
from PySide6.QtGui import QPainter, QPixmap

@dataclass(frozen=True)
class WallpaperMapping:
    viewport: QSize
    source_size: QSize
    scaled_size: QSize
    crop_x: float
    crop_y: float
    scale: float
    device_pixel_ratio: float

    def desktop_to_source(self, rect: QRect) -> QRectF:
        dpr = max(1.0, self.device_pixel_ratio)
        return QRectF(
            (rect.x() + self.crop_x) * dpr,
            (rect.y() + self.crop_y) * dpr,
            rect.width() * dpr,
            rect.height() * dpr,
        )

class WallpaperRenderService(QObject):
    changed = Signal()

    def __init__(self, cache_dir: Path, parent=None):
        super().__init__(parent)
        self.cache_dir = Path(cache_dir) / "wallpaper_cache_v26"  # supersedes wallpaper_cache_v35
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.path: Path | None = None
        self.original = QPixmap()
        self.scaled = QPixmap()
        self.blurred: dict[int, QPixmap] = {}
        self.mapping = WallpaperMapping(QSize(), QSize(), QSize(), 0, 0, 1.0, 1.0)
        self._viewport = QSize()
        self._dpr = 1.0
        self._fit = "cover"
        self._saturation = 100

    def set_wallpaper(self, path: Path, *, fit: str = "cover", saturation: int = 100) -> None:
        target = Path(path).expanduser().resolve()
        if not target.is_file():
            raise FileNotFoundError(target)
        pixmap = QPixmap(str(target))
        if pixmap.isNull():
            raise ValueError(f"Unsupported or damaged wallpaper: {target}")
        previous = self.path
        self.path = target
        self.original = pixmap
        self._fit = "fill" if fit == "cover" else (fit if fit in {"fill", "fit", "stretch"} else "fill")
        self._saturation = max(0, min(180, int(saturation)))
        self.blurred.clear()
        self._render()
        if previous != target:
            self.prune_cache()

    def update_viewport(self, size: QSize, device_pixel_ratio: float = 1.0) -> None:
        size = QSize(max(1, size.width()), max(1, size.height()))
        dpr = max(1.0, float(device_pixel_ratio or 1.0))
        if size == self._viewport and abs(dpr - self._dpr) < 0.01:
            return
        self._viewport = size
        self._dpr = dpr
        self._render()

    def _render(self) -> None:
        if self.original.isNull() or not self._viewport.isValid():
            return
        target_px = QSize(round(self._viewport.width() * self._dpr), round(self._viewport.height() * self._dpr))
        source = self.original.size()
        if self.path is not None and self.path.suffix.casefold() != ".svg":
            cache = self.cache_dir / f"{self._cache_key(0)}-base.png"
            if not cache.exists():
                with Image.open(self.path) as image:
                    image = image.convert("RGB")
                    target = (target_px.width(), target_px.height())
                    if self._fit == "stretch":
                        rendered = image.resize(target, Image.Resampling.LANCZOS)
                        scale = max(target[0] / image.width, target[1] / image.height)
                    elif self._fit == "fit":
                        scale = min(target[0] / image.width, target[1] / image.height)
                        resized = image.resize((max(1, round(image.width * scale)), max(1, round(image.height * scale))), Image.Resampling.LANCZOS)
                        rendered = Image.new("RGB", target, (20, 22, 28))
                        rendered.paste(resized, ((target[0] - resized.width) // 2, (target[1] - resized.height) // 2))
                    else:
                        scale = max(target[0] / image.width, target[1] / image.height)
                        resized = image.resize((max(1, round(image.width * scale)), max(1, round(image.height * scale))), Image.Resampling.LANCZOS)
                        left = max(0, (resized.width - target[0]) // 2)
                        top = max(0, (resized.height - target[1]) // 2)
                        rendered = resized.crop((left, top, left + target[0], top + target[1]))
                    if scale > 1.05:
                        rendered = rendered.filter(ImageFilter.UnsharpMask(radius=0.9, percent=58, threshold=3))
                    if self._saturation != 100:
                        rendered = ImageEnhance.Color(rendered).enhance(self._saturation / 100)
                    rendered.save(cache, optimize=True)
            canvas = QPixmap(str(cache))
            if not canvas.isNull():
                canvas.setDevicePixelRatio(self._dpr)
                self.scaled = canvas
                self.mapping = WallpaperMapping(
                    QSize(self._viewport), QSize(source), QSize(target_px), 0.0, 0.0,
                    target_px.width() / max(1, source.width()), self._dpr,
                )
                self.blurred.clear()
                self.changed.emit()
                return
        if self._fit == "stretch":
            scaled_px = target_px
            mode = Qt.IgnoreAspectRatio
        elif self._fit == "fit":
            scaled_px = source.scaled(target_px, Qt.KeepAspectRatio)
            mode = Qt.KeepAspectRatio
        else:
            scaled_px = source.scaled(target_px, Qt.KeepAspectRatioByExpanding)
            mode = Qt.KeepAspectRatioByExpanding
        scaled = self.original.scaled(scaled_px, mode, Qt.SmoothTransformation)
        canvas = QPixmap(target_px)
        canvas.fill(Qt.transparent)
        painter = QPainter(canvas)
        x = (target_px.width() - scaled.width()) // 2
        y = (target_px.height() - scaled.height()) // 2
        painter.drawPixmap(x, y, scaled)
        painter.end()
        canvas.setDevicePixelRatio(self._dpr)
        self.scaled = canvas
        self.mapping = WallpaperMapping(
            QSize(self._viewport), QSize(source), QSize(scaled_px),
            max(0.0, -x / self._dpr), max(0.0, -y / self._dpr),
            scaled_px.width() / max(1, source.width()), self._dpr,
        )
        self.blurred.clear()
        self.changed.emit()

    def _cache_key(self, radius: int) -> str:
        if self.path is None:
            return "empty"
        stat = self.path.stat()
        raw = f"{self.path}:{stat.st_mtime_ns}:{stat.st_size}:{self._viewport.width()}x{self._viewport.height()}:{self._dpr:.3f}:{radius}:{self._fit}:{self._saturation}"
        return hashlib.sha256(raw.encode()).hexdigest()[:24]

    def blurred_pixmap(self, radius: int) -> QPixmap:
        radius = max(0, min(80, int(radius)))
        if radius <= 0:
            return self.scaled
        if radius in self.blurred:
            return self.blurred[radius]
        cache = self.cache_dir / f"{self._cache_key(radius)}.png"
        if cache.exists():
            pixmap = QPixmap(str(cache))
            if not pixmap.isNull():
                pixmap.setDevicePixelRatio(self._dpr)
                self.blurred[radius] = pixmap
                return pixmap
        if self.path is None:
            return self.scaled
        rendered_source = cache.with_name(cache.stem + "-source.png")
        self.scaled.save(str(rendered_source), "PNG")
        with Image.open(rendered_source) as image:
            image = image.convert("RGB")
            rendered = image.filter(ImageFilter.GaussianBlur(radius=max(0.1, radius * self._dpr)))
            rendered.save(cache, optimize=True)
        rendered_source.unlink(missing_ok=True)
        pixmap = QPixmap(str(cache)); pixmap.setDevicePixelRatio(self._dpr)
        self.blurred[radius] = pixmap
        return pixmap

    def prune_cache(self, max_files: int = 48) -> None:
        """Keep recent render variants and remove only stale cache entries."""
        entries = sorted(
            self.cache_dir.glob("*.png"),
            key=lambda item: item.stat().st_mtime_ns if item.exists() else 0,
            reverse=True,
        )
        for stale in entries[max(8, int(max_files)):]:
            try:
                stale.unlink()
            except OSError:
                pass

    def paint_backdrop(self, painter: QPainter, widget, host, radius: int) -> bool:
        pixmap = self.blurred_pixmap(radius)
        if pixmap.isNull():
            return False
        try:
            top_left = widget.mapTo(host, QPoint(0, 0))
        except RuntimeError:
            return False
        logical = QRect(top_left, widget.size()).intersected(QRect(QPoint(0, 0), self._viewport))
        if logical.isEmpty():
            return False
        local_target = QRect(logical.topLeft() - top_left, logical.size())
        dpr = self._dpr
        source = QRectF(logical.x()*dpr, logical.y()*dpr, logical.width()*dpr, logical.height()*dpr)
        painter.drawPixmap(QRectF(local_target), pixmap, source)
        return True
