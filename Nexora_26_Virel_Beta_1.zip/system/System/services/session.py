"""Persistent restoration of open Nexora windows and their geometry."""
from __future__ import annotations

import json
import os
import time
import logging
from pathlib import Path


class SessionRecoveryService:
    def __init__(self, data_dir: Path, apps_dir: Path):
        self.data_dir = Path(data_dir)
        self.apps_dir = Path(apps_dir).resolve()
        self.marker = self.data_dir / "session.active"
        self.layout = self.data_dir / "session_layout.json"
        self.data_dir.mkdir(parents=True, exist_ok=True)

    def begin(self) -> bool:
        """Mark the session active and request restoration whenever a layout exists."""
        should_restore = self.layout.is_file()
        payload = {"pid": os.getpid(), "started_at": time.time()}
        self._atomic_json(self.marker, payload)
        return should_restore

    def _safe_app_path(self, value):
        try:
            path = Path(value).resolve()
            path.relative_to(self.apps_dir)
        except (OSError, ValueError, TypeError):
            return None
        if path.is_file() and path.suffix == ".py":
            return path
        return None

    def save_windows(self, windows) -> None:
        entries = []
        seen = set()
        for order, window in enumerate(windows):
            try:
                path = self._safe_app_path(window.path)
                if path is None or id(window) in seen:
                    continue
                seen.add(id(window))
                geometry = window.geometry()
                normal = getattr(window, "_normal_geometry", geometry)
                if getattr(window, "_zoomed", False) and normal.isValid():
                    geometry = normal
                entries.append({
                    "path": str(path),
                    "x": int(geometry.x()), "y": int(geometry.y()),
                    "width": int(geometry.width()), "height": int(geometry.height()),
                    "zoomed": bool(getattr(window, "_zoomed", False)),
                    "minimized": not bool(window.isVisible()),
                    "order": int(order),
                })
            except (AttributeError, RuntimeError, TypeError, ValueError):
                continue
        self._atomic_json(self.layout, {"schema": 2, "windows": entries, "saved_at": time.time()})

    def save_open_apps(self, paths) -> None:
        """Compatibility path for older callers; preserves app list only."""
        entries = []
        for order, value in enumerate(paths):
            path = self._safe_app_path(value)
            if path is not None:
                entries.append({"path": str(path), "order": order})
        self._atomic_json(self.layout, {"schema": 2, "windows": entries, "saved_at": time.time()})

    def restore_windows(self) -> tuple[dict, ...]:
        try:
            payload = json.loads(self.layout.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            return ()
        result = []
        if isinstance(payload, dict) and payload.get("schema") == 2:
            values = payload.get("windows", [])
            if not isinstance(values, list):
                return ()
            for item in values:
                if not isinstance(item, dict):
                    continue
                path = self._safe_app_path(item.get("path"))
                if path is None:
                    continue
                state = dict(item)
                state["path"] = path
                result.append(state)
            result.sort(key=lambda item: int(item.get("order", 0)))
            return tuple(result)
        if isinstance(payload, dict) and payload.get("schema") == 1:
            for order, value in enumerate(payload.get("apps", [])):
                path = self._safe_app_path(value)
                if path is not None:
                    result.append({"path": path, "order": order})
        return tuple(result)

    def restore_apps(self) -> tuple[Path, ...]:
        return tuple(item["path"] for item in self.restore_windows())

    def finish(self) -> None:
        try:
            self.marker.unlink(missing_ok=True)
        except OSError as exc:
            logging.getLogger(__name__).debug("Session marker cleanup failed: %s", exc)

    @staticmethod
    def _atomic_json(path: Path, payload: dict) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        os.replace(temporary, path)
