"""Lazy service namespace.

Public service classes are resolved only when requested.  This keeps backend
modules importable in diagnostics/tests without importing every Qt service at
startup, while preserving the historical ``from System.services import X`` API.
"""
from __future__ import annotations

from importlib import import_module
from typing import Any

_CLASS_MODULES = {
    "ClipboardService": ".clipboard",
    "MotionEngine": ".motion",
    "SessionRecoveryService": ".session",
    "SoundService": ".sound",
    "UsageService": ".usage",
    "WallpaperMapping": ".wallpaper",
    "WallpaperRenderService": ".wallpaper",
}

_MODULE_NAMES = {
    "action_registry", "activity", "clipboard", "crash_center", "motion",
    "recent_items", "safe_formula", "session", "session_profiles",
    "settings_history", "sound", "usage", "wallpaper", "workspace_context",
}

__all__ = sorted([*_CLASS_MODULES, *_MODULE_NAMES])


def __getattr__(name: str) -> Any:
    module_name = _CLASS_MODULES.get(name)
    if module_name is not None:
        module = import_module(module_name, __name__)
        value = getattr(module, name)
        globals()[name] = value
        return value
    if name in _MODULE_NAMES:
        module = import_module(f".{name}", __name__)
        globals()[name] = module
        return module
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
