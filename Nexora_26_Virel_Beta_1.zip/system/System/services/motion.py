"""Central animation lifecycle manager."""
from __future__ import annotations
from weakref import WeakKeyDictionary
from PySide6.QtCore import QObject, QEasingCurve, QPropertyAnimation, Signal

class MotionEngine(QObject):
    animationFinished = Signal(object, str)
    def __init__(self, settings_store, parent=None):
        super().__init__(parent); self.settings_store=settings_store; self._active=WeakKeyDictionary()
    def _duration(self, base: int) -> int:
        st=self.settings_store.snapshot()
        if st.get("reduce_motion") or not st.get("animations", True): return 0
        return max(60, round(base/max(0.25,float(st.get("animation_speed",1.0)))))
    def animate(self, target, property_name: bytes, start, end, *, duration=260, easing=QEasingCurve.OutCubic, key="default", finished=None):
        bucket=self._active.setdefault(target,{})
        previous=bucket.pop(key,None)
        if previous is not None: previous.stop(); previous.deleteLater()
        ms=self._duration(duration)
        if ms==0:
            target.setProperty(property_name.decode(), end)
            if finished: finished()
            return None
        animation=QPropertyAnimation(target,property_name,self); animation.setDuration(ms); animation.setStartValue(start); animation.setEndValue(end); animation.setEasingCurve(easing)
        bucket[key]=animation
        def done():
            bucket.pop(key,None); self.animationFinished.emit(target,key)
            if finished: finished()
            animation.deleteLater()
        animation.finished.connect(done); animation.start(); return animation
    def stop(self,target,key=None):
        bucket=self._active.get(target,{})
        for name,animation in list(bucket.items()):
            if key is None or name==key: animation.stop(); animation.deleteLater(); bucket.pop(name,None)
