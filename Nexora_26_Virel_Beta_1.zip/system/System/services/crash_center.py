"""Persistent, privacy-conscious application crash history."""
from __future__ import annotations

import json
import os
import time
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class CrashRecord:
    app_id: str
    error_type: str
    message: str
    timestamp: float
    session_id: str = ""


class CrashCenter:
    def __init__(self, data_dir: Path, *, max_records: int = 100) -> None:
        self.path = Path(data_dir) / "crashes.json"
        self.max_records = max(10, int(max_records))

    def record(self, app_id: str, error_type: str, message: str, *, session_id: str = "") -> CrashRecord:
        record = CrashRecord(
            app_id=self._clean(app_id, 120),
            error_type=self._clean(error_type, 120),
            message=self._clean(message, 500),
            timestamp=time.time(),
            session_id=self._clean(session_id, 120),
        )
        records = list(self.records())
        records.append(record)
        self._write(records[-self.max_records :])
        return record

    def records(self) -> tuple[CrashRecord, ...]:
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            return ()
        result = []
        for item in payload.get("records", []) if isinstance(payload, dict) else []:
            if not isinstance(item, dict):
                continue
            try:
                result.append(CrashRecord(
                    app_id=str(item["app_id"]), error_type=str(item["error_type"]),
                    message=str(item.get("message", "")), timestamp=float(item["timestamp"]),
                    session_id=str(item.get("session_id", "")),
                ))
            except (KeyError, TypeError, ValueError):
                continue
        return tuple(result)

    def summary(self) -> dict[str, int]:
        return dict(Counter(record.app_id for record in self.records()))

    def clear(self, app_id: str | None = None) -> None:
        if app_id is None:
            self._write([])
        else:
            self._write([record for record in self.records() if record.app_id != app_id])

    @staticmethod
    def _clean(value: object, limit: int) -> str:
        text = str(value).replace("\x00", "").strip()
        return text[:limit]

    def _write(self, records: list[CrashRecord]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"schema": 1, "records": [asdict(record) for record in records]}
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(temp, self.path)
