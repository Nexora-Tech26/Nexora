"""In-session clipboard history with duplicate suppression."""
from __future__ import annotations
from collections import deque
from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QApplication

class ClipboardService(QObject):
    historyChanged=Signal()
    def __init__(self,parent=None,limit=40):
        super().__init__(parent);self.limit=max(1,int(limit));self._items=deque(maxlen=self.limit)
        app=QApplication.instance();self.clipboard=app.clipboard() if app else None
        if self.clipboard:self.clipboard.dataChanged.connect(self._capture)
    def _capture(self):
        text=self.clipboard.text().strip() if self.clipboard else ""
        if not text or (self._items and self._items[0]==text):return
        try:self._items.remove(text)
        except ValueError:pass
        self._items.appendleft(text);self.historyChanged.emit()
    def history(self):return tuple(self._items)
    def restore(self,index):
        if not self.clipboard:return False
        try:self.clipboard.setText(self._items[index]);return True
        except IndexError:return False
    def clear(self):self._items.clear();self.historyChanged.emit()
