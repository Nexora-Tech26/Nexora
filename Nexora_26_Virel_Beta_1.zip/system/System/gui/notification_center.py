"""Desktop notification center backed exclusively by NotificationService."""
from __future__ import annotations

from datetime import datetime

from .shared import *
from .components import GlassFrame


class NotificationCenter(GlassFrame):
    def __init__(self, desktop):
        super().__init__(desktop.ui_layer, radius=24, alpha=48, gradient=True, wallpaper_backdrop=True)
        self.desktop = desktop
        self.service = desktop.notification_service
        self.setFixedSize(420, 590)
        self.hide()
        root = QVBoxLayout(self); root.setContentsMargins(18, 18, 18, 18); root.setSpacing(10)
        header = QHBoxLayout()
        title = QLabel("Notifications"); title.setFont(font(18, True)); header.addWidget(title); header.addStretch()
        self.dnd = QCheckBox("Do Not Disturb"); self.dnd.setChecked(bool(load_settings().get("do_not_disturb", False))); self.dnd.toggled.connect(self._set_dnd); header.addWidget(self.dnd)
        clear = QPushButton("Clear all"); clear.clicked.connect(self.service.clear)
        close = QPushButton("×"); close.clicked.connect(self.hide)
        apply_connected_group((clear, close), "#B9A7E8", radius=13, height=34)
        close.setMinimumWidth(38); close.setMaximumWidth(38)
        header.addWidget(clear); header.addWidget(close)
        root.addLayout(header)
        self.subtitle = QLabel(); self.subtitle.setStyleSheet(f"color:{MUTED};"); root.addWidget(self.subtitle)
        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True); self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.host = QWidget(); self.items_layout = QVBoxLayout(self.host); self.items_layout.setContentsMargins(0, 0, 0, 0); self.items_layout.setSpacing(9); self.items_layout.addStretch()
        self.scroll.setWidget(self.host); root.addWidget(self.scroll, 1)
        self.service.historyChanged.connect(self.refresh)
        self.refresh()

    def toggle(self):
        if self.isVisible():
            self.hide()
        else:
            self.desktop.position_shells(); self.refresh(); self.show(); self.raise_()

    def _set_dnd(self, value: bool):
        settings = load_settings(); settings["do_not_disturb"] = bool(value); save_settings(settings)
        if hasattr(self.desktop, "quick_shell"): self.desktop.quick_shell._refresh_labels()

    def refresh(self):
        while self.items_layout.count() > 1:
            item = self.items_layout.takeAt(0); widget = item.widget()
            if widget is not None: widget.deleteLater()
        history = self.service.history()
        unread = sum(not item.read for item in history)
        self.subtitle.setText(f"{unread} unread • {len(history)} in history")
        if not history:
            empty = QLabel("No notifications\nNew activity from Nexora apps will appear here.")
            empty.setAlignment(Qt.AlignCenter); empty.setWordWrap(True); empty.setStyleSheet(f"color:{MUTED};padding:50px;")
            self.items_layout.insertWidget(0, empty)
            return
        last_app = None
        insert_index = 0
        for notification in history:
            if notification.app_id != last_app:
                group = QLabel(notification.app_id.replace("_", " ").title())
                group.setFont(font(9, True)); group.setStyleSheet(f"color:{MUTED};padding:6px 4px 1px;")
                self.items_layout.insertWidget(insert_index, group); insert_index += 1; last_app = notification.app_id
            card = self._card(notification)
            self.items_layout.insertWidget(insert_index, card); insert_index += 1

    def _card(self, notification):
        card = QFrame(); card.setObjectName("NotificationCard")
        accent = {"critical": "#F47C8C", "high": "#FFD18A", "normal": "#8AB4F8", "low": "#A7D8A1"}.get(notification.priority, "#8AB4F8")
        card.setStyleSheet(f"QFrame#NotificationCard{{background:{rgba(accent, 28)};border:none;border-radius:24px;}}")
        layout = QVBoxLayout(card); layout.setContentsMargins(13, 11, 13, 11); layout.setSpacing(5)
        top = QHBoxLayout(); title = QLabel(notification.title); title.setFont(font(10, True)); top.addWidget(title, 1)
        stamp = QLabel(datetime.fromtimestamp(notification.timestamp).strftime("%H:%M")); stamp.setStyleSheet(f"color:{MUTED};"); top.addWidget(stamp)
        dismiss = QPushButton("×"); dismiss.setFixedSize(26, 26); dismiss.setStyleSheet(oneui_button_css("#B8C0CC", radius=8)); dismiss.clicked.connect(lambda _=False, key=notification.id: self.service.dismiss(key)); top.addWidget(dismiss)
        layout.addLayout(top)
        body = QLabel(notification.message); body.setWordWrap(True); body.setStyleSheet(f"color:{MUTED};"); layout.addWidget(body)
        if notification.actions:
            actions = QHBoxLayout(); actions.setSpacing(0); actions.addStretch()
            action_buttons = []
            for action_name in notification.actions:
                button = QPushButton(action_name)
                button.clicked.connect(lambda _=False, key=notification.id, action=action_name: self._invoke(key, action))
                action_buttons.append(button); actions.addWidget(button)
            apply_connected_group(action_buttons, accent, radius=11, height=34)
            layout.addLayout(actions)
        if not notification.read:
            card.setToolTip("Unread")
            card.mousePressEvent = lambda event, key=notification.id, original=card.mousePressEvent: (self.service.mark_read(key), original(event))[-1]
        return card

    def _invoke(self, notification_id: str, action: str):
        if not self.service.invoke(notification_id, action):
            self.desktop.show_system_message("Notification", "This action is no longer available.")
        self.service.mark_read(notification_id)
