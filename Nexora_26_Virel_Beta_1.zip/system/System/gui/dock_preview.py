"""Window thumbnail previews for dock application groups."""
from __future__ import annotations

from .shared import *
from .components import GlassFrame


def _rounded_preview(source: QPixmap, width: int, height: int, radius: int = 14) -> QPixmap:
    canvas = QPixmap(width, height)
    canvas.fill(Qt.transparent)
    painter = QPainter(canvas)
    painter.setRenderHint(QPainter.Antialiasing, True)
    path = QPainterPath()
    path.addRoundedRect(0, 0, width, height, radius, radius)
    painter.setClipPath(path)
    scaled = source.scaled(width, height, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
    x = (width - scaled.width()) // 2
    y = (height - scaled.height()) // 2
    painter.drawPixmap(x, y, scaled)
    painter.end()
    return canvas


class DockPreview(GlassFrame):
    def __init__(self, desktop):
        super().__init__(desktop.ui_layer, radius=16, alpha=34, gradient=True, wallpaper_backdrop=True)
        self.desktop = desktop; self._path = None; self._anchor = None
        self._show_timer = QTimer(self); self._show_timer.setSingleShot(True); self._show_timer.setInterval(380); self._show_timer.timeout.connect(self._show_requested)
        self._hide_timer = QTimer(self); self._hide_timer.setSingleShot(True); self._hide_timer.setInterval(220); self._hide_timer.timeout.connect(self.hide)
        self.setMouseTracking(True); self.hide()
        self.root = QVBoxLayout(self); self.root.setContentsMargins(12, 10, 12, 12); self.root.setSpacing(8)
        self.title = QLabel(); self.title.setFont(font(11, True)); self.root.addWidget(self.title)
        self.grid_host = QWidget(); self.grid = QGridLayout(self.grid_host); self.grid.setContentsMargins(0, 0, 0, 0); self.grid.setSpacing(8); self.root.addWidget(self.grid_host)

    def request(self, path, anchor):
        self._path = Path(path).resolve(); self._anchor = anchor; self._hide_timer.stop(); self._show_timer.start()

    def cancel_request(self):
        self._show_timer.stop(); self._hide_timer.start()

    def enterEvent(self, event):
        self._hide_timer.stop(); super().enterEvent(event)

    def leaveEvent(self, event):
        self._hide_timer.start(); super().leaveEvent(event)

    def _show_requested(self):
        windows = [window for window in self.desktop.window_groups.get(self._path, []) if window is not None]
        if not windows or self._anchor is None: return
        while self.grid.count():
            item = self.grid.takeAt(0); widget = item.widget()
            if widget: widget.deleteLater()
        self.title.setText(f"{app_name(self._path)} · {len(windows)} window{'s' if len(windows) != 1 else ''}")
        card_w, card_h = 224, 148
        for index, window in enumerate(windows[:6]):
            button = QPushButton(); button.setToolTip(getattr(window, "title", app_name(self._path))); button.setFixedSize(card_w, card_h)
            try:
                shot = _rounded_preview(window.grab(), card_w - 12, card_h - 36, 12)
                button.setIcon(QIcon(shot)); button.setIconSize(shot.size())
            except RuntimeError:
                button.setText(getattr(window, "title", app_name(self._path)))
            button.setFocusPolicy(Qt.NoFocus)
            button.setAutoDefault(False)
            button.setDefault(False)
            button.setStyleSheet(
                "QPushButton{background:rgba(255,255,255,18);border:none;outline:none;border-radius:14px;padding:6px;margin:0;}"
                "QPushButton:hover{background:rgba(255,255,255,30);border:none;outline:none;border-radius:14px;padding:6px;margin:0;}"
                "QPushButton:pressed{background:rgba(255,255,255,12);border:none;outline:none;border-radius:14px;padding:6px;margin:0;}"
                "QPushButton:focus{border:none;outline:none;}"
            )
            button.clicked.connect(lambda _=False, target=window: self._activate(target))
            self.grid.addWidget(button, index // 3, index % 3)
        columns = min(3, len(windows)); rows = (min(6, len(windows)) + columns - 1) // max(1, columns)
        self.setFixedSize(28 + columns * card_w + max(0, columns - 1) * 8, 58 + rows * card_h + max(0, rows - 1) * 8)
        global_anchor = self._anchor.mapToGlobal(self._anchor.rect().center()); local = self.desktop.ui_layer.mapFromGlobal(global_anchor)
        profile = panel_profile(); edge = profile.get("edge", "bottom")
        if profile.get("vertical"):
            x = local.x() + 46 if edge == "left" else local.x() - self.width() - 46
            y = local.y() - self.height() // 2
        elif edge == "top":
            x = local.x() - self.width() // 2; y = local.y() + 46
        else:
            x = local.x() - self.width() // 2; y = local.y() - self.height() - 46
        x = max(10, min(x, self.desktop.ui_layer.width() - self.width() - 10)); y = max(10, min(y, self.desktop.ui_layer.height() - self.height() - 10))
        self.move(x, y); self.show(); self.raise_()

    def _activate(self, window):
        self.hide()
        if not window.isVisible(): window.restore_animated()
        self.desktop.activate_window(window)
