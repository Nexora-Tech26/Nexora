"""Functional local package Store for Nexora."""
from __future__ import annotations

import sys
from pathlib import Path

from .shared import *
from System.apps.packages import PackageError, PackageManager, PackageManifest


class StoreApplicationMixin:
    def build_store(self):
        self.heading("Store", "Built-in applications and validated local Nexora packages")
        self.package_manager = PackageManager(DATA_DIR)
        self.store_stack = QStackedWidget(); self.content_layout.addWidget(self.store_stack, 1)

        self.store_home = self._store_catalog_page("All applications")
        self.store_categories = self._store_catalog_page("Categories")
        self.store_installed_page = QWidget(); installed_layout = QVBoxLayout(self.store_installed_page); installed_layout.setContentsMargins(0, 0, 0, 0)
        installed_top = QHBoxLayout(); title = QLabel("Installed packages"); title.setFont(font(18, True)); installed_top.addWidget(title); installed_top.addStretch()
        install = QPushButton("Install package…"); install.setStyleSheet(oneui_button_css("#59C36A", radius=12)); install.clicked.connect(self._store_choose_package); installed_top.addWidget(install)
        installed_layout.addLayout(installed_top)
        self.store_installed_list = QListWidget(); self.store_installed_list.setContextMenuPolicy(Qt.CustomContextMenu); self.store_installed_list.customContextMenuRequested.connect(self._store_package_menu)
        installed_layout.addWidget(self.store_installed_list, 1)

        self.store_updates_page = QWidget(); update_layout = QVBoxLayout(self.store_updates_page); update_layout.setContentsMargins(0, 0, 0, 0)
        update_top = QHBoxLayout(); update_title = QLabel("Package updates"); update_title.setFont(font(18, True)); update_top.addWidget(update_title); update_top.addStretch()
        scan = QPushButton("Scan Downloads"); scan.setStyleSheet(oneui_button_css("#8AB4F8", radius=12)); scan.clicked.connect(self._store_scan_updates); update_top.addWidget(scan)
        update_layout.addLayout(update_top); self.store_updates_list = QListWidget(); update_layout.addWidget(self.store_updates_list, 1)
        self.store_update_button = QPushButton("Install selected update"); self.store_update_button.setStyleSheet(oneui_button_css("#46C8B0", radius=12)); self.store_update_button.clicked.connect(self._store_install_selected_update); update_layout.addWidget(self.store_update_button)

        for page in (self.store_home, self.store_categories, self.store_installed_page, self.store_updates_page): self.store_stack.addWidget(page)
        for label, index in (("Home", 0), ("Categories", 1), ("Installed", 2), ("Updates", 3)):
            button = self.sidebar_buttons.get(label)
            if button is not None: button.clicked.connect(lambda _=False, i=index: self._store_show_page(i))
        self.header_search.textChanged.connect(self._store_filter)
        self._store_refresh_catalogs(); self._store_refresh_installed(); self._store_scan_updates()

    def _store_catalog_page(self, title_text: str):
        page = QWidget(); layout = QVBoxLayout(page); layout.setContentsMargins(0, 0, 0, 0)
        title = QLabel(title_text); title.setFont(font(18, True)); layout.addWidget(title)
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        host = QWidget(); grid = QGridLayout(host); grid.setSpacing(10); scroll.setWidget(host); layout.addWidget(scroll, 1)
        page.catalog_host = host; page.catalog_grid = grid
        return page

    def _store_refresh_catalogs(self):
        apps = []
        seen = set()
        for path in self.desktop.app_paths:
            name = app_name(path)
            if name in seen: continue
            seen.add(name); apps.append((name, path, "Built-in"))
        apps.sort(key=lambda value: value[0].casefold())
        self._store_catalog_entries = apps
        self._store_fill_grid(self.store_home.catalog_grid, apps)
        grouped = []
        categories = {
            "Productivity": {"Documents", "Spreadsheets", "Presentations", "Notepad", "Calendar"},
            "Creative": {"Image Editor", "Video Editor", "Audio Editor", "Paint", "Whiteboard"},
            "System": {"Files", "Settings", "Terminal", "Task Manager", "BackUp", "AboutPC"},
            "Internet": {"Browser", "Maps", "Weather", "Store"},
        }
        for name, path, _ in apps:
            category = next((key for key, names in categories.items() if name in names), "Other")
            grouped.append((name, path, category))
        grouped.sort(key=lambda value: (value[2], value[0].casefold()))
        self._store_fill_grid(self.store_categories.catalog_grid, grouped, show_category=True)

    def _store_fill_grid(self, grid: QGridLayout, apps, show_category=False):
        while grid.count():
            item = grid.takeAt(0); widget = item.widget()
            if widget: widget.deleteLater()
        for index, (name, path, category) in enumerate(apps):
            card = QFrame(); card.setObjectName("StoreCard"); card.setProperty("searchText", f"{name} {category}".casefold())
            card.setStyleSheet(f"QFrame#StoreCard{{background:{rgba(APP_COLORS.get(name, '#7F9DB9'), 32)};border:none;border-radius:22px;}}")
            layout = QVBoxLayout(card); layout.setContentsMargins(14, 14, 14, 14)
            icon = QLabel(); icon.setPixmap(qt_icon(name).pixmap(44, 44)); layout.addWidget(icon, 0, Qt.AlignLeft)
            label = QLabel(name); label.setFont(font(12, True)); layout.addWidget(label)
            if show_category:
                detail = QLabel(category); detail.setStyleSheet(f"color:{MUTED};"); layout.addWidget(detail)
            open_button = QPushButton("Open"); open_button.setStyleSheet(oneui_button_css(APP_COLORS.get(name, "#7F9DB9"), radius=11)); open_button.clicked.connect(lambda _=False, target=path: self.desktop.open_app(target)); layout.addWidget(open_button)
            grid.addWidget(card, index // 3, index % 3)
        grid.setRowStretch((len(apps) + 2) // 3, 1)

    def _store_filter(self, text: str):
        query = text.strip().casefold()
        for page in (self.store_home, self.store_categories):
            for card in page.catalog_host.findChildren(QFrame, "StoreCard"):
                card.setVisible(not query or query in str(card.property("searchText")))

    def _store_show_page(self, index: int):
        self.store_stack.setCurrentIndex(index)
        labels = ("Home", "Categories", "Installed", "Updates")
        self.set_active_sidebar(labels[index])
        if index == 2: self._store_refresh_installed()
        elif index == 3: self._store_scan_updates()

    def _store_choose_package(self):
        self.desktop.show_file_picker("Install Nexora package", "open", self._store_install_package, extensions={".zip"})

    def _store_install_package(self, path):
        try:
            manifest = self.package_manager.inspect(Path(path))
        except PackageError as exc:
            self.desktop.show_system_message("Store", str(exc)); return
        message = f"Install {manifest.name} {manifest.version}?\n\n{manifest.description}\n\nPackages are not executed during installation."
        self.desktop.show_confirm("Install package", message, lambda: self._store_install_confirmed(Path(path)))

    def _store_install_confirmed(self, path: Path):
        try:
            manifest = self.package_manager.install(path)
        except (OSError, PackageError) as exc:
            self.desktop.show_system_message("Store", f"Installation failed: {exc}"); return
        self.desktop.notch.notify(f"Installed {manifest.name} {manifest.version}")
        self._store_refresh_installed(); self._store_show_page(2)

    def _store_refresh_installed(self):
        self.store_installed_list.clear()
        for manifest in self.package_manager.installed():
            item = QListWidgetItem(f"{manifest.name}  •  {manifest.version}\n{manifest.description}")
            item.setData(Qt.UserRole, manifest.app_id); item.setData(Qt.UserRole + 1, manifest.to_mapping())
            self.store_installed_list.addItem(item)
        if self.store_installed_list.count() == 0:
            item = QListWidgetItem("No local packages installed.\nUse ‘Install package…’ to select a validated .zip package."); item.setFlags(Qt.NoItemFlags); self.store_installed_list.addItem(item)

    def _store_package_menu(self, position):
        item = self.store_installed_list.itemAt(position)
        if item is None or not item.data(Qt.UserRole): return
        manifest = PackageManifest.from_mapping(item.data(Qt.UserRole + 1))
        menu = QMenu(self)
        details = menu.addAction("Package details")
        entry = self.package_manager.entrypoint(manifest)
        run = menu.addAction("Run entrypoint") if entry is not None else None
        uninstall = menu.addAction("Uninstall")
        selected = menu.exec(self.store_installed_list.mapToGlobal(position))
        if selected is details:
            self.desktop.show_system_message(manifest.name, f"Version: {manifest.version}\nCategory: {manifest.category}\nID: {manifest.app_id}\n\n{manifest.description}")
        elif run is not None and selected is run:
            self._store_confirm_run(manifest, entry)
        elif selected is uninstall:
            self.desktop.show_confirm("Uninstall package", f"Move {manifest.name} to the Nexora package trash?", lambda: self._store_uninstall(manifest))

    def _store_confirm_run(self, manifest: PackageManifest, entrypoint: Path):
        self.desktop.show_confirm(
            "Run package code",
            f"Run {manifest.name}'s Python entrypoint as your current user? Only run packages you trust.",
            lambda: self._store_run_entrypoint(manifest, entrypoint),
        )

    def _store_run_entrypoint(self, manifest: PackageManifest, entrypoint: Path):
        ok, _pid = QProcess.startDetached(sys.executable, [str(entrypoint)], str(entrypoint.parent))
        if ok: self.desktop.notch.notify(f"Started {manifest.name}")
        else: self.desktop.show_system_message("Store", "The package entrypoint could not be started.")

    def _store_uninstall(self, manifest: PackageManifest):
        try: self.package_manager.uninstall(manifest.app_id)
        except (OSError, PackageError) as exc: self.desktop.show_system_message("Store", str(exc)); return
        self.desktop.notch.notify(f"Uninstalled {manifest.name}"); self._store_refresh_installed()

    def _store_scan_updates(self):
        if not hasattr(self, "store_updates_list"): return
        self.store_updates_list.clear(); self._store_updates = self.package_manager.updates_from(NEXORA_HOME / "Downloads")
        for manifest, archive in self._store_updates:
            item = QListWidgetItem(f"{manifest.name}  •  {manifest.version}\n{archive.name}")
            item.setData(Qt.UserRole, str(archive)); self.store_updates_list.addItem(item)
        if not self._store_updates:
            item = QListWidgetItem("No package updates found in Downloads."); item.setFlags(Qt.NoItemFlags); self.store_updates_list.addItem(item)

    def _store_install_selected_update(self):
        item = self.store_updates_list.currentItem()
        if item is None or not item.data(Qt.UserRole): return
        self._store_install_package(Path(item.data(Qt.UserRole)))
