"""Desktop snapping and time-aware wallpaper behavior."""
from .shared import *


class DesktopLayoutMixin:
    def snap_widget(self, widget, *, live=False):
        """Magnetically join widgets to grid, edges and nearby widgets."""
        grid = max(8, int(load_settings().get("widget_gap", 12)))
        join_gap = 0
        threshold = 13 if live else max(22, grid + 10)
        g = widget.geometry()
        x, y = round(g.x() / grid) * grid, round(g.y() / grid) * grid
        best_x, best_y = (threshold + 1, x), (threshold + 1, y)
        for other in self.desktop_widgets:
            if other is widget or not other.isVisible():
                continue
            o = other.geometry()
            vertical_overlap = min(g.bottom(), o.bottom()) - max(g.top(), o.top())
            horizontal_overlap = min(g.right(), o.right()) - max(g.left(), o.left())
            if vertical_overlap > min(g.height(), o.height()) * 0.18:
                for candidate in (o.right() + join_gap + 1, o.left() - join_gap - g.width(), o.left(), o.right() - g.width() + 1):
                    distance = abs(g.x() - candidate)
                    if distance < best_x[0]: best_x = (distance, candidate)
                for candidate in (o.top(), o.bottom() - g.height() + 1):
                    distance = abs(g.y() - candidate)
                    if distance < best_y[0]: best_y = (distance, candidate)
            if horizontal_overlap > min(g.width(), o.width()) * 0.18:
                for candidate in (o.bottom() + join_gap + 1, o.top() - join_gap - g.height(), o.top(), o.bottom() - g.height() + 1):
                    distance = abs(g.y() - candidate)
                    if distance < best_y[0]: best_y = (distance, candidate)
                for candidate in (o.left(), o.right() - g.width() + 1):
                    distance = abs(g.x() - candidate)
                    if distance < best_x[0]: best_x = (distance, candidate)
        if best_x[0] <= threshold: x = best_x[1]
        if best_y[0] <= threshold: y = best_y[1]
        widget.move(
            max(0, min(x, self.app_layer.width() - g.width())),
            max(0, min(y, self.app_layer.height() - g.height())),
        )

    def apply_wallpaper_variant(self, variant=None, _family=None, *, persist=True):
        settings = load_settings()
        selected = str(variant or settings.get("wallpaper_variant", "light")).casefold()
        if selected not in {"light", "dark"}: selected = "light"
        if persist and settings.get("wallpaper_variant") != selected:
            settings["wallpaper_variant"] = selected
            save_settings(settings)
        configured = str(settings.get(f"wallpaper_{selected}", "")).strip()
        target = Path(configured).expanduser()
        if not target.is_absolute():
            target = (PROJECT_ROOT.parent / target).resolve()
        if not target.is_file():
            fallback = "Blue Horizon 4K.jpg" if selected == "light" else "Wolf Moon 4K.jpg"
            target = WALLPAPERS_DIR / fallback
        current = getattr(self, "wallpaper_path", None)
        if target.is_file() and (current is None or target.resolve() != current.resolve()):
            self.set_wallpaper(target, persist=False)
