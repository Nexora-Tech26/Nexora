import logging
from .shared import *

class NexoraSearchWorker(QThread):
    # Crash-resistant search engine used by Nexora Browser.
    finished_html = Signal(str, str)

    def __init__(self, query: str, parent=None):
        super().__init__(parent)
        self.query = query.strip()

    def cancel(self):
        self.requestInterruption()

    @staticmethod
    def _escape(value: str) -> str:
        import html
        return html.escape(value or "")

    def run(self):
        import html
        query = self.query
        if not query:
            self.finished_html.emit("Nexora Search", self.home_html())
            return
        results = []
        summary = ""
        if self.isInterruptionRequested():
            return
        try:
            wiki_url = "https://en.wikipedia.org/w/api.php?" + urllib.parse.urlencode({
                "action": "opensearch", "search": query, "limit": 6,
                "namespace": 0, "format": "json", "origin": "*",
            })
            req = urllib.request.Request(wiki_url, headers={"User-Agent": "Nexora/26.4"})
            with urllib.request.urlopen(req, timeout=5) as response:
                payload = json.loads(response.read().decode("utf-8", "replace"))
            titles, descriptions, links = payload[1], payload[2], payload[3]
            for title, description, link in zip(titles, descriptions, links):
                results.append((title, description or "Wikipedia result", link, "Wikipedia"))
        except Exception as exc:
            logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)
        if self.isInterruptionRequested():
            return
        try:
            ddg_url = "https://api.duckduckgo.com/?" + urllib.parse.urlencode({
                "q": query, "format": "json", "no_html": 1, "skip_disambig": 1,
            })
            req = urllib.request.Request(ddg_url, headers={"User-Agent": "Nexora/26.4"})
            with urllib.request.urlopen(req, timeout=5) as response:
                payload = json.loads(response.read().decode("utf-8", "replace"))
            summary = payload.get("AbstractText", "") or ""
            if payload.get("AbstractURL") and summary:
                results.insert(0, (payload.get("Heading") or query, summary, payload["AbstractURL"], payload.get("AbstractSource") or "Knowledge"))
            for item in payload.get("RelatedTopics", [])[:8]:
                if isinstance(item, dict) and item.get("FirstURL") and item.get("Text"):
                    results.append((item["Text"].split(" - ")[0], item["Text"], item["FirstURL"], "Related"))
        except Exception as exc:
            logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)
        if self.isInterruptionRequested():
            return
        # Always include robust direct searches as fallbacks.
        encoded = urllib.parse.quote_plus(query)
        results.extend([
            (f"Search the web for {query}", "Open privacy-friendly web results.", f"https://duckduckgo.com/?q={encoded}", "Web"),
            (f"Search videos for {query}", "Open video search results.", f"https://www.youtube.com/results?search_query={encoded}", "Video"),
        ])
        seen=set(); clean=[]
        for item in results:
            if item[2] not in seen:
                seen.add(item[2]); clean.append(item)
        cards=[]
        for title, desc, link, source in clean[:12]:
            cards.append(
                f'<div class="card"><div class="source">{html.escape(source)}</div>'
                f'<a href="{html.escape(link)}"><h3>{html.escape(title)}</h3></a>'
                f'<p>{html.escape(desc)}</p></div>'
            )
        body = ''.join(cards) or '<div class="card"><h3>No online results</h3><p>Check the connection or try another phrase.</p></div>'
        self.finished_html.emit(f"{query} — Nexora Search", self.wrap_html(f"Results for “{html.escape(query)}”", body))

    @classmethod
    def wrap_html(cls, heading: str, body: str) -> str:
        return f'''<!doctype html><html><head><meta charset="utf-8"><style>
        body{{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:transparent;color:#f4f4f5;margin:18px;}}
        h1{{font-size:27px;margin:6px 0 18px}} h3{{margin:3px 0 6px;color:#dce9ff}}
        a{{text-decoration:none}} p{{color:#c4c8d2;line-height:1.45;margin:0}}
        .card{{background:rgba(255,255,255,.07);border:none;border-radius:24px;padding:15px;margin:10px 0}}
        .source{{color:#8ab4f8;font-size:12px;font-weight:600}}
        .hero{{background:linear-gradient(135deg,rgba(138,180,248,.25),rgba(185,167,232,.18));border-radius:24px;padding:22px}}
        </style></head><body><div class="hero"><h1>{heading}</h1><p>Nexora Search combines key-free public sources and opens pages safely in your default browser.</p></div>{body}</body></html>'''

    @classmethod
    def home_html(cls) -> str:
        body='''<div class="card"><h3>Private by design</h3><p>No embedded Chromium process, no browser crash taking down Nexora, and no API key required.</p></div>
        <div class="card"><h3>Search from the address bar</h3><p>Enter a topic, website address, or question. Nexora Search ranks knowledge results and safe external links.</p></div>'''
        return cls.wrap_html("Nexora Browser", body)

