import logging
from .shared import *
from .components import DockHoverButton, InternalFilePicker, SystemOverlay
from .desktop_widget import DesktopWidget
from .desktop_layout import DesktopLayoutMixin

class DesktopStateMixin(DesktopLayoutMixin):
    def show_system_message(self, title, text):
        if hasattr(self, "sound_service"):
            self.sound_service.play("error")
        overlay=SystemOverlay(self,str(title),str(text))
        close=QPushButton("OK");close.setStyleSheet(oneui_button_css("#8AB4F8",radius=13));close.clicked.connect(overlay.deleteLater);overlay.buttons.addWidget(close)
        return overlay

    def show_clipboard_history(self):
        overlay = SystemOverlay(self, "Clipboard history", "Select an item to copy it back to the clipboard.")
        overlay.setFixedSize(620, 510)
        overlay.move((self.ui_layer.width() - overlay.width()) // 2, (self.ui_layer.height() - overlay.height()) // 2)
        history = QListWidget()
        history.setWordWrap(True)
        history.setStyleSheet(
            f"QListWidget{{background:rgba(255,255,255,24);color:{TEXT};border:none;border-radius:22px;padding:7px;}}"
            "QListWidget::item{padding:10px;margin:2px;border-radius:22px;}"
            "QListWidget::item:selected{background:rgba(138,180,248,110);}"
        )
        values = list(self.clipboard_service.history()) if hasattr(self, "clipboard_service") else []
        if values:
            for index, value in enumerate(values):
                compact = value.replace("\n", " ").strip()
                item = QListWidgetItem(compact[:180] + ("…" if len(compact) > 180 else ""))
                item.setData(Qt.UserRole, index)
                item.setToolTip(value[:1200])
                item.setSizeHint(QSize(0, 48))
                history.addItem(item)
        else:
            item = QListWidgetItem("Clipboard history is empty")
            item.setFlags(Qt.NoItemFlags)
            history.addItem(item)
        overlay.layout().insertWidget(2, history, 1)

        def restore_selected():
            item = history.currentItem()
            if item is None or item.data(Qt.UserRole) is None:
                return
            if self.clipboard_service.restore(int(item.data(Qt.UserRole))):
                self.notch.notify("Copied from clipboard history")
                overlay.deleteLater()

        history.itemDoubleClicked.connect(lambda *_: restore_selected())
        clear_button = QPushButton("Clear history")
        clear_button.setStyleSheet(oneui_button_css("#F47C8C", radius=13))
        clear_button.setEnabled(bool(values))
        clear_button.clicked.connect(lambda: (self.clipboard_service.clear(), overlay.deleteLater()))
        close_button = QPushButton("Close")
        close_button.setStyleSheet(oneui_button_css("#B9A7E8", radius=13))
        close_button.clicked.connect(overlay.deleteLater)
        paste_button = QPushButton("Copy selected")
        paste_button.setStyleSheet(oneui_button_css("#8AB4F8", radius=13))
        paste_button.setEnabled(bool(values))
        paste_button.clicked.connect(restore_selected)
        overlay.buttons.addWidget(clear_button)
        overlay.buttons.addWidget(close_button)
        overlay.buttons.addWidget(paste_button)
        if values:
            history.setCurrentRow(0)
        return overlay

    def show_file_picker(self, title, mode, callback, default_name="", extensions=None):
        picker=InternalFilePicker(self,str(title),str(mode),callback,str(default_name or ""),sorted(extensions or []))
        self._active_file_picker=picker
        return picker

    def toggle_start(self):
        if getattr(self.menu,"_animating",False): return
        target=getattr(self,"_start_target_rect",QRect(10,10,self.menu.width(),self.menu.height()))
        opening=not self.menu.isVisible()
        self.menu._animating=True
        if opening:
            self.menu.setGraphicsEffect(None);self.menu.setGeometry(target.translated(0,22));self.menu.show();self.menu.raise_();self.menu.search.setFocus()
            if load_settings().get("animations",True) and load_settings().get("start_animation",True):
                effect=QGraphicsOpacityEffect(self.menu);self.menu.setGraphicsEffect(effect);group=QParallelAnimationGroup(self.menu)
                a=QPropertyAnimation(self.menu,b"geometry",group);a.setDuration(MOTION.menu_open);a.setStartValue(target.translated(0,26));a.setEndValue(target);a.setEasingCurve(enter_curve())
                o=QPropertyAnimation(effect,b"opacity",group);o.setDuration(MOTION.menu_open);o.setStartValue(0.08);o.setEndValue(1.0);group.addAnimation(a);group.addAnimation(o)
                def done():self.menu.setGeometry(target);self.menu.setGraphicsEffect(None);self.menu._animating=False
                group.finished.connect(done);self.menu._show_anim=group;group.start()
            else:self.menu.setGeometry(target);self.menu._animating=False
        else:
            if load_settings().get("animations",True) and load_settings().get("start_animation",True):
                effect=QGraphicsOpacityEffect(self.menu);self.menu.setGraphicsEffect(effect);group=QParallelAnimationGroup(self.menu)
                a=QPropertyAnimation(self.menu,b"geometry",group);a.setDuration(MOTION.menu_close);a.setStartValue(target);a.setEndValue(target.translated(0,20));a.setEasingCurve(exit_curve())
                o=QPropertyAnimation(effect,b"opacity",group);o.setDuration(MOTION.menu_close);o.setStartValue(1.0);o.setEndValue(0.0);o.setEasingCurve(exit_curve());group.addAnimation(a);group.addAnimation(o)
                def done():self.menu.hide();self.menu.setGeometry(target);self.menu.setGraphicsEffect(None);self.menu._animating=False
                group.finished.connect(done);self.menu._hide_anim=group;group.start()
            else:self.menu.hide();self.menu.setGeometry(target);self.menu._animating=False
        if hasattr(self,"power_overlay") and self.power_overlay.isVisible():self.power_overlay.raise_()

    def show_text_prompt(self, title, label, callback, default_text=""):
        overlay = SystemOverlay(self, str(title), str(label))
        field = QLineEdit(str(default_text or ""))
        field.setStyleSheet(glass_input_css(ACCENT))
        overlay.layout().insertWidget(2, field)
        error = QLabel(); error.setStyleSheet("color:#FF7777;background:transparent;")
        overlay.layout().insertWidget(3, error)
        cancel = QPushButton("Cancel"); cancel.setStyleSheet(oneui_button_css("#B9A7E8", radius=13)); cancel.clicked.connect(overlay.deleteLater)
        accept = QPushButton("Create"); accept.setStyleSheet(oneui_button_css("#8AB4F8", radius=13))
        def submit_value():
            value = field.text().strip()
            if not value:
                error.setText("Name cannot be empty."); return
            try:
                callback(value)
            except Exception as exc:
                error.setText(str(exc)); return
            overlay.deleteLater()
        accept.clicked.connect(submit_value); field.returnPressed.connect(submit_value)
        overlay.buttons.addWidget(cancel); overlay.buttons.addWidget(accept); field.setFocus()

    def show_password_prompt(self, title, label, callback):
        overlay = SystemOverlay(self, str(title), str(label))
        field = QLineEdit(); field.setEchoMode(QLineEdit.Password); field.setPlaceholderText("Password")
        field.setStyleSheet(glass_input_css(ACCENT)); overlay.layout().insertWidget(2, field)
        cancel = QPushButton("Cancel"); cancel.setStyleSheet(oneui_button_css("#B9A7E8", radius=13)); cancel.clicked.connect(overlay.deleteLater)
        accept = QPushButton("Continue"); accept.setStyleSheet(oneui_button_css("#8AB4F8", radius=13))
        def submit():
            value = field.text(); overlay.deleteLater(); callback(value)
        accept.clicked.connect(submit); field.returnPressed.connect(submit)
        overlay.buttons.addWidget(cancel); overlay.buttons.addWidget(accept); field.setFocus()

    def show_confirm(self, title, text, callback):
        overlay = SystemOverlay(self, str(title), str(text))
        cancel = QPushButton("Cancel"); cancel.setStyleSheet(oneui_button_css("#B9A7E8", radius=13)); cancel.clicked.connect(overlay.deleteLater)
        accept = QPushButton("Confirm"); accept.setStyleSheet(oneui_button_css("#F47C8C", radius=13))
        accept.clicked.connect(lambda: (overlay.deleteLater(), callback()))
        overlay.buttons.addWidget(cancel); overlay.buttons.addWidget(accept)

    def load_pinned_folders(self):
        """Return valid folders shown in Start and Files.

        Runtime state is deliberately stored under ``System/data`` and is
        excluded from the integrity snapshot. Invalid or deleted entries are
        removed automatically so a stale JSON file cannot break desktop boot.
        """
        defaults = []
        home = NEXORA_HOME if NEXORA_HOME.exists() else PROJECT_ROOT
        for candidate in (home, home / "Desktop", home / "Documents", home / "Downloads", home / "Images", home / "Music", home / "Videos"):
            try:
                resolved = candidate.expanduser().resolve()
            except OSError:
                continue
            if resolved.exists() and resolved.is_dir() and resolved not in defaults:
                defaults.append(resolved)
        try:
            raw = json.loads(PINNED_FOLDERS_FILE.read_text(encoding="utf-8"))
            folders = []
            for value in raw if isinstance(raw, list) else []:
                try:
                    folder = Path(value).expanduser().resolve()
                except (OSError, TypeError):
                    continue
                if folder.exists() and folder.is_dir() and inside_home(folder) and folder not in folders:
                    folders.append(folder)
            return folders or defaults
        except (OSError, json.JSONDecodeError, TypeError):
            return defaults

    def save_pinned_folders(self, folders):
        clean = []
        for value in folders:
            try:
                folder = Path(value).expanduser().resolve()
            except (OSError, TypeError):
                continue
            if folder.exists() and folder.is_dir() and inside_home(folder) and folder not in clean:
                clean.append(folder)
        PINNED_FOLDERS_FILE.write_text(
            json.dumps([str(folder) for folder in clean], indent=2),
            encoding="utf-8",
        )
        return clean

    def pin_folder(self, folder):
        try:
            folder = Path(folder).expanduser().resolve()
        except (OSError, TypeError):
            return False
        if not folder.exists() or not folder.is_dir() or not inside_home(folder):
            return False
        folders = self.load_pinned_folders()
        if folder not in folders:
            folders.append(folder)
            self.save_pinned_folders(folders)
        if hasattr(self, "menu"):
            self.menu.refresh_folders()
        self.notch.notify("Folder pinned")
        return True

    def open_folder(self, folder):
        try:
            folder = Path(folder).expanduser().resolve()
        except (OSError, TypeError):
            return
        if not folder.exists() or not folder.is_dir():
            self.show_system_message("Files", "This folder is no longer available.")
            if hasattr(self, "menu"):
                self.menu.refresh_folders()
            return
        files_path = next((path for path in self.app_paths if app_name(path) == "Files"), None)
        if files_path is None:
            self.show_system_message("Files", "The Files application is unavailable.")
            return
        self.open_app(files_path)
        window = self.windows.get(files_path.resolve())
        if window is not None and hasattr(window, "navigate_files"):
            window.navigate_files(folder)
        self.menu.hide()

    def show_power_overlay(self):
        self.menu.hide()
        self.power_overlay.show_overlay()
        self.notch.notify("Power")

    def restart_ui(self):
        """Restart the visual shell without spawning a second Qt instance."""
        self.power_overlay.hide()
        for window in list(self.windows.values()):
            window.hide()
            window.deleteLater()
        self.windows.clear()
        self.refresh_taskbar()
        self.menu.refresh_folders()
        self.menu.refresh()
        self.position_shells()
        self.raise_shells()
        self.notch.notify("UI restarted")

    def load_pins(self):
        try:
            raw = json.loads(PINNED_FILE.read_text(encoding="utf-8"))
            values = []
            for value in raw if isinstance(raw, list) else []:
                candidate = Path(value)
                if not candidate.is_absolute():
                    candidate = APPS_DIR / candidate
                candidate = candidate.resolve()
                try:
                    candidate.relative_to(APPS_DIR.resolve())
                except ValueError:
                    continue
                if candidate.is_file() and candidate.suffix == ".py" and candidate not in values:
                    values.append(candidate)
            if values:
                return values
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            logging.getLogger(__name__).debug("Pinned application store unavailable: %s", exc)
        defaults = ("Browser", "Files", "Notepad", "Settings", "Gallery", "Terminal")
        found = []
        for wanted in defaults:
            path = next((p.resolve() for p in self.app_paths if app_name(p) == wanted), None)
            if path is not None:
                found.append(path)
        return found

    def save_pins(self):
        PINNED_FILE.parent.mkdir(parents=True, exist_ok=True)
        portable = []
        for item in self.pinned:
            path = Path(item).resolve()
            try:
                portable.append(str(path.relative_to(APPS_DIR.resolve())))
            except ValueError:
                continue
        temporary = PINNED_FILE.with_suffix(PINNED_FILE.suffix + ".tmp")
        temporary.write_text(json.dumps(portable, indent=2), encoding="utf-8")
        os.replace(temporary, PINNED_FILE)

    def is_pinned(self, path):
        return Path(path).resolve() in self.pinned

    def toggle_pin(self, path):
        path = Path(path).resolve()
        if path in self.pinned:
            self.pinned.remove(path)
            state = False
        else:
            self.pinned.append(path)
            state = True
        self.save_pins()
        self.refresh_taskbar()
        self.menu.refresh()
        self.notch.notify(("Pinned " if state else "Unpinned ") + app_name(path))
        return state



    def set_wallpaper(self, path, *, persist=True):
        path = Path(path).expanduser().resolve()
        if not path.exists() or not path.is_file():
            self.show_system_message("Wallpaper", "The selected wallpaper is unavailable.")
            return False
        settings = load_settings()
        previous_pixmap = QPixmap()
        if hasattr(self, "background") and self.background.pixmap() is not None:
            previous_pixmap = QPixmap(self.background.pixmap())
        if persist:
            try:
                portable_path = str(path.relative_to(PROJECT_ROOT.parent))
            except ValueError:
                portable_path = str(path)
            variant = str(settings.get("wallpaper_variant", "light")).casefold()
            if variant not in {"light", "dark"}:
                variant = "light"
            settings["wallpaper"] = portable_path
            settings[f"wallpaper_{variant}"] = portable_path
            settings["wallpaper_variant"] = variant
            save_settings(settings)
        try:
            self.wallpaper_service.set_wallpaper(path, fit=str(settings.get("wallpaper_fit", "fill")), saturation=int(settings.get("material_saturation", 100)))
            self.wallpaper_service.update_viewport(self.size(), self.devicePixelRatioF())
        except (OSError, ValueError) as exc:
            self.show_system_message("Wallpaper", str(exc))
            return False
        self.wallpaper_path = path
        self.wallpaper = self.wallpaper_service.original
        self.blurred_scaled = self.wallpaper_service.blurred_pixmap(int(settings.get("blur_radius", 48)))
        if hasattr(self, "background"):
            self.background.setPixmap(self.wallpaper_service.scaled)
            self.background.update()
            if settings.get("animations", True) and not settings.get("reduce_motion", False) and not previous_pixmap.isNull():
                old_overlay = getattr(self, "_wallpaper_transition_overlay", None)
                if old_overlay is not None:
                    old_overlay.deleteLater()
                overlay = QLabel(self)
                overlay.setAttribute(Qt.WA_TransparentForMouseEvents, True)
                overlay.setGeometry(self.background.geometry())
                overlay.setAlignment(Qt.AlignCenter)
                overlay.setPixmap(previous_pixmap)
                overlay.show()
                overlay.stackUnder(self.ui_layer)
                effect = QGraphicsOpacityEffect(overlay)
                overlay.setGraphicsEffect(effect)
                animation = QPropertyAnimation(effect, b"opacity", overlay)
                animation.setDuration(380)
                animation.setStartValue(1.0)
                animation.setEndValue(0.0)
                animation.setEasingCurve(QEasingCurve.OutCubic)
                animation.finished.connect(overlay.deleteLater)
                animation.finished.connect(lambda: setattr(self, "_wallpaper_transition_overlay", None))
                self._wallpaper_transition_overlay = overlay
                self._wallpaper_transition_animation = animation
                animation.start()
        for widget in list(getattr(self, "desktop_widgets", [])) + list(getattr(self, "window_z", [])):
            widget.update()
        return True


    def next_wallpaper(self):
        files = wallpaper_files()
        if not files:
            return
        current = getattr(self, "wallpaper_path", current_wallpaper_path()).resolve()
        try:
            index = [p.resolve() for p in files].index(current)
        except ValueError:
            index = -1
        self.set_wallpaper(files[(index + 1) % len(files)])
        if hasattr(self, "notch"):
            self.notch.notify("Wallpaper changed")

    def show_desktop_menu(self, global_pos):
        now=time.monotonic()
        if now-getattr(self,"_desktop_menu_last",0.0)<0.35 or getattr(self,"_desktop_menu_open",False):
            return
        self._desktop_menu_last=now; self._desktop_menu_open=True
        menu = create_nexora_menu(self)
        wallpaper_menu = menu.addMenu("Choose wallpaper")
        wallpaper_actions = {}
        for path in wallpaper_files():
            width, height, tier = wallpaper_details(path)
            action = wallpaper_menu.addAction(f"{path.stem}  ·  {tier}")
            action.setToolTip(f"{width} × {height}")
            wallpaper_actions[action] = path
        next_action = menu.addAction("Next wallpaper")
        random_action = menu.addAction("Surprise me")
        menu.addSeparator()
        show_desktop_action = menu.addAction("Show desktop")
        tidy_action = menu.addAction("Tidy open windows")
        new_folder_action = menu.addAction("New folder on desktop")
        terminal_action = menu.addAction("Open Terminal")
        files_action = menu.addAction("Open Files")
        settings_action = menu.addAction("Open Settings")
        widgets_action = menu.addAction("Toggle desktop widgets")
        tiling_action = menu.addAction("Toggle window tiling")
        lock_action = menu.addAction("Lock Nexora")
        menu.addSeparator()
        icon_size_menu=menu.addMenu("Icon size")
        small_icons=icon_size_menu.addAction("Small"); medium_icons=icon_size_menu.addAction("Medium"); large_icons=icon_size_menu.addAction("Large")
        arrange_action=menu.addAction("Auto arrange icons"); arrange_action.setCheckable(True); arrange_action.setChecked(bool(load_settings().get("desktop_auto_arrange",False)))
        grid_action=menu.addAction("Align icons to grid"); grid_action.setCheckable(True); grid_action.setChecked(bool(load_settings().get("desktop_align_grid",True)))
        show_icons_action=menu.addAction("Show desktop icons"); show_icons_action.setCheckable(True); show_icons_action.setChecked(bool(load_settings().get("desktop_show_icons",True)))
        restore_layout_action=menu.addAction("Restore default icon layout")
        menu.addSeparator()
        clear_action = menu.addAction("Clear selection")
        refresh_action = menu.addAction("Refresh desktop")
        chosen = menu.exec(global_pos)
        self._desktop_menu_open=False
        if chosen in wallpaper_actions:
            self.set_wallpaper(wallpaper_actions[chosen]); self.notch.notify("Wallpaper changed")
        elif chosen == next_action:
            self.next_wallpaper()
        elif chosen == random_action:
            import random
            files = wallpaper_files()
            if files:
                self.set_wallpaper(random.choice(files)); self.notch.notify("Wallpaper changed")
        elif chosen == show_desktop_action:
            for group in self.window_groups.values():
                for window in group:
                    if window.isVisible(): window.minimize_animated()
            self.notch.notify("Desktop revealed")
        elif chosen == new_folder_action:
            base = NEXORA_HOME / "Desktop"
            base.mkdir(parents=True, exist_ok=True)
            index = 1
            target = base / "New folder"
            while target.exists():
                index += 1
                target = base / f"New folder {index}"
            target.mkdir()
            self.refresh_desktop_shortcuts(); self.notch.notify("Folder created")
        elif chosen == terminal_action:
            self.open_named_app("Terminal")
        elif chosen == files_action:
            self.open_named_app("Files")
        elif chosen == settings_action:
            self.open_named_app("Settings")
        elif chosen == widgets_action:
            st=load_settings(); st["desktop_show_widgets"]=not bool(st.get("desktop_show_widgets",False)); save_settings(st)
            if hasattr(self,"refresh_desktop_widgets"): self.refresh_desktop_widgets()
        elif chosen == tiling_action:
            st=load_settings(); st["tiling_enabled"]=not bool(st.get("tiling_enabled",False)); save_settings(st)
            if hasattr(self,"apply_tiling_mode"): self.apply_tiling_mode(st["tiling_enabled"])
        elif chosen == lock_action:
            if hasattr(self,"lock_session"): self.lock_session()
        elif chosen == tidy_action:
            visible=[w for group in self.window_groups.values() for w in group if w.isVisible()]
            if visible:
                gap=max(10,int(load_settings().get("widget_gap",12))); cols=max(1,int(len(visible)**0.5)); rows=(len(visible)+cols-1)//cols
                cell_w=max(360,(self.app_layer.width()-gap*(cols+1))//cols); cell_h=max(260,(self.app_layer.height()-gap*(rows+1))//rows)
                for i,w in enumerate(visible):
                    w.setGeometry(gap+(i%cols)*(cell_w+gap),gap+(i//cols)*(cell_h+gap),cell_w,cell_h)
            self.notch.notify("Workspace tidied")
        elif chosen in {small_icons,medium_icons,large_icons}:
            mode={small_icons:"small",medium_icons:"medium",large_icons:"large"}[chosen]
            st=load_settings();st["icon_size"]=mode;save_settings(st)
            for item in self.desktop_shortcuts:item.apply_size(mode)
            self.finish_desktop_shortcut_drag()
        elif chosen in {arrange_action,grid_action,show_icons_action}:
            st=load_settings();st["desktop_auto_arrange"]=arrange_action.isChecked();st["desktop_align_grid"]=grid_action.isChecked();st["desktop_show_icons"]=show_icons_action.isChecked();save_settings(st);self.refresh_desktop_shortcuts()
        elif chosen == restore_layout_action:
            self.restore_default_desktop_layout()
        elif chosen == clear_action:
            self.selection_glass.hide(); self._selection_origin = None; self.clear_desktop_shortcut_selection()
        elif chosen == refresh_action:
            self.reload_app_catalog(); self.refresh_taskbar(); self.update()

    def _desktop_local_point(self, watched, event):
        try:
            global_point = event.globalPosition().toPoint()
            return self.app_layer.mapFromGlobal(global_point)
        except (AttributeError, RuntimeError):
            return QPoint()

    def _point_hits_desktop_object(self, global_pos):
        """Return True when a desktop-level event is geometrically over UI.

        Transparent child widgets can let mouse events bubble to AppLayer on
        macOS. Geometry checking prevents selection rectangles from starting
        through an application, widget, shortcut, snap overlay, or menu.
        """
        try:
            local = self.app_layer.mapFromGlobal(global_pos)
        except RuntimeError:
            return False
        for window in list(getattr(self, "window_z", [])):
            try:
                if window.isVisible() and window.geometry().contains(local):
                    return True
            except RuntimeError:
                continue
        for widget in list(getattr(self, "desktop_widgets", [])) + list(getattr(self, "desktop_shortcuts", [])):
            try:
                if widget.isVisible() and widget.geometry().contains(local):
                    return True
            except RuntimeError:
                continue
        for overlay_name in ("_snap_picker", "_snap_assist"):
            overlay = getattr(self, overlay_name, None)
            try:
                if overlay is not None and overlay.isVisible():
                    return True
            except RuntimeError:
                pass
        return False

    def eventFilter(self, watched, event):
        try:
            event_type = event.type()
            if event_type == QEvent.KeyPress and hasattr(self, "_handle_global_shortcut"):
                if self._handle_global_shortcut(event):
                    return True
            if event_type == QEvent.MouseButtonRelease and hasattr(event, "button") and event.button() == Qt.LeftButton and isinstance(watched, (QPushButton, QToolButton)):
                if hasattr(self, "sound_service"):
                    self.sound_service.play("click")
            desktop_surface = watched in (getattr(self, "app_layer", None), getattr(self, "background", None), getattr(self, "ui_layer", None))
            if desktop_surface and event_type in (QEvent.ContextMenu, QEvent.MouseButtonPress, QEvent.MouseMove, QEvent.MouseButtonRelease):
                try:
                    global_pos = event.globalPosition().toPoint()
                except AttributeError:
                    global_pos = event.globalPos() if hasattr(event, "globalPos") else QCursor.pos()
                if self._point_hits_desktop_object(global_pos):
                    return False
            if desktop_surface and event_type == QEvent.ContextMenu:
                self.show_desktop_menu(event.globalPos())
                return True
            if desktop_surface and event_type == QEvent.MouseButtonPress and event.button() == Qt.LeftButton:
                panel = getattr(self, "control_center", None)
                if panel is not None and panel.isVisible():
                    try:
                        local_panel_point = panel.mapFromGlobal(global_pos)
                        if not panel.rect().contains(local_panel_point):
                            panel.hide_animated() if hasattr(panel, "hide_animated") else panel.hide()
                    except RuntimeError:
                        pass
                point = self._desktop_local_point(watched, event)
                self._selection_origin = point
                self.selection_glass.setGeometry(QRect(point, point))
                self.selection_glass.show(); self.selection_glass.lower()
                return True
            if desktop_surface and event_type == QEvent.MouseMove and self._selection_origin is not None and event.buttons() & Qt.LeftButton:
                point = self._desktop_local_point(watched, event)
                rect = QRect(self._selection_origin, point).normalized().intersected(self.app_layer.rect())
                self.selection_glass.setGeometry(rect)
                self.selection_glass.lower()
                return True
            if desktop_surface and event_type == QEvent.MouseButtonRelease and event.button() == Qt.LeftButton and self._selection_origin is not None:
                origin = self._selection_origin
                self._selection_origin = None
                rect = QRect(self.selection_glass.geometry())
                if rect.width() < 5 or rect.height() < 5:
                    self.clear_desktop_shortcut_selection()
                else:
                    additive = bool(event.modifiers() & (Qt.ControlModifier | Qt.MetaModifier))
                    if not additive:
                        self.clear_desktop_shortcut_selection()
                    for shortcut in self.desktop_shortcuts:
                        if rect.intersects(shortcut.geometry()):
                            shortcut.set_selected(True)
                self.selection_glass.hide()
                return True
            if event_type == QEvent.MouseButtonPress:
                # Local imports avoid the Desktop -> mixin -> AppWindow circular import
                # while keeping runtime type checks reliable on every platform.
                from .app_window import AppWindow
                from .desktop_widget import DesktopWidget
                w = watched
                visited = set()
                while w is not None and id(w) not in visited:
                    visited.add(id(w))
                    if isinstance(w, AppWindow):
                        self.activate_window(w); break
                    if isinstance(w, DesktopWidget):
                        self.activate_widget(w); break
                    w = w.parentWidget() if hasattr(w, "parentWidget") else None
        except (RuntimeError, AttributeError):
            pass
        return False

    def activate_window(self, window):
        if window in self.window_z:self.window_z.remove(window)
        self.window_z.append(window);window.raise_()
        mac = False
        if hasattr(window, "toolbar"):
            window.toolbar.setVisible(not mac)
        if mac:
            self.rebuild_global_menu(window)
        for widget in self.desktop_widgets: widget.stackUnder(window)
        self.raise_shells()

    def activate_widget(self, widget):
        widget.raise_();self.raise_shells()

    def snap_window(self, window):
        gap = int(load_settings().get("widget_gap", 12))
        threshold = max(24, gap + 10)
        g = window.geometry()
        host_w, host_h = self.app_layer.width(), self.app_layer.height()
        x, y = g.x(), g.y()

        # Screen-edge snap zones: left half, right half and full workspace.
        if g.left() <= threshold:
            target = QRect(gap, gap, max(420, (host_w - gap * 3) // 2), max(300, host_h - gap * 2))
            window.setGeometry(target); window._zoomed = False; window._normal_geometry = target; return
        if host_w - g.right() <= threshold:
            half = max(420, (host_w - gap * 3) // 2)
            target = QRect(host_w - half - gap, gap, half, max(300, host_h - gap * 2))
            window.setGeometry(target); window._zoomed = False; window._normal_geometry = target; return
        if g.top() <= threshold:
            target = QRect(gap, gap, max(420, host_w - gap * 2), max(300, host_h - gap * 2))
            window.setGeometry(target); window._zoomed = True; return

        # Magnetic alignment to grid and neighbouring windows.
        x = round(x / gap) * gap
        y = round(y / gap) * gap
        for group in self.window_groups.values():
            for other in group:
                if other is window or not other.isVisible():
                    continue
                o = other.geometry()
                if abs(g.left() - (o.right() + gap)) < threshold: x = o.right() + gap
                if abs(g.right() - (o.left() - gap)) < threshold: x = o.left() - gap - g.width() + 1
                if abs(g.top() - (o.bottom() + gap)) < threshold: y = o.bottom() + gap
                if abs(g.bottom() - (o.top() - gap)) < threshold: y = o.top() - gap - g.height() + 1
        x = max(0, min(x, host_w - g.width()))
        y = max(0, min(y, host_h - g.height()))
        window.move(x, y)
        window._zoomed = False
        window._normal_geometry = window.geometry()

    def add_desktop_widget(self, kind, pos=None, size="small", *, widget_id=None, locked=False, config=None):
        widget=DesktopWidget(self,kind,pos,size,widget_id=widget_id,locked=locked,config=config)
        self.desktop_widgets.append(widget);self.save_widget_layout();self.notch.notify(f"{widget._spec().title} widget added");self.raise_shells();return widget

    def remove_desktop_widget(self, widget):
        if widget in self.desktop_widgets:self.desktop_widgets.remove(widget)
        if hasattr(widget,"shutdown"):widget.shutdown()
        widget.deleteLater();self.save_widget_layout()

    def toggle_widget_edit_mode(self):
        self.widget_edit_mode=not bool(getattr(self,"widget_edit_mode",False))
        for widget in self.desktop_widgets:widget.set_edit_mode(self.widget_edit_mode)
        self.notch.notify("Widget edit mode on" if self.widget_edit_mode else "Widget edit mode off")


    def widget_layout_path(self): return DATA_DIR/'desktop_widgets.json'
    def save_widget_layout(self):
        payload=[{"id":w.widget_id,"kind":w.kind,"x":w.x(),"y":w.y(),"size":w.size_mode,"locked":w.locked,"config":w.config} for w in self.desktop_widgets]
        try:
            target=self.widget_layout_path();target.parent.mkdir(parents=True,exist_ok=True);temp=target.with_suffix(".tmp");temp.write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding="utf-8");temp.replace(target)
        except OSError:pass
    def desktop_shortcut_layout_path(self):
        return DATA_DIR / "desktop_shortcuts_layout.json"

    def selected_desktop_shortcuts(self):
        return [item for item in self.desktop_shortcuts if bool(item.property("selected"))]

    def clear_desktop_shortcut_selection(self):
        for item in self.desktop_shortcuts:
            item.set_selected(False)

    def select_desktop_shortcut(self, shortcut, *, additive=False, range_select=False):
        if range_select and getattr(self, "_last_desktop_shortcut", None) in self.desktop_shortcuts:
            start=self.desktop_shortcuts.index(self._last_desktop_shortcut); end=self.desktop_shortcuts.index(shortcut)
            if not additive: self.clear_desktop_shortcut_selection()
            for item in self.desktop_shortcuts[min(start,end):max(start,end)+1]: item.set_selected(True)
        elif additive:
            shortcut.set_selected(not bool(shortcut.property("selected")))
        else:
            if shortcut not in self.selected_desktop_shortcuts() or len(self.selected_desktop_shortcuts())>1:
                self.clear_desktop_shortcut_selection(); shortcut.set_selected(True)
        self._last_desktop_shortcut=shortcut

    def move_selected_desktop_shortcuts(self, starts, delta):
        host=self.app_layer.rect()
        for item,start in starts.items():
            point=start+delta
            x=max(0,min(point.x(),host.width()-item.width())); y=max(0,min(point.y(),host.height()-item.height()))
            item.move(x,y)

    def _shortcut_grid_point(self, point, item):
        settings=load_settings()
        if not settings.get("desktop_align_grid", True): return point
        grid=max(72, item.width()+8); row=max(72,item.height()+8)
        return QPoint(round(point.x()/grid)*grid+20,round(point.y()/row)*row+24)

    def _resolve_shortcut_overlap(self, item, point):
        candidate=QRect(point,item.size()); step=max(16,int(load_settings().get("widget_gap",12)))
        occupied=[other.geometry() for other in self.desktop_shortcuts if other is not item]
        attempts=0
        while any(candidate.intersects(rect.adjusted(4,4,-4,-4)) for rect in occupied) and attempts<200:
            candidate.moveLeft(candidate.x()+step)
            if candidate.right()>self.app_layer.width(): candidate.moveLeft(20); candidate.moveTop(candidate.y()+item.height()+step)
            if candidate.bottom()>self.app_layer.height(): candidate.moveTop(24)
            attempts+=1
        return candidate.topLeft()

    def finish_desktop_shortcut_drag(self):
        for item in self.selected_desktop_shortcuts():
            point=self._shortcut_grid_point(item.pos(),item)
            if load_settings().get("desktop_auto_arrange") or load_settings().get("desktop_align_grid",True):
                point=self._resolve_shortcut_overlap(item,point)
            item.set_position(point)
        self.save_desktop_shortcut_layout()

    def save_desktop_shortcut_layout(self):
        payload={}
        for item in self.desktop_shortcuts:
            payload[item.shortcut_file.name]={"x":item.x(),"y":item.y(),"size":item.size_mode}
        tmp=self.desktop_shortcut_layout_path().with_suffix(".tmp")
        tmp.write_text(json.dumps(payload,indent=2),encoding="utf-8"); tmp.replace(self.desktop_shortcut_layout_path())

    def restore_default_desktop_layout(self):
        try:self.desktop_shortcut_layout_path().unlink()
        except OSError:pass
        self.refresh_desktop_shortcuts()

    def desktop_shortcut_files(self):
        folder = NEXORA_HOME / "Desktop"
        folder.mkdir(parents=True, exist_ok=True)
        return sorted(folder.glob("*.nexora-app"), key=lambda p: p.stem.casefold())

    def refresh_desktop_shortcuts(self):
        from .desktop_shortcut import DesktopShortcut
        for button in list(getattr(self, "desktop_shortcuts", [])):
            try: button.deleteLater()
            except RuntimeError: pass
        self.desktop_shortcuts = []
        try:
            layout=json.loads(self.desktop_shortcut_layout_path().read_text(encoding="utf-8"))
            if not isinstance(layout,dict): layout={}
        except (OSError,json.JSONDecodeError): layout={}
        settings=load_settings()
        if not settings.get("desktop_show_icons",True): return
        columns=max(1,min(8,max(1,self.app_layer.width()//112)))
        shortcuts=self.desktop_shortcut_files()
        sort_mode=str(settings.get("desktop_sort","name"))
        if sort_mode=="date": shortcuts.sort(key=lambda p:p.stat().st_mtime,reverse=True)
        elif sort_mode=="type": shortcuts.sort(key=lambda p:(p.suffix.casefold(),p.stem.casefold()))
        for index,shortcut in enumerate(shortcuts):
            try:
                payload=json.loads(shortcut.read_text(encoding="utf-8")); app_path=Path(payload.get("app","")).expanduser().resolve()
            except (OSError,ValueError,TypeError,json.JSONDecodeError): continue
            if not app_path.exists():
                try:shortcut.unlink()
                except OSError:pass
                continue
            saved=layout.get(shortcut.name,{})
            row,col=divmod(index,columns); default=QPoint(20+col*104,24+row*100)
            point=QPoint(int(saved.get("x",default.x())),int(saved.get("y",default.y())))
            button=DesktopShortcut(self,app_path,shortcut,point,str(saved.get("size",settings.get("icon_size","medium"))))
            button.show(); button.raise_(); self.desktop_shortcuts.append(button)
        self.raise_shells()

    def load_widget_layout(self):
        try:data=json.loads(self.widget_layout_path().read_text(encoding="utf-8"))
        except (OSError,ValueError,TypeError,json.JSONDecodeError):data=[]
        allowed={spec.key for spec in self.widget_registry.all()}|{"Clock","Calendar","System","Battery","Storage","Notes","Files","Weather","Maps","Gallery","Downloads"}
        for item in data if isinstance(data,list) else []:
            try:
                kind=str(item.get("kind",""));size=str(item.get("size","small"))
                if kind not in allowed:continue
                point=QPoint(max(0,int(item.get("x",24))),max(0,int(item.get("y",24))))
                self.add_desktop_widget(kind,point,size,widget_id=item.get("id"),locked=bool(item.get("locked",False)),config=item.get("config") if isinstance(item.get("config"),dict) else {})
            except (TypeError,ValueError,RuntimeError):continue
        self.raise_shells()

    def open_app(self, path):
        path = Path(path).resolve()
        lock = self._app_locks().get(str(path)) if hasattr(self, "_app_locks") else None
        if lock:
            def verified(entered):
                if not self._verify_app_password(lock, entered):
                    self.show_system_message("Locked application", "Incorrect application password.")
                    return
                self._open_app_unlocked(path)
            self.show_password_prompt("Locked application", f"Password for {app_name(path)}", verified)
            return None
        return self._open_app_unlocked(path)

    def _open_app_unlocked(self, path):
        from .app_window import AppWindow
        path = Path(path).resolve()
        self.menu.hide()
        if path in self.window_groups and self.window_groups[path]:
            window = self.window_groups[path][-1]
            if window.isVisible(): self.activate_window(window)
            else: window.restore_animated()
            return window
        name = app_name(path)
        if hasattr(self, "app_badges"):
            self.app_badges.pop(path, None)
        if hasattr(self, "usage_service"):
            self.usage_service.record_launch(path)
        from System.navigation import NavigationModel
        sidebar = NavigationModel.for_app(name).has_sidebar
        toolbar = name in {"Files", "Notepad", "Gallery", "Paint", "Documents", "Code Editor", "Image Editor", "Video Editor", "Presentations"}
        size_profiles = {
            "Calculator": (460, 620), "Clock": (560, 610), "Calendar": (900, 690),
            "Files": (1080, 720), "Settings": (1050, 720), "Browser": (1180, 760),
            "Notepad": (860, 640), "Gallery": (1110, 730), "Paint": (1160, 750),
            "Maps": (1040, 700), "Weather": (760, 620), "Terminal": (940, 620),
            "Task Manager": (980, 670), "Widgets": (880, 650),
            "AboutPC": (760, 560), "BackUp": (820, 600), "Screenshot": (900, 620),
            "Welcome": (820, 590),
            "Image Editor": (1180, 760), "Video Editor": (1180, 760), "Code Editor": (1120, 740),
            "Documents": (980, 720), "Spreadsheets": (1180, 760), "Presentations": (1120, 740),
            "Virtual Machine": (900, 650), "Database": (1050, 700), "PDF Editor": (900, 690),
            "Audio Editor": (1040, 690), "Whiteboard": (1100, 720), "Archives": (900, 650),
"Notes": (1040, 700), "Markdown Editor": (1100, 720),
            "Mail": (980, 700), "Music Player": (900, 650), "Camera": (820, 620),
            "Recorder": (760, 540), "Screen Recorder": (760, 520), 
            "Package Manager": (1040, 700), "PDF Viewer": (960, 700), "System Monitor": (1060, 720),
            "Performance Monitor": (1060, 720), "System Health": (900, 680), "Disk Manager": (1000, 680),
            "Backup Manager": (960, 680), "Clipboard Manager": (880, 650), "Password Manager": (940, 700),
            "Color Picker": (720, 560), "Download Manager": (920, 650), "Game Launcher": (940, 680),
            "File Sharing": (900, 640), "Git Client": (1000, 680),
            "SSH Client": (820, 600), "FTP Client": (820, 600), "Remote Desktop": (720, 500),
            "Screen Mirroring": (720, 500), "Focus Mode": (760, 580), "Studio": (900, 620),
            "Media Center": (900, 620), "Terminal Pro": (980, 660),
            "Spaces": (940, 680), "Automation": (960, 680), "Extensions": (940, 660),
            "Photo Editor": (1180, 760), 
            "Task Manager Pro": (980, 670), "Virtual Machine Manager": (900, 650),
        }
        size = size_profiles.get(name, (930, 650))
        try:
            window = AppWindow(self, path, size, sidebar, toolbar)
        except Exception as exc:
            logger = getattr(self, "logger", None)
            if logger is not None:
                logger.exception("Application launch failed: %s", name)
            self.show_system_message("Application launch failed", f"{name}: {type(exc).__name__}: {exc}")
            return
        if hasattr(self, "sound_service"):
            self.sound_service.play("open")
        self.notch.notify(name)
        window.closed.connect(self.close_app)
        window.minimized.connect(lambda _: self.refresh_taskbar())
        self.window_groups.setdefault(path, []).append(window)
        self.windows[path] = window
        self.activate_window(window); self.refresh_taskbar(); self.raise_shells()
        if hasattr(self, "save_window_session"):
            self.save_window_session()
        QTimer.singleShot(0, self.arrange_tiled_windows)
        return window

    def open_app_new(self,path):
        from .app_window import AppWindow

        path=Path(path).resolve();name=app_name(path)
        if hasattr(self,"usage_service"):self.usage_service.record_launch(path)
        from System.navigation import NavigationModel
        sidebar=NavigationModel.for_app(name).has_sidebar;toolbar=name in {"Files","Notepad","Gallery","Paint"};size=(1040,690) if sidebar else ((930,650) if name not in {"Calculator","Clock"} else (430,590))
        window=AppWindow(self,path,size,sidebar,toolbar)
        if hasattr(self,"sound_service"):self.sound_service.play("open")
        window.closed.connect(self.close_app);window.minimized.connect(lambda _:self.refresh_taskbar());self.window_groups.setdefault(path,[]).append(window);self.windows[path]=window
        self.activate_window(window);self.refresh_taskbar()
        if hasattr(self,"save_window_session"):self.save_window_session()
        QTimer.singleShot(0, self.arrange_tiled_windows)
        return window

    def close_app(self, window):
        if hasattr(self, "sound_service"):
            self.sound_service.play("close")
        path = window.path
        window.deleteLater()
        group=self.window_groups.get(path,[])
        if window in group:group.remove(window)
        if group:self.windows[path]=group[-1]
        else:self.windows.pop(path,None);self.window_groups.pop(path,None)
        if window in self.window_z: self.window_z.remove(window)
        if hasattr(self, "save_window_session"):
            self.save_window_session()
        self.refresh_taskbar()
        QTimer.singleShot(0, self.arrange_tiled_windows)

    def task_target(self, path):
        button = self.task_buttons.get(Path(path).resolve())
        if button:
            global_pos = button.mapToGlobal(QPoint(0, 0))
            pos = self.app_layer.mapFromGlobal(global_pos)
            return QRect(pos.x(), pos.y(), max(36, button.width()), max(28, button.height()))
        return QRect(self.width() // 2 - 20, self.app_layer.height() - 20, 40, 30)

    def refresh_taskbar(self):
        if not self._ui_ready:
            return
        while self.task_layout.count():
            item = self.task_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.hide(); widget.setParent(None); widget.deleteLater()
        self.task_buttons = {}
        order = []
        pinned_set = {Path(path).resolve() for path in self.pinned}
        for path in self.pinned + list(self.windows):
            resolved = Path(path).resolve()
            if resolved not in order:
                order.append(resolved)
        if bool(load_settings().get("dock_recent_apps", True)) and bool(load_settings().get("predictive_dock", True)) and hasattr(self, "usage_service"):
            for recent in self.usage_service.top(self.app_paths, limit=3):
                if recent not in order and self.usage_service.score(recent) > 0:
                    order.append(recent)
        self._task_count = len(order) + (1 if load_settings().get("dock_show_trash", True) else 0)
        button_size, gap, _ = self._taskbar_metrics(); self.task_layout.setSpacing(gap)
        inserted_separator = False
        for index, path in enumerate(order):
            if not inserted_separator and index > 0 and path not in pinned_set and any(item in pinned_set for item in order[:index]):
                # No separator strokes: grouping is expressed only by spacing.
                spacer = QFrame(self.task_shell); spacer.setFixedSize(max(5, gap + 3), 1); spacer.setStyleSheet("background:transparent;border:none;")
                self.task_layout.addWidget(spacer, 0, Qt.AlignCenter); inserted_separator = True
            name = app_name(path); button = DockHoverButton(self.task_shell)
            button.setIcon(qt_icon(name)); button.setIconSize(QSize(max(32, button_size - 2), max(32, button_size - 2))); button.setFixedSize(button_size, button_size)
            button.setFocusPolicy(Qt.NoFocus)
            button.setAutoDefault(False)
            button.setDefault(False)
            try:
                button.setAttribute(Qt.WA_MacShowFocusRect, False)
            except AttributeError:
                pass
            window_count = len(self.window_groups.get(path, [])); button.setToolTip(name + (f" · {window_count} window(s)" if window_count else ""))
            # The artwork itself is the app tile.  Keep the clickable area a
            # perfect circle and do not draw a second square/rounded-square
            # background behind the original Nexora icon.
            # Every taskbar control has its own color and silhouette. Qt CSS
            button._base_style = (
                f"QPushButton{{background:transparent;border:none;outline:none;"
                f"border-radius:{button_size // 2}px;padding:0;margin:0;color:white;}}"
                f"QPushButton:hover{{background:rgba(255,255,255,24);border:none;outline:none;padding:0;margin:0;border-radius:{button_size // 2}px;}}"
                f"QPushButton:pressed{{background:rgba(255,255,255,14);border:none;outline:none;padding:0;margin:0;border-radius:{button_size // 2}px;}}"
                f"QPushButton:focus,QPushButton:checked{{background:transparent;border:none;outline:none;padding:0;margin:0;border-radius:{button_size // 2}px;}}"
            )
            button.setStyleSheet(button._base_style)
            if window_count:
                dots = QLabel("•" * min(window_count, 4), button); dots.setAlignment(Qt.AlignCenter); dots.setAttribute(Qt.WA_TransparentForMouseEvents, True)
                dots.setStyleSheet(f"background:transparent;border:none;color:{TEXT};font-size:8px;"); dots.setGeometry(4, button_size - 9, button_size - 8, 6); dots.show()
            badge_value = int(getattr(self, "app_badges", {}).get(path, 0))
            if badge_value:
                badge = QLabel("99+" if badge_value > 99 else str(badge_value), button); badge.setAlignment(Qt.AlignCenter); badge.setAttribute(Qt.WA_TransparentForMouseEvents, True)
                badge.setStyleSheet("background:#F05D6F;color:white;border:none;border-radius:22px;font-size:7px;font-weight:700;padding:1px;")
                badge.setGeometry(max(0, button_size - 22), 1, 21, 17); badge.show()
            progress_value = getattr(self, "app_progress", {}).get(path)
            if progress_value is not None:
                progress = QProgressBar(button); progress.setRange(0, 100); progress.setValue(int(progress_value)); progress.setTextVisible(False); progress.setAttribute(Qt.WA_TransparentForMouseEvents, True)
                progress.setStyleSheet("QProgressBar{background:rgba(0,0,0,45);border:none;border-radius:2px;}QProgressBar::chunk{background:#8AB4F8;border-radius:2px;}")
                progress.setGeometry(5, button_size - 6, button_size - 10, 4); progress.show()
            button.clicked.connect(lambda _=False, app_path=path: self.task_click(app_path))
            button.dragStarted.connect(lambda global_pos, app_path=path: self._dock_drag_start(app_path, global_pos))
            button.dragMoved.connect(lambda global_pos, app_path=path: self._dock_drag_move(app_path, global_pos))
            button.dragFinished.connect(lambda global_pos, app_path=path: self._dock_drag_finish(app_path, global_pos))
            button.setContextMenuPolicy(Qt.CustomContextMenu)
            button.customContextMenuRequested.connect(lambda pos, app_path=path, btn=button: self.task_context(app_path, btn, pos))
            self.task_layout.addWidget(button, 0, Qt.AlignCenter)
            button.pointerMoved.connect(lambda point, btn=button: self._dock_pointer_moved(btn.mapTo(self.task_shell, point)))
            button.hoverChanged.connect(self._dock_shell_hover)
            button.hoverChanged.connect(lambda entered, app_path=path, btn=button: self.dock_preview.request(app_path, btn) if entered and self.window_groups.get(app_path) else self.dock_preview.cancel_request())
            self.task_buttons[path] = button
        if bool(load_settings().get("dock_show_trash", True)):
            spacer = QFrame(self.task_shell); spacer.setFixedSize(max(5, gap + 3), 1); spacer.setStyleSheet("background:transparent;border:none;"); self.task_layout.addWidget(spacer, 0, Qt.AlignCenter)
            trash = DockHoverButton(self.task_shell); trash.setIcon(qt_icon("Trash")); trash.setIconSize(QSize(max(22, button_size - 14), max(22, button_size - 14))); trash.setToolTip("Trash"); trash.setFixedSize(button_size, button_size); trash.setFocusPolicy(Qt.NoFocus); trash.setAutoDefault(False); trash.setDefault(False); trash.setStyleSheet(f"QPushButton{{background:transparent;border:none;outline:none;border-radius:{button_size // 2}px;padding:0;margin:0;}}QPushButton:hover{{background:rgba(255,255,255,24);border:none;outline:none;border-radius:{button_size // 2}px;}}QPushButton:pressed{{background:rgba(255,255,255,14);border:none;outline:none;border-radius:{button_size // 2}px;padding:0;margin:0;}}QPushButton:focus,QPushButton:checked{{background:transparent;border:none;outline:none;border-radius:{button_size // 2}px;padding:0;margin:0;}}"); trash.clicked.connect(self.open_trash); self.task_layout.addWidget(trash, 0, Qt.AlignCenter)
        self.position_shells(); self.task_shell.updateGeometry(); self.task_shell.update(); self.raise_shells()
