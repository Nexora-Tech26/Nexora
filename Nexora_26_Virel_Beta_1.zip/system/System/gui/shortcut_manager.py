from .shared import *

class ShortcutManagerMixin:
    def _active_window(self):
        for window in reversed(getattr(self, "window_z", [])):
            if qt_object_is_valid(window) and window.isVisible(): return window
        return None

    def _open_named_app(self, name):
        path=self._find_app_path(name)
        if path is not None:self.open_app(path)

    def _cycle_window(self, reverse=False):
        windows=[w for w in self.window_z if qt_object_is_valid(w) and w.isVisible()]
        if windows:self.activate_window(windows[0] if reverse else (windows[-2] if len(windows)>1 else windows[-1]))

    def _snap_active(self, mode):
        window=self._active_window()
        if window is None:return
        area=self.app_layer.rect().adjusted(12,12,-12,-12);gap=10;half_w=(area.width()-gap)//2;half_h=(area.height()-gap)//2
        rects={
            "left":QRect(area.x(),area.y(),half_w,area.height()),
            "right":QRect(area.x()+half_w+gap,area.y(),area.width()-half_w-gap,area.height()),
            "top":QRect(area.x(),area.y(),area.width(),half_h),
            "bottom":QRect(area.x(),area.y()+half_h+gap,area.width(),area.height()-half_h-gap),
            "top_left":QRect(area.x(),area.y(),half_w,half_h),
            "top_right":QRect(area.x()+half_w+gap,area.y(),area.width()-half_w-gap,half_h),
            "bottom_left":QRect(area.x(),area.y()+half_h+gap,half_w,area.height()-half_h-gap),
            "bottom_right":QRect(area.x()+half_w+gap,area.y()+half_h+gap,area.width()-half_w-gap,area.height()-half_h-gap)}
        if mode in rects:window.setGeometry(rects[mode]);self.activate_window(window)

    def _toggle_tiling_shortcut(self):
        enabled=not bool(self.settings_store.get("tiling_enabled",False))
        snapshot=self.settings_store.update({"tiling_enabled":enabled});self.apply_settings(snapshot)
        self.show_system_message("Window tiling","Enabled" if enabled else "Disabled")

    def _show_shortcut_help(self):
        self.show_system_message("Nexora keyboard shortcuts","\n".join(f"{k} — {v}" for k,v in self.shortcut_reference()))

    def _save_workspace_shortcut(self):
        self.save_window_session()
        self.show_system_message("Workspace saved", "Open windows, sizes and positions were saved.")

    def _arrange_workspace_shortcut(self):
        visible = [w for w in self.window_z if qt_object_is_valid(w) and w.isVisible()]
        if not visible:
            return
        gap = 12
        cols = max(1, round(len(visible) ** 0.5))
        rows = (len(visible) + cols - 1) // cols
        cell_w = max(320, (self.app_layer.width() - gap * (cols + 1)) // cols)
        cell_h = max(220, (self.app_layer.height() - gap * (rows + 1)) // rows)
        for index, window in enumerate(visible):
            window.setGeometry(gap + (index % cols) * (cell_w + gap), gap + (index // cols) * (cell_h + gap), cell_w, cell_h)
            window.raise_()
        self.save_window_session()

    @staticmethod
    def shortcut_reference():
        return (("Ctrl/Cmd + Space","Nexora Search (Spotlight)"),("Ctrl/Cmd + K","Command Palette"),("Ctrl/Cmd + Shift + Space","Start menu"),("Ctrl/Cmd + Shift + C","Control Center"),("Ctrl/Cmd + Shift + N","Notification Center"),("Ctrl/Cmd + Alt/Option + T","Terminal"),("Ctrl/Cmd + Alt/Option + E","Files"),("Ctrl/Cmd + ,","Settings"),("Ctrl/Cmd + Tab","Window overview"),("Alt/Option + Tab","Next Nexora window"),("Alt/Option + Shift + Tab","Previous Nexora window"),("Ctrl/Cmd + W","Close active window"),("Ctrl/Cmd + M","Minimize active window"),("Ctrl/Cmd + Shift + M","Maximize or restore"),("Ctrl/Cmd + Alt/Option + L/R","Snap left or right"),("Ctrl/Cmd + Alt/Option + Up/Down","Snap top or bottom"),("Ctrl/Cmd + Alt/Option + 1/2/3/4","Snap to screen quarter"),("Ctrl/Cmd + Shift + T","Toggle automatic tiling"),("Ctrl/Cmd + Alt/Option + S","Save workspace now"),("Ctrl/Cmd + Alt/Option + A","Arrange open windows"),("Ctrl/Cmd + Shift + F","Focus Mode"),("Ctrl/Cmd + Shift + V","Clipboard history"),("Ctrl/Cmd + Shift + L","Lock Nexora"),("Ctrl/Cmd + Shift + /","Shortcut help"),("F11","Maximize or restore"),("Escape","Close active overlay"))

    def _handle_global_shortcut(self,event):
        key=event.key();mods=event.modifiers();primary=bool(mods&(Qt.ControlModifier|Qt.MetaModifier));shift=bool(mods&Qt.ShiftModifier);alt=bool(mods&Qt.AltModifier);active=self._active_window()
        if primary and key==Qt.Key_Space and not shift:self.command_palette.show_palette()
        elif primary and key==Qt.Key_K and not shift:self.command_palette.show_palette()
        elif primary and shift and key==Qt.Key_Space:self.toggle_start()
        elif primary and shift and key==Qt.Key_C:self.toggle_control_center()
        elif primary and shift and key==Qt.Key_N:self.toggle_notification_center()
        elif primary and alt and key==Qt.Key_T:self._open_named_app("Terminal")
        elif primary and alt and key==Qt.Key_E:self._open_named_app("Files")
        elif primary and key==Qt.Key_Comma:self._open_named_app("Settings")
        elif primary and key==Qt.Key_Tab:self.toggle_overview()
        elif alt and key==Qt.Key_Tab:self._cycle_window(reverse=shift)
        elif primary and key==Qt.Key_W and active is not None:active.close_animated() if hasattr(active,"close_animated") else active.close()
        elif primary and key==Qt.Key_M and active is not None and not shift:active.minimize_animated() if hasattr(active,"minimize_animated") else active.hide()
        elif (primary and shift and key==Qt.Key_M) or key==Qt.Key_F11:
            if active is not None:active.toggle_zoom()
        elif primary and alt and key==Qt.Key_L:self._snap_active("left")
        elif primary and alt and key==Qt.Key_R:self._snap_active("right")
        elif primary and alt and key==Qt.Key_Up:self._snap_active("top")
        elif primary and alt and key==Qt.Key_Down:self._snap_active("bottom")
        elif primary and alt and key in (Qt.Key_1,Qt.Key_2,Qt.Key_3,Qt.Key_4):self._snap_active({Qt.Key_1:"top_left",Qt.Key_2:"top_right",Qt.Key_3:"bottom_left",Qt.Key_4:"bottom_right"}[key])
        elif primary and shift and key==Qt.Key_T:self._toggle_tiling_shortcut()
        elif primary and alt and key==Qt.Key_S:self._save_workspace_shortcut()
        elif primary and alt and key==Qt.Key_A:self._arrange_workspace_shortcut()
        elif primary and shift and key==Qt.Key_F:self.toggle_focus_mode()
        elif primary and shift and key==Qt.Key_V:self.show_clipboard_history()
        elif primary and shift and key==Qt.Key_L:self.lockRequested.emit()
        elif primary and shift and key==Qt.Key_Slash:self._show_shortcut_help()
        elif key==Qt.Key_Escape:
            for name in ("command_palette","control_center","notification_center","menu"):
                widget=getattr(self,name,None)
                if widget is not None and widget.isVisible():widget.hide();return True
            return False
        else:return False
        event.accept();return True
