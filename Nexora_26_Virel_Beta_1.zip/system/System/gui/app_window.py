import traceback
from .shared import *
from .components import GlassFrame, InternalFilePicker, SystemOverlay
from .search import NexoraSearchWorker
from .app_builders import ApplicationBuildersMixin
from .window_behavior import WindowBehaviorMixin
from System.navigation import NavigationModel
from System.apps import AppCrashBoundary

class AppWindow(ApplicationBuildersMixin, WindowBehaviorMixin, GlassFrame):
    # App windows use the desktop's pre-blurred wallpaper cache. This restores
    # real frosted-glass blur without a live QGraphicsBlurEffect, so dragging
    # remains substantially cheaper on Intel macOS.
    closed = Signal(object)
    minimized = Signal(object)
    pin_changed = Signal(object, bool)

    def __init__(self, desktop: "Desktop", path: Path, size=(900, 620), sidebar=False, toolbar=False):
        super().__init__(desktop.app_layer, radius=14, alpha=72, gradient=True, wallpaper_backdrop=True)
        self.desktop = desktop
        self.path = path.resolve()
        self.title = app_name(path)
        self.navigation_model = NavigationModel.for_app(self.title)
        self.sidebar_enabled = bool(sidebar and self.navigation_model.has_sidebar)
        self.toolbar_enabled = toolbar
        self._toolbar_actions = []
        self.drag_offset = QPoint()
        self._snap_picker = None
        self._drag_last_global = QPoint()
        self._drag_last_time = 0.0
        self._resize_margin = 9
        self._resize_edges = 0
        self._resize_origin_global = QPoint()
        self._resize_origin_geometry = QRect()
        self.animation = None
        self._normal_geometry = QRect()
        self._zoomed = False
        self.sidebar_buttons = {}
        self._active_sidebar = None
        self.setObjectName("AppWindow")
        self.setWindowFlags(Qt.Widget)
        self.setParent(desktop.app_layer)
        # AppWindow is always an in-desktop child surface. These attributes
        # prevent Qt/macOS from promoting complex sidebar windows to native
        # child NSViews that can resemble a Space/desktop transition.
        self.setAttribute(Qt.WA_NativeWindow, False)
        self.setAttribute(Qt.WA_DontCreateNativeAncestors, True)
        self.radius = max(26, min(38, self._coerce_radius(load_settings().get("window_radius", 24), 24)))
        self.setMinimumSize(420, 300)
        area = desktop.app_layer.rect()
        available_w = max(440, area.width() - 48)
        available_h = max(320, area.height() - 48)
        self.resize(min(size[0], available_w), min(size[1], available_h))
        self.move(max(24, (area.width() - self.width()) // 2), max(24, (area.height() - self.height()) // 2))
        restored, restored_zoomed = desktop.window_state.restore(self.title, area.size(), self.minimumSize())
        if restored is not None:
            self.setGeometry(restored)
        self._normal_geometry = QRect(self.geometry())
        self._restore_zoomed_after_build = restored_zoomed
        self.accent = FLAT_ICON_COLORS.get(self.title, APP_COLORS.get(self.title, "#6F86B8"))
        self.tint_color = self.accent
        self.setStyleSheet("QLabel{background:transparent;border:none;color:%s;} QCheckBox{background:transparent;color:%s;}" % (TEXT, TEXT))
        self._build()
        self._install_resize_tracking()
        self.apply_theme_skin()
        # shadows disabled for performance

        # On macOS, large widget trees with a full-height sidebar must be ready
        # before the first paint. Showing an empty shell and filling it later
        # creates a visible compositor transition resembling a new Space.
        if sys.platform == "darwin" and self.sidebar_enabled:
            self._finish_content_build()

        self.show()
        self.raise_()
        if getattr(self.desktop, "touchbar", None) is not None:
            self.desktop.touchbar.set_active_window(self)
        self.animate_open()
        if getattr(self, "_restore_zoomed_after_build", False):
            QTimer.singleShot(0, self.toggle_zoom)
        if not self._content_ready:
            self._schedule_content_build()

    def apply_theme_skin(self, theme=None):
        theme = theme or getattr(self.desktop.theme_engine, "current", None)
        if theme is None:
            theme = self.desktop.theme_engine.resolve(load_settings())
        self.radius = 28
        dark = QColor(theme.background).lightness() < 128
        fallback_fg = "#FFFFFF" if dark else "#111318"
        legacy_glass = "rgba(19,23,31,34)" if dark else "rgba(239,246,252,26)"
        fg = theme.text if QColor(theme.text).isValid() else fallback_fg
        surface = QColor(theme.surface if QColor(theme.surface).isValid() else legacy_glass)
        sidebar = QColor(theme.sidebar)
        border = QColor(theme.border)
        accent = QColor(self.accent)
        def blend(base, tint, amount):
            return QColor(
                round(base.red() * (1.0 - amount) + tint.red() * amount),
                round(base.green() * (1.0 - amount) + tint.green() * amount),
                round(base.blue() * (1.0 - amount) + tint.blue() * amount),
            )
        # Minimal application tint: recognizable, but never overpowering.
        surface = blend(surface, accent, 0.22)
        sidebar = blend(sidebar, accent, 0.30)
        border = blend(border, accent, 0.22)
        raw_alpha = round(255 * (100 - int(theme.transparency)) / 100)
        # Keep the wallpaper visibly present through every application window.
        # With the Nexora 26 Beta 1 default (72% transparency), the material remains light
        # rather than becoming an opaque gray panel.
        body_alpha = max(38, min(82, raw_alpha + 20))
        rail_alpha = max(34, min(72, raw_alpha + 12))
        glass = f"rgba({surface.red()},{surface.green()},{surface.blue()},{body_alpha})"
        rail = f"rgba({sidebar.red()},{sidebar.green()},{sidebar.blue()},{rail_alpha})"
        border_css = f"rgba({border.red()},{border.green()},{border.blue()},{max(64,min(210,body_alpha+76))})"
        radius = 28
        self.body.setStyleSheet(f"#Body{{background:{glass};border:none;border-radius:{radius}px;}}")
        self.sidebar.setStyleSheet(f"#Sidebar{{background:{rail};border:none;border-right:none;border-top-left-radius:{radius-1}px;border-bottom-left-radius:{radius-1}px;}}")
        self.main_surface.setStyleSheet("#MainSurface{background:transparent;border:none;}")
        self.titlebar.setStyleSheet("#TitleBar{background:transparent;border:none;}")
        if hasattr(self, "toolbar"):
            self.toolbar.setStyleSheet("#Toolbar{background:transparent;border:none;}")
        self.content.setStyleSheet("#Content{background:transparent;border:none;}")
        self.title_label.setStyleSheet(f"color:{fg};background:transparent;border:none;")
        input_bg = rgba(theme.surface, 34)
        input_hover = rgba(theme.accent, 54)
        self.setStyleSheet(f"""
            QWidget {{ background: transparent; color:{fg}; }}
            QLabel {{ background:transparent; border:none; color:{fg}; }}
            QLabel[nexoraMuted="true"] {{ color:{theme.muted}; background:transparent; border:none; }}
            QLineEdit, QTextEdit, QPlainTextEdit {{ background:{input_bg}; border:none; border-radius:22px; min-height:42px; color:{fg}; selection-background-color:{theme.accent}; padding:11px 13px; }}
            QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {{ border:none; background:{input_hover}; }}
            QScrollArea, QScrollArea > QWidget > QWidget {{ background:transparent; border:none; }}
            QFrame, QWidget#Content, QWidget#centralWidget {{ background:transparent; }}
            QCalendarWidget QWidget, QStackedWidget, QSplitter {{ background:transparent; }}
            QCheckBox {{ background:transparent; color:{fg}; spacing:8px; }}
            QCheckBox::indicator {{ width:18px; height:18px; border-radius:22px; border:none; background:{input_bg}; }}
            QCheckBox::indicator:checked {{ background:{theme.accent}; border:none; }}
            QComboBox, QSpinBox {{ background:{input_bg}; border:none; border-radius:22px; min-height:42px; color:{fg}; padding:8px 32px 8px 10px; }}
            QComboBox::drop-down {{ border:none; width:30px; background:transparent; }}
            QComboBox QAbstractItemView {{ background:rgba(224,236,248,224); color:#142033; border:none; border-radius:18px; padding:6px; outline:none; selection-background-color:{rgba(theme.accent,72)}; selection-color:#142033; }}
            QComboBox QAbstractItemView::item {{ min-height:34px; border:none; border-radius:15px; padding:4px 10px; margin:2px; }}
            QComboBox QAbstractItemView::item:hover, QComboBox QAbstractItemView::item:selected {{ background:{rgba(theme.accent,96)}; border:none; border-radius:15px; }}
            QTabWidget::pane {{ border:none; border-radius:16px; background:transparent; }}
            QTabBar {{ background:transparent; border:none; }}
            QTabBar::tab {{ border:none; outline:none; border-radius:0; min-height:40px; padding:9px 18px; margin:0; background:rgba(255,255,255,18); }}
            QTabBar::tab:first {{ border-top-left-radius:11px; border-bottom-left-radius:11px; }}
            QTabBar::tab:last {{ border-top-right-radius:11px; border-bottom-right-radius:11px; }}
            QTabBar::tab:hover {{ background:rgba(255,255,255,42); }}
            QTabBar::tab:selected {{ background:{rgba(theme.accent,105)}; border:none; outline:none; }}
        """)
        # SettingsSection geometry is assigned by settings_builder.py so adjacent
        # cards remain one connected vertical group. Do not overwrite it here.
        if hasattr(self, "_refresh_sidebar_styles"):
            self._refresh_sidebar_styles()
        self.update()

    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.setSizeConstraint(QLayout.SetDefaultConstraint)
        self._outer_layout = outer

        # One uninterrupted glass surface. The sidebar reaches from the very
        # top to the bottom; the old separate title-bar slab no longer exists.
        body = QFrame()
        body.setAttribute(Qt.WA_StyledBackground, True)
        body.setObjectName("Body")
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)
        self.body = body
        self.body_layout = body_layout

        # Window controls live on the same full-height rail as navigation.
        self.sidebar = QFrame()
        self.sidebar.setObjectName("Sidebar")
        profile = panel_profile(load_settings())
        sidebar_width = int(profile.get("sidebar_width", 204)) if self.sidebar_enabled else 0
        self.sidebar.setFixedWidth(sidebar_width)
        self.sidebar.setVisible(self.sidebar_enabled)
        self.sidebar.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
        self.sidebar_layout = QVBoxLayout(self.sidebar)
        self.sidebar_layout.setContentsMargins(12, 16, 12, 14)
        self.sidebar_layout.setSpacing(0)

        control_settings = load_settings()
        self.window_controls_style = str(control_settings.get("window_controls_style", "traffic_lights"))
        self.window_controls_position = str(control_settings.get("window_controls_position", "left"))
        self.window_controls_joined = bool(control_settings.get("window_controls_joined", True))
        self.controls_host = QFrame()
        self.controls_host.setObjectName("WindowControlsHost")
        self.controls_host.setStyleSheet("QFrame#WindowControlsHost{background:transparent;border:none;}")
        self.controls_layout = QHBoxLayout(self.controls_host)
        self.controls_layout.setContentsMargins(0, 0, 0, 0)
        self.controls_layout.setSpacing(0 if self.window_controls_joined else (8 if self.window_controls_style == "traffic_lights" else 6))
        self.close_btn = self.traffic(RED, self.close_animated, "Close window", "close")
        self.minimize_btn = self.traffic("#FFBD2E", self.minimize_animated, "Minimize window", "minimize")
        self.zoom_btn = self.traffic("#28C840", self.toggle_zoom, "Maximize or restore window", "maximize")
        self._arrange_window_controls()
        self._restyle_window_controls()
        self._tiling_mode = bool(control_settings.get("tiling_enabled", False))
        self.minimize_btn.setVisible(not self._tiling_mode)
        self.zoom_btn.setVisible(not self._tiling_mode)
        if self.window_controls_position == "left" and self.sidebar_enabled:
            self.sidebar_layout.addWidget(self.controls_host, 0, Qt.AlignLeft)
            self.sidebar_layout.addSpacing(10)

        self.pin_btn = QPushButton("●" if self.desktop.is_pinned(self.path) else "○")
        self.pin_btn.setToolTip("Unpin from taskbar" if self.desktop.is_pinned(self.path) else "Pin to taskbar")
        self.pin_btn.setFixedSize(36, 36)
        self.pin_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.pin_btn.setFocusPolicy(Qt.NoFocus)
        self.pin_btn.setAutoDefault(False)
        self.pin_btn.setDefault(False)
        self.pin_btn.setStyleSheet(
            f"QPushButton{{background:{rgba(self.accent, 46)};border:none;outline:none;"
            f"color:{TEXT};font-size:15px;border-radius:18px;min-width:36px;max-width:36px;"
            "min-height:36px;max-height:36px;padding:0;margin:0;}"
            f"QPushButton:hover{{background:{rgba(self.accent, 92)};border:none;outline:none;border-radius:18px;padding:0;margin:0;}}"
            f"QPushButton:pressed{{background:{rgba(self.accent, 118)};border:none;outline:none;border-radius:18px;padding:0;margin:0;}}"
            "QPushButton:focus,QPushButton:checked{border:none;outline:none;border-radius:18px;padding:0;margin:0;}"
        )
        self.pin_btn.clicked.connect(self.toggle_pin)
        self.sidebar_layout.addWidget(self.pin_btn, 0, Qt.AlignLeft)
        self.sidebar_layout.addSpacing(4)
        self.sidebar_nav_scroll = QScrollArea()
        self.sidebar_nav_scroll.setWidgetResizable(True)
        self.sidebar_nav_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.sidebar_nav_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.sidebar_nav_scroll.setFrameShape(QFrame.NoFrame)
        self.sidebar_nav_scroll.setStyleSheet("QScrollArea{background:transparent;border:none;}QScrollArea>QWidget>QWidget{background:transparent;}")
        self.sidebar_nav_host = QWidget()
        self.sidebar_nav_layout = QVBoxLayout(self.sidebar_nav_host)
        self.sidebar_nav_layout.setContentsMargins(0, 0, 0, 0)
        self.sidebar_nav_layout.setSpacing(5)
        self.sidebar_nav_layout.addStretch()
        self.sidebar_nav_scroll.setWidget(self.sidebar_nav_host)
        self.sidebar_layout.addWidget(self.sidebar_nav_scroll, 1)
        body_layout.addWidget(self.sidebar)

        main = QFrame()
        main.setObjectName("MainSurface")
        main_layout = QVBoxLayout(main)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        self.main_surface = main

        # Integrated command header: visually part of content and draggable.
        self.titlebar = QFrame()
        self.titlebar.setObjectName("TitleBar")
        self.titlebar.setFixedHeight(40)
        title_layout = QHBoxLayout(self.titlebar)
        self.title_layout = title_layout
        title_layout.setContentsMargins(16, 6, 16, 6)
        title_layout.setSpacing(8)
        self.title_label = QLabel(self.title)
        self.title_label.setFont(font(15, True))
        self.title_label.setMinimumWidth(100)
        if self.window_controls_position == "left" and not self.sidebar_enabled:
            self.controls_host.setParent(self.titlebar)
            title_layout.addWidget(self.controls_host, 0, Qt.AlignVCenter)
        title_layout.addWidget(self.title_label)
        title_layout.addStretch(1)
        self.header_search = QLineEdit()
        self.header_search.setObjectName("HeaderSearch")
        self.header_search.setClearButtonEnabled(True)
        self.header_search.setFixedHeight(30)
        self.header_search.setMaximumWidth(330)
        self.header_search.setPlaceholderText(f"Search {self.title}")
        self.header_search.setStyleSheet(
            f"QLineEdit#HeaderSearch{{background:rgba(246,249,252,205);border:none;outline:none;"
            f"border-radius:15px;color:{TEXT};padding:3px 10px;min-height:30px;max-height:30px;}}"
            f"QLineEdit#HeaderSearch:hover{{background:rgba(249,251,253,225);border:none;}}"
            f"QLineEdit#HeaderSearch:focus{{background:rgba(252,253,255,238);border:none;outline:none;}}"
        )
        self.header_search.textChanged.connect(self._on_header_search)
        title_layout.addWidget(self.header_search)
        if self.window_controls_position == "right":
            self.controls_host.setParent(self.titlebar)
            title_layout.addWidget(self.controls_host, 0, Qt.AlignVCenter)
        main_layout.addWidget(self.titlebar)

        if self.toolbar_enabled:
            self.toolbar = QFrame()
            self.toolbar.setObjectName("Toolbar")
            self.toolbar.setFixedHeight(36)
            self.toolbar_layout = QHBoxLayout(self.toolbar)
            self.toolbar_layout.setContentsMargins(16, 3, 16, 3)
            self.toolbar_layout.setSpacing(0)
            self.toolbar_layout.addStretch()
            main_layout.addWidget(self.toolbar)

        self.content = QFrame()
        self.content.setObjectName("Content")
        self.content.setMinimumSize(0, 0)
        self.content.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
        self.content.setAttribute(Qt.WA_StyledBackground, True)
        self.content.setAttribute(Qt.WA_OpaquePaintEvent, False)
        self.content_layout = QVBoxLayout(self.content)
        self.content_layout.setContentsMargins(16, 10, 16, 16)
        self.content_layout.setSpacing(8)
        main_layout.addWidget(self.content, 1)
        body_layout.addWidget(main, 1)
        outer.addWidget(body, 1)

        self._loading_label = QLabel("Opening…")
        self._loading_label.setAlignment(Qt.AlignCenter)
        self._loading_label.setStyleSheet(f"color:{MUTED};background:transparent;border:none;")
        self.content_layout.addWidget(self._loading_label, 1)
        self._content_ready = False
        self.setStyleSheet(self.styleSheet() + f"""
            QWidget {{ background: transparent; }}
            QLabel {{ background: transparent; border: none; color: {TEXT}; }}
            QLineEdit, QTextEdit, QPlainTextEdit {{ background: rgba(255,255,255,18); border:none; border-radius: 25px; color: {TEXT}; selection-background-color: {self.accent}; padding:9px; }}
            QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {{ border:none; background:rgba(255,255,255,27); }}
            QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; border: none; }}
            QFrame, QWidget#Content, QWidget#centralWidget {{ background: transparent; }}
            QCalendarWidget QWidget, QStackedWidget, QSplitter {{ background: transparent; }}
            QCheckBox {{ background: transparent; color: {TEXT}; spacing: 8px; }}
            QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit, QTimeEdit {{ background:rgba(255,255,255,38);border:none;border-radius:12px;padding:7px 10px;color:{TEXT};min-height:26px; }}
            QComboBox::drop-down, QSpinBox::up-button, QSpinBox::down-button, QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{ border:none;background:rgba(255,255,255,25);width:26px; }}
            QToolTip {{ background:rgba(35,39,48,238);color:white;border:none;border-radius:10px;padding:7px 10px; }}
            QCheckBox::indicator {{ width: 18px; height: 18px; border-radius: 9px; border:none; background: rgba(255,255,255,22); }}
            QCheckBox::indicator:checked {{ background: {self.accent}; border-color: {self.accent}; }}
        """)
        self._shadow = None


    def _finish_content_build(self):
        if self._content_ready:
            return
        self._content_ready = True
        if getattr(self, "_loading_label", None) is not None:
            self.content_layout.removeWidget(self._loading_label)
            self._loading_label.deleteLater()
            self._loading_label = None
        boundary = AppCrashBoundary(self.title, getattr(self.desktop, "logger", None))
        self._crash_boundary = boundary
        def build():
            self._populate()
            self._normalize_child_layouts()
            self._normalize_search_geometry()
            self._normalize_button_geometry()
            # Titlebar decoration must never decide whether an application opens.
            # Promote tabs only after the app builder has completed successfully.
            QTimer.singleShot(0, self._safe_promote_all_tabs_to_titlebar)
            self._animate_content_in()
        def show_crash(crash):
            self._content_ready = True
            while self.content_layout.count():
                item = self.content_layout.takeAt(0)
                widget = item.widget()
                if widget is not None:
                    widget.deleteLater()
            title = QLabel("This app could not be opened")
            title.setFont(font(18, True))
            detail = QLabel(f"{crash.error_type}: {crash.message}")
            detail.setWordWrap(True)
            detail.setStyleSheet(f"color:{MUTED};background:transparent;border:none;")
            retry = QPushButton("Try again")
            retry.clicked.connect(self._retry_content_build)
            self.content_layout.addStretch()
            self.content_layout.addWidget(title, 0, Qt.AlignCenter)
            self.content_layout.addWidget(detail, 0, Qt.AlignCenter)
            self.content_layout.addWidget(retry, 0, Qt.AlignCenter)
            self.content_layout.addStretch()
        boundary.run(build, show_crash)


    def _safe_promote_all_tabs_to_titlebar(self):
        """Mirror tabs only when an app has no equivalent left-side navigation."""
        # Sidebar applications already expose their sections on the left. Mirroring
        # the same tabs into the title bar creates duplicate controls in applications with side navigation.
        if self.sidebar_enabled:
            return
        try:
            if qt_object_is_valid(self):
                self._promote_all_tabs_to_titlebar()
        except (RuntimeError, AttributeError, TypeError, IndexError):
            logger = getattr(self.desktop, "logger", None)
            if logger is not None:
                logger.exception("Titlebar tab promotion failed for %s", self.title)

    def _promote_all_tabs_to_titlebar(self):
        """Safely mirror application tabs without changing or deleting source pages."""
        tab_widgets = [tabs for tabs in self.findChildren(QTabWidget) if tabs.count() > 0]
        if not tab_widgets:
            return
        self._titlebar_tab_mirrors = getattr(self, "_titlebar_tab_mirrors", [])
        for tabs in tab_widgets:
            if bool(tabs.property("nexoraTabsPromoted")) or not qt_object_is_valid(tabs):
                continue
            tabs.setProperty("nexoraTabsPromoted", True)
            source_bar = tabs.tabBar()
            mirror = QTabBar(self.titlebar)
            mirror.setObjectName("TitleBarTabs")
            mirror.setDocumentMode(True)
            mirror.setMovable(False)
            mirror.setExpanding(False)
            mirror.setTabsClosable(tabs.tabsClosable())
            mirror.setUsesScrollButtons(True)
            mirror.setElideMode(Qt.ElideRight)
            mirror.setMaximumWidth(520)
            mirror.setFixedHeight(28)
            mirror.setStyleSheet(
                f"QTabBar#TitleBarTabs::tab{{background:rgba(255,255,255,18);border:none;border-radius:14px;"
                f"min-height:26px;max-height:26px;padding:0 10px;margin:1px 2px;color:{TEXT};}}"
                f"QTabBar#TitleBarTabs::tab:selected{{background:{rgba(self.accent,52)};}}"
                f"QTabBar#TitleBarTabs::tab:hover{{background:{rgba(self.accent,30)};}}"
            )
            state = {"syncing": False}

            def sync(_index=-1, source=tabs, target=mirror, guard=state):
                if guard["syncing"] or not qt_object_is_valid(source) or not qt_object_is_valid(target):
                    return
                guard["syncing"] = True
                blocker = QSignalBlocker(target)
                try:
                    while target.count():
                        target.removeTab(0)
                    for index in range(source.count()):
                        target.addTab(source.tabIcon(index), source.tabText(index))
                        target.setTabToolTip(index, source.tabToolTip(index))
                    target.setCurrentIndex(source.currentIndex())
                    target.setVisible(source.count() > 0)
                finally:
                    del blocker
                    guard["syncing"] = False

            def select_source(index, source=tabs, guard=state):
                if guard["syncing"] or not qt_object_is_valid(source):
                    return
                if 0 <= index < source.count() and source.currentIndex() != index:
                    source.setCurrentIndex(index)

            mirror.currentChanged.connect(select_source)
            tabs.currentChanged.connect(sync)
            if tabs.tabsClosable():
                def request_close(index, source=tabs):
                    if qt_object_is_valid(source) and 0 <= index < source.count():
                        source.tabCloseRequested.emit(index)
                mirror.tabCloseRequested.connect(request_close)
            index = self.title_layout.indexOf(self.title_label)
            self.title_layout.insertWidget(index + 1, mirror, 0, Qt.AlignVCenter)
            sync()
            # Keep the original bar alive and only collapse its height. Some complex
            # Qt widgets rebuild or replace their tab bar internally; deleting/hiding
            # it during construction can invalidate child pages.
            if qt_object_is_valid(source_bar):
                source_bar.setMaximumHeight(0)
                source_bar.setMinimumHeight(0)
                source_bar.setEnabled(False)
            self._titlebar_tab_mirrors.append((tabs, mirror, sync))

    def set_tiling_mode(self, enabled: bool):
        self._tiling_mode = bool(enabled)
        self.minimize_btn.setVisible(not self._tiling_mode)
        self.zoom_btn.setVisible(not self._tiling_mode)
        self.setCursor(Qt.ArrowCursor)
        self.setProperty("tilingMode", self._tiling_mode)
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def shutdown_resources(self):
        """Stop timers, processes, workers and animations owned by this app."""
        if self.animation is not None:
            try:
                self.animation.stop()
            except RuntimeError:
                pass
        for timer in self.findChildren(QTimer):
            timer.stop()
        for process in self.findChildren(QProcess):
            if process.state() != QProcess.NotRunning:
                process.terminate()
                if not process.waitForFinished(300):
                    process.kill()
        for worker in list(getattr(self, "_workers", [])):
            cancel = getattr(worker, "cancel", None)
            if callable(cancel):
                cancel()

    def _retry_content_build(self):
        self._content_ready = False
        self._schedule_content_build()

    def _schedule_content_build(self):
        # Files and Settings are large widget trees. On macOS, showing an empty
        # shell and filling it one event-loop turn later resembles a native Space
        # transition. Build them immediately inside the existing Nexora desktop.
        if sys.platform == "darwin" and self.sidebar_enabled:
            self._finish_content_build()
            return
        QTimer.singleShot(0, self._finish_content_build)


    def _animate_content_in(self):
        if sys.platform == "darwin" or bool(load_settings().get("reduce_motion", False)) or not bool(load_settings().get("animations", True)):
            return
        effect = QGraphicsOpacityEffect(self.content)
        self.content.setGraphicsEffect(effect)
        effect.setOpacity(0.0)
        animation = QPropertyAnimation(effect, b"opacity", self)
        animation.setDuration(260)
        animation.setStartValue(0.0)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.OutCubic)
        animation.finished.connect(lambda: self.content.setGraphicsEffect(None))
        self._content_animation = animation
        animation.start()

    def _on_header_search(self, text: str):
        query = text.strip().casefold()
        # Files: filter the current directory without changing its state.
        listing = getattr(self, "files_listing", None)
        if listing is not None:
            for index in range(listing.count()):
                item = listing.item(index)
                item.setHidden(bool(query) and query not in item.text().casefold())
        # Settings: filter both navigation and visible setting rows.
        if self.title == "Settings":
            for name, button in self.sidebar_buttons.items():
                button.setVisible(not query or query in name.casefold())
            for section in self.findChildren(QFrame, "SettingsSection"):
                labels = " ".join(label.text() for label in section.findChildren(QLabel)).casefold()
                section.setVisible(not query or query in labels)
        # Other apps: hide list rows when a list-based view is present.
        for listing_widget in self.findChildren(QListWidget):
            if listing_widget is listing:
                continue
            for index in range(listing_widget.count()):
                item = listing_widget.item(index)
                item.setHidden(bool(query) and query not in item.text().casefold())


    def _normalize_search_geometry(self):
        """Keep application search bars compact and prevent vertical expansion."""
        for field in self.findChildren(QLineEdit):
            placeholder = field.placeholderText().strip().casefold()
            name = field.objectName().casefold()
            if "search" not in placeholder and "search" not in name and field is not getattr(self, "header_search", None):
                continue
            field.setMinimumHeight(30)
            field.setMaximumHeight(34)
            policy = field.sizePolicy()
            policy.setVerticalPolicy(QSizePolicy.Fixed)
            field.setSizePolicy(policy)
            field.setStyleSheet(field.styleSheet() + "QLineEdit{border:none;outline:none;padding-top:3px;padding-bottom:3px;}QLineEdit:focus{border:none;outline:none;}")

    def _normalize_button_geometry(self):
        """Keep ordinary app buttons compact without touching intentional large tiles."""
        for button in self.findChildren(QAbstractButton):
            if button.objectName().startswith("WindowControl_") or button.property("preserveGeometry"):
                continue
            # Preserve dock/window controls, icon tiles and intentionally tall launch cards.
            if button in {getattr(self, name, None) for name in (
                "close_btn", "minimize_btn", "zoom_btn", "pin_btn"
            )}:
                continue
            if button.minimumHeight() > 44 or button.height() > 64:
                continue
            if button.property("allowTallControl"):
                continue
            hint = max(30, min(40, button.sizeHint().height()))
            if button.maximumHeight() < 16777215:
                hint = min(hint, button.maximumHeight())
            button.setMinimumHeight(hint)
            button.setMaximumHeight(hint)
            policy = button.sizePolicy()
            policy.setVerticalPolicy(QSizePolicy.Fixed)
            button.setSizePolicy(policy)

    def _normalize_child_layouts(self):
        # Remove stale/minimum size hints that made Settings, Files and other
        # applications extend past the rounded window after resize.
        for widget in self.findChildren(QWidget):
            if widget is self:
                continue
            if isinstance(widget, QScrollArea):
                widget.setWidgetResizable(True)
                widget.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
                widget.setMinimumSize(0, 0)
                widget.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
            elif isinstance(widget, (QTextEdit, QTextBrowser, QPlainTextEdit)):
                widget.setMinimumWidth(0)
                widget.setMinimumHeight(max(150, widget.minimumHeight()))
                widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            elif isinstance(widget, (QStackedWidget, QListWidget, QTreeWidget, QTableWidget)):
                widget.setMinimumSize(0, 0)
                widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            elif isinstance(widget, QFrame) and widget.objectName() not in {"TitleBar", "Toolbar", "Sidebar"}:
                widget.setMinimumWidth(0)
        for layout in self.findChildren(QLayout):
            layout.setSizeConstraint(QLayout.SetDefaultConstraint)
            layout.invalidate()

    def closeEvent(self, event):
        geometry = QRect(self._normal_geometry if self._zoomed and self._normal_geometry.isValid() else self.geometry())
        try:
            self.desktop.window_state.save(self.title, geometry, self.desktop.app_layer.size(), zoomed=self._zoomed)
        except (OSError, RuntimeError, ValueError):
            pass
        self.shutdown_resources()
        super().closeEvent(event)

    def _arrange_window_controls(self):
        """Mirror the complete control order when controls are on the right."""
        while self.controls_layout.count():
            item = self.controls_layout.takeAt(0)
            if item.widget() is not None:
                item.widget().setParent(self.controls_host)
        ordered = [self.close_btn, self.minimize_btn, self.zoom_btn]
        if self.window_controls_position == "right":
            ordered.reverse()
        for button in ordered:
            self.controls_layout.addWidget(button)

    def _restyle_window_controls(self):
        """Apply connected radii from the actual visual order in the layout."""
        buttons = []
        for i in range(self.controls_layout.count()):
            w = self.controls_layout.itemAt(i).widget()
            if isinstance(w, QPushButton):
                buttons.append(w)
        joined = bool(getattr(self, "window_controls_joined", True))
        style = str(getattr(self, "window_controls_style", "traffic_lights"))
        for i, b in enumerate(buttons):
            role = str(b.property("controlRole") or "")
            if style == "traffic_lights":
                base = {"close":"#FF5F57","minimize":"#FEBC2E","maximize":"#28C840"}.get(role,"#8A94A6")
                hover = {"close":"#FF746D","minimize":"#FFCA55","maximize":"#4BD45F"}.get(role,base)
                pressed = {"close":"#E94C45","minimize":"#E0A31D","maximize":"#20A936"}.get(role,base)
                width, height, radius, fg = ((22, 18, 9, "transparent") if joined else (14, 14, 7, "transparent"))
            else:
                if role == "close": base, hover, pressed, fg = "#D94B4B", "#E65B5B", "#BD3D3D", "#FFFFFF"
                else: base, hover, pressed, fg = "#D8DCE2", "#E8EBEF", "#C3C8D0", "#252A31"
                width, height, radius = ((31, 26, 9) if joined else (27, 26, 9))
            left = radius if (not joined or i == 0) else 0
            right = radius if (not joined or i == len(buttons)-1) else 0
            common = (f"border:none;outline:none;padding:0;margin:0;min-width:{width}px;max-width:{width}px;"
                      f"min-height:{height}px;max-height:{height}px;border-top-left-radius:{left}px;"
                      f"border-bottom-left-radius:{left}px;border-top-right-radius:{right}px;border-bottom-right-radius:{right}px;")
            b.setFixedSize(width, height)
            b.setStyleSheet(f"QPushButton{{background:{base};color:{fg};{common}}}"
                            f"QPushButton:hover{{background:{hover};{common}}}"
                            f"QPushButton:pressed{{background:{pressed};{common}}}")

    def refresh_window_controls(self, settings=None):
        settings = settings or load_settings()
        self.window_controls_style = str(settings.get("window_controls_style", "traffic_lights"))
        self.window_controls_position = str(settings.get("window_controls_position", "left"))
        self.window_controls_joined = bool(settings.get("window_controls_joined", True))
        callbacks = {
            "close": self.close_animated,
            "minimize": self.minimize_animated,
            "maximize": self.toggle_zoom,
        }
        colors = {"close": RED, "minimize": "#FFBD2E", "maximize": "#28C840"}
        labels = {"close": "Close window", "minimize": "Minimize window", "maximize": "Maximize or restore window"}
        for attr in ("close_btn", "minimize_btn", "zoom_btn"):
            button = getattr(self, attr, None)
            if button is not None:
                self.controls_layout.removeWidget(button)
                button.deleteLater()
        self.close_btn = self.traffic(colors["close"], callbacks["close"], labels["close"], "close")
        self.minimize_btn = self.traffic(colors["minimize"], callbacks["minimize"], labels["minimize"], "minimize")
        self.zoom_btn = self.traffic(colors["maximize"], callbacks["maximize"], labels["maximize"], "maximize")
        self.controls_layout.setSpacing(0 if self.window_controls_joined else (8 if self.window_controls_style == "traffic_lights" else 6))
        self._arrange_window_controls()
        self._restyle_window_controls()
        self._tiling_mode = bool(settings.get("tiling_enabled", False))
        self.minimize_btn.setVisible(not self._tiling_mode)
        self.zoom_btn.setVisible(not self._tiling_mode)
        if self.window_controls_position == "right":
            self.controls_host.setParent(self.titlebar)
            self.titlebar.layout().addWidget(self.controls_host, 0, Qt.AlignVCenter)
        elif self.sidebar_enabled:
            self.controls_host.setParent(self.sidebar)
            self.sidebar_layout.insertWidget(0, self.controls_host, 0, Qt.AlignLeft | Qt.AlignVCenter)
        else:
            self.controls_host.setParent(self.titlebar)
            self.titlebar.layout().insertWidget(0, self.controls_host, 0, Qt.AlignVCenter)
        self.controls_host.setFixedHeight(30)
        self.controls_host.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.controls_host.show()
        self.controls_host.updateGeometry()

    def traffic(self, color, callback, tooltip="", role="close"):
        style = str(getattr(self, "window_controls_style", "traffic_lights"))
        joined = bool(getattr(self, "window_controls_joined", True))
        order = ["close", "minimize", "maximize"]
        if getattr(self, "window_controls_position", "left") == "right":
            order.reverse()
        index = order.index(role) if role in order else 1

        if style == "traffic_lights":
            # Nexora connected controls: compact colored segments without platform-native chrome.
            size = 18 if joined else 14
            outer_radius = size // 2
            left_radius = outer_radius if (not joined or index == 0) else 0
            right_radius = outer_radius if (not joined or index == len(order) - 1) else 0
            base = {"close": "#FF5F57", "minimize": "#FEBC2E", "maximize": "#28C840"}.get(role, color)
            hover = {"close": "#FF746D", "minimize": "#FFCA55", "maximize": "#4BD45F"}.get(role, color)
            pressed = {"close": "#E94C45", "minimize": "#E0A31D", "maximize": "#20A936"}.get(role, color)
            text = ""
            foreground = "transparent"
            width, height = (20, 16) if joined else (14, 14)
        else:
            # GNOME-style controls: red close button and neutral gray window
            # actions, all with visible semantic icons.
            outer_radius = 8
            left_radius = outer_radius if (not joined or index == 0) else 0
            right_radius = outer_radius if (not joined or index == len(order) - 1) else 0
            text = {"close": "×", "minimize": "−", "maximize": "□"}.get(role, "")
            if role == "close":
                base, hover, pressed, foreground = "#D94B4B", "#E65B5B", "#BD3D3D", "#FFFFFF"
            else:
                base, hover, pressed, foreground = "#D8DCE2", "#E8EBEF", "#C3C8D0", "#252A31"
            width, height = (31, 26) if joined else (27, 26)

        b = QPushButton(text)
        b.setFixedSize(width, height)
        b.setFont(font(11, True))
        b.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        b.setStyleSheet(
            f"QPushButton{{background:{base};color:{foreground};border:none;outline:none;padding:0;margin:0;"
            f"min-width:{width}px;max-width:{width}px;min-height:{height}px;max-height:{height}px;"
            f"border-top-left-radius:{left_radius}px;border-bottom-left-radius:{left_radius}px;"
            f"border-top-right-radius:{right_radius}px;border-bottom-right-radius:{right_radius}px;}}"
            f"QPushButton:hover{{background:{hover};border:none;outline:none;min-width:{width}px;max-width:{width}px;min-height:{height}px;max-height:{height}px;"
            f"border-top-left-radius:{left_radius}px;border-bottom-left-radius:{left_radius}px;"
            f"border-top-right-radius:{right_radius}px;border-bottom-right-radius:{right_radius}px;}}"
            f"QPushButton:pressed{{background:{pressed};border:none;outline:none;padding:0;min-width:{width}px;max-width:{width}px;min-height:{height}px;max-height:{height}px;"
            f"border-top-left-radius:{left_radius}px;border-bottom-left-radius:{left_radius}px;"
            f"border-top-right-radius:{right_radius}px;border-bottom-right-radius:{right_radius}px;}}"
        )
        b.setObjectName(f"WindowControl_{role}")
        b.setAccessibleName(tooltip or role.title())
        b.setProperty("controlRole", role)
        b.setCursor(Qt.PointingHandCursor)
        b.setFocusPolicy(Qt.NoFocus)
        if tooltip:
            b.setToolTip(tooltip)
        b.clicked.connect(callback)
        return b

    def add_toolbar(self, name, callback=None):
        b = QPushButton(name)
        toolbar_icons = {
            "New folder": "NewFolder", "New text file": "Documents", "Copy": "Copy",
            "Cut": "Cut", "Paste": "Paste", "Delete": "Delete", "Refresh": "Restart",
            "Save": "Documents", "Back": "Back", "Forward": "Forward", "New tab": "NewFolder",
        }
        b.setIcon(qt_icon(toolbar_icons.get(name, name)))
        b.setIconSize(QSize(20, 20))
        b.setFont(font(9))
        b.setToolTip({"File":"File actions: create, open, save and export","Edit":"Editing actions: undo, copy, cut and paste","View":"Change how the application is displayed"}.get(name, name))
        b.setFixedHeight(28)
        b.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        b.setProperty("nexoraSegment", True)
        if callback: b.clicked.connect(callback)
        self._toolbar_actions.append((name, callback))
        self.toolbar_layout.insertWidget(self.toolbar_layout.count() - 1, b)
        self._restyle_toolbar_segments()
        return b

    def _restyle_toolbar_segments(self):
        buttons = [self.toolbar_layout.itemAt(i).widget() for i in range(self.toolbar_layout.count())]
        buttons = [b for b in buttons if isinstance(b, QPushButton) and b.property("nexoraSegment")]
        for index, button in enumerate(buttons):
            left = 10 if index == 0 else 0
            right = 10 if index == len(buttons) - 1 else 0
            button.setStyleSheet(
                f"QPushButton{{background:{rgba(self.accent, 38)};color:{TEXT};border:none;"
                f"border-top-left-radius:{left}px;border-bottom-left-radius:{left}px;"
                f"border-top-right-radius:{right}px;border-bottom-right-radius:{right}px;"
                "padding:0 11px;margin:0;}}"
                f"QPushButton:hover{{background:{rgba(self.accent, 64)};border:none;outline:none;"
                f"border-top-left-radius:{left}px;border-bottom-left-radius:{left}px;"
                f"border-top-right-radius:{right}px;border-bottom-right-radius:{right}px;}}"
                f"QPushButton:pressed{{background:{rgba(self.accent, 82)};border:none;outline:none;padding:0 11px;"
                f"border-top-left-radius:{left}px;border-bottom-left-radius:{left}px;"
                f"border-top-right-radius:{right}px;border-bottom-right-radius:{right}px;}}"
            )

    def add_sidebar(self, name, callback=None, selected=False):
        icon_names = {
            "Home": "Home", "Desktop": "DesktopFolder", "Documents": "Documents",
            "Downloads": "Downloads", "Images": "Pictures", "Trash": "Trash",
            "Appearance": "Appearance", "Sound": "Sound", "Users": "Users",
            "Privacy": "Privacy", "System": "System", "Apps": "Apps",
            "Dock & Taskbar": "Dock",
            "Battery": "Battery", "Storage": "Storage", "About": "About",
            "Accessibility": "Accessibility", "Display": "Display",
        }
        b = QPushButton(name.replace('&', '&&'))
        b.setIcon(qt_icon(icon_names.get(name, name)))
        b.setIconSize(QSize(24, 24))
        b.setCursor(Qt.PointingHandCursor)
        sidebar_tips = {
            "Commands": "Open the command palette and run registered Nexora actions",
            "Privacy": "Review application permissions and local privacy controls",
            "Document": "Write and edit the current document",
            "Formatting": "Change text style, emphasis and layout",
            "Export": "Save or export the current work",
            "Sheet": "Edit cells and workbook data",
            "Recalculate": "Recalculate the selected formula or workbook",
            "Export CSV": "Save the current sheet as a CSV file",
            "Slides": "Browse and select slides in this presentation",
            "Add slide": "Create a new slide",
            "Delete slide": "Remove the selected slide",
            "Save": "Save the current presentation",
            "History": "See pages opened earlier",
            "Favorites": "Open saved websites",
            "Downloads": "View downloaded files",
            "Processes": "View currently running processes",
            "Performance": "Inspect CPU, memory and system performance",
            "Startup": "Manage apps launched with Nexora",
            "Services": "Inspect background system services",
        }
        b.setToolTip(sidebar_tips.get(name, f"Open the {name} section in {self.title}"))
        b.setFixedHeight(32)
        b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        b.setFont(font(10, selected))
        self.sidebar_buttons[name] = b
        if callback:
            b.clicked.connect(callback)
        b.clicked.connect(lambda _=False, key=name: self.set_active_sidebar(key))
        layout = getattr(self, "sidebar_nav_layout", self.sidebar_layout)
        layout.insertWidget(layout.count() - 1, b)
        if selected:
            self._active_sidebar = name
        self._refresh_sidebar_styles()
        return b

    def _refresh_sidebar_styles(self):
        items = list(self.sidebar_buttons.items())
        for index, (name, button) in enumerate(items):
            selected = name == self._active_sidebar
            base = rgba(self.accent, 112) if selected else "rgba(255,255,255,38)"
            top = 12 if index == 0 else 0
            bottom = 12 if index == len(items) - 1 else 0
            button.setFont(font(10, selected))
            button.setStyleSheet(
                f"QPushButton{{text-align:left;background:{base};color:{TEXT};border:none;"
                f"padding:4px 11px;margin:0;"
                f"border-top-left-radius:{top}px;border-top-right-radius:{top}px;"
                f"border-bottom-left-radius:{bottom}px;border-bottom-right-radius:{bottom}px;}}"
                f"QPushButton:hover{{background:{rgba(self.accent, 78)};border:none;outline:none;"
                f"border-top-left-radius:{top}px;border-top-right-radius:{top}px;"
                f"border-bottom-left-radius:{bottom}px;border-bottom-right-radius:{bottom}px;}}"
                f"QPushButton:pressed{{background:{rgba(self.accent, 132)};border:none;outline:none;padding:4px 11px;"
                f"border-top-left-radius:{top}px;border-top-right-radius:{top}px;"
                f"border-bottom-left-radius:{bottom}px;border-bottom-right-radius:{bottom}px;}}"
            )
        layout = getattr(self, "sidebar_nav_layout", None)
        if layout is not None:
            layout.setSpacing(0)

    def set_active_sidebar(self, name: str):
        if name in self.sidebar_buttons:
            self._active_sidebar = name
            self._refresh_sidebar_styles()

    def heading(self, title, subtitle=""):
        # The app name already lives in the integrated command header.
        # Keep only a subtle description so content and header read as one surface.
        if subtitle:
            s = QLabel(subtitle); s.setFont(font(10)); s.setWordWrap(True); s.setStyleSheet(f"color:{MUTED};padding-bottom:4px;"); self.content_layout.addWidget(s)
