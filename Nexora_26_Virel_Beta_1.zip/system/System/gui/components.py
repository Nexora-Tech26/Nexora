from .shared import *

class GlassFrame(QWidget):
    DEFAULT_RADIUS = 18

    @staticmethod
    def _coerce_radius(value, default=18):
        try:
            value = int(value)
        except (TypeError, ValueError, OverflowError):
            value = int(default)
        return max(0, min(128, value))

    def __init__(self, parent=None, radius=18, alpha=58, gradient=True, wallpaper_backdrop=True):
        # Set paint-critical fields before QWidget construction. On macOS Qt can
        # synchronously deliver style/paint events while native widgets are being
        # created, so these attributes must already exist.
        self._radius = self._coerce_radius(radius, self.DEFAULT_RADIUS)
        self.alpha = alpha
        self.use_gradient = bool(gradient)
        self.wallpaper_backdrop = bool(wallpaper_backdrop)
        super().__init__(parent)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        # Shadows are added only to selected shell surfaces. Applying a graphics
        # effect to every translucent frame forces off-screen rendering and causes
        # severe input latency on Intel macOS.

    @property
    def radius(self):
        return self._coerce_radius(getattr(self, "_radius", self.DEFAULT_RADIUS), self.DEFAULT_RADIUS)

    @radius.setter
    def radius(self, value):
        self._radius = self._coerce_radius(value, self.DEFAULT_RADIUS)
        if hasattr(self, "update"):
            self.update()

    @property
    def gradient(self):
        return bool(getattr(self, "use_gradient", True))

    @gradient.setter
    def gradient(self, value):
        self.use_gradient = bool(value)
        if hasattr(self, "update"):
            self.update()

    def _sync_rounded_mask(self):
        # Masks are deliberately disabled: setMask() forces expensive region updates on macOS.
        return

    def paintEvent(self, event):
        self._sync_rounded_mask()
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        path = QPainterPath()
        radius = self.radius
        path.addRoundedRect(self.rect().adjusted(1, 1, -1, -1), radius, radius)
        painter.setClipPath(path)
        host = None
        candidate = self
        while candidate is not None:
            if hasattr(candidate, "wallpaper_service") and hasattr(candidate, "app_layer"):
                host = candidate
                break
            candidate = candidate.parentWidget()
        if host is None:
            window = self.window()
            host = getattr(window, "desktop", None)
            if host is None and hasattr(window, "wallpaper_service"):
                host = window
        theme = getattr(getattr(host, "theme_engine", None), "current", None)
        settings = load_settings()
        if theme is None:
            from System.theme.engine import ThemeEngine
            class _SnapshotStore:
                def snapshot(self): return dict(settings)
            theme = ThemeEngine(_SnapshotStore()).resolve(settings)
        if self.wallpaper_backdrop and host is not None:
            service = getattr(host, "wallpaper_service", None)
            if service is not None and int(theme.blur) > 0:
                painter.save()
                # The blurred wallpaper is the glass backdrop, not an opaque
                # replacement surface. A slight reduction keeps the original
                # desktop visible and makes transparency perceptible.
                painter.setOpacity(0.88)
                service.paint_backdrop(painter, self, host, int(theme.blur))
                painter.restore()
        saved_transparency = int(settings.get("glass_transparency", 48))
        transparency = max(0, min(96, int(getattr(theme, "transparency", saved_transparency))))
        raw_alpha = round(255 * (100 - transparency) / 100)
        # Transparency is literal: 80 means a light 20%-opaque material.
        # A small readability lift is enough; the old +72 made every surface
        # look almost solid and hid the wallpaper blur.
        global_alpha = max(24, min(235, raw_alpha))
        requested_alpha = max(24, min(235, int(getattr(self, "alpha", global_alpha))))
        # Global transparency is authoritative across every glass surface.
        glass_alpha = global_alpha
        base = QColor(getattr(self, "tint_color", theme.surface))
        if self.use_gradient:
            grad = QLinearGradient(0, 0, self.width(), self.height())
            top = QColor(base.lighter(112)); top.setAlpha(min(168, glass_alpha + 20))
            bottom = QColor(base.darker(106)); bottom.setAlpha(max(18, glass_alpha - 10))
            grad.setColorAt(0.0, top)
            grad.setColorAt(1.0, bottom)
            painter.fillPath(path, grad)
        else:
            base.setAlpha(glass_alpha)
            painter.fillPath(path, base)
        # No edge stroke: the glass surface remains completely borderless.



class QuickControls(GlassFrame):
    """Single glass control-center button; the surface itself is interactive."""

    def __init__(self, desktop):
        super().__init__(desktop.ui_layer, radius=22, alpha=52, gradient=False, wallpaper_backdrop=True)
        self.desktop = desktop
        self.settings = load_settings()
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Volume, brightness, appearance and focus")
        self.setMinimumHeight(46)
        self.setMaximumHeight(64)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(11, 3, 11, 3)
        layout.setSpacing(6)
        self.icon = QLabel("◐")
        self.icon.setFont(font(16, True))
        self.label = QLabel("Control Center")
        self.label.setFont(font(9, True))
        for widget in (self.icon, self.label):
            widget.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            widget.setStyleSheet("background:transparent;border:none;color:white;")
        layout.addWidget(self.icon)
        layout.addWidget(self.label)
        layout.addStretch()
        self.volume = QSlider(Qt.Horizontal, self); self.volume.setRange(0,100); self.volume.hide()
        self.brightness = QSlider(Qt.Horizontal, self); self.brightness.setRange(10,100); self.brightness.hide()
        self._volume_timer = QTimer(self); self._volume_timer.setSingleShot(True); self._volume_timer.setInterval(90)
        self._brightness_timer = QTimer(self); self._brightness_timer.setSingleShot(True); self._brightness_timer.setInterval(110)
        self._volume_timer.timeout.connect(self._apply_volume)
        self._brightness_timer.timeout.connect(self._apply_brightness)
        self.volume.valueChanged.connect(self.volume_changed)
        self.brightness.valueChanged.connect(self.brightness_changed)
        self.reload()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
            self.desktop.toggle_control_center()
        super().mouseReleaseEvent(event)

    def recommended_width(self, _viewport_width: int) -> int: return 154
    def apply_theme(self, theme=None):
        theme = theme or getattr(self.desktop.theme_engine, "current", None)
        if theme:
            color = "#FFFFFF" if str(getattr(theme, "mode", "light")) == "dark" else "#172033"
            self.icon.setStyleSheet(f"background:transparent;border:none;color:{getattr(theme,'accent','#5B9DF5')};")
            self.label.setStyleSheet(f"background:transparent;border:none;color:{color};")
        self.update()
    def _refresh_labels(self):
        self.label.setText("Focus · Controls" if bool(load_settings().get("do_not_disturb",False)) else "Control Center")
    def reload(self):
        self.settings=load_settings()
        self.volume.blockSignals(True); self.brightness.blockSignals(True)
        self.volume.setValue(int(self.settings.get("volume",65))); self.brightness.setValue(int(self.settings.get("brightness",100)))
        self.volume.blockSignals(False); self.brightness.blockSignals(False)
        self._refresh_labels(); self.apply_theme()
    def volume_changed(self,value):
        self._pending_volume=int(value); settings=load_settings(); settings["volume"]=int(value); save_settings(settings); self._volume_timer.start()
    def brightness_changed(self,value):
        self._pending_brightness=int(value); settings=load_settings(); settings["brightness"]=int(value); save_settings(settings); self.desktop.apply_brightness(int(value)); self._brightness_timer.start()
    def _apply_volume(self):
        submit(system_services.set_volume,int(getattr(self,"_pending_volume",self.volume.value())),on_error=lambda m:self.desktop.notch.notify("Volume: "+m))
    def _apply_brightness(self):
        submit(system_services.set_brightness,int(getattr(self,"_pending_brightness",self.brightness.value())),on_error=lambda m:self.desktop.notch.notify("Brightness: "+m))


class AnimatedNotch(GlassFrame):
    """Configurable notch with hover system telemetry."""
    def __init__(self, parent: QWidget, text: str = "Nexora"):
        super().__init__(parent, radius=18, alpha=70, gradient=False, wallpaper_backdrop=False)
        self.settings = load_settings()
        self.compact_width, self.expanded_width = 154, 420
        self.compact_height, self.expanded_height = 34, 96
        self.setMouseTracking(True)
        self.setMinimumSize(self.compact_width, self.compact_height); self.setMaximumSize(self.expanded_width, self.expanded_height); self.resize(self.compact_width, self.compact_height)
        self.setStyleSheet("background:transparent;border:none;")
        self.layout_root = QVBoxLayout(self)
        self.layout_root.setContentsMargins(16, 5, 16, 8)
        self.layout_root.setSpacing(5)
        row = QHBoxLayout(); row.setSpacing(8)
        self.dot = QLabel("●"); self.dot.setStyleSheet(f"color:{ACCENT};background:transparent;border:none;")
        self.label = QLabel(text); self.label.setAlignment(Qt.AlignCenter); self.label.setFont(font(9, True)); self.label.setStyleSheet("color:#252A31;background:transparent;border:none;")
        row.addStretch(); row.addWidget(self.dot); row.addWidget(self.label); row.addStretch(); self.layout_root.addLayout(row)
        self.metrics = QLabel(""); self.metrics.setAlignment(Qt.AlignCenter); self.metrics.setFont(font(8)); self.metrics.setStyleSheet("color:#66707D;background:transparent;border:none;"); self.metrics.hide(); self.layout_root.addWidget(self.metrics)
        self._animation = None
        self.activities = {}
        self._notification_active = False
        self.timer = QTimer(self); self.timer.setInterval(10000); self.timer.timeout.connect(self.update_metrics)
        self.apply_mode()

    def paintEvent(self, event):
        # Notch uses exactly the same blurred material as every other shell.
        GlassFrame.paintEvent(self, event)

    def apply_mode(self):
        self.settings=load_settings(); mode="dynamic"
        self.setVisible(mode != "off"); self.update()

    def start(self): self.apply_mode()
    def enterEvent(self,event): self.expand("System status", show_metrics=True); super().enterEvent(event)
    def leaveEvent(self,event): QTimer.singleShot(220,self.collapse); super().leaveEvent(event)
    def mousePressEvent(self,event): self.expand("System status", show_metrics=True); super().mousePressEvent(event)

    def update_metrics(self):
        try:
            import psutil
            cpu=psutil.cpu_percent(); ram=psutil.virtual_memory().percent; disk=psutil.disk_usage(str(PROJECT_ROOT)).percent
            battery=psutil.sensors_battery(); batt=f"  BAT {battery.percent:.0f}%" if battery else ""
            self.metrics.setText(f"CPU {cpu:.0f}%   RAM {ram:.0f}%   DISK {disk:.0f}%{batt}")
        except Exception: self.metrics.setText("System metrics unavailable")

    def _animate(self, size: QSize, duration=240):
        """Animate the notch without relaying out the whole desktop each frame.

        Only this widget is resized and re-centered. Updates are frame-throttled,
        so the effect remains visible while avoiding a storm of layout/paint work.
        """
        if self._animation:
            self._animation.stop()
            self._animation = None
        start = QSize(self.size())
        target = QSize(size)
        if start == target:
            return
        parent = self.parentWidget()
        start_y = self.y()
        last_frame = [0.0]
        animation = QVariantAnimation(self)
        animation.setStartValue(0.0)
        animation.setEndValue(1.0)
        animation.setDuration(max(150, int(duration)))
        animation.setEasingCurve(QEasingCurve.OutCubic if target.width() > start.width() else QEasingCurve.InOutCubic)

        def apply_frame(value):
            now = time.monotonic()
            if value < 1.0 and now - last_frame[0] < 1.0 / 60.0:
                return
            last_frame[0] = now
            t = float(value)
            width = round(start.width() + (target.width() - start.width()) * t)
            height = round(start.height() + (target.height() - start.height()) * t)
            if self.width() == width and self.height() == height:
                return
            x = self.x()
            if parent is not None:
                x = max(10, (parent.width() - width) // 2)
            self.setGeometry(x, start_y, width, height)
            self.update()

        def finish():
            if parent is not None:
                self.setGeometry(max(10, (parent.width() - target.width()) // 2), start_y, target.width(), target.height())
            else:
                self.resize(target)
            self._animation = None
            self.update()

        animation.valueChanged.connect(apply_frame)
        animation.finished.connect(finish)
        self._animation = animation
        animation.start()

    def expand(self,text="System status", show_metrics=False):
        if not self.isVisible(): return
        self.label.setText(text)
        if show_metrics:
            self.metrics.show(); self.update_metrics()
        elif self.activities:
            key=next(reversed(self.activities)); title,value,_persistent=self.activities[key]
            self.label.setText(title); self.metrics.setText(value); self.metrics.show()
        else:
            self.metrics.hide()
        target_h=self.expanded_height if self.metrics.isVisible() else 58
        self._animate(QSize(self.expanded_width,target_h))

    def set_activity(self,key,title,value,persistent=True):
        self.activities[str(key)]=(str(title),str(value),bool(persistent))
        self.expand(title,show_metrics=False)

    def clear_activity(self,key):
        self.activities.pop(str(key),None)
        if self.activities:
            active=next(reversed(self.activities)); title,value,_=self.activities[active]
            self.label.setText(title); self.metrics.setText(value); self.metrics.show(); self._animate(QSize(self.expanded_width,self.expanded_height))
        elif not self._notification_active:
            self.collapse(force=True)
    def notify(self, text: str, duration: int = 1800):
        settings = load_settings()
        try:
            desktop = self.window()
            if settings.get("notification_location", "notch") == "corner" and hasattr(desktop, "show_corner_notification"):
                desktop.show_corner_notification(text, duration)
                return
            if not self.isVisible():
                if hasattr(desktop, "show_corner_notification"):
                    desktop.show_corner_notification(text, duration)
                return
            self._notification_active = True
            self.expand(text, show_metrics=False)
            if not hasattr(self, "_notification_timer"):
                self._notification_timer = QTimer(self)
                self._notification_timer.setSingleShot(True)
                self._notification_timer.timeout.connect(self._finish_notification)
            self._notification_timer.start(max(100, int(duration)))
        except RuntimeError:
            # The old screen/notch may already have been destroyed while the
            # application transitions from OOBE to Login or Desktop.
            return

    def _finish_notification(self):
        try:
            self._notification_active = False
            if self.activities:
                self.expand(show_metrics=False)
            else:
                self.collapse(force=True)
        except RuntimeError:
            return

    def collapse(self, force=False):
        try:
            if not self.isVisible() or (self.underMouse() and not force):
                return
            if self.activities and not force:
                self.expand(show_metrics=False)
                return
            self.metrics.hide()
            self.label.setText("Nexora")
            self._animate(QSize(self.compact_width, self.compact_height), 260)
        except RuntimeError:
            return


class NotificationToast(GlassFrame):
    """Animated notification card anchored to the top-right corner."""
    def __init__(self, desktop):
        super().__init__(desktop.ui_layer, radius=20, alpha=30, gradient=False, wallpaper_backdrop=True)
        self.desktop = desktop
        self.setFixedSize(360, 96)
        self.hide()
        self._anim = None
        self._timer = QTimer(self); self._timer.setSingleShot(True); self._timer.timeout.connect(self.dismiss)
        root = QHBoxLayout(self); root.setContentsMargins(16,14,16,14); root.setSpacing(12)
        self.badge = QLabel("N"); self.badge.setAlignment(Qt.AlignCenter); self.badge.setFixedSize(44,44); self.badge.setFont(font(16,True))
        self.badge.setStyleSheet("background:#8AB4F8;color:#17191F;border-radius:22px;")
        texts=QVBoxLayout(); self.title=QLabel("Nexora"); self.title.setFont(font(10,True)); self.message=QLabel(); self.message.setWordWrap(True); self.message.setFont(font(9))
        texts.addWidget(self.title); texts.addWidget(self.message); root.addWidget(self.badge); root.addLayout(texts,1)
        self._apply_theme()

    def _apply_theme(self):
        light = True
        title_color = "#17191F" if light else "#FFFFFF"
        message_color = "#343A46" if light else "#E7E9EF"
        self.title.setStyleSheet(f"color:{title_color};background:transparent;border:none;")
        self.message.setStyleSheet(f"color:{message_color};background:transparent;border:none;")
        self.badge.setStyleSheet("background:#8AB4F8;color:#17191F;border-radius:22px;")

    def present(self, message, duration=1800):
        self._apply_theme()
        self.message.setText(message)
        self.show(); self.raise_()
        end=QRect(max(12,self.desktop.width()-self.width()-18),18,self.width(),self.height())
        start=QRect(self.desktop.width()+12,18,self.width(),self.height())
        self.setGeometry(start)
        if self._anim: self._anim.stop()
        self._anim=QPropertyAnimation(self,b"geometry",self); self._anim.setDuration(MOTION.toast_in); self._anim.setStartValue(start); self._anim.setEndValue(end); self._anim.setEasingCurve(enter_curve()); self._anim.start()
        self._timer.start(duration)
    def dismiss(self):
        if not self.isVisible(): return
        start=self.geometry(); end=QRect(self.desktop.width()+12,start.y(),start.width(),start.height())
        if self._anim:self._anim.stop()
        self._anim=QPropertyAnimation(self,b"geometry",self); self._anim.setDuration(MOTION.toast_out); self._anim.setStartValue(start); self._anim.setEndValue(end); self._anim.setEasingCurve(exit_curve()); self._anim.finished.connect(self.hide); self._anim.start()


class PowerOverlay(QWidget):
    def __init__(self, desktop: "Desktop"):
        super().__init__(desktop.ui_layer)
        self.desktop = desktop
        self.setStyleSheet("background:rgba(10,10,14,185);")
        self.hide()
        card = GlassFrame(self, radius=24, alpha=118, gradient=True)
        card.setFixedSize(430, 270)
        root = QVBoxLayout(self)
        root.addStretch(); root.addWidget(card, 0, Qt.AlignCenter); root.addStretch()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(34, 30, 34, 28)
        title = QLabel("Power")
        title.setAlignment(Qt.AlignCenter); title.setFont(font(22, True))
        title.setStyleSheet("background:transparent;border:none;")
        layout.addWidget(title)
        subtitle = QLabel("Choose what Nexora should do")
        subtitle.setAlignment(Qt.AlignCenter); subtitle.setStyleSheet(f"color:{MUTED};background:transparent;border:none;")
        layout.addWidget(subtitle); layout.addSpacing(12)
        buttons = QHBoxLayout()
        buttons.setSpacing(0)
        cancel = QPushButton("Cancel")
        restart = QPushButton("Restart UI")
        shutdown = QPushButton("Shut down")
        for button in (cancel, restart, shutdown):
            button.setMinimumHeight(44)
        power_specs = ((cancel, "#B9A7E8"), (restart, "#8AB4F8"), (shutdown, "#F4A7B9"))
        for index, (button, tint) in enumerate(power_specs):
            left = 14 if index == 0 else 0
            right = 14 if index == len(power_specs) - 1 else 0
            button.setStyleSheet(
                f"QPushButton{{background:{tint};color:#17191F;border:none;outline:none;"
                f"border-top-left-radius:{left}px;border-bottom-left-radius:{left}px;"
                f"border-top-right-radius:{right}px;border-bottom-right-radius:{right}px;"
                "padding:8px 16px;margin:0;font-weight:700;}"
                "QPushButton:hover{background:rgba(255,255,255,210);}"
                "QPushButton:pressed{background:rgba(255,255,255,170);padding:8px 16px;}"
            )
        cancel.clicked.connect(self.hide)
        restart.clicked.connect(self.desktop.restart_ui)
        shutdown.clicked.connect(QApplication.instance().quit)
        buttons.addWidget(cancel); buttons.addWidget(restart); buttons.addWidget(shutdown)
        layout.addLayout(buttons)

    def show_overlay(self):
        self.setGeometry(self.parentWidget().rect())
        self.show(); self.raise_()


class SystemOverlay(GlassFrame):
    """In-system sheet used instead of native operating-system dialogs."""
    def __init__(self, desktop, title, text=""):
        super().__init__(desktop.ui_layer, radius=24, alpha=54, gradient=True, wallpaper_backdrop=True)
        self.desktop = desktop
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setFixedSize(540, 280)
        self.move((desktop.ui_layer.width() - self.width()) // 2, (desktop.ui_layer.height() - self.height()) // 2)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 26, 30, 26)
        layout.setSpacing(14)
        heading = QLabel(title)
        heading.setFont(font(20, True))
        heading.setStyleSheet(f"color:{TEXT};background:transparent;border:none;")
        layout.addWidget(heading)
        body = QLabel(text)
        body.setWordWrap(True)
        body.setStyleSheet(f"color:{MUTED};background:transparent;border:none;")
        layout.addWidget(body, 1)
        self.body = body
        self.buttons = QHBoxLayout()
        self.buttons.setSpacing(10)
        self.buttons.addStretch()
        layout.addLayout(self.buttons)
        self._shadow = apply_shadow(self, blur=50, y=14, alpha=155)
        self.show(); self.raise_()

    def add_button(self, label, callback, color="#8AB4F8"):
        button = QPushButton(label)
        button.setMinimumHeight(42)
        button.setStyleSheet(gradient_button_style(color, radius=13))
        button.clicked.connect(lambda: (callback(), self.deleteLater()))
        self.buttons.addWidget(button)
        return button


class InternalFilePicker(GlassFrame):
    """Sandboxed Finder-like picker restricted to Nexora/Home/User."""
    def __init__(self, desktop, title, mode, callback, default_name="", extensions=None):
        super().__init__(desktop.ui_layer, radius=26, alpha=48, gradient=True, wallpaper_backdrop=True)
        self.desktop = desktop
        self.mode = mode
        self.callback = callback
        self.extensions = {e.lower() for e in (extensions or [])}
        self.folder = (NEXORA_HOME / "Documents").resolve()
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setFixedSize(760, 540)
        self.move((desktop.ui_layer.width() - self.width()) // 2, (desktop.ui_layer.height() - self.height()) // 2)

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 22, 24, 22)
        root.setSpacing(12)
        header = QHBoxLayout()
        title_label = QLabel(title)
        title_label.setFont(font(20, True))
        title_label.setStyleSheet(f"color:{TEXT};background:transparent;border:none;")
        header.addWidget(title_label)
        header.addStretch()
        close = QPushButton("×")
        close.setFixedSize(34, 34)
        close.setStyleSheet(gradient_button_style("#F4A7B9", radius=12))
        close.clicked.connect(self.deleteLater)
        header.addWidget(close)
        root.addLayout(header)

        self.path_label = QLabel()
        self.path_label.setStyleSheet(f"color:{MUTED};background:transparent;border:none;padding:4px 2px;")
        root.addWidget(self.path_label)

        self.list = QListWidget()
        self.list.setStyleSheet(
            f"QListWidget{{background:rgba(255,255,255,24);color:{TEXT};border:none;"
            "border-radius:24px;padding:8px;outline:none;}"
            "QListWidget::item{padding:10px 12px;margin:2px;border-radius:24px;}"
            f"QListWidget::item:hover{{background:{rgba('#8AB4F8', 42)};}}"
            f"QListWidget::item:selected{{background:{rgba('#8AB4F8', 88)};color:{TEXT};}}"
        )
        self.list.itemDoubleClicked.connect(self.activate)
        root.addWidget(self.list, 1)

        self.name = QLineEdit(default_name)
        self.name.setPlaceholderText("File name")
        self.name.setVisible(mode == "save")
        self.name.setStyleSheet(glass_input_css(ACCENT))
        root.addWidget(self.name)

        row = QHBoxLayout()
        row.setSpacing(0)
        row.addStretch()
        cancel = QPushButton("Cancel")
        choose = QPushButton("Open" if mode == "open" else "Save")
        cancel.setStyleSheet("QPushButton{background:rgba(185,167,232,95);border:none;border-top-left-radius:13px;border-bottom-left-radius:13px;border-top-right-radius:0;border-bottom-right-radius:0;padding:9px 16px;}QPushButton:hover{background:rgba(185,167,232,130);}")
        choose.setStyleSheet("QPushButton{background:rgba(138,180,248,120);border:none;border-top-right-radius:13px;border-bottom-right-radius:13px;border-top-left-radius:0;border-bottom-left-radius:0;padding:9px 16px;}QPushButton:hover{background:rgba(138,180,248,155);}")
        cancel.clicked.connect(self.deleteLater)
        choose.clicked.connect(self.choose)
        row.addWidget(cancel); row.addWidget(choose)
        root.addLayout(row)
        self._shadow = apply_shadow(self, blur=54, y=16, alpha=165)
        self.refresh(); self.show(); self.raise_()

    def refresh(self):
        relative = self.folder.relative_to(NEXORA_HOME) if self.folder != NEXORA_HOME else Path()
        self.path_label.setText("Home" + (" / " + str(relative) if str(relative) != "." else ""))
        self.list.clear()
        if self.folder != NEXORA_HOME:
            item = QListWidgetItem("‹  Back")
            item.setData(Qt.UserRole, "__back__")
            self.list.addItem(item)
        try:
            items = sorted(self.folder.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except OSError:
            items = []
        for path in items:
            if path.is_file() and self.extensions and path.suffix.lower() not in self.extensions:
                continue
            item = QListWidgetItem(("▣  " if path.is_dir() else "•  ") + path.name)
            item.setData(Qt.UserRole, path)
            self.list.addItem(item)

    def activate(self, item):
        value = item.data(Qt.UserRole)
        if value == "__back__":
            parent = self.folder.parent
            self.folder = parent if inside_home(parent) else NEXORA_HOME
            self.refresh(); return
        if not value:
            return
        path = Path(value)
        if path.is_dir():
            self.folder = path.resolve(); self.refresh()
        elif self.mode == "open":
            self.callback(path); self.deleteLater()

    def choose(self):
        if self.mode == "open":
            item = self.list.currentItem()
            value = item.data(Qt.UserRole) if item else None
            if value and value != "__back__" and Path(value).is_file():
                self.callback(Path(value)); self.deleteLater()
            return
        name = self.name.text().strip() or "untitled.txt"
        target = (self.folder / name).resolve()
        if self.extensions and target.suffix.lower() not in self.extensions:
            preferred = sorted(self.extensions)[0]
            target = target.with_suffix(preferred)
        if inside_home(target):
            self.callback(target); self.deleteLater()


class DockHoverButton(QPushButton):
    hoverChanged = Signal(bool)
    pointerMoved = Signal(QPoint)
    dragStarted = Signal(QPoint)
    dragMoved = Signal(QPoint)
    dragFinished = Signal(QPoint)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMouseTracking(True)
        self._drag_press_global = None
        self._dock_dragging = False
        self._base_style = ""

    def set_shape(self, shape_name: str):
        # Compatibility only. Polygon masks were removed because they caused
        # clipping and resize crashes on macOS. All dock controls use a stable
        # rounded rectangle/circle defined by Qt Style Sheets.
        return None

    def resizeEvent(self, event):
        super().resizeEvent(event)

    def enterEvent(self, event):
        self.hoverChanged.emit(True)
        self.pointerMoved.emit(self.rect().center())
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.hoverChanged.emit(False)
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._drag_press_global = event.globalPosition().toPoint()
            self._dock_dragging = False
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        self.pointerMoved.emit(event.position().toPoint())
        if self._drag_press_global is not None and event.buttons() & Qt.LeftButton:
            global_pos = event.globalPosition().toPoint()
            if not self._dock_dragging and (global_pos - self._drag_press_global).manhattanLength() >= QApplication.startDragDistance():
                self._dock_dragging = True
                self.dragStarted.emit(global_pos)
            if self._dock_dragging:
                self.dragMoved.emit(global_pos)
                event.accept()
                return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self._dock_dragging:
            self.dragFinished.emit(event.globalPosition().toPoint())
            self._drag_press_global = None
            self._dock_dragging = False
            self.setDown(False)
            event.accept()
            return
        self._drag_press_global = None
        self._dock_dragging = False
        super().mouseReleaseEvent(event)


class DockShell(QWidget):
    hoverChanged = Signal(bool)
    pointerMoved = Signal(QPoint)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setMouseTracking(True)
        self.setStyleSheet("background:transparent;border:none;")

    def enterEvent(self, event):
        self.hoverChanged.emit(True)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.hoverChanged.emit(False)
        super().leaveEvent(event)

    def mouseMoveEvent(self, event):
        self.pointerMoved.emit(event.position().toPoint())
        super().mouseMoveEvent(event)


class PreviewChoiceButton(QPushButton):
    """A selectable card that draws a real miniature of a Nexora layout."""
    def __init__(self, value, title, subtitle, colors, parent=None):
        super().__init__(parent)
        self.value, self.title, self.subtitle, self.colors = value, title, subtitle, colors
        self.active = False
        self.setCheckable(True)
        self.setMinimumSize(210, 138)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("background:transparent;border:none;")

    def setActive(self, active):
        self.active = bool(active); self.setChecked(active); self.update()

    def paintEvent(self, event):
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        r=self.rect().adjusted(2,2,-2,-2)
        bg=QColor(20,25,36,225) if load_settings().get("theme_mode") == "dark" else QColor(240,245,251,225)
        p.setBrush(bg); p.setPen(QColor(76,151,255,235) if self.active else QColor(255,255,255,105)); p.drawRoundedRect(r,18,18)
        preview=QRect(r.left()+12,r.top()+12,r.width()-24,78)
        p.setBrush(QColor(29,38,56,210)); p.setPen(QColor(255,255,255,35)); p.drawRoundedRect(preview,12,12)
        # miniature window
        win=QRect(preview.left()+14,preview.top()+11,preview.width()-28,preview.height()-22)
        p.setBrush(QColor(226,235,246,95)); p.setPen(QColor(255,255,255,70)); p.drawRoundedRect(win,8,8)
        p.fillRect(QRect(win.left(),win.top(),win.width(),10), QColor(75,139,232,150))
        profile=PANEL_STYLES.get(self.value)
        if profile:
            edge=profile.get("edge","bottom"); vertical=profile.get("vertical",False)
            if vertical:
                bw=10; bh=max(32,win.height()-12); y=win.top()+6
                x=win.left()+5 if edge=="left" else win.right()-bw-5
                bar=QRect(x,y,bw,bh)
            else:
                bh=10; bw=win.width()-18 if profile.get("width")=="full" else max(44,win.width()//2)
                x=win.center().x()-bw//2
                y=win.top()+5 if edge=="top" else win.bottom()-bh-5
                if profile.get("align")=="right": x=win.right()-bw-6
                bar=QRect(x,y,bw,bh)
            p.setBrush(QColor(130,180,248,185)); p.setPen(Qt.NoPen); p.drawRoundedRect(bar,5,5)
            # app dots/icons
            p.setBrush(QColor(255,255,255,210))
            if vertical:
                for i in range(4): p.drawEllipse(QPoint(bar.center().x(),bar.top()+9+i*10),2,2)
            else:
                for i in range(5): p.drawEllipse(QPoint(bar.left()+9+i*8,bar.center().y()),2,2)
        else:
            c1,c2=self.colors; grad=QLinearGradient(preview.topLeft(),preview.bottomRight());
            if self.value=="dark": a,b=QColor(40,48,70),QColor(12,16,25)
            else: a,b=QColor(170,214,244),QColor(235,226,246)
            grad.setColorAt(0,a); grad.setColorAt(1,b); p.fillRect(preview.adjusted(5,5,-5,-5),grad)
        text_color=QColor(255,255,255) if load_settings().get("theme_mode")=="dark" else QColor(23,25,31)
        p.setPen(text_color); p.setFont(font(11,True)); p.drawText(QRect(r.left()+14,r.top()+96,r.width()-28,20),Qt.AlignLeft|Qt.AlignVCenter,self.title)
        p.setPen(QColor(190,199,214) if load_settings().get("theme_mode")=="dark" else QColor(82,92,108)); p.setFont(font(8)); p.drawText(QRect(r.left()+14,r.top()+116,r.width()-28,18),Qt.AlignLeft|Qt.AlignVCenter,self.subtitle)


class VisualChoice(QWidget):
    """Button-based selector with a real miniature layout preview."""
    changed = Signal(str)
    def __init__(self, options, selected, parent=None):
        super().__init__(parent); self._value=selected; self._buttons={}
        grid=QGridLayout(self); grid.setContentsMargins(0,0,0,0); grid.setHorizontalSpacing(12); grid.setVerticalSpacing(12)
        for index,(value,title,subtitle,colors) in enumerate(options):
            button=PreviewChoiceButton(value,title,subtitle,colors,self)
            button.clicked.connect(lambda checked=False,v=value:self.setValue(v))
            self._buttons[value]=button; grid.addWidget(button,index//2,index%2)
        self.setValue(selected,emit=False)
    def currentData(self): return self._value
    def setValue(self,value,emit=True):
        if value not in self._buttons: value=next(iter(self._buttons))
        self._value=value
        for key,button in self._buttons.items(): button.setActive(key==value)
        if emit:self.changed.emit(value)


# ---------------------------------------------------------------------------
# Nexora 26 semantic component layer
# ---------------------------------------------------------------------------
class NexoraGlassSurface(GlassFrame):
    """Canonical frosted surface used by new Nexora UI."""

    def __init__(self, parent=None, *, radius: int = 25, alpha: int = 64, gradient: bool = False):
        super().__init__(parent, radius=radius, alpha=alpha, gradient=gradient, wallpaper_backdrop=True)


class NexoraButton(QPushButton):
    def __init__(self, text: str = "", parent=None, *, primary: bool = False):
        super().__init__(text, parent)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(40)
        self.setProperty("nexoraPrimary", bool(primary))
        dark = load_settings().get("ui_style") == "cosmic_dark" or load_settings().get("theme_mode") == "dark"
        if dark:
            base_a, base_b, hover_a, hover_b = "#27345F", "#4C3E87", "#35477A", "#6651A8"
            primary_a, primary_b, foreground = "#6172FF", "#9A6CFF", "#F7F8FF"
        else:
            base_a, base_b, hover_a, hover_b = "#D7EEFF", "#B9DFFF", "#E9F7FF", "#C9E8FF"
            primary_a, primary_b, foreground = "#58B6FF", "#668CFF", "#14243A"
        self.setStyleSheet(
            f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {base_a},stop:1 {base_b});"
            f"border:none;border-radius:10px;padding:7px 14px;color:{foreground};font-weight:650;}}"
            f"QPushButton[nexoraPrimary=true]{{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {primary_a},stop:1 {primary_b});color:white;}}"
            f"QPushButton:hover{{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {hover_a},stop:1 {hover_b});}}"
            f"QPushButton[nexoraPrimary=true]:hover{{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {primary_b},stop:1 {primary_a});}}"
            "QPushButton:focus{outline:none;border:none;}"
            "QPushButton:disabled{color:rgba(120,130,150,110);background:rgba(150,165,190,50);}"
        )


class NexoraIconButton(NexoraButton):
    def __init__(self, text: str = "", parent=None, *, size: int = 38, primary: bool = False):
        super().__init__(text, parent, primary=primary)
        self.setFixedSize(size, size)
        self.setStyleSheet(self.styleSheet() + f"QPushButton{{padding:0;border-radius:{size // 2}px;}}")


class NexoraTextField(QLineEdit):
    def __init__(self, placeholder: str = "", parent=None, *, compact: bool = False):
        super().__init__(parent)
        self.setPlaceholderText(placeholder)
        self.setMinimumHeight(34 if compact else 42)
        self.setStyleSheet(
            "QLineEdit{background:rgba(248,250,253,76);border:none;"
            "border-radius:24px;padding:7px 12px;color:#17191F;selection-background-color:#3F8CFF;}"
            "QLineEdit:focus{border:none;outline:none;background:rgba(248,251,253,92);}"
        )


class NexoraSidebar(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("NexoraSidebar")
        self.setStyleSheet(
            "QFrame#NexoraSidebar{background:rgba(224,233,242,58);border:none;"
            "border-top-left-radius:25px;border-bottom-left-radius:25px;}"
        )


class NexoraPopup(NexoraGlassSurface):
    def __init__(self, parent=None):
        super().__init__(parent, radius=25, alpha=76, gradient=False)
        self.setWindowFlags(Qt.Popup | Qt.FramelessWindowHint | Qt.NoDropShadowWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)


class NexoraContextMenu(QMenu):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlag(Qt.NoDropShadowWindowHint, True)
        self.setStyleSheet(
            "QMenu{background:rgba(239,245,250,242);border:none;"
            "border-radius:25px;padding:9px;color:#17191F;}"
            "QMenu::item{min-height:30px;padding:5px 34px 5px 12px;border-radius:24px;}"
            "QMenu::item:selected{background:rgba(63,140,255,38);}"
            "QMenu::separator{height:6px;background:transparent;margin:1px 10px;}"
        )


class NexoraSlider(QSlider):
    def __init__(self, orientation=Qt.Horizontal, parent=None):
        super().__init__(orientation, parent)
        self.setStyleSheet(
            "QSlider{background:transparent;border:none;}"
            "QSlider::groove:horizontal{height:8px;background:rgba(255,255,255,58);border:none;border-radius:4px;}"
            "QSlider::sub-page:horizontal{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #5B9DF5,stop:1 #9B67DF);border:none;border-radius:4px;}"
            "QSlider::handle:horizontal{background:rgba(255,255,255,235);border:none;width:18px;margin:-5px 0;border-radius:22px;}"
        )


class NexoraToggle(QCheckBox):
    def __init__(self, text: str = "", parent=None):
        super().__init__(text, parent)
        self.setStyleSheet(
            "QCheckBox{spacing:9px;background:transparent;color:#17191F;}"
            "QCheckBox::indicator{width:34px;height:20px;border-radius:24px;"
            "background:rgba(100,115,135,65);border:none;}"
            "QCheckBox::indicator:checked{background:#3F8CFF;}"
            "QCheckBox:focus{outline:none;}"
        )


class NexoraTitleBar(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("NexoraTitleBar")
        self.setFixedHeight(48)
        self.setStyleSheet("QFrame#NexoraTitleBar{background:transparent;border:none;}")


class NexoraDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.Dialog | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setStyleSheet("QDialog{background:rgba(239,245,250,242);border-radius:25px;color:#17191F;}")
