"""Settings application builder for Nexora 26 Beta 1 .

The builder keeps a working copy separate from SettingsStore. Every control can
be previewed without writing to disk, then committed, reverted, imported,
exported or restored to defaults.
"""
from __future__ import annotations

import json
import platform
import sys
import time
from pathlib import Path

from .shared import *
from .components import SystemOverlay
from System.settings import DEFAULTS, validate_settings


def _average_wallpaper_accent(path: Path) -> str:
    """Return a stable accent extracted from a small wallpaper thumbnail."""
    try:
        with Image.open(path) as image:
            image = image.convert("RGB")
            image.thumbnail((64, 64), Image.Resampling.LANCZOS)
            pixels = list(image.getdata())
        if not pixels:
            return "#3F8CFF"
        # Ignore nearly black/white pixels, which otherwise dominate many
        # wallpapers and produce unreadable accents.
        useful = [p for p in pixels if 35 < sum(p) / 3 < 225]
        useful = useful or pixels
        red = sum(p[0] for p in useful) // len(useful)
        green = sum(p[1] for p in useful) // len(useful)
        blue = sum(p[2] for p in useful) // len(useful)
        # Increase chroma slightly while keeping a safe luminance range.
        peak, low = max(red, green, blue), min(red, green, blue)
        if peak - low < 38:
            blue = min(255, blue + 48)
            red = max(32, red - 10)
        scale = 1.0
        luminance = (red * 0.2126 + green * 0.7152 + blue * 0.0722)
        if luminance < 70:
            scale = 95 / max(1, luminance)
        elif luminance > 205:
            scale = 180 / luminance
        red, green, blue = (max(0, min(255, round(v * scale))) for v in (red, green, blue))
        return f"#{red:02X}{green:02X}{blue:02X}"
    except (OSError, ValueError):
        return "#3F8CFF"


def build_settings_ui(self):
    """Minimal, instant Settings UI with only core Nexora controls."""
    settings = load_settings()
    initial_settings = dict(settings)
    self.settings_data = dict(settings)
    self.heading("Settings", "Essential Nexora preferences")

    pages = QStackedWidget()
    pages.setStyleSheet("QStackedWidget{background:transparent;border:none;}")
    self.content_layout.addWidget(pages, 1)

    page_names = [
        "Appearance", "Desktop", "Dock & Taskbar",
        "Sound", "Apps", "Users", "Privacy", "Accessibility", "System",
    ]
    page_map = {}
    section_groups = {}

    def page(name, subtitle):
        host = QScrollArea()
        host.setWidgetResizable(True)
        host.setFrameShape(QFrame.NoFrame)
        host.setStyleSheet("QScrollArea{background:transparent;border:none;}QScrollArea>QWidget>QWidget{background:transparent;}")
        body = QWidget()
        layout = QVBoxLayout(body)
        layout.setContentsMargins(6, 6, 14, 18)
        layout.setSpacing(10)
        title = QLabel(name)
        title.setFont(font(20, True))
        desc = QLabel(subtitle)
        desc.setWordWrap(True)
        desc.setProperty("nexoraMuted", True)
        desc.setStyleSheet("background:transparent;border:none;")
        layout.addWidget(title)
        layout.addWidget(desc)
        host.setWidget(body)
        pages.addWidget(host)
        page_map[name] = (host, layout)
        return layout

    def section(layout, icon, title, subtitle=""):
        box = QFrame()
        box.setObjectName("SettingsSection")
        group = section_groups.setdefault(id(layout), [])
        group.append(box)
        for index, card in enumerate(group):
            top = 16 if index == 0 else 0
            bottom = 16 if index == len(group) - 1 else 0
            card.setStyleSheet(
                "QFrame#SettingsSection{background:rgba(255,255,255,28);border:none;"
                f"border-top-left-radius:{top}px;border-top-right-radius:{top}px;"
                f"border-bottom-left-radius:{bottom}px;border-bottom-right-radius:{bottom}px;}}"
            )
        layout.setSpacing(0)
        row = QVBoxLayout(box)
        row.setContentsMargins(16, 14, 16, 14)
        row.setSpacing(8)
        heading_row = QHBoxLayout()
        icon_label = QLabel()
        icon_map = {
            "Theme": "Appearance", "Accent": "Personalization",
            "Dock": "Dock", "Desktop": "Desktop", "Output": "Sound",
            "Current account": "User", "Local data": "Privacy",
            "Nexora 26 Beta 1": "About",
        }
        pixmap = qt_icon(icon_map.get(title, title)).pixmap(28, 28)
        icon_label.setPixmap(pixmap)
        icon_label.setFixedSize(30, 30)
        heading = QLabel(title)
        heading.setFont(font(12, True))
        heading_row.addWidget(icon_label)
        heading_row.addWidget(heading)
        heading_row.addStretch()
        row.addLayout(heading_row)
        if subtitle:
            text = QLabel(subtitle)
            text.setWordWrap(True)
            text.setProperty("nexoraMuted", True)
            text.setStyleSheet("background:transparent;border:none;")
            row.addWidget(text)
        layout.addWidget(box)
        return row

    def store_many(values):
        changed_keys = tuple(values)
        self.settings_data.update(values)
        preview = validate_settings(self.settings_data)
        save_settings(preview)
        # Apply synchronously so already-open surfaces change immediately.
        self.desktop.preview_settings(preview, changed_keys)

    def store(key, value):
        store_many({key: value})

    appearance = page("Appearance", "Minimal themes, window controls and accent colors.")
    row = section(appearance, "◐", "Theme")
    theme_row = QHBoxLayout()
    theme_row.setSpacing(0)
    light = QPushButton("Nexora Cloud")
    dark = QPushButton("Nexora Space")
    theme_choices = QButtonGroup(self)
    theme_choices.setExclusive(True)
    light.setIcon(qt_icon("Display")); dark.setIcon(qt_icon("Sleep"))
    light.setIconSize(QSize(24, 24)); dark.setIconSize(QSize(24, 24))
    for theme_index, (button, style_key, mode, accent, a, b) in enumerate((
        (light, "cloud_light", "light", "#55A7FF", "#B9E0FF", "#F7FCFF"),
        (dark, "cosmic_dark", "dark", "#8A7CFF", "#111934", "#4D3F92"),
    )):
        button.setObjectName(f"ThemeChoice_{style_key}")
        button.setMinimumHeight(42)
        button.setCheckable(True)
        button.setChecked(settings.get("ui_style", "cloud_light") == style_key)
        theme_choices.addButton(button)
        foreground = "#17243A" if mode == "light" else "#FFFFFF"
        left_r = 14 if theme_index == 0 else 0
        right_r = 14 if theme_index == 1 else 0
        button.setStyleSheet(f"QPushButton{{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {a},stop:1 {b});color:{foreground};border:none;padding:8px 16px;font-weight:700;border-top-left-radius:{left_r}px;border-bottom-left-radius:{left_r}px;border-top-right-radius:{right_r}px;border-bottom-right-radius:{right_r}px;}}QPushButton:checked{{border:none;background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 {accent},stop:1 {b});}}")
        def choose_theme(_checked=False, key=style_key, selected_mode=mode, selected_accent=accent):
            cloud = key == "cloud_light"
            store_many({
                "ui_style": key,
                "theme_mode": selected_mode,
                "accent_color": selected_accent,
                "glass_transparency": 72,
                "blur_radius": 60,
                "material_saturation": 112 if cloud else 128,
                "surface_brightness": 104 if cloud else 92,
                "wallpaper_variant": "light" if cloud else "dark",
            })
        button.clicked.connect(choose_theme)
        theme_row.addWidget(button)
    row.addLayout(theme_row)

    material = section(appearance, "Appearance", "Nexora Glass", "The material is automatic and consistent across the whole system.")
    material_note = QLabel("Strong blur, high transparency, readable text and rounded hover states are enabled by default. Extra glass sliders remain removed.")
    material_note.setWordWrap(True)
    material_note.setProperty("nexoraMuted", True)
    material.addWidget(material_note)

    row = section(appearance, "Window", "Window controls", "Choose the connected macOS or GNOME control design.")
    controls_row = QHBoxLayout()
    controls_row.setSpacing(0)
    controls_group = QButtonGroup(self)
    controls_group.setExclusive(True)
    current_controls = str(settings.get("window_controls_style", "traffic_lights"))
    for control_index, (label, style_key) in enumerate((("macOS", "traffic_lights"), ("GNOME", "gnome"))):
        button = QPushButton(label)
        button.setCheckable(True)
        button.setChecked(current_controls == style_key or (current_controls == "nexora" and style_key == "traffic_lights"))
        button.setMinimumHeight(40)
        controls_group.addButton(button)
        left_r = 14 if control_index == 0 else 0
        right_r = 14 if control_index == 1 else 0
        button.setStyleSheet(
            f"QPushButton{{background:rgba(255,255,255,34);border:none;color:inherit;padding:8px 18px;"
            f"border-top-left-radius:{left_r}px;border-bottom-left-radius:{left_r}px;"
            f"border-top-right-radius:{right_r}px;border-bottom-right-radius:{right_r}px;}}"
            f"QPushButton:hover{{background:rgba(255,255,255,58);border:none;"
            f"border-top-left-radius:{left_r}px;border-bottom-left-radius:{left_r}px;"
            f"border-top-right-radius:{right_r}px;border-bottom-right-radius:{right_r}px;}}"
            f"QPushButton:checked{{background:{rgba(settings.get('accent_color', '#3F8CFF'), 118)};border:none;"
            f"border-top-left-radius:{left_r}px;border-bottom-left-radius:{left_r}px;"
            f"border-top-right-radius:{right_r}px;border-bottom-right-radius:{right_r}px;}}"
        )
        button.clicked.connect(lambda _checked=False, value=style_key: store_many({
            "window_controls_style": value,
            "window_controls_position": "left",
            "window_controls_joined": True,
        }))
        controls_row.addWidget(button)
    row.addLayout(controls_row)
    controls_note = QLabel("Minimize, maximize and close always stay connected as one rounded control group.")
    controls_note.setWordWrap(True)
    controls_note.setProperty("nexoraMuted", True)
    row.addWidget(controls_note)

    row = section(appearance, "●", "Accent color")
    accents = QHBoxLayout()
    accents.setSpacing(0)
    for color_index, color in enumerate(("#3F8CFF", "#8B67DE", "#45C4B0", "#F2B84B", "#EE6A6A")):
        button = QPushButton(); button.setFixedSize(40,34)
        left_r = 12 if color_index == 0 else 0
        right_r = 12 if color_index == 4 else 0
        button.setStyleSheet(f"background:{color};border:none;border-top-left-radius:{left_r}px;border-bottom-left-radius:{left_r}px;border-top-right-radius:{right_r}px;border-bottom-right-radius:{right_r}px;")
        button.clicked.connect(lambda _=False, value=color: store("accent_color", value))
        accents.addWidget(button)
    accents.addStretch(); row.addLayout(accents)
    appearance.addStretch()

    desktop = page("Desktop", "Only the essential desktop and dock behavior.")
    row = section(desktop, "▦", "Dock")
    animations = QCheckBox("Use window animations"); animations.setChecked(bool(settings.get("animations",True))); animations.toggled.connect(lambda v: store("animations",v)); row.addWidget(animations)
    magnification = QCheckBox("Magnify icons on hover"); magnification.setChecked(False); magnification.setEnabled(False); row.addWidget(magnification)
    row = section(desktop, "▦", "Window tiling")
    tiling = QCheckBox("Automatically tile windows like Hyprland")
    tiling.setChecked(bool(settings.get("tiling_enabled", False)))
    tiling.setToolTip("Automatically arranges all visible windows. Minimize and maximize controls are hidden while enabled.")
    tiling.toggled.connect(lambda value: store("tiling_enabled", value))
    row.addWidget(tiling)
    tiling_hint = QLabel("New and closed windows automatically rebalance the layout.")
    tiling_hint.setProperty("nexoraMuted", True)
    row.addWidget(tiling_hint)

    row = section(desktop, "⌁", "Desktop")
    widgets = QCheckBox("Show desktop widgets"); widgets.setChecked(bool(settings.get("desktop_show_widgets",True))); widgets.toggled.connect(lambda v: store("desktop_show_widgets",v)); row.addWidget(widgets)
    row = section(desktop, "Wallpaper", "Desktop wallpaper")
    wallpaper_grid = QGridLayout()
    wallpaper_grid.setSpacing(10)
    wallpaper_choices = QButtonGroup(self)
    wallpaper_choices.setExclusive(True)
    selected_wallpaper = current_wallpaper_path().resolve()
    def choose_wallpaper(path):
        variant = "dark" if str(self.settings_data.get("theme_mode", "light")) == "dark" else "light"
        try:
            portable = str(path.relative_to(PROJECT_ROOT.parent))
        except ValueError:
            portable = str(path)
        self.desktop.set_wallpaper(path)
        store_many({"wallpaper": portable, f"wallpaper_{variant}": portable, "wallpaper_variant": variant})
    for index, path in enumerate(wallpaper_files()):
        width, height, tier = wallpaper_details(path)
        choice = QPushButton(f"{path.stem}\n{tier}  ·  {width}×{height}")
        choice.setObjectName(f"WallpaperChoice_{index}")
        choice.setIcon(QIcon(str(path)))
        choice.setIconSize(QSize(144, 81))
        choice.setMinimumHeight(108)
        choice.setCheckable(True)
        choice.setChecked(path.resolve() == selected_wallpaper)
        wallpaper_choices.addButton(choice)
        choice.setStyleSheet(
            "QPushButton{text-align:left;background:rgba(255,255,255,26);"
            "border:none;border-radius:22px;padding:9px;}"
            "QPushButton:hover{background:rgba(255,255,255,52);border:none;}"
            "QPushButton:checked{background:rgba(75,141,255,56);border:none;}"
        )
        choice.clicked.connect(lambda _checked=False, selected=path: choose_wallpaper(selected))
        wallpaper_grid.addWidget(choice, index // 2, index % 2)
    row.addLayout(wallpaper_grid)
    desktop.addStretch()

    dock = page("Dock & Taskbar", "Position, size and behavior of the application dock.")
    row = section(dock, "Dock", "Dock & Taskbar")
    position_row = QHBoxLayout()
    position_row.setSpacing(0)
    position_choices = QButtonGroup(self)
    position_choices.setExclusive(True)
    for label, value, preview in (("Top", "top", "● ● ●\n────────"), ("Bottom", "bottom", "────────\n● ● ●")):
        choice = QPushButton(f"{preview}\n{label}")
        choice.setCheckable(True)
        choice.setChecked(settings.get("dock_position", "bottom") == value)
        position_choices.addButton(choice)
        choice.setMinimumHeight(82)
        choice.setStyleSheet(
            "QPushButton{background:rgba(255,255,255,38);border:none;"
            "border-radius:22px;padding:9px;font-weight:700;}"
            "QPushButton:checked{background:rgba(75,141,255,82);border:none;}"
        )
        choice.clicked.connect(lambda _checked=False, selected=value: store("dock_position", selected))
        position_row.addWidget(choice)
    autohide = QCheckBox("Automatically hide the dock")
    autohide.setChecked(bool(settings.get("dock_autohide", False)))
    autohide.toggled.connect(lambda value: store("dock_autohide", value))
    row.addLayout(position_row); row.addWidget(autohide)
    dock.addStretch()

    sound = page("Sound", "Volume and system sound feedback.")
    row = section(sound, "♪", "Output")
    volume = QSlider(Qt.Horizontal); volume.setRange(0,100); volume.setValue(int(settings.get("volume",65))); row.addWidget(QLabel("Volume")); row.addWidget(volume)
    volume.sliderReleased.connect(lambda: store("volume", volume.value()))
    effects = QCheckBox("System sounds"); effects.setChecked(bool(settings.get("sound_effects",False))); effects.toggled.connect(lambda v: store("sound_effects",v)); row.addWidget(effects)
    sound.addStretch()

    apps_page = page("Apps", "Install or remove optional daily-use applications safely.")
    apps_section = section(apps_page, "Apps", "Optional applications", "Uninstalling hides the application and closes its Nexora windows. Its personal files remain untouched.")
    from System.apps.catalog import OPTIONAL_DAILY_FILES
    disabled_apps = set(str(x) for x in settings.get("disabled_apps", []))
    app_buttons = {}
    def set_app_enabled(stem, enabled):
        disabled = set(str(x) for x in self.settings_data.get("disabled_apps", []))
        if enabled: disabled.discard(stem)
        else: disabled.add(stem)
        self.settings_data["disabled_apps"] = sorted(disabled); save_settings(validate_settings(self.settings_data))
        if not enabled:
            for path, windows in list(getattr(self.desktop, "window_groups", {}).items()):
                if Path(path).stem == stem:
                    for window in list(windows): window.close()
        self.desktop.reload_app_catalog(); self.desktop.refresh_taskbar(); self.desktop.menu.refresh(); refresh_app_buttons()
    def refresh_app_buttons():
        disabled=set(str(x) for x in load_settings().get("disabled_apps", []))
        for stem,button in app_buttons.items(): button.setText("Install" if stem in disabled else "Uninstall")
    for filename in OPTIONAL_DAILY_FILES:
        stem=Path(filename).stem; line=QHBoxLayout(); label=QLabel(stem.replace("_"," ")); button=QPushButton(); button.setMinimumHeight(34); button.setStyleSheet(oneui_button_css(APP_COLORS.get(stem.replace("_"," "), "#7C91C7"), radius=11)); button.clicked.connect(lambda _=False,s=stem: set_app_enabled(s, s in set(str(x) for x in load_settings().get("disabled_apps", []))))
        app_buttons[stem]=button; line.addWidget(label,1); line.addWidget(button); apps_section.addLayout(line)
    refresh_app_buttons(); apps_page.addStretch()

    users = page("Users", "Account and sign-in behavior.")
    row = section(users, "◎", "Current account", "Manage password and avatar from the Login screen or Welcome app.")
    open_welcome = QPushButton("Open Welcome")
    open_welcome.setIcon(qt_icon("Welcome"))
    open_welcome.setIconSize(QSize(24, 24))
    open_welcome.setStyleSheet(oneui_button_css("#8B67DE", radius=15))
    open_welcome.clicked.connect(lambda: self.desktop.open_app(next((p for p in self.desktop.app_paths if app_name(p)=="Welcome"), self.path)))
    row.addWidget(open_welcome)
    users.addStretch()

    privacy = page("Privacy", "Local-only privacy controls.")
    row = section(privacy, "◆", "Local data")
    for key,label,default in (("diagnostics","Diagnostic data",False),("usage_history","Application usage history",False),("search_history","Search history",False),("session_restore","Restore previous session",True)):
        check=QCheckBox(label); check.setChecked(bool(settings.get(key,default))); check.toggled.connect(lambda v,k=key: store(k,v)); row.addWidget(check)
    privacy.addStretch()

    accessibility = page("Accessibility", "Readable, keyboard-friendly and motion-aware interface options.")
    row = section(accessibility, "Accessibility", "Accessibility")
    for key, label in (
        ("high_contrast", "High contrast"), ("large_text", "Large text"),
        ("reduce_motion", "Reduce motion"), ("underline_buttons", "Underline buttons"),
    ):
        option = QCheckBox(label)
        option.setChecked(bool(settings.get(key, False)))
        option.toggled.connect(lambda value, setting=key: store(setting, value))
        row.addWidget(option)
    accessibility.addStretch()

    system = page("System", "Nexora version and host information.")
    row = section(system, "⚙", "Nexora 26 Beta 1")
    info = QLabel(f"Python {platform.python_version()}\nQt {qVersion()}\n{platform.system()} {platform.release()}\n{platform.machine()}")
    info.setWordWrap(True); info.setProperty("nexoraMuted", True); info.setStyleSheet("background:transparent;border:none;"); row.addWidget(info)
    system.addStretch()

    actions = QHBoxLayout()
    actions.setSpacing(0)
    def commit(values):
        validated = validate_settings(values)
        save_settings(validated)
        self.settings_data = dict(validated)
        self.desktop.apply_settings(validated)
    def export_settings(path):
        Path(path).write_text(json.dumps(validate_settings(self.settings_data), indent=2, ensure_ascii=False), encoding="utf-8")
        self.desktop.notch.notify("Settings exported")
    def import_settings(path):
        try:
            imported = json.loads(Path(path).read_text(encoding="utf-8"))
            commit(imported)
            self.desktop.notch.notify("Settings imported")
        except (OSError, ValueError, TypeError) as exc:
            self.desktop.show_system_message("Settings", f"Import failed: {exc}")
    action_specs = (
        ("Revert", lambda: commit(initial_settings)),
        ("Save preset", lambda: export_settings(DATA_DIR / "settings-preset.json")),
        ("Export", lambda: self.desktop.show_file_picker("Export settings", "save", export_settings, default_name="nexora-settings.json", extensions={".json"})),
        ("Import", lambda: self.desktop.show_file_picker("Import settings", "open", import_settings, extensions={".json"})),
        ("Defaults", lambda: commit(DEFAULTS)),
        ("Apply", lambda: commit(self.settings_data)),
    )
    for index, (label, callback) in enumerate(action_specs):
        button = QPushButton(label)
        button.setFixedHeight(34)
        left = 12 if index == 0 else 0
        right = 12 if index == len(action_specs) - 1 else 0
        button.setStyleSheet(
            f"QPushButton{{background:{rgba('#8AB4F8', 58)};color:{TEXT};border:none;outline:none;"
            f"border-top-left-radius:{left}px;border-bottom-left-radius:{left}px;"
            f"border-top-right-radius:{right}px;border-bottom-right-radius:{right}px;"
            "padding:5px 12px;margin:0;font-weight:650;}"
            f"QPushButton:hover{{background:{rgba('#8AB4F8', 86)};}}"
            f"QPushButton:pressed{{background:{rgba('#8AB4F8', 112)};padding:5px 12px;}}"
        )
        button.clicked.connect(callback)
        actions.addWidget(button)
    self.content_layout.addLayout(actions)

    def switch(name):
        target = page_map[name][0]
        if pages.currentWidget() is not target:
            pages.setCurrentWidget(target)
        self.set_active_sidebar(name)

    for index,name in enumerate(page_names):
        button=self.sidebar_buttons.get(name)
        if button is not None:
            button.clicked.connect(lambda _=False,n=name: switch(n))
    pages.setCurrentWidget(page_map["Appearance"][0])
    self.set_active_sidebar("Appearance")
