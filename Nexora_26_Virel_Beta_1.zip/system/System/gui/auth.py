"""Compatibility aliases for the single active Nexora authentication UI.

The production implementation lives in :mod:`System.runtime.auth_ui`. Keeping only
aliases here prevents old launchers from instantiating a second login/OOBE
implementation with native full-screen windows.
"""
from System.runtime.auth_ui import LoginScreen as Login
from System.runtime.auth_ui import SetupScreen as OOBE

__all__ = ["Login", "OOBE"]
