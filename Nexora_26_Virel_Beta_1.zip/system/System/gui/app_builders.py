from .shared import *
from .components import VisualChoice, InternalFilePicker, SystemOverlay
from .search import NexoraSearchWorker
from .pro_app_builders import ProfessionalApplicationBuildersMixin
from .files_builder import FilesApplicationMixin
from .browser_builder import BrowserApplicationMixin
from .daily_apps import DailyOfficeAppsMixin
import ssl
class ApplicationBuildersMixin(DailyOfficeAppsMixin, BrowserApplicationMixin, FilesApplicationMixin, ProfessionalApplicationBuildersMixin):
    def _populate(self):
        name = self.title
        if self.toolbar_enabled:
            for item in ("File", "Edit", "View"):
                self.add_toolbar(item, lambda _=False, key=item: self.show_app_menu(key))
        # Populate only the declarative navigation model owned by this app.
        # NavigationModel prevents the historical Files-sidebar leakage bug.
        if self.sidebar_enabled:
            model = self.navigation_model
            lab = QLabel(model.title)
            lab.setStyleSheet(f"color:{MUTED};padding:4px 8px;")
            lab.setFont(font(8, True))
            layout = getattr(self, "sidebar_nav_layout", self.sidebar_layout)
            layout.insertWidget(max(0, layout.count() - 1), lab)
            for i, item in enumerate(model.items):
                self.add_sidebar(item.label, callback=lambda _=False, key=item.label: self.handle_sidebar_action(key), selected=i == 0)
        if name == "Calculator":
            self.build_calculator()
        elif name == "Notepad":
            self.build_notepad()
        elif name == "Files":
            self.build_files()
        elif name == "Settings":
            self.build_settings()
        elif name == "Terminal": self.build_terminal()
        elif name == "Calendar": self.build_calendar()
        elif name == "Clock": self.build_clock()
        elif name == "Gallery": self.build_gallery()
        elif name == "Maps": self.build_maps()
        elif name == "Paint": self.build_paint()
        elif name == "Screenshot": self.build_screenshots()
        elif name == "Weather": self.build_weather()
        elif name in {"Task Manager", "Task Manager Pro"}: self.build_task_manager()
        elif name == "AboutPC": self.build_about()
        elif name == "BackUp": self.build_backup()
        elif name == "Widgets": self.build_widgets()
        elif name == "Welcome": self.build_welcome()
        elif name == "Browser": self.build_browser()
        elif name == "Documents": self.build_documents()
        elif name == "Sheets": self.build_sheets()
        elif name == "Presentations": self.build_presentations()
        elif self.build_professional_application(name): pass
        else: self.build_welcome()
    def show_app_menu(self, section):
        """Show a Nexora-owned menu inside the application window.

        This deliberately avoids QMenu/menuBar so macOS and Windows can never
        replace the UI with a native system menu.
        """
        previous = getattr(self, "_nexora_menu_panel", None)
        if previous is not None:
            previous.hide()
            previous.deleteLater()

        actions = {
            "File": [("New", "Create a new item"), ("Open…", "Open a local file"), ("Save", "Save current work"), ("Export…", "Export to another format")],
            "Edit": [("Undo", "Undo the last change"), ("Redo", "Restore the undone change"), ("Cut", "Move selected content"), ("Copy", "Copy selected content"), ("Paste", "Paste from clipboard")],
            "View": [("Focus mode", "Hide distractions"), ("Zoom in", "Increase content size"), ("Zoom out", "Decrease content size"), ("Reset view", "Restore the default view")],
        }
        panel = QFrame(self)
        panel.setObjectName("NexoraInWindowMenu")
        panel.setAttribute(Qt.WA_StyledBackground, True)
        panel.setStyleSheet(
            f"QFrame#NexoraInWindowMenu{{background:rgba(226,236,247,238);border:none;border-radius:20px;}}"
            f"QLabel{{color:{TEXT};background:transparent;padding:2px 8px;}}"
            f"QPushButton{{text-align:left;background:transparent;color:{TEXT};border:none;border-radius:14px;padding:8px 12px;min-height:24px;}}"
            f"QPushButton:hover{{background:{rgba(self.accent,92)};border:none;border-radius:14px;}}"
            f"QPushButton:pressed{{background:{rgba(self.accent,132)};border:none;border-radius:14px;}}"
        )
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(2)
        heading = QLabel(section)
        heading.setFont(font(9, True))
        layout.addWidget(heading)
        for label, tip in actions.get(section, []):
            button = QPushButton(label)
            button.setToolTip(tip)
            button.setAccessibleDescription(tip)
            button.clicked.connect(lambda _=False, name=label, host=panel: (self.execute_app_action(name), host.hide()))
            layout.addWidget(button)
        panel.adjustSize()
        panel.setFixedWidth(max(210, panel.sizeHint().width()))
        sender = self.sender()
        if isinstance(sender, QPushButton):
            point = sender.mapTo(self, QPoint(0, sender.height() + 5))
        else:
            point = QPoint(16, 54)
        x = max(8, min(point.x(), self.width() - panel.width() - 8))
        y = max(8, min(point.y(), self.height() - panel.height() - 8))
        panel.move(x, y)
        panel.raise_()
        panel.show()
        self._nexora_menu_panel = panel

    def execute_app_action(self, action):
        """Execute common menu actions against the active Nexora control."""
        focus = QApplication.focusWidget()
        if action in {"Undo", "Redo", "Cut", "Copy", "Paste"}:
            method = getattr(focus, action.lower(), None)
            if callable(method):
                method()
                return
        if action == "New":
            for candidate in (getattr(self, "editor", None), focus):
                clear = getattr(candidate, "clear", None)
                if callable(clear):
                    clear(); self.desktop.notch.notify(f"{self.title}: new item"); return
        if action == "Open…" and hasattr(self, "notepad_open") and self.title == "Notepad":
            self.notepad_open(); return
        if action == "Save" and hasattr(self, "notepad_save") and self.title == "Notepad":
            self.notepad_save(); return
        if action == "Focus mode":
            sidebar = getattr(self, "sidebar", None)
            toolbar = getattr(self, "toolbar", None)
            for widget in (sidebar, toolbar):
                if widget is not None: widget.setVisible(not widget.isVisible())
            return
        if action in {"Zoom in", "Zoom out", "Reset view"}:
            delta = 1 if action == "Zoom in" else (-1 if action == "Zoom out" else 0)
            widgets = []
            for widget_type in (QTextEdit, QTextBrowser, QPlainTextEdit):
                widgets.extend(self.findChildren(widget_type))
            for widget in widgets:
                if action == "Reset view":
                    widget.setFont(font(10))
                elif delta > 0: widget.zoomIn(1)
                else: widget.zoomOut(1)
            return
        self.desktop.notch.notify(f"{self.title}: {action}")

    def handle_sidebar_action(self, name):
        self.set_active_sidebar(name)
        # Sidebar navigation is the primary section switcher. Keep it functional
        # and avoid duplicating the same tabs in the title bar.
        handlers = {
            "Add slide": lambda: getattr(self, "presentation_add_slide", lambda: None)(),
            "Delete slide": lambda: getattr(self, "presentation_delete_slide", lambda: None)(),
            "Save": lambda: getattr(self, "presentation_save", lambda: None)(),
            "Recalculate": lambda: getattr(self, "sheets_recalculate", lambda: None)(),
            "Export CSV": lambda: getattr(self, "sheets_export", lambda: None)(),
        }
        handler = handlers.get(name)
        if handler: handler()
        else: self.desktop.notch.notify(f"{self.title}: {name}")

    def build_calculator(self):
        display = QLineEdit(); display.setAlignment(Qt.AlignRight); display.setFont(font(22)); display.setFixedHeight(68)
        display.setStyleSheet(f"background:{rgba(self.accent, 18)};border:none;border-radius:22px;padding:12px;color:{TEXT};")
        self.content_layout.addWidget(display)
        gridw = QWidget(); gridw.setAttribute(Qt.WA_TranslucentBackground, True); gridw.setStyleSheet("background:transparent;border:none;"); grid = QGridLayout(gridw); grid.setSpacing(7)
        keys = ["C","(",")","/","7","8","9","*","4","5","6","-","1","2","3","+","0",".","%","="]
        def press(k):
            if k == "C": display.clear()
            elif k == "=":
                try:
                    display.setText(str(evaluate_calculation(display.text())))
                except CalculatorError as exc:
                    display.setText("Error")
                    display.setToolTip(str(exc))
            else: display.insert(k)
        for i,k in enumerate(keys):
            b=QPushButton(k); b.setFont(font(13, True)); b.setMinimumHeight(49)
            palette = ["#8AB4F8", "#A7D8A1", "#FFD18A", "#F4A7B9", "#B9A7E8"]
            if k == "=":
                color = self.accent
            elif k in {"+", "-", "*", "/", "%"}:
                color = "#8AB4F8"
            elif k in {"C", "(", ")"}:
                color = "#F4A7B9"
            else:
                color = palette[(i // 4) % len(palette)]
            b.setStyleSheet(oneui_button_css(color, radius=15))
            b.clicked.connect(lambda _=False, key=k: press(key)); grid.addWidget(b, i//4, i%4)
        self.content_layout.addWidget(gridw, 1)
    def build_notepad(self):
        if self.toolbar_enabled:
            self.add_toolbar("Open", self.notepad_open); self.add_toolbar("Save", self.notepad_save)
        self.editor = QTextEdit(); self.editor.setFont(font(11)); self.editor.setStyleSheet(glass_input_css(self.accent)); self.editor.setMinimumHeight(460); self.editor.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.content_layout.addWidget(self.editor, 1)
    def notepad_open(self):
        self.desktop.show_file_picker("Open text file", "open", lambda p: self._load_note(p), extensions={".txt", ".md"})
    def _load_note(self, p):
        try:self.editor.setPlainText(Path(p).read_text(encoding="utf-8"))
        except OSError as exc:self.desktop.show_system_message("Notepad", str(exc))
    def notepad_save(self):
        self.desktop.show_file_picker("Save note", "save", lambda p: self._save_note(p), default_name="note.txt", extensions={".txt"})
    def _save_note(self, p):
        try:Path(p).write_text(self.editor.toPlainText(),encoding="utf-8");self.desktop.notch.notify("Note saved")
        except OSError as exc:self.desktop.show_system_message("Notepad", str(exc))
    def build_settings(self):
        from .settings_builder import build_settings_ui
        build_settings_ui(self)
    # Browser implementation lives in browser_builder.py.

    def build_terminal(self):
        from .terminal_builder import build_terminal_ui
        build_terminal_ui(self)

    def _card(self, color=None):
        c=QFrame(); c.setStyleSheet(f"background:{rgba('#FFFFFF', 32)};border:none;border-radius:22px;")
        c.setLayout(QVBoxLayout()); c.layout().setContentsMargins(20,18,20,18); c.layout().setSpacing(8); return c

    def build_calendar(self):
        self.heading("Calendar", "Plan events and dates")
        cal=QCalendarWidget(); cal.setGridVisible(True); cal.setStyleSheet(f"QCalendarWidget QWidget{{background:rgba(255,255,255,12);color:{TEXT};}} QCalendarWidget QToolButton{{background:{rgba(self.accent,80)};color:{TEXT};border-radius:22px;padding:6px;}} QCalendarWidget QAbstractItemView{{selection-background-color:{self.accent};selection-color:white;}}"); self.content_layout.addWidget(cal,1)

    def build_clock(self):
        self.heading("Clock", "Local time, timer and stopwatch")
        clock=QLabel(); clock.setAlignment(Qt.AlignCenter); clock.setFont(font(42,True)); clock.setStyleSheet(f"background:{rgba(self.accent,26)};border:none;border-radius:24px;padding:24px;")
        self.content_layout.addWidget(clock)
        elapsed=[0]; running=[False]
        status=QLabel("00:00.0"); status.setAlignment(Qt.AlignCenter); status.setFont(font(25,True)); self.content_layout.addWidget(status)
        row=QHBoxLayout(); start=QPushButton("Start / Pause"); reset=QPushButton("Reset"); start.setStyleSheet(oneui_button_css("#A7D8A1")); reset.setStyleSheet(oneui_button_css("#F4A7B9")); row.addWidget(start);row.addWidget(reset); self.content_layout.addLayout(row)
        timer=QTimer(self); timer.setInterval(100)
        def formatted_elapsed():
            return f"{elapsed[0]//600:02d}:{(elapsed[0]//10)%60:02d}.{elapsed[0]%10}"
        def tick():
            clock.setText(datetime.now().strftime("%H:%M:%S\n%A, %d %B"))
            if running[0]: elapsed[0]+=1
            value=formatted_elapsed(); status.setText(value)
            if running[0]: self.desktop.notch.set_activity("stopwatch", "Stopwatch", value, persistent=True)
            else: self.desktop.notch.clear_activity("stopwatch")
        def toggle_stopwatch():
            running[0]=not running[0]; tick()
        def reset_stopwatch():
            elapsed[0]=0; running[0]=False; self.desktop.notch.clear_activity("stopwatch"); tick()
        timer.timeout.connect(tick); timer.start(); tick(); start.clicked.connect(toggle_stopwatch); reset.clicked.connect(reset_stopwatch)

        countdown=[0]; countdown_running=[False]
        countdown_row=QHBoxLayout(); minutes=QSpinBox(); minutes.setRange(1,180); minutes.setValue(5); minutes.setSuffix(" min")
        timer_start=QPushButton("Start timer"); timer_cancel=QPushButton("Cancel timer")
        timer_start.setStyleSheet(oneui_button_css("#8AB4F8")); timer_cancel.setStyleSheet(oneui_button_css("#B9A7E8"))
        countdown_row.addWidget(minutes); countdown_row.addWidget(timer_start); countdown_row.addWidget(timer_cancel); self.content_layout.addLayout(countdown_row)
        countdown_tick=QTimer(self); countdown_tick.setInterval(1000)
        def countdown_text():
            return f"{countdown[0]//60:02d}:{countdown[0]%60:02d}"
        def update_countdown():
            if not countdown_running[0]: return
            countdown[0]=max(0,countdown[0]-1)
            self.desktop.notch.set_activity("timer","Timer",countdown_text(),persistent=True)
            if countdown[0]<=0:
                countdown_running[0]=False; countdown_tick.stop(); self.desktop.notch.notify("Timer finished",3000); self.desktop.notch.clear_activity("timer")
        def start_countdown():
            countdown[0]=int(minutes.value())*60; countdown_running[0]=True
            self.desktop.notch.set_activity("timer","Timer",countdown_text(),persistent=True); countdown_tick.start()
        def cancel_countdown():
            countdown_running[0]=False; countdown_tick.stop(); countdown[0]=0; self.desktop.notch.clear_activity("timer")
        countdown_tick.timeout.connect(update_countdown); timer_start.clicked.connect(start_countdown); timer_cancel.clicked.connect(cancel_countdown)

    def build_gallery(self):
        self.heading("Gallery","Images and videos from Nexora Home")
        splitter=QHBoxLayout(); media=QListWidget(); media.setMinimumWidth(245); preview=QLabel("Select a photo or video");preview.setAlignment(Qt.AlignCenter);preview.setWordWrap(True);preview.setStyleSheet(f"background:rgba(255,255,255,14);border:none;border-radius:24px;")
        splitter.addWidget(media);splitter.addWidget(preview,1);self.content_layout.addLayout(splitter,1)
        roots=[NEXORA_HOME/'Images',NEXORA_HOME/'Videos']; exts={'.png','.jpg','.jpeg','.webp','.bmp','.gif','.mp4','.mov','.mkv','.avi','.webm'}
        files=[]
        for root in roots:
            root.mkdir(parents=True,exist_ok=True)
            files.extend([x for x in root.rglob('*') if x.is_file() and x.suffix.lower() in exts])
        for path in sorted(files,key=lambda x:x.name.lower()):
            item=QListWidgetItem(("▶ " if path.suffix.lower() in {'.mp4','.mov','.mkv','.avi','.webm'} else "▧ ")+path.name);item.setData(Qt.UserRole,str(path));media.addItem(item)
        def show_item(item):
            path=Path(item.data(Qt.UserRole))
            if path.suffix.lower() in {'.mp4','.mov','.mkv','.avi','.webm'}:
                preview.setPixmap(QPixmap());preview.setText(f"Video\n{path.name}\n\nDouble-click to open in the system player")
            else:
                pm=QPixmap(str(path));preview.setPixmap(pm.scaled(max(200,preview.width()-20),max(160,preview.height()-20),Qt.KeepAspectRatio,Qt.SmoothTransformation));preview.setText("")
        media.currentItemChanged.connect(lambda current,_: current and show_item(current))
        from PySide6.QtGui import QDesktopServices
        media.itemDoubleClicked.connect(lambda item:QDesktopServices.openUrl(QUrl.fromLocalFile(item.data(Qt.UserRole))))

    def build_maps(self):
        self.heading("Maps","Search places safely with OpenStreetMap")
        search=QLineEdit();search.setPlaceholderText("City, address or place"); self.content_layout.addWidget(search)
        result=QLabel("Search for a place. The map opens in your browser to avoid Qt WebEngine crashes.");result.setWordWrap(True);result.setAlignment(Qt.AlignCenter);result.setStyleSheet(f"background:{rgba('#44C7A8',30)};border:none;border-radius:22px;padding:24px;");self.content_layout.addWidget(result,1)
        row=QHBoxLayout(); find=QPushButton("Find place");open_map=QPushButton("Open map");find.setStyleSheet(oneui_button_css("#89D4CF"));open_map.setStyleSheet(oneui_button_css("#8AB4F8"));open_map.setEnabled(False);row.addWidget(find);row.addWidget(open_map);self.content_layout.addLayout(row)
        state={"url":"https://www.openstreetmap.org"}
        def lookup():
            query=search.text().strip()
            if not query:return
            find.setEnabled(False);result.setText("Searching…");open_map.setEnabled(False)
            def request_place():
                req=urllib.request.Request("https://nominatim.openstreetmap.org/search?"+urllib.parse.urlencode({"q":query,"format":"jsonv2","limit":1}),headers={"User-Agent":f"NexoraDesktop/{NEXORA_VERSION} (local desktop map search)"})
                # Python.org builds on macOS can miss the Keychain CA bridge. Use a
                # verified CA bundle when available; never disable TLS verification.
                context = None
                try:
                    import certifi
                    context = ssl.create_default_context(cafile=certifi.where())
                except Exception:
                    for ca_file in ("/etc/ssl/cert.pem", "/private/etc/ssl/cert.pem"):
                        if Path(ca_file).is_file():
                            context = ssl.create_default_context(cafile=ca_file)
                            break
                if context is None:
                    context = ssl.create_default_context()
                with urllib.request.urlopen(req, timeout=10, context=context) as response:
                    data=json.load(response)
                if not data:raise ValueError("No results")
                return data[0]
            def found(item):
                lat=float(item['lat']);lon=float(item['lon']);state['url']=f"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}#map=15/{lat}/{lon}";result.setText(f"{item.get('display_name',query)}\n\nLatitude {lat:.5f}   Longitude {lon:.5f}");open_map.setEnabled(True)
            submit(request_place,on_success=found,on_error=lambda message:result.setText(f"Map search unavailable\n{message}"),on_finished=lambda:find.setEnabled(True))
        find.clicked.connect(lookup);search.returnPressed.connect(lookup);open_map.clicked.connect(lambda:webbrowser.open(state['url']))

    def build_paint(self):
        self.heading("Paint", "Draw with the pointer")
        class Canvas(QWidget):
            def __init__(slf): super().__init__(); slf.image=QPixmap(900,500); slf.image.fill(QColor(255,255,255,30)); slf.last=None; slf.color=QColor(self.accent); slf.setMinimumSize(500,300)
            def paintEvent(slf,e): QPainter(slf).drawPixmap(slf.rect(),slf.image)
            def mousePressEvent(slf,e): slf.last=e.position().toPoint()
            def mouseMoveEvent(slf,e):
                if slf.last is None:return
                painter=QPainter(slf.image); pen=QColor(slf.color); painter.setPen(pen); painter.drawLine(slf.last,e.position().toPoint()); painter.end(); slf.last=e.position().toPoint(); slf.update()
            def mouseReleaseEvent(slf,e): slf.last=None
        canvas=Canvas(); canvas.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding); self.content_layout.addWidget(canvas,1)
        color=QPushButton("Color"); clear=QPushButton("Clear"); save=QPushButton("Save")
        row=self._connected_bar([("Color",lambda: setattr(canvas,'color',QColorDialog.getColor(canvas.color,self))),("Clear",lambda:(canvas.image.fill(QColor(255,255,255,30)),canvas.update())),("Save",lambda:None)],"#E86AA5")
        self.content_layout.addLayout(row)
        # the last segmented button is the Save action
        save_button=row.itemAt(row.count()-1).widget()

        def save_img():
            d=NEXORA_HOME/'Images';d.mkdir(parents=True,exist_ok=True);self.desktop.show_file_picker('Save painting','save',lambda p:canvas.image.save(str(p)),default_name='painting.png',extensions={'.png'})
        save_button.clicked.connect(save_img)

    def build_screenshots(self):
        self.heading("Screenshot", "Capture the Nexora desktop")
        preview=QLabel("No screenshot yet"); preview.setAlignment(Qt.AlignCenter); preview.setMinimumHeight(320); preview.setStyleSheet(f"background:rgba(255,255,255,12);border:none;border-radius:24px;"); self.content_layout.addWidget(preview,1)
        b=QPushButton("Capture desktop"); b.setStyleSheet(oneui_button_css("#8AB4F8")); self.content_layout.addWidget(b)
        def capture():
            pm=self.desktop.grab(); preview.setPixmap(pm.scaled(preview.size(),Qt.KeepAspectRatio,Qt.SmoothTransformation)); d=NEXORA_HOME/'Images';d.mkdir(parents=True,exist_ok=True); pm.save(str(d/f"Screenshot_{datetime.now():%Y%m%d_%H%M%S}.png"))
        b.clicked.connect(capture)

    def build_weather(self):
        self.heading("Weather","Reliable weather through Open‑Meteo — no API key")
        city=QLineEdit(str(load_settings().get("weather_city","Warsaw")));city.setPlaceholderText("City or town");self.content_layout.addWidget(city)
        result=QLabel("Enter a city and press Refresh");result.setAlignment(Qt.AlignCenter);result.setFont(font(17,True));result.setWordWrap(True);result.setStyleSheet(f"background:{rgba('#48BFE3',30)};border:none;border-radius:24px;padding:28px;");self.content_layout.addWidget(result,1)
        b=QPushButton("Refresh");b.setStyleSheet(oneui_button_css("#89D4CF"));self.content_layout.addWidget(b)
        codes={0:"Clear",1:"Mostly clear",2:"Partly cloudy",3:"Cloudy",45:"Fog",48:"Fog",51:"Drizzle",53:"Drizzle",55:"Drizzle",61:"Rain",63:"Rain",65:"Heavy rain",71:"Snow",73:"Snow",75:"Heavy snow",80:"Showers",81:"Showers",82:"Heavy showers",95:"Thunderstorm"}
        def load_weather(name):
            query = urllib.parse.urlencode({'name': name, 'count': 1, 'language': 'en', 'format': 'json'})
            request = urllib.request.Request(
                'https://geocoding-api.open-meteo.com/v1/search?' + query,
                headers={'User-Agent': 'Nexora/26.0'},
            )
            with urllib.request.urlopen(request, timeout=12) as response:
                geo = json.loads(response.read().decode('utf-8'))
            items = geo.get('results') or []
            if not items:
                raise ValueError('City was not found.')
            item = items[0]
            params = urllib.parse.urlencode({
                'latitude': item['latitude'],
                'longitude': item['longitude'],
                'current': 'temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,weather_code',
                'daily': 'temperature_2m_max,temperature_2m_min',
                'timezone': 'auto',
                'forecast_days': 1,
            })
            request = urllib.request.Request(
                'https://api.open-meteo.com/v1/forecast?' + params,
                headers={'User-Agent': 'Nexora/26.0'},
            )
            with urllib.request.urlopen(request, timeout=12) as response:
                data = json.loads(response.read().decode('utf-8'))
            return {'place': item, 'data': data, 'query': name}

        self.weather_task = None

        def fetch():
            if not all(qt_object_is_valid(widget) for widget in (self, city, result, b)):
                return
            name = city.text().strip()
            if not name:
                result.setText('Enter a city name.')
                return
            b.setEnabled(False)
            result.setText('Loading weather…')

            def ok(payload):
                if not all(qt_object_is_valid(widget) for widget in (self, result, b)):
                    return
                b.setEnabled(True)
                item = payload['place']
                data = payload['data']
                cur = data.get('current', {})
                daily = data.get('daily', {})
                code = int(cur.get('weather_code', -1))
                lo = (daily.get('temperature_2m_min') or ['—'])[0]
                hi = (daily.get('temperature_2m_max') or ['—'])[0]
                text = "\n".join([
                    str(item.get('name', payload['query'])),
                    str(codes.get(code, 'Current conditions')),
                    f"{cur.get('temperature_2m','—')} °C · feels {cur.get('apparent_temperature','—')} °C",
                    f"Humidity {cur.get('relative_humidity_2m','—')}% · wind {cur.get('wind_speed_10m','—')} km/h",
                    f"Today {lo}–{hi} °C",
                ])
                result.setText(text)

            def fail(message):
                if qt_object_is_valid(b):
                    b.setEnabled(True)
                if qt_object_is_valid(result):
                    result.setText('Weather unavailable\n' + message)

            self.weather_task = submit(load_weather, name, on_success=ok, on_error=fail)

        b.clicked.connect(fetch)
        city.returnPressed.connect(fetch)
        # Network access starts only after explicit user input. This avoids
        # background DNS/HTTP work when Weather is merely restored or tested.

    def build_task_manager(self):
        from .task_manager_builder import build_task_manager_ui
        build_task_manager_ui(self)


def build_about(self):
    import platform
    try:
        import psutil
        memory=f"{psutil.virtual_memory().total/(1024**3):.1f} GB"
        disk=psutil.disk_usage(str(Path.home()))
        storage=f"{disk.used/(1024**3):.1f} GB used of {disk.total/(1024**3):.1f} GB"
        cpu=platform.processor() or getattr(psutil,'cpu_freq',lambda:None)() or "Unknown"
    except Exception:
        memory,storage,cpu="Unavailable","Unavailable",platform.processor() or "Unknown"
    self.heading("About PC", "Device and Nexora information")
    scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
    host=QWidget(); outer=QVBoxLayout(host); outer.setContentsMargins(2,2,8,8); outer.setSpacing(10)
    hero=QFrame(); hero.setObjectName("AboutHero"); hero.setStyleSheet(f"QFrame#AboutHero{{background:{rgba(self.accent,38)};border:none;border-radius:16px;}}")
    hl=QVBoxLayout(hero); hl.setContentsMargins(20,18,20,18)
    name=QLabel(DISPLAY_NAME); name.setFont(font(25,True)); desc=QLabel(f"{CODENAME} · Version {NEXORA_VERSION}"); desc.setStyleSheet(f"color:{MUTED};")
    hl.addWidget(name); hl.addWidget(desc); outer.addWidget(hero)
    groups=(("Device",(("Processor",str(cpu)),("Architecture",platform.machine() or "Unknown"),("Memory",memory),("Storage",storage))),
            ("Software",(("Host system",platform.platform()),("Python",platform.python_version()),("Qt",qVersion()),("PySide6",PYSIDE_VERSION))),
            ("Nexora",(("Home",str(NEXORA_HOME)),("Project",str(PROJECT_ROOT)),("Codename",CODENAME))))
    for group,items in groups:
        card=QFrame(); card.setObjectName("AboutCard"); card.setStyleSheet("QFrame#AboutCard{background:rgba(255,255,255,22);border:none;border-radius:14px;}")
        vl=QVBoxLayout(card); vl.setContentsMargins(16,14,16,14); vl.setSpacing(0)
        label=QLabel(group); label.setFont(font(13,True)); vl.addWidget(label); vl.addSpacing(8)
        for i,(key,value) in enumerate(items):
            row=QWidget(); rl=QHBoxLayout(row); rl.setContentsMargins(0,8,0,8); rl.setSpacing(18)
            kl=QLabel(key); kl.setMinimumWidth(125); kl.setStyleSheet(f"color:{MUTED};")
            val=QLabel(value); val.setWordWrap(True); val.setTextInteractionFlags(Qt.TextSelectableByMouse)
            rl.addWidget(kl); rl.addWidget(val,1); vl.addWidget(row)
            if i<len(items)-1:
                line=QFrame(); line.setFixedHeight(1); line.setStyleSheet("background:rgba(127,140,160,34);border:none;"); vl.addWidget(line)
        outer.addWidget(card)
    outer.addStretch(); scroll.setWidget(host); self.content_layout.addWidget(scroll,1)

    def build_backup(self):
        self.heading("Backup", "Create a ZIP backup of Nexora Home")
        info=QLabel("Backups include Desktop, Documents, Downloads, Images, Music and Videos.");info.setWordWrap(True);self.content_layout.addWidget(info)
        b=QPushButton("Create backup");b.setStyleSheet(oneui_button_css("#A7D8A1"));self.content_layout.addWidget(b);status=QLabel();self.content_layout.addWidget(status);self.content_layout.addStretch()
        def operation():
            out=PROJECT_ROOT/f"Nexora_Backup_{datetime.now():%Y%m%d_%H%M%S}"
            return shutil.make_archive(str(out),"zip",str(NEXORA_HOME))
        def backup():
            b.setEnabled(False); status.setText("Creating backup in the background…")
            self.backup_task=submit(operation,on_success=lambda path:status.setText(f"Saved: {path}"),on_error=lambda error:status.setText(f"Backup failed: {error}"),on_finished=lambda:b.setEnabled(True))
        b.clicked.connect(backup)

    # Store implementation lives in store_builder.py.

    def build_widgets(self):
        self.heading("Widgets", "Live, configurable desktop widgets")
        controls=QHBoxLayout();edit=QPushButton("Toggle edit mode");edit.setStyleSheet(oneui_button_css("#8AB4F8",radius=13));edit.clicked.connect(self.desktop.toggle_widget_edit_mode);controls.addWidget(edit);controls.addStretch();self.content_layout.addLayout(controls)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff);host=QWidget();grid=QGridLayout(host);grid.setSpacing(10)
        palette=("#8AB4F8","#F4A7B9","#89D4CF","#FFD18A","#A7D8A1","#B9A7E8","#F3B4E2")
        for index,spec in enumerate(self.desktop.widget_registry.all()):
            card=QPushButton(f"Add {spec.title}");card.setToolTip("Sizes: "+", ".join(size.value.title() for size in spec.sizes));card.setMinimumHeight(62);card.setStyleSheet(oneui_button_css(palette[index%len(palette)],radius=16));card.clicked.connect(lambda _=False,key=spec.key:self.desktop.add_desktop_widget(key));grid.addWidget(card,index//2,index%2)
        scroll.setWidget(host);self.content_layout.addWidget(scroll,1)

    def build_welcome(self):
        self.heading("Welcome to Nexora", "Interactive guides for the desktop, windows and everyday tools")

        topics = (
            (
                "Getting started", "Welcome", "Your first five minutes",
                ("Open Start with the N button.", "Pin favorite apps from their context menu.", "Use Ctrl/Cmd + K for the Command Palette."),
                "Open Start", lambda: self.desktop.toggle_start(),
            ),
            (
                "Windows", "Display", "Move, resize and arrange windows",
                ("Drag the integrated title area to move a window.", "Move to a workspace edge to activate Snap Assist.", "Use the green control or F11 to zoom inside Nexora."),
                "Show window tip", lambda: self.desktop.notch.notify("Drag a window to an edge to preview Snap Assist", 3200),
            ),
            (
                "Personalization", "Appearance", "Make Nexora yours",
                ("Choose Cloud Light or Cosmic Dark in Settings.", "Select wallpapers from visual preview tiles.", "Tune glass transparency, blur and accent color."),
                "Open Settings", lambda: self.desktop.open_app(next(path for path in self.desktop.app_paths if app_name(path) == "Settings")),
            ),
            (
                "Files and apps", "Files", "Keep work organized",
                ("Files starts inside your private Nexora Home.", "Use tabs, previews, search and the recoverable Trash.", "Open Show Apps to discover optional local tools."),
                "Open Files", lambda: self.desktop.open_app(next(path for path in self.desktop.app_paths if app_name(path) == "Files")),
            ),
            (
                "Shortcuts", "CommandPalette", "Work without leaving the keyboard",
                ("Ctrl/Cmd + Space opens search.", "Ctrl/Cmd + K opens the Command Palette.", "Alt/Option + Tab switches Nexora windows; Ctrl/Cmd + W closes one."),
                "Open Command Palette", lambda: self.desktop.command_palette.show_palette(),
            ),
        )

        shell = QHBoxLayout()
        shell.setSpacing(14)
        navigation = QVBoxLayout()
        navigation.setSpacing(8)
        self.welcome_topic_buttons = []
        self.welcome_stack = QStackedWidget()

        for index, (label, icon_name, title_text, steps, action_text, action) in enumerate(topics):
            topic_button = QPushButton(label)
            topic_button.setIcon(qt_icon(icon_name))
            topic_button.setIconSize(QSize(26, 26))
            topic_button.setMinimumSize(190, 48)
            topic_button.clicked.connect(lambda _checked=False, selected=index: show_topic(selected))
            navigation.addWidget(topic_button)
            self.welcome_topic_buttons.append(topic_button)

            page = QFrame()
            page.setObjectName("WelcomeTutorial")
            page.setStyleSheet(
                "QFrame#WelcomeTutorial{background:rgba(255,255,255,32);"
                "border:none;border-radius:24px;}"
            )
            page_layout = QVBoxLayout(page)
            page_layout.setContentsMargins(26, 24, 26, 24)
            page_layout.setSpacing(14)
            hero = QLabel()
            hero.setPixmap(qt_icon(icon_name).pixmap(64, 64))
            hero.setAlignment(Qt.AlignLeft)
            page_layout.addWidget(hero)
            heading = QLabel(title_text)
            heading.setFont(font(22, True))
            page_layout.addWidget(heading)
            for number, step_text in enumerate(steps, 1):
                step = QLabel(f"{number:02d}   {step_text}")
                step.setWordWrap(True)
                step.setMinimumHeight(42)
                step.setStyleSheet(
                    f"background:{rgba('#FFFFFF', 30)};border:none;"
                    f"border-radius:24px;padding:9px;color:{TEXT};"
                )
                page_layout.addWidget(step)
            page_layout.addStretch()
            action_button = QPushButton(action_text)
            action_button.setIcon(qt_icon(icon_name))
            action_button.setIconSize(QSize(24, 24))
            action_button.setMinimumHeight(44)
            action_button.setStyleSheet(oneui_button_css("#4B8DFF", radius=14))
            action_button.clicked.connect(action)
            page_layout.addWidget(action_button, 0, Qt.AlignRight)
            self.welcome_stack.addWidget(page)

        navigation.addStretch()
        shell.addLayout(navigation)
        shell.addWidget(self.welcome_stack, 1)
        self.content_layout.addLayout(shell, 1)

        footer = QHBoxLayout()
        self.welcome_progress = QLabel()
        previous = QPushButton("← Previous")
        following = QPushButton("Next →")
        for button in (previous, following):
            button.setMinimumHeight(38)
            button.setStyleSheet(oneui_button_css("#8B7BE8", radius=12))
        previous.clicked.connect(lambda: show_topic(max(0, self.welcome_stack.currentIndex() - 1)))
        following.clicked.connect(lambda: show_topic(min(self.welcome_stack.count() - 1, self.welcome_stack.currentIndex() + 1)))
        footer.addWidget(self.welcome_progress)
        footer.addStretch()
        footer.addWidget(previous)
        footer.addWidget(following)
        self.content_layout.addLayout(footer)

        def show_topic(index):
            index = max(0, min(index, self.welcome_stack.count() - 1))
            self.welcome_stack.setCurrentIndex(index)
            self.welcome_progress.setText(f"Guide {index + 1} of {self.welcome_stack.count()}")
            for position, button in enumerate(self.welcome_topic_buttons):
                active = position == index
                button.setStyleSheet(
                    oneui_button_css("#4B8DFF" if active else "#7F8DA3", radius=14)
                )
            page = self.welcome_stack.currentWidget()
            effect = QGraphicsOpacityEffect(page)
            page.setGraphicsEffect(effect)
            animation = QPropertyAnimation(effect, b"opacity", self)
            animation.setDuration(180)
            animation.setStartValue(0.35)
            animation.setEndValue(1.0)
            animation.setEasingCurve(QEasingCurve.OutCubic)
            animation.finished.connect(lambda target=page: target.setGraphicsEffect(None))
            self.welcome_transition = animation
            animation.start()

        show_topic(0)
