from .shared import *
from System.settings import validate_settings

class DesktopSettingsMixin:
    def update_clock(self):
        if not self._ui_ready:
            return
        settings=load_settings(); fmt=("%H:%M" if settings.get("clock_24h",True) else "%I:%M %p") + (":%S" if settings.get("show_seconds",False) else "") + "\n%d.%m.%Y"; self.clock.setText(datetime.now().strftime(fmt))
        if self._clock_timer is None:
            from PySide6.QtCore import QTimer
            self._clock_timer = QTimer(self)
            self._clock_timer.setInterval(1000)
            self._clock_timer.timeout.connect(self.update_clock)
            self._clock_timer.start()

    def apply_settings(self, values=None):
        values = validate_settings(values or load_settings())
        theme = self.theme_engine.resolve(values)
        # Settings must be deterministic: apply the final palette immediately.
        apply_theme_palette(values, theme=theme)
        app = QApplication.instance()
        if app:
            app.setStyleSheet(rounded_control_stylesheet(values, theme=theme))
        self.theme_engine.current = theme
        self._on_theme_complete(theme)

        # Rebuild the cached blurred wallpaper only when the blur value changes.
        blur_radius = int(values.get("blur_radius", 48))
        try:
            self.blurred_scaled = self.wallpaper_service.blurred_pixmap(blur_radius)
        except Exception:
            self.blurred_scaled = QPixmap()

        notch = getattr(self, "notch", None)
        if notch is not None and hasattr(notch, "apply_mode"):
            notch.apply_mode()
        quick_shell = getattr(self, "quick_shell", None)
        if quick_shell is not None and hasattr(quick_shell, "reload"):
            quick_shell.reload()
        self.apply_ui_style()
        self.apply_display_viewport()
        self.apply_brightness(int(values.get("brightness", 100)))
        self.apply_night_light(bool(values.get("night_light", False)), int(values.get("night_light_strength", 28)))
        self.position_shells()
        menu = getattr(self, "menu", None)
        if menu is not None and hasattr(menu, "apply_profile"):
            menu.apply_profile()
        self.refresh_taskbar()
        self.arrange_tiled_windows(values)

        # Refresh existing windows and every custom-painted glass surface.
        for group in self.window_groups.values():
            for window in tuple(group):
                if hasattr(window, "apply_theme_skin"):
                    window.apply_theme_skin(theme)
                if hasattr(window, "refresh_window_controls"):
                    window.refresh_window_controls(values)
                if not qt_object_is_valid(window):
                    continue
                window.style().unpolish(window)
                window.style().polish(window)
                for child in window.findChildren(QWidget):
                    if not qt_object_is_valid(child):
                        continue
                    child.style().unpolish(child)
                    child.style().polish(child)
                    child.update()
                window.update()
        for widget in self.findChildren(QWidget):
            if qt_object_is_valid(widget) and (hasattr(widget, "alpha") or widget.objectName() in {"Content", "Sidebar", "TitleBar"}):
                widget.update()
        for widget in self.desktop_widgets:
            widget.setVisible(bool(values.get("desktop_show_widgets", True)))
            widget.update()
        self.raise_shells()
        self.update()

    def preview_settings(self, values, changed_keys=()):
        """Preview only the systems touched by a Settings control."""
        keys = set(changed_keys)
        theme_keys = {
            "ui_style", "theme_mode", "accent_color", "glass_transparency",
            "blur_radius", "material_saturation", "surface_brightness",
            "text_contrast", "window_radius", "panel_radius", "border_width",
            "shadow_strength", "disable_transparency", "high_contrast", "large_text",
            "ui_scale", "font_family", "design_density", "animations", "reduce_motion",
            "animation_speed", "animation_easing", "performance_mode",
            "window_controls_style", "window_controls_position", "window_controls_joined", "tiling_enabled",
        }
        if keys & theme_keys:
            self.apply_settings(values)
            return
        if "desktop_show_widgets" in keys:
            for widget in self.desktop_widgets:
                widget.setVisible(bool(values.get("desktop_show_widgets", True)))
        if "tiling_enabled" in keys:
            self.apply_settings(values)
            return
        if keys & {"dock_position", "taskbar_size", "dock_autohide", "dock_magnification", "dock_recent_apps", "dock_show_trash", "predictive_dock"}:
            self.position_shells()
            self.refresh_taskbar()
            self.raise_shells()
        if keys & {"clock_24h", "show_seconds"}:
            self.update_clock()
        if keys & {"desktop_auto_arrange", "desktop_align_grid", "desktop_show_icons", "desktop_sort"}:
            if hasattr(self, "refresh_desktop_shortcuts"):
                self.refresh_desktop_shortcuts()
        if keys & {"start_layout", "start_recommended", "start_recent_apps", "start_history"}:
            menu = getattr(self, "menu", None)
            if menu is not None and hasattr(menu, "refresh"):
                menu.refresh()
        if "brightness" in keys:
            self.apply_brightness(int(values.get("brightness", 100)))
        if keys & {"night_light", "night_light_strength"}:
            self.apply_night_light(bool(values.get("night_light", False)), int(values.get("night_light_strength", 28)))
        if keys & {"wallpaper_variant", "wallpaper_light", "wallpaper_dark"}:
            self.apply_wallpaper_variant(values.get("wallpaper_variant"), persist=False)


    def arrange_tiled_windows(self, values=None):
        settings = values or load_settings()
        enabled = bool(settings.get("tiling_enabled", False))
        windows = [w for w in getattr(self, "window_z", []) if qt_object_is_valid(w) and not bool(getattr(w, "_minimized", False))]
        for window in windows:
            if hasattr(window, "set_tiling_mode"):
                window.set_tiling_mode(enabled)
        if not enabled or not windows:
            return
        area = self.app_layer.rect().adjusted(12, 12, -12, -12)
        gap = 10
        count = len(windows)
        if count == 1:
            rects = [QRect(area)]
        elif count == 2:
            left_w = (area.width() - gap) // 2
            rects = [QRect(area.x(), area.y(), left_w, area.height()), QRect(area.x()+left_w+gap, area.y(), area.width()-left_w-gap, area.height())]
        elif count == 3:
            master_w = int((area.width()-gap) * 0.58)
            stack_w = area.width()-master_w-gap
            half_h = (area.height()-gap)//2
            rects = [QRect(area.x(), area.y(), master_w, area.height()), QRect(area.x()+master_w+gap, area.y(), stack_w, half_h), QRect(area.x()+master_w+gap, area.y()+half_h+gap, stack_w, area.height()-half_h-gap)]
        else:
            cols = max(2, round(count ** 0.5))
            rows = (count + cols - 1)//cols
            cell_w = (area.width()-gap*(cols-1))//cols
            cell_h = (area.height()-gap*(rows-1))//rows
            rects=[]
            for i in range(count):
                c, r = i % cols, i // cols
                rects.append(QRect(area.x()+c*(cell_w+gap), area.y()+r*(cell_h+gap), cell_w if c<cols-1 else area.right()-(area.x()+c*(cell_w+gap))+1, cell_h if r<rows-1 else area.bottom()-(area.y()+r*(cell_h+gap))+1))
        for window, rect in zip(windows, rects):
            window.setGeometry(rect)
            window.raise_()

    def apply_night_light(self, enabled=None, strength=None):
        settings = load_settings()
        enabled = bool(settings.get("night_light", False) if enabled is None else enabled)
        strength = int(settings.get("night_light_strength", 28) if strength is None else strength)
        strength = max(0, min(90, strength)) if enabled else 0
        overlay = getattr(self, "night_light_overlay", None)
        if overlay is None:
            return
        overlay.setGeometry(self.ui_layer.rect())
        overlay.setStyleSheet(f"QFrame#NightLightOverlay{{background:rgba(255,132,48,{strength});border:none;}}")
        overlay.setVisible(strength > 0)
        self.raise_shells()

    def toggle_overview(self):
        visible=[w for w in self.window_z if w.isVisible()]
        if not visible:return
        gap=max(12,int(load_settings().get("widget_gap",12)));cols=max(1,round(len(visible)**0.5));rows=(len(visible)+cols-1)//cols
        cell_w=max(320,(self.app_layer.width()-gap*(cols+1))//cols);cell_h=max(220,(self.app_layer.height()-gap*(rows+1))//rows)
        for index,window in enumerate(visible):
            window.setGeometry(gap+(index%cols)*(cell_w+gap),gap+(index//cols)*(cell_h+gap),cell_w,cell_h);window.raise_()

    def toggle_focus_mode(self):
        st=load_settings();st["focus_mode"]=not bool(st.get("focus_mode"));st["do_not_disturb"]=st["focus_mode"];save_settings(st)
        self.notch.notify("Focus mode on" if st["focus_mode"] else "Focus mode off")

    def toggle_night_light(self):
        st = load_settings()
        st["night_light"] = not bool(st.get("night_light"))
        save_settings(st)
        self.apply_night_light(st["night_light"], int(st.get("night_light_strength", 28)))
        self.notch.notify("Night Light on" if st["night_light"] else "Night Light off")

    def closeEvent(self,event):
        if hasattr(self, "sound_service"):
            self.sound_service.play("logout")
            self.sound_service.shutdown()
        for timer_name in ("_clock_timer","_dock_anim_timer","_session_save_timer"):
            timer=getattr(self,timer_name,None)
            if timer is not None:timer.stop()
        for window in list(getattr(self,"window_z",[])):
            if hasattr(window,"shutdown_resources"):window.shutdown_resources()
        for widget in list(getattr(self,"desktop_widgets",[])):
            if hasattr(widget,"shutdown"):widget.shutdown()
        for worker in list(getattr(self, "search_workers", [])):
            if hasattr(worker, "requestInterruption"): worker.requestInterruption()
            if hasattr(worker, "quit"): worker.quit()
            if hasattr(worker, "wait"): worker.wait(600)
        pool = QThreadPool.globalInstance()
        pool.clear()
        pool.waitForDone(1800)
        if hasattr(self, "save_window_session"):
            self.save_window_session()
        if hasattr(self, "session_recovery"):
            self.session_recovery.finish()
        app = QApplication.instance()
        if app is not None:
            app.removeEventFilter(self)
        self.windows.clear()
        self.window_groups.clear()
        self.window_z.clear()
        self.settings_store.close()
        super().closeEvent(event)

    def keyPressEvent(self, event):
        modifiers = event.modifiers()
        palette = getattr(self, "command_palette", None)
        if event.key() == Qt.Key_K and modifiers & (Qt.ControlModifier | Qt.MetaModifier):
            if palette is not None:
                palette.show_palette()
            event.accept()
            return
        if event.key() == Qt.Key_V and modifiers & (Qt.ControlModifier | Qt.MetaModifier) and modifiers & Qt.ShiftModifier:
            self.show_clipboard_history()
            event.accept()
            return
        if event.key() == Qt.Key_Tab and modifiers & Qt.AltModifier:
            visible = [w for w in getattr(self, "window_z", []) if w.isVisible()]
            if visible:
                self.activate_window(visible[-2] if len(visible) > 1 else visible[-1])
            event.accept()
            return
        if event.key() == Qt.Key_Escape and palette is not None and palette.isVisible():
            palette.hide()
            event.accept()
            return
        super().keyPressEvent(event)
