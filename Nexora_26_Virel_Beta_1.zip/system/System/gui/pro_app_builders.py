"""Professional applications introduced in Nexora 26 Beta 1 .

The builders deliberately share small primitives and persistent services. Every
application performs a real local action; capability-dependent integrations
report unavailability instead of pretending that an operation succeeded.
"""
from __future__ import annotations

import html
import json
import os
import platform
import re
import secrets
import shutil
import string
import subprocess
import sys
import time
import threading
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt, QProcess, QTimer, QUrl, QObject, Signal
from PySide6.QtGui import QColor, QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QFormLayout, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QListWidget, QListWidgetItem, QPlainTextEdit, QProgressBar,
    QPushButton, QSpinBox, QCheckBox, QTableWidget, QTableWidgetItem, QTextBrowser, QTextEdit, QMessageBox,
    QVBoxLayout, QWidget, QColorDialog, QTabWidget, QSizePolicy,
)

from .shared import (
    ACCENT, APP_COLORS, DATA_DIR, MUTED, NEXORA_HOME, PROJECT_ROOT, TEXT,
    app_name, evaluate_calculation, font, glass_input_css, load_settings,
    oneui_button_css, rgba, save_settings, submit,
)
from .components import InternalFilePicker
from System.pro import LocalVault, VaultError
from System.apps.packages import PackageManager


def _button(text, callback=None, color="#8AB4F8"):
    button = QPushButton(text)
    button.setMinimumHeight(38)
    button.setStyleSheet(oneui_button_css(color, radius=11))
    if callback:
        button.clicked.connect(callback)
    return button


def _section(title, subtitle=""):
    card = QFrame()
    card.setObjectName("ProCard")
    card.setStyleSheet(
        "QFrame#ProCard{background:rgba(255,255,255,18);border:none;border-radius:22px;}"
    )
    layout = QVBoxLayout(card)
    layout.setContentsMargins(16, 14, 16, 14)
    layout.setSpacing(7)
    label = QLabel(title)
    label.setFont(font(13, True))
    layout.addWidget(label)
    if subtitle:
        detail = QLabel(subtitle)
        detail.setWordWrap(True)
        detail.setStyleSheet(f"color:{MUTED};")
        layout.addWidget(detail)
    return card, layout


def _json_read(path: Path, default):
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value
    except (OSError, ValueError, TypeError):
        return default


def _json_write(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    os.replace(tmp, path)


class ProfessionalApplicationBuildersMixin:
    PRO_BUILDERS = {
        "Notes": "build_notes_pro",
        "Markdown Editor": "build_markdown_editor",
        "Mail": "build_mail",
        "Music Player": "build_music_player",
        "Camera": "build_camera",
        "Recorder": "build_recorder",
        "Screen Recorder": "build_screen_recorder",
        "Developer Hub": "build_developer_hub",
        "Package Manager": "build_package_manager_pro",
        "PDF Viewer": "build_pdf_viewer",
        "System Monitor": "build_system_monitor",
        "Performance Monitor": "build_system_monitor",
        "System Health": "build_system_health",
        "Disk Manager": "build_disk_manager",
        "Backup Manager": "build_backup_manager",
        "Clipboard Manager": "build_clipboard_manager",
        "Password Manager": "build_password_manager",
        "Color Picker": "build_color_picker",
        "Download Manager": "build_download_manager",
        "Game Launcher": "build_game_launcher",
        "Cloud Drive": "build_cloud_drive",
        "File Sharing": "build_file_sharing",
        "Git Client": "build_git_client",
        "SSH Client": "build_ssh_client",
        "FTP Client": "build_ftp_client",
        "Remote Desktop": "build_remote_desktop",
        "Screen Mirroring": "build_screen_mirroring",
        "Focus Mode": "build_focus_mode_app",
        "Studio": "build_studio_hub",
        "Media Center": "build_media_center",
        "Calculator Pro": "build_calculator_pro",
        "Terminal Pro": "build_terminal_pro",
        "Spaces": "build_spaces",
        "Automation": "build_automation",
        "Extensions": "build_extensions",
        "Continuum": "build_continuum",
    }

    def build_professional_application(self, name: str) -> bool:
        method_name = self.PRO_BUILDERS.get(name)
        if not method_name:
            return False
        builder = getattr(self, method_name, None)
        if not callable(builder):
            raise RuntimeError(f"Application builder is missing: {name} -> {method_name}")
        builder()
        return True

    # ------------------------------------------------------------------ media
    def build_music_player(self):
        self.heading("Music Player", "Local library browser using the platform media player")
        folder = NEXORA_HOME / "Music"; folder.mkdir(parents=True, exist_ok=True)
        listing = QListWidget(); listing.setSelectionMode(QAbstractItemView.SingleSelection); self.content_layout.addWidget(listing, 1)
        supported = {".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"}
        def refresh():
            listing.clear()
            for path in sorted(folder.rglob("*")):
                if path.is_file() and path.suffix.casefold() in supported:
                    item = QListWidgetItem(path.name); item.setData(Qt.UserRole, str(path)); listing.addItem(item)
        def play():
            item = listing.currentItem()
            if item: QDesktopServices.openUrl(QUrl.fromLocalFile(item.data(Qt.UserRole)))
        def reveal(): QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))
        row = QHBoxLayout(); row.addWidget(_button("Play selected", play, "#A7D8A1")); row.addWidget(_button("Open Music folder", reveal, "#8AB4F8")); row.addWidget(_button("Refresh", refresh, "#B9A7E8")); row.addStretch(); self.content_layout.insertLayout(1, row); listing.itemDoubleClicked.connect(lambda *_: play()); refresh()

    def build_media_center(self):
        self.heading("Media Center", "Unified launch surface for photos, music, video and recordings")
        grid = QGridLayout()
        entries = (("Music Player", "#89D4CF"), ("Gallery", "#B9A7E8"), ("Video Editor", "#F4A7B9"), ("Audio Editor", "#8AB4F8"), ("Screen Recorder", "#FFD18A"), ("Files", "#A7D8A1"))
        for index, (name, color) in enumerate(entries):
            def launch(_=False, target=name):
                path = next((p for p in self.desktop.app_paths if app_name(p) == target), None)
                if path: self.desktop.open_app(path)
            button = _button(name, launch, color); button.setMinimumHeight(82); grid.addWidget(button, index // 3, index % 3)
        self.content_layout.addLayout(grid); self.content_layout.addStretch()

    def build_camera(self):
        self.heading("Camera", "Capability-aware camera launcher and screenshot capture")
        status = QLabel("Camera permission: " + ("allowed" if self.desktop.permission_manager.get("camera", "camera") else "blocked")); status.setWordWrap(True); self.content_layout.addWidget(status)
        def toggle():
            allowed = not self.desktop.permission_manager.get("camera", "camera"); self.desktop.permission_manager.set("camera", "camera", allowed); status.setText("Camera permission: " + ("allowed" if allowed else "blocked"))
        def open_camera():
            if not self.desktop.permission_manager.get("camera", "camera"):
                self.desktop.show_system_message("Camera", "Camera permission is disabled in Nexora."); return
            adapter = self.desktop.platform_adapter
            result = adapter.open_camera() if hasattr(adapter, "open_camera") else None
            if result is None or not getattr(result, "success", False): self.desktop.show_system_message("Camera", getattr(result, "message", "Use the platform Camera application."))
        def screenshot():
            screen = self.screen()
            target = NEXORA_HOME / "Images" / f"Capture {datetime.now():%Y-%m-%d %H.%M.%S}.png"
            if screen and screen.grabWindow(0).save(str(target), "PNG"): self.desktop.notch.notify(f"Saved {target.name}")
        row = QHBoxLayout(); row.addWidget(_button("Toggle permission", toggle, "#FFD18A")); row.addWidget(_button("Open camera", open_camera, "#8AB4F8")); row.addWidget(_button("Capture screen", screenshot, "#A7D8A1")); row.addStretch(); self.content_layout.addLayout(row); self.content_layout.addStretch()

    def build_recorder(self):
        self.heading("Recorder", "Open the native audio recorder with explicit microphone permission")
        allowed = self.desktop.permission_manager.get("recorder", "microphone")
        status = QLabel(f"Microphone permission: {'allowed' if allowed else 'blocked'}"); self.content_layout.addWidget(status)
        def toggle():
            value = not self.desktop.permission_manager.get("recorder", "microphone"); self.desktop.permission_manager.set("recorder", "microphone", value); status.setText(f"Microphone permission: {'allowed' if value else 'blocked'}")
        def launch():
            if not self.desktop.permission_manager.get("recorder", "microphone"):
                self.desktop.show_system_message("Recorder", "Microphone permission is disabled."); return
            commands = []
            if sys_platform := platform.system().lower():
                if sys_platform == "darwin": commands = [["open", "-a", "Voice Memos"]]
                elif sys_platform == "windows": commands = [["cmd", "/c", "start", "ms-callrecording:"]]
                else: commands = [[shutil.which("gnome-sound-recorder") or "gnome-sound-recorder"]]
            try: subprocess.Popen(commands[0]); self.desktop.notch.notify("Recorder opened")
            except (OSError, IndexError): self.desktop.show_system_message("Recorder", "No supported native recorder was found.")
        row = self._connected_bar([("Toggle microphone", toggle), ("Open recorder", launch)], "#F47C8C"); self.content_layout.addLayout(row); self.content_layout.addStretch()

    def build_screen_recorder(self):
        self.heading("Screen Recorder", "Launch the verified platform recording workflow")
        detail = QLabel("Nexora delegates capture to the operating system so privacy prompts, audio routing and codecs remain correct."); detail.setWordWrap(True); detail.setStyleSheet(f"color:{MUTED};"); self.content_layout.addWidget(detail)
        def launch():
            result = self.desktop.platform_adapter.open_screen_recording()
            if getattr(result, "success", False): self.desktop.notch.notify("Screen recording controls opened")
            else: self.desktop.show_system_message("Screen Recorder", getattr(result, "message", "Recording controls are unavailable."))
        self.content_layout.addWidget(_button("Open recording controls", launch, "#F4A7B9"), 0, Qt.AlignLeft); self.content_layout.addStretch()

    # ------------------------------------------------------------- development
    def build_developer_hub(self):
        self.heading("Developer Hub", "Project diagnostics, runtime information and quality checks")
        info = QTextBrowser(); info.setStyleSheet(glass_input_css("#8AB4F8")); self.content_layout.addWidget(info, 1)
        output = QPlainTextEdit(); output.setReadOnly(True); output.setMaximumHeight(180); self.content_layout.addWidget(output)
        info.setHtml(
            f"<h3>Nexora {html.escape(str(load_settings().get('schema_version', 36)))}</h3>"
            f"<p>Python {html.escape(platform.python_version())}<br>{html.escape(platform.platform())}<br>Project: {html.escape(str(PROJECT_ROOT))}</p>"
        )
        process = QProcess(self); process.setWorkingDirectory(str(PROJECT_ROOT))
        process.readyReadStandardOutput.connect(lambda: output.appendPlainText(bytes(process.readAllStandardOutput()).decode(errors="replace")))
        process.readyReadStandardError.connect(lambda: output.appendPlainText(bytes(process.readAllStandardError()).decode(errors="replace")))
        def run(args):
            if process.state() != QProcess.NotRunning: return
            output.clear(); process.start(shutil.which("python3") or shutil.which("python") or "python", args)
        row = QHBoxLayout(); row.addWidget(_button("Compile all", lambda: run(["-m", "compileall", "-q", "System", "nexora"]), "#A7D8A1")); row.addWidget(_button("Run tests", lambda: run(["-m", "pytest", "-q"]), "#8AB4F8")); row.addWidget(_button("Benchmark", lambda: run(["benchmarks/benchmark_startup.py", "--output", "benchmarks/results/latest.json"]), "#B9A7E8")); row.addStretch(); self.content_layout.insertLayout(1, row)

    def build_package_manager_pro(self):
        self.heading("Package Manager", "Installed Nexora packages and extension inventory")
        table = QTableWidget(0, 4); table.setHorizontalHeaderLabels(["Name", "Version", "Category", "ID"]); table.horizontalHeader().setStretchLastSection(True); self.content_layout.addWidget(table, 1)
        def refresh():
            manager = getattr(self, "package_manager", None) or PackageManager(DATA_DIR)
            manifests = manager.installed()
            table.setRowCount(len(manifests))
            for row, manifest in enumerate(manifests):
                for col, value in enumerate((manifest.name, manifest.version, manifest.category, manifest.app_id)): table.setItem(row, col, QTableWidgetItem(str(value)))
        def open_store():
            path = next((p for p in self.desktop.app_paths if app_name(p) == "Store"), None)
            if path: self.desktop.open_app(path)
        row = QHBoxLayout(); row.addWidget(_button("Refresh", refresh, "#B9A7E8")); row.addWidget(_button("Open Store", open_store, "#8AB4F8")); row.addStretch(); self.content_layout.insertLayout(1, row); refresh()

    def build_pdf_viewer(self):
        self.heading("PDF Viewer", "Open and inspect local PDF files")
        details = QTextBrowser(); details.setStyleSheet(glass_input_css("#F4A7B9")); self.content_layout.addWidget(details, 1)
        state = {"path": None}
        def open_pdf():
            def done(path):
                state["path"] = path
                try:
                    data = path.read_bytes(); pages = len(re.findall(rb"/Type\s*/Page\b", data)); size = path.stat().st_size
                    details.setHtml(f"<h2>{html.escape(path.name)}</h2><p>{pages or 'Unknown'} page objects<br>{size/1024:.1f} KB<br>{html.escape(str(path))}</p>")
                except OSError as exc: details.setPlainText(str(exc))
            self._picker = InternalFilePicker(self.desktop, "Open PDF", "open", done, extensions=[".pdf"])
        def external():
            if state["path"]: QDesktopServices.openUrl(QUrl.fromLocalFile(str(state["path"])))
        row = self._connected_bar([("Choose PDF", open_pdf), ("Open in system viewer", external)], "#F47C8C"); self.content_layout.insertLayout(1, row)

    # -------------------------------------------------------------- monitoring
    def build_system_monitor(self):
        self.heading(self.title, "Live CPU, memory, disk and process telemetry")
        grid = QGridLayout(); cards = {}
        for index, key in enumerate(("CPU", "Memory", "Disk", "Processes")):
            card, layout = _section(key); value = QLabel("—"); value.setFont(font(24, True)); layout.addWidget(value); cards[key] = value; grid.addWidget(card, index // 2, index % 2)
        self.content_layout.addLayout(grid)
        processes = QTableWidget(0, 3); processes.setHorizontalHeaderLabels(["Process", "PID", "Memory MB"]); processes.horizontalHeader().setStretchLastSection(True); self.content_layout.addWidget(processes, 1)
        def refresh():
            try:
                import psutil
                cards["CPU"].setText(f"{psutil.cpu_percent():.0f}%")
                mem = psutil.virtual_memory(); cards["Memory"].setText(f"{mem.percent:.0f}%")
                disk = psutil.disk_usage(str(PROJECT_ROOT)); cards["Disk"].setText(f"{disk.percent:.0f}%")
                items = []
                for proc in psutil.process_iter(["pid", "name", "memory_info"]):
                    try: items.append((proc.info["memory_info"].rss, proc.info["name"], proc.info["pid"]))
                    except (psutil.NoSuchProcess, psutil.AccessDenied, AttributeError): continue
                items.sort(reverse=True); items = items[:25]; cards["Processes"].setText(str(len(psutil.pids())))
                processes.setRowCount(len(items))
                for row, (rss, name, pid) in enumerate(items):
                    for col, value in enumerate((name, pid, f"{rss/1024**2:.1f}")): processes.setItem(row, col, QTableWidgetItem(str(value)))
            except Exception as exc: cards["CPU"].setText("Unavailable"); processes.setRowCount(0); processes.setToolTip(str(exc))
        timer = QTimer(self); timer.setInterval(1500); timer.timeout.connect(refresh); timer.start(); refresh()

    def build_system_health(self):
        self.heading("System Health", "Actionable diagnostics without destructive automatic repair")
        report = QTextBrowser(); report.setStyleSheet(glass_input_css("#A7D8A1")); self.content_layout.addWidget(report, 1)
        def refresh():
            data = self.desktop.health_monitor.collect(); issues = data["issues"] or ["No critical issues detected"]
            report.setHtml(
                f"<h2>{data['status'].title()}</h2><p>CPU: {data['cpu_percent']}%<br>Memory: {data['memory_percent']}%<br>Disk: {data['disk_percent']}%<br>Processes: {data['processes']}<br>Cache: {data['cache']['bytes']/1024**2:.1f} MB</p>"
                + "<h3>Findings</h3><ul>" + "".join(f"<li>{html.escape(str(x))}</li>" for x in issues) + "</ul>"
            )
        def clear_cache(): removed = self.desktop.cache_manager.clear(); self.desktop.notch.notify(f"Removed {removed} cached files"); refresh()
        row = QHBoxLayout(); row.addWidget(_button("Run check", refresh, "#A7D8A1")); row.addWidget(_button("Clear cache", clear_cache, "#FFD18A")); row.addStretch(); self.content_layout.insertLayout(1, row); refresh()

    def build_disk_manager(self):
        self.heading("Disk Manager", "Read-only volume inventory with safe folder access")
        table = QTableWidget(0, 5); table.setHorizontalHeaderLabels(["Device", "Mount", "File system", "Used", "Free GB"]); table.horizontalHeader().setStretchLastSection(True); self.content_layout.addWidget(table, 1)
        def refresh():
            try:
                import psutil
                rows = []
                for part in psutil.disk_partitions(all=False):
                    try:
                        usage = psutil.disk_usage(part.mountpoint); rows.append((part.device, part.mountpoint, part.fstype, f"{usage.percent:.0f}%", f"{usage.free/1024**3:.1f}"))
                    except (OSError, PermissionError): continue
                table.setRowCount(len(rows))
                for r, row in enumerate(rows):
                    for c, value in enumerate(row): table.setItem(r, c, QTableWidgetItem(str(value)))
            except Exception: table.setRowCount(0)
        def open_mount():
            item = table.item(table.currentRow(), 1) if table.currentRow() >= 0 else None
            if item: QDesktopServices.openUrl(QUrl.fromLocalFile(item.text()))
        row = QHBoxLayout(); row.addWidget(_button("Refresh", refresh)); row.addWidget(_button("Open selected volume", open_mount, "#A7D8A1")); row.addStretch(); self.content_layout.insertLayout(1, row); refresh()

    # -------------------------------------------------------------- backup etc
    def build_backup_manager(self):
        self.heading("Backup Manager", "Checksummed snapshots of Nexora settings and optional user files")
        listing = QListWidget(); self.content_layout.addWidget(listing, 1)
        include_home = QComboBox(); include_home.addItem("Settings only", False); include_home.addItem("Settings and Home files", True)
        def refresh():
            listing.clear()
            for snapshot in self.desktop.snapshot_manager.list():
                item = QListWidgetItem(f"{snapshot.name} · {datetime.fromtimestamp(snapshot.created_at):%Y-%m-%d %H:%M}\n{snapshot.file_count} files · {snapshot.size/1024:.1f} KB")
                item.setData(Qt.UserRole, snapshot.snapshot_id); listing.addItem(item)
        def create():
            snap = self.desktop.snapshot_manager.create("Manual snapshot", include_home=bool(include_home.currentData())); self.desktop.notch.notify(f"Snapshot {snap.snapshot_id} created"); refresh()
        def restore():
            item = listing.currentItem()
            if not item: return
            sid = item.data(Qt.UserRole)
            self.desktop.show_confirm("Restore snapshot", "Restore the selected snapshot? Current top-level settings files will be copied to a recovery folder first.", lambda: (self.desktop.snapshot_manager.restore(sid, restore_home=bool(include_home.currentData())), self.desktop.notch.notify("Snapshot restored")))
        def delete():
            item = listing.currentItem()
            if item: self.desktop.snapshot_manager.delete(item.data(Qt.UserRole)); refresh()
        row = QHBoxLayout(); row.addWidget(include_home); row.addWidget(_button("Create snapshot", create, "#A7D8A1")); row.addWidget(_button("Restore", restore, "#8AB4F8")); row.addWidget(_button("Delete", delete, "#F4A7B9")); row.addStretch(); self.content_layout.insertLayout(1, row); refresh()

    def build_clipboard_manager(self):
        self.heading("Clipboard Manager", "Searchable clipboard history managed inside Nexora")
        search = QLineEdit(); search.setPlaceholderText("Search clipboard history")
        listing = QListWidget(); self.content_layout.addWidget(search); self.content_layout.addWidget(listing, 1)
        def values():
            service = self.desktop.clipboard_service
            if hasattr(service, "history"): return list(service.history())
            if hasattr(service, "items"): return list(service.items)
            return []
        def refresh(text=""):
            listing.clear(); query = text.casefold().strip()
            for value in values():
                raw = str(getattr(value, "text", value))
                if not query or query in raw.casefold():
                    item = QListWidgetItem(raw[:500]); item.setData(Qt.UserRole, raw); listing.addItem(item)
        def copy_selected():
            item = listing.currentItem()
            if item: QApplication.clipboard().setText(item.data(Qt.UserRole)); self.desktop.notch.notify("Copied from history")
        from PySide6.QtWidgets import QApplication
        search.textChanged.connect(refresh); listing.itemDoubleClicked.connect(lambda *_: copy_selected())
        row = QHBoxLayout(); row.addWidget(_button("Copy selected", copy_selected, "#A7D8A1")); row.addWidget(_button("Refresh", refresh, "#B9A7E8")); row.addStretch(); self.content_layout.insertLayout(2, row); refresh()

    def build_password_manager(self):
        self.heading("Password Manager", "Encrypted local vault with PBKDF2 and integrity verification")
        vault = LocalVault(DATA_DIR / "vault.nxvault")
        password = QLineEdit(); password.setEchoMode(QLineEdit.Password); password.setPlaceholderText("Vault password (minimum 8 characters)")
        service = QLineEdit(); username = QLineEdit(); secret = QLineEdit(); secret.setEchoMode(QLineEdit.Password)
        service.setPlaceholderText("Service"); username.setPlaceholderText("Username"); secret.setPlaceholderText("Password")
        listing = QListWidget(); self.content_layout.addWidget(password); self.content_layout.addWidget(listing, 1)
        form = QFormLayout(); form.addRow("Service", service); form.addRow("Username", username); form.addRow("Password", secret); self.content_layout.addLayout(form)
        state = {"entries": []}
        def refresh():
            listing.clear()
            for entry in state["entries"]:
                item = QListWidgetItem(f"{entry.get('service','')}\n{entry.get('username','')}"); item.setData(Qt.UserRole, entry); listing.addItem(item)
        def unlock():
            if not vault.exists(): state["entries"] = []; refresh(); self.desktop.notch.notify("New vault ready")
            else:
                try: state["entries"] = vault.load(password.text()); refresh(); self.desktop.notch.notify("Vault unlocked")
                except VaultError as exc: self.desktop.show_system_message("Password Manager", str(exc))
        def save_vault():
            try: vault.save(password.text(), state["entries"]); self.desktop.notch.notify("Vault saved")
            except VaultError as exc: self.desktop.show_system_message("Password Manager", str(exc))
        def add():
            if not service.text().strip() or not secret.text(): return
            state["entries"].append({"service": service.text().strip(), "username": username.text().strip(), "password": secret.text()}); service.clear(); username.clear(); secret.clear(); refresh(); save_vault()
        def generate():
            alphabet = string.ascii_letters + string.digits + "!@#$%^&*_-+"; secret.setText("".join(secrets.choice(alphabet) for _ in range(20)))
        def reveal():
            item = listing.currentItem()
            if item:
                entry = item.data(Qt.UserRole); self.desktop.show_system_message(entry.get("service", "Credential"), f"Username: {entry.get('username','')}\nPassword: {entry.get('password','')}")
        row = QHBoxLayout(); row.addWidget(_button("Unlock / Create", unlock)); row.addWidget(_button("Generate", generate, "#FFD18A")); row.addWidget(_button("Add", add, "#A7D8A1")); row.addWidget(_button("Reveal selected", reveal, "#F4A7B9")); row.addStretch(); self.content_layout.insertLayout(2, row)

    def build_color_picker(self):
        self.heading("Color Picker", "Pick, preview and copy precise colors")
        preview = QFrame(); preview.setMinimumHeight(180)
        value = QLineEdit("#3F8CFF"); value.setAlignment(Qt.AlignCenter); value.setFont(font(20, True))
        self.content_layout.addWidget(preview); self.content_layout.addWidget(value)
        def apply_color(text=None):
            color = QColor(text or value.text())
            if color.isValid(): value.setText(color.name(QColor.HexArgb) if color.alpha() < 255 else color.name()); preview.setStyleSheet(f"background:{color.name()};border-radius:24px;border:none;")
        def choose():
            color = QColorDialog.getColor(QColor(value.text()), self, "Choose color")
            if color.isValid(): apply_color(color.name())
        def copy():
            from PySide6.QtWidgets import QApplication
            QApplication.clipboard().setText(value.text()); self.desktop.notch.notify("Color copied")
        value.editingFinished.connect(apply_color)
        row = QHBoxLayout(); row.addWidget(_button("Choose", choose)); row.addWidget(_button("Copy", copy, "#A7D8A1")); row.addStretch(); self.content_layout.addLayout(row); apply_color()

    # --------------------------------------------------------------- transfers
    def build_download_manager(self):
        self.heading("Download Manager", "Background downloads with destination validation")
        url = QLineEdit(); url.setPlaceholderText("https://example.com/file.zip")
        listing = QListWidget(); self.content_layout.addWidget(url); self.content_layout.addWidget(listing, 1)
        def start():
            raw = url.text().strip(); parsed = urllib.parse.urlparse(raw)
            if parsed.scheme not in {"http", "https"}:
                self.desktop.show_system_message("Download Manager", "Only HTTP and HTTPS URLs are supported."); return
            name = Path(urllib.parse.unquote(parsed.path)).name or f"download-{int(time.time())}.bin"
            target = NEXORA_HOME / "Downloads" / name
            item = QListWidgetItem(f"Downloading {name}…"); listing.insertItem(0, item)
            def work():
                request = urllib.request.Request(raw, headers={"User-Agent": "Nexora/36"})
                with urllib.request.urlopen(request, timeout=30) as response, target.open("wb") as out:
                    shutil.copyfileobj(response, out, length=256 * 1024)
                return target
            submit(work, on_success=lambda path: (item.setText(f"Complete · {path.name}\n{path}"), item.setData(Qt.UserRole, str(path))), on_error=lambda message: item.setText(f"Failed · {message}"))
        def open_selected():
            item = listing.currentItem(); path = item.data(Qt.UserRole) if item else None
            if path: QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        row = QHBoxLayout(); row.addWidget(_button("Download", start, "#8AB4F8")); row.addWidget(_button("Open selected", open_selected, "#A7D8A1")); row.addStretch(); self.content_layout.insertLayout(2, row)

    def build_cloud_drive(self):
        self.heading("Cloud Drive", "Local synchronization staging area for any external sync provider")
        cloud = NEXORA_HOME / "Cloud Drive"; cloud.mkdir(parents=True, exist_ok=True)
        listing = QListWidget(); self.content_layout.addWidget(listing, 1)
        def refresh():
            listing.clear()
            for p in sorted(cloud.rglob("*")):
                if p.is_file(): listing.addItem(str(p.relative_to(cloud)))
        def import_file():
            def done(path): shutil.copy2(path, cloud / path.name); refresh(); self.desktop.notch.notify(f"Added {path.name}")
            self._picker = InternalFilePicker(self.desktop, "Add to Cloud Drive", "open", done)
        row = QHBoxLayout(); row.addWidget(_button("Add file", import_file, "#A7D8A1")); row.addWidget(_button("Open folder", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(cloud))), "#8AB4F8")); row.addWidget(_button("Refresh", refresh, "#B9A7E8")); row.addStretch(); self.content_layout.insertLayout(1, row); refresh()

    def build_file_sharing(self):
        self.heading("File Sharing", "A controlled local share folder ready for LAN or cloud tools")
        shared = NEXORA_HOME / "Shared"; shared.mkdir(parents=True, exist_ok=True)
        listing = QListWidget(); self.content_layout.addWidget(listing, 1)
        def refresh(): listing.clear(); [listing.addItem(p.name) for p in sorted(shared.iterdir()) if p.is_file()]
        def add():
            def done(path): shutil.copy2(path, shared / path.name); refresh()
            self._picker = InternalFilePicker(self.desktop, "Share file", "open", done)
        row = QHBoxLayout(); row.addWidget(_button("Add file", add, "#A7D8A1")); row.addWidget(_button("Open shared folder", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(shared))), "#8AB4F8")); row.addStretch(); self.content_layout.insertLayout(1, row); refresh()

    # ------------------------------------------------------------------- tools
    def build_git_client(self):
        self.heading("Git Client", "Status, history and initialization through the installed Git CLI")
        repo = QLineEdit(str(NEXORA_HOME / "Documents")); output = QPlainTextEdit(); output.setReadOnly(True)
        self.content_layout.addWidget(repo); self.content_layout.addWidget(output, 1)
        def run(args):
            root = Path(repo.text()).expanduser()
            if not root.exists(): output.setPlainText("Repository folder does not exist."); return
            git = shutil.which("git")
            if not git: output.setPlainText("Git is not installed."); return
            try:
                result = subprocess.run([git, *args], cwd=root, capture_output=True, text=True, timeout=12)
                output.setPlainText((result.stdout or "") + (result.stderr or ""))
            except (OSError, subprocess.SubprocessError) as exc: output.setPlainText(str(exc))
        row = QHBoxLayout(); row.addWidget(_button("Status", lambda: run(["status", "--short", "--branch"]))); row.addWidget(_button("Log", lambda: run(["log", "--oneline", "-20"]), "#B9A7E8")); row.addWidget(_button("Initialize", lambda: run(["init"]), "#A7D8A1")); row.addStretch(); self.content_layout.insertLayout(2, row)

    def _build_remote_cli(self, kind: str):
        host = QLineEdit(); host.setPlaceholderText("user@example.com" if kind == "ssh" else "example.com")
        port = QSpinBox(); port.setRange(1, 65535); port.setValue(22 if kind == "ssh" else 21)
        output = QPlainTextEdit(); output.setReadOnly(True)
        form = QFormLayout(); form.addRow("Host", host); form.addRow("Port", port); self.content_layout.addLayout(form); self.content_layout.addWidget(output, 1)
        def launch():
            executable = shutil.which(kind)
            if not executable: output.setPlainText(f"{kind.upper()} client is not installed."); return
            target = host.text().strip()
            if not re.fullmatch(r"[A-Za-z0-9._@:-]+", target): output.setPlainText("Host contains unsupported characters."); return
            args = ["-p" if kind == "ssh" else "-P", str(port.value()), target] if kind == "ssh" else [target, str(port.value())]
            try: subprocess.Popen([executable, *args]); output.setPlainText(f"Started {kind.upper()} client in a separate process.")
            except OSError as exc: output.setPlainText(str(exc))
        self.content_layout.insertWidget(1, _button(f"Launch {kind.upper()}", launch, "#8AB4F8"), 0, Qt.AlignLeft)

    def build_ssh_client(self): self.heading("SSH Client", "Launch a local SSH session without storing credentials"); self._build_remote_cli("ssh")
    def build_ftp_client(self): self.heading("FTP Client", "Launch the installed FTP client without storing credentials"); self._build_remote_cli("ftp")

    def build_remote_desktop(self):
        self.heading("Remote Desktop", "Open the operating system's remote desktop client")
        def launch():
            system = platform.system().lower()
            commands = [["open", "-a", "Screen Sharing"]] if system == "darwin" else [["mstsc"]] if system == "windows" else [[shutil.which("remmina") or "remmina"]]
            try: subprocess.Popen(commands[0]); self.desktop.notch.notify("Remote desktop opened")
            except OSError: self.desktop.show_system_message("Remote Desktop", "No supported remote desktop client was found.")
        self.content_layout.addWidget(_button("Open remote desktop", launch, "#8AB4F8"), 0, Qt.AlignLeft); self.content_layout.addStretch()

    def build_screen_mirroring(self):
        self.heading("Screen Mirroring", "Open verified display and casting controls")
        def launch():
            result = self.desktop.platform_adapter.open_display_settings()
            if not getattr(result, "success", False): self.desktop.show_system_message("Screen Mirroring", getattr(result, "message", "Display controls unavailable."))
        self.content_layout.addWidget(_button("Open display controls", launch, "#B9A7E8"), 0, Qt.AlignLeft); self.content_layout.addStretch()

    def build_focus_mode_app(self):
        self.heading("Focus Mode", "Reduce interruptions and switch Nexora into a low-distraction profile")
        status = QLabel(); status.setFont(font(20, True)); self.content_layout.addWidget(status)
        duration = QSpinBox(); duration.setRange(5, 240); duration.setValue(25); duration.setSuffix(" min")
        remaining = QLabel(); remaining.setFont(font(34, True)); remaining.setAlignment(Qt.AlignCenter); self.content_layout.addWidget(remaining, 1)
        state = {"seconds": 0}; timer = QTimer(self); timer.setInterval(1000)
        def refresh_status(): status.setText("Focus is ON" if load_settings().get("focus_mode") else "Focus is OFF")
        def toggle():
            settings = load_settings(); settings["focus_mode"] = not bool(settings.get("focus_mode")); settings["do_not_disturb"] = settings["focus_mode"]; save_settings(settings); self.desktop.apply_settings(settings); refresh_status()
        def start(): state["seconds"] = duration.value() * 60; timer.start(); toggle() if not load_settings().get("focus_mode") else None
        def tick():
            state["seconds"] = max(0, state["seconds"] - 1); remaining.setText(f"{state['seconds']//60:02d}:{state['seconds']%60:02d}")
            if state["seconds"] == 0: timer.stop();
        timer.timeout.connect(tick)
        row = QHBoxLayout(); row.addWidget(duration); row.addWidget(_button("Start session", start, "#A7D8A1")); row.addWidget(_button("Toggle Focus", toggle, "#8AB4F8")); row.addStretch(); self.content_layout.insertLayout(2, row); refresh_status(); remaining.setText("00:00")

    def build_studio_hub(self):
        self.heading("Studio", "Creator workspace for image, audio, video, documents and code")
        grid = QGridLayout()
        names = ("Image Editor", "Video Editor", "Audio Editor", "Code Editor", "Documents", "Whiteboard")
        for i, name in enumerate(names):
            def launch(_=False, target=name):
                path = next((p for p in self.desktop.app_paths if app_name(p) == target), None)
                if path: self.desktop.open_app(path)
            b = _button(name, launch, APP_COLORS.get(name, "#8AB4F8")); b.setMinimumHeight(82); grid.addWidget(b, i // 3, i % 3)
        self.content_layout.addLayout(grid); self.content_layout.addStretch()

    def build_calculator_pro(self):
        self.heading("Calculator Pro", "Safe expression evaluation with reusable history")
        expression = QLineEdit(); expression.setFont(font(20, True)); expression.setPlaceholderText("(12.5 * 4) + 18%")
        result = QLabel("0"); result.setFont(font(32, True)); result.setAlignment(Qt.AlignRight)
        history = QListWidget(); self.content_layout.addWidget(expression); self.content_layout.addWidget(result); self.content_layout.addWidget(history, 1)
        def calculate():
            try:
                value = evaluate_calculation(expression.text()); result.setText(str(value)); history.insertItem(0, f"{expression.text()} = {value}")
            except Exception as exc: result.setText("Error"); result.setToolTip(str(exc))
        expression.returnPressed.connect(calculate); self.content_layout.insertWidget(2, _button("Calculate", calculate, "#A7D8A1"), 0, Qt.AlignRight)

    def build_terminal_pro(self):
        self.build_terminal()
        banner = QLabel("Terminal Pro · tabs, history, aliases and ANSI-compatible process output")
        banner.setStyleSheet(f"color:{MUTED};")
        self.content_layout.insertWidget(0, banner)

    # --------------------------------------------------------------- platforms
    def build_game_launcher(self):
        self.heading("Game Launcher", "Unified launcher with Gaming Mode resource profile")
        listing = QListWidget(); self.content_layout.addWidget(listing, 1)
        games_file = DATA_DIR / "games.json"; games = _json_read(games_file, [])
        def refresh():
            listing.clear()
            for entry in games:
                item = QListWidgetItem(f"{entry.get('name')}\n{entry.get('path')}"); item.setData(Qt.UserRole, entry); listing.addItem(item)
        def add_game():
            def done(path): games.append({"name": path.stem, "path": str(path)}); _json_write(games_file, games); refresh()
            self._picker = InternalFilePicker(self.desktop, "Add game", "open", done)
        def launch():
            item = listing.currentItem()
            if not item: return
            settings = load_settings(); settings["performance_mode"] = "performance"; settings["gaming_mode"] = True; save_settings(settings); self.desktop.apply_settings(settings)
            path = Path(item.data(Qt.UserRole)["path"])
            try: subprocess.Popen([str(path)]); self.desktop.notch.notify(f"Launching {path.stem}")
            except OSError as exc: self.desktop.show_system_message("Game Launcher", str(exc))
        row = QHBoxLayout(); row.addWidget(_button("Add game", add_game, "#A7D8A1")); row.addWidget(_button("Launch in Gaming Mode", launch, "#8AB4F8")); row.addStretch(); self.content_layout.insertLayout(1, row); refresh()

    def build_spaces(self):
        self.heading("Spaces", "Separate app, theme and performance contexts for work, study and play")
        listing = QListWidget(); self.content_layout.addWidget(listing, 1)
        def refresh():
            listing.clear(); active = self.desktop.space_manager.active().key
            for space in self.desktop.space_manager.list():
                item = QListWidgetItem(("● " if space.key == active else "○ ") + f"{space.name}\n{space.theme} · {space.performance} · {', '.join(space.apps)}"); item.setData(Qt.UserRole, space.key); listing.addItem(item)
        def activate():
            item = listing.currentItem()
            if not item: return
            try:
                self.desktop.activate_space(item.data(Qt.UserRole), launch_apps=True)
            except (KeyError, ValueError, RuntimeError) as exc:
                self.desktop.show_system_message("Spaces", str(exc))
            refresh()
        def create():
            self.desktop.show_text_prompt("Create Space", "Name", lambda name: (self.desktop.space_manager.save(name, theme=load_settings().get("ui_style", "nexora_glass"), performance=load_settings().get("performance_mode", "balanced"), apps=()), refresh()), "New Space")
        row = QHBoxLayout(); row.addWidget(_button("Activate", activate, "#8AB4F8")); row.addWidget(_button("Create from current profile", create, "#A7D8A1")); row.addStretch(); self.content_layout.insertLayout(1, row); listing.itemDoubleClicked.connect(lambda *_: activate()); refresh()

    def build_automation(self):
        self.heading("Automation", "Local event scenarios with explicit, safe actions")
        listing = QListWidget(); self.content_layout.addWidget(listing, 1)
        trigger = QComboBox(); trigger.addItem("On Nexora start", "startup"); trigger.addItem("When monitor connects", "monitor_connected"); trigger.addItem("When battery is low", "battery_low")
        action = QComboBox(); action.addItem("Enable performance mode", {"type": "set_setting", "key": "performance_mode", "value": "performance"}); action.addItem("Enable battery saver", {"type": "set_setting", "key": "performance_mode", "value": "battery_saver"}); action.addItem("Enable Focus", {"type": "set_setting", "key": "focus_mode", "value": True}); action.addItem("Show notification", {"type": "notify", "title": "Automation", "message": "Scenario completed"})
        def refresh():
            listing.clear()
            for scenario in self.desktop.scenario_engine.list():
                item = QListWidgetItem(f"{'On' if scenario.enabled else 'Off'} · {scenario.name}\n{scenario.trigger.get('type')} → {len(scenario.actions)} action(s)")
                item.setData(Qt.UserRole, scenario.scenario_id); listing.addItem(item)
        def selected():
            item = listing.currentItem(); return item.data(Qt.UserRole) if item else None
        def add():
            name = f"{trigger.currentText()} → {action.currentText()}"; self.desktop.scenario_engine.save(name, {"type": trigger.currentData()}, [action.currentData()]); refresh()
        def toggle():
            sid = selected()
            scenario = next((item for item in self.desktop.scenario_engine.list() if item.scenario_id == sid), None)
            if scenario:
                self.desktop.scenario_engine.save(scenario.name, scenario.trigger, scenario.actions, enabled=not scenario.enabled, scenario_id=scenario.scenario_id); refresh()
        def run_now():
            sid = selected()
            scenario = next((item for item in self.desktop.scenario_engine.list() if item.scenario_id == sid), None)
            if not scenario: return
            try:
                for command in scenario.actions: self.desktop._execute_automation_action(dict(command))
                self.desktop.notch.notify("Scenario completed")
            except (OSError, RuntimeError, TypeError, ValueError, KeyError) as exc:
                self.desktop.show_system_message("Automation", str(exc))
        def delete():
            sid = selected()
            if sid: self.desktop.scenario_engine.delete(sid); refresh()
        row = QHBoxLayout(); row.addWidget(trigger); row.addWidget(action); row.addWidget(_button("Add", add, "#A7D8A1")); row.addWidget(_button("Run now", run_now, "#8AB4F8")); row.addWidget(_button("Enable / disable", toggle, "#FFD18A")); row.addWidget(_button("Delete", delete, "#F4A7B9")); self.content_layout.insertLayout(1, row); refresh()

    def build_extensions(self):
        self.heading("Extensions", "Validated declarative extensions compatible with Nexora API v1")
        listing = QListWidget(); self.content_layout.addWidget(listing, 1)
        def refresh():
            listing.clear()
            for ext in self.desktop.extension_manager.discover():
                item = QListWidgetItem(f"{'Enabled' if ext.enabled else 'Disabled'} · {ext.name} {ext.version}\n{ext.extension_id} · permissions: {', '.join(ext.permissions) or 'none'}")
                item.setData(Qt.UserRole, ext.extension_id); listing.addItem(item)
        def toggle():
            item = listing.currentItem()
            if not item: return
            ext = next((x for x in self.desktop.extension_manager.discover() if x.extension_id == item.data(Qt.UserRole)), None)
            if ext: self.desktop.extension_manager.set_enabled(ext.extension_id, not ext.enabled); refresh()
        row = QHBoxLayout(); row.addWidget(_button("Refresh", refresh)); row.addWidget(_button("Enable / disable", toggle, "#FFD18A")); row.addWidget(_button("Open extensions folder", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.desktop.extension_manager.root))), "#8AB4F8")); row.addStretch(); self.content_layout.insertLayout(1, row); refresh()


    # ---------------------------------------------------------- CONTINUUM
    def build_continuum(self):
        """Local workspace continuity engine: captures, restores and bundles context."""
        self.heading("Continuum", "Save complete working contexts and restore them as one action")
        state_path = DATA_DIR / "continuum_workspaces.json"
        data = _json_read(state_path, {"workspaces": [], "timeline": []})

        name = QLineEdit(); name.setPlaceholderText("Workspace name, e.g. Nexora UI sprint")
        note = QLineEdit(); note.setPlaceholderText("Optional intent or next step")
        capture = _button("Capture current context", color="#7C5CFC")
        restore = _button("Restore selected", color="#38BFA7")
        remove = _button("Delete", color="#F06A78")
        row = QHBoxLayout(); row.addWidget(name, 1); row.addWidget(note, 2); row.addWidget(capture)
        actions = QHBoxLayout(); actions.addWidget(restore); actions.addWidget(remove); actions.addStretch(1)
        workspaces = QListWidget(); workspaces.setSelectionMode(QAbstractItemView.SingleSelection)
        timeline = QTextBrowser(); timeline.setOpenExternalLinks(False)
        timeline.setStyleSheet(glass_input_css("#7C5CFC"))
        self.content_layout.addLayout(row); self.content_layout.addWidget(workspaces, 1); self.content_layout.addLayout(actions)
        self.content_layout.addWidget(QLabel("Local activity timeline")); self.content_layout.addWidget(timeline, 1)

        def current_context():
            opened=[]
            for window in getattr(self.desktop, "windows", []):
                if window is self or not window.isVisible(): continue
                opened.append({"app": getattr(window, "title", "Application"), "geometry": [window.x(),window.y(),window.width(),window.height()]})
            return {"apps": opened, "theme": load_settings().get("ui_style","nexora_glass"), "created": datetime.now().isoformat(timespec="seconds")}

        def refresh():
            workspaces.clear()
            for item in data.get("workspaces", []):
                label=f"{item['name']}  ·  {len(item.get('context',{}).get('apps',[]))} apps  ·  {item.get('context',{}).get('created','')}"
                q=QListWidgetItem(label); q.setData(Qt.UserRole, item.get("id")); workspaces.addItem(q)
            timeline.setHtml("<br>".join(f"<b>{html.escape(e.get('time',''))}</b> — {html.escape(e.get('event',''))}" for e in reversed(data.get("timeline", [])[-80:])))

        def persist(): _json_write(state_path, data); refresh()
        def log(event):
            data.setdefault("timeline", []).append({"time":datetime.now().isoformat(timespec="seconds"),"event":event})
            data["timeline"] = data["timeline"][-200:]

        def capture_now():
            title=name.text().strip() or f"Workspace {len(data.get('workspaces',[]))+1}"
            item={"id":secrets.token_hex(6),"name":title,"note":note.text().strip(),"context":current_context()}
            data.setdefault("workspaces", []).append(item); log(f"Captured {title}"); persist(); name.clear(); note.clear()

        def selected():
            item=workspaces.currentItem(); ident=item.data(Qt.UserRole) if item else None
            return next((x for x in data.get("workspaces",[]) if x.get("id")==ident),None)

        def restore_now():
            item=selected()
            if not item: return
            available={app_name(p):p for p in self.desktop.app_paths}
            for entry in item.get("context",{}).get("apps",[]):
                path=available.get(entry.get("app"))
                if path: self.desktop.open_app(path)
            log(f"Restored {item['name']}"); persist()
            self.desktop.show_system_message("Continuum", f"Restored {item['name']}")

        def delete_now():
            item=selected()
            if not item: return
            data["workspaces"]=[x for x in data.get("workspaces",[]) if x.get("id")!=item.get("id")]
            log(f"Deleted {item['name']}"); persist()

        capture.clicked.connect(capture_now); restore.clicked.connect(restore_now); remove.clicked.connect(delete_now)
        refresh()
