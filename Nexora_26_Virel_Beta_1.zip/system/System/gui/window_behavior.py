from .shared import *

try:
    from shiboken6 import isValid as shiboken_is_valid
except ImportError:
    def shiboken_is_valid(obj):
        return obj is not None


class SnapLayoutPicker(QWidget):
    """Windows-style glass palette containing complete snap arrangements."""
    LAYOUTS = (
        ("full", "Full"),
        ("halves", "Two columns"),
        ("quarters", "Four corners"),
        ("wide_left", "Wide left"),
        ("wide_right", "Wide right"),
        ("three", "Three columns"),
        ("main_stack", "Main + stack"),
    )

    def __init__(self, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(820, 154)
        self.hovered_layout = None
        self.hovered_slot = None
        self._cells = []
        self.hide()

    @staticmethod
    def normalized_slots(key):
        if key == "full": return ((0,0,1,1),)
        if key == "halves": return ((0,0,.5,1),(.5,0,.5,1))
        if key == "quarters": return ((0,0,.5,.5),(.5,0,.5,.5),(0,.5,.5,.5),(.5,.5,.5,.5))
        if key == "wide_left": return ((0,0,.66,1),(.66,0,.34,1))
        if key == "wide_right": return ((0,0,.34,1),(.34,0,.66,1))
        if key == "three": return ((0,0,1/3,1),(1/3,0,1/3,1),(2/3,0,1/3,1))
        return ((0,0,.66,1),(.66,0,.34,.5),(.66,.5,.34,.5))

    @classmethod
    def layout_rects(cls, key, host_rect, gap=12):
        area = host_rect.adjusted(gap, gap, -gap, -gap)
        result=[]
        for nx,ny,nw,nh in cls.normalized_slots(key):
            x=area.x()+round(nx*area.width())
            y=area.y()+round(ny*area.height())
            w=round(nw*area.width())
            h=round(nh*area.height())
            result.append(QRect(x+gap//2, y+gap//2, max(260,w-gap), max(210,h-gap)))
        return result

    def reposition(self):
        host=self.parentWidget(); self.move(max(10,(host.width()-self.width())//2),10); self.raise_()

    def reveal(self):
        host=self.parentWidget(); target=QPoint(max(10,(host.width()-self.width())//2),10)
        if not self.isVisible():
            self.move(target.x(),-self.height()+12); self.show(); self.raise_()
            self._reveal_anim=QPropertyAnimation(self,b"pos",self)
            self._reveal_anim.setStartValue(self.pos()); self._reveal_anim.setEndValue(target)
            self._reveal_anim.setDuration(180); self._reveal_anim.setEasingCurve(enter_curve()); self._reveal_anim.start()
        else:
            self.move(target); self.raise_()
        self.update()

    def dismiss(self):
        self.hovered_layout=None; self.hovered_slot=None; self.hide()

    def _cell_rects(self):
        margin=18; gap=10; top=42; count=len(self.LAYOUTS)
        cell_w=(self.width()-margin*2-gap*(count-1))//count
        return [(key,QRect(margin+i*(cell_w+gap),top,cell_w,92)) for i,(key,_label) in enumerate(self.LAYOUTS)]

    @classmethod
    def _slot_rects_in_preview(cls,key,preview):
        rects=[]; gap=3
        for nx,ny,nw,nh in cls.normalized_slots(key):
            r=QRect(preview.x()+round(nx*preview.width()), preview.y()+round(ny*preview.height()), round(nw*preview.width()), round(nh*preview.height()))
            rects.append(r.adjusted(gap,gap,-gap,-gap))
        return rects

    def update_hover(self,global_pos):
        local=self.mapFromGlobal(global_pos); layout=None; slot=None
        cells=self._cells or self._cell_rects()
        for key,rect in cells:
            if rect.contains(local):
                layout=key; preview=rect.adjusted(10,9,-10,-25)
                slots=self._slot_rects_in_preview(key,preview)
                for idx,srect in enumerate(slots):
                    if srect.contains(local): slot=idx; break
                if slot is None and slots: slot=0
                break
        if (layout,slot)!=(self.hovered_layout,self.hovered_slot):
            self.hovered_layout,self.hovered_slot=layout,slot; self.update()
        return (layout,slot) if layout is not None else None

    def chosen_at(self,global_pos):
        return self.update_hover(global_pos) if self.isVisible() else None

    def paintEvent(self,event):
        dark=str(load_settings().get("theme_mode","light")).lower()=="dark"
        painter=QPainter(self); painter.setRenderHint(QPainter.Antialiasing,True)
        panel=self.rect().adjusted(3,3,-3,-3)
        desktop=self.window(); blurred=getattr(desktop,"blurred_scaled",None)
        if blurred is not None and not blurred.isNull():
            top_left=self.mapTo(desktop,QPoint(0,0)); painter.save(); clip=QPainterPath(); clip.addRoundedRect(panel,24,24); painter.setClipPath(clip); painter.drawPixmap(self.rect(),blurred,QRect(top_left,self.size())); painter.restore()
        top=QColor(24,29,38,148) if dark else QColor(238,245,251,142)
        bottom=QColor(17,21,29,136) if dark else QColor(215,228,240,128)
        fg=QColor(255,255,255,235) if dark else QColor(17,19,24,235)
        border=QColor(255,255,255,78) if dark else QColor(255,255,255,165)
        grad=QLinearGradient(0,panel.top(),0,panel.bottom()); grad.setColorAt(0,top); grad.setColorAt(1,bottom)
        painter.setPen(border); painter.setBrush(grad); painter.drawRoundedRect(panel,24,24)
        painter.setPen(fg); painter.setFont(font(11,True)); painter.drawText(20,29,"Snap layouts")
        painter.setFont(font(7)); self._cells=self._cell_rects(); labels=dict(self.LAYOUTS)
        for key,rect in self._cells:
            active=key==self.hovered_layout
            painter.setPen(QColor(91,166,255,210) if active else QColor(border))
            painter.setBrush(QColor(63,139,255,72) if active else QColor(255,255,255,14 if dark else 62))
            painter.drawRoundedRect(rect,13,13)
            preview=rect.adjusted(10,9,-10,-25)
            for idx,srect in enumerate(self._slot_rects_in_preview(key,preview)):
                selected=active and idx==self.hovered_slot
                painter.setPen(Qt.NoPen)
                painter.setBrush(QColor(92,169,255,235) if selected else QColor(142,183,226,150))
                painter.drawRoundedRect(srect,4,4)
            painter.setPen(fg if active else QColor(fg.red(),fg.green(),fg.blue(),165))
            painter.drawText(rect.adjusted(3,68,-3,-2),Qt.AlignCenter,labels[key])


class SnapAssistOverlay(QWidget):
    """Interactive companion-window chooser shown after the first snap."""
    def __init__(self, desktop, source, layout_key, chosen_slot):
        super().__init__(desktop.app_layer)
        self.desktop=desktop; self.source=source; self.layout_key=layout_key
        self.slots=SnapLayoutPicker.layout_rects(layout_key,desktop.app_layer.rect(),int(load_settings().get("widget_gap",12)))
        self.remaining=[i for i in range(len(self.slots)) if i!=chosen_slot]
        self.candidates=[]; seen=set()
        for group in desktop.window_groups.values():
            for window in group:
                if window is source or not window.isVisible() or id(window) in seen: continue
                seen.add(id(window)); self.candidates.append(window)
        self.active_slot=0; self.cards=[]; self.hovered=None
        self.setMouseTracking(True); self.setAttribute(Qt.WA_TranslucentBackground,True)
        self.setGeometry(desktop.app_layer.rect()); self.show(); self.raise_(); self.update()
        if not self.remaining: QTimer.singleShot(0,self.close)

    def _target(self): return self.slots[self.remaining[self.active_slot]]

    def _card_layout(self):
        target=self._target().adjusted(18,18,-18,-18)
        entries=self.candidates+[None]
        cols=2 if target.width()<700 else 3
        gap=12; rows=max(1,(len(entries)+cols-1)//cols)
        cw=max(120,(target.width()-gap*(cols-1))//cols); ch=max(90,min(170,(target.height()-gap*(rows-1))//rows))
        cards=[]
        for i,item in enumerate(entries):
            r=i//cols; c=i%cols
            cards.append((item,QRect(target.x()+c*(cw+gap),target.y()+r*(ch+gap),cw,ch)))
        return cards

    def paintEvent(self,event):
        dark=str(load_settings().get("theme_mode","light")).lower()=="dark"
        p=QPainter(self); p.setRenderHint(QPainter.Antialiasing,True)
        p.fillRect(self.rect(),QColor(4,8,14,30 if dark else 14))
        target=self._target(); p.setPen(QPen(QColor(92,169,255,210),2)); p.setBrush(QColor(47,126,235,42)); p.drawRoundedRect(target,24,24)
        self.cards=self._card_layout(); fg=QColor(255,255,255,235) if dark else QColor(17,19,24,235)
        for item,rect in self.cards:
            active=item is self.hovered
            p.setPen(QColor(104,177,255,230) if active else QColor(255,255,255,90 if dark else 180))
            p.setBrush(QColor(35,42,54,168) if dark else QColor(235,243,250,166))
            p.drawRoundedRect(rect,18,18)
            if item is None:
                p.setPen(fg); p.setFont(font(10,True)); p.drawText(rect,Qt.AlignCenter,"Leave empty")
            else:
                try: shot=item.grab(); image=rect.adjusted(10,10,-10,-34); p.drawPixmap(image,shot,shot.rect())
                except RuntimeError: pass
                p.setPen(fg); p.setFont(font(8,True)); p.drawText(rect.adjusted(8,rect.height()-28,-8,-5),Qt.AlignCenter,getattr(item,"title","Window"))

    def mouseMoveEvent(self,e):
        pos=e.position().toPoint(); hovered=None
        for item,rect in self.cards:
            if rect.contains(pos): hovered=item; break
        if hovered is not self.hovered: self.hovered=hovered; self.update()

    def mousePressEvent(self,e):
        if e.button()!=Qt.LeftButton: return
        pos=e.position().toPoint(); chosen='miss'
        for item,rect in self.cards:
            if rect.contains(pos): chosen=item; break
        if chosen=='miss': return
        if chosen is not None:
            target=self._target(); chosen._normal_geometry=QRect(target); chosen._zoomed=False
            if load_settings().get("animations",True): chosen._animate(chosen.geometry(),target,1,1,170)
            else: chosen.setGeometry(target)
            chosen.raise_(); self.candidates=[w for w in self.candidates if w is not chosen]
        self.active_slot+=1
        if self.active_slot>=len(self.remaining): self.close()
        else: self.hovered=None; self.update()

    def close(self):
        """Close once; Qt may already have deleted the C++ object."""
        try:
            if not shiboken_is_valid(self):
                return
            owner = getattr(self, "desktop", None)
            if owner is not None and getattr(owner, "_snap_assist", None) is self:
                owner._snap_assist = None
            self.hide()
            self.deleteLater()
        except RuntimeError:
            return


class WindowBehaviorMixin:
    def _install_resize_tracking(self):
        """Install a small, fixed set of resize observers.

        Older builds installed a Python event filter on every child widget.
        Settings and Files can contain hundreds of controls, so every mouse move
        crossed Python dozens of times and caused measurable input delay.  Edge
        resizing only needs the window and its three main surfaces.
        """
        widgets = [self]
        for name in ("titlebar", "body", "content", "sidebar"):
            widget = getattr(self, name, None)
            if widget is not None:
                widgets.append(widget)
        seen = set()
        for widget in widgets:
            if id(widget) in seen:
                continue
            seen.add(id(widget))
            widget.setMouseTracking(True)
            widget.installEventFilter(self)

        # Cache expensive descendant queries once.  They are reused by the
        # coalesced containment pass instead of findChildren() on every resize.
        self._containment_scrolls = self.findChildren(QScrollArea)
        self._containment_views = []
        for view_type in (QListWidget, QTreeWidget, QTableWidget, QStackedWidget):
            self._containment_views.extend(self.findChildren(view_type))
        self._containment_layouts = [
            layout for layout in (
                getattr(self, "_outer_layout", None),
                getattr(self, "body_layout", None),
                getattr(self, "content_layout", None),
            ) if layout is not None
        ]
        self._containment_pending = False

    def _local_point_from_watched(self, watched, event):
        try:
            point = event.position().toPoint()
            return point if watched is self else watched.mapTo(self, point)
        except (AttributeError, RuntimeError):
            return QPoint(-1000, -1000)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        width = max(1, self.width())
        if hasattr(self, "sidebar"):
            if not getattr(self, "sidebar_enabled", False):
                self.sidebar.setFixedWidth(0)
            elif width < 650:
                self.sidebar.setMinimumWidth(168); self.sidebar.setMaximumWidth(196)
            elif width < 820:
                self.sidebar.setMinimumWidth(196); self.sidebar.setMaximumWidth(228)
            else:
                self.sidebar.setMinimumWidth(220); self.sidebar.setMaximumWidth(272)
        if hasattr(self, "content_layout"):
            margin = 12 if width < 620 else (17 if width < 820 else 24)
            self.content_layout.setContentsMargins(margin, margin, margin, margin)

        # Collapse a burst of resize events into one layout pass.  Native window
        # drags can emit hundreds of events per second; activating layouts and
        # walking the widget tree in each event caused the input lag.
        if not getattr(self, "_containment_pending", False):
            self._containment_pending = True
            QTimer.singleShot(0, self._apply_containment)
        self.updateMask()

    def _apply_containment(self):
        self._containment_pending = False
        if not self.isVisible():
            return
        if hasattr(self, "body") and hasattr(self, "content"):
            available_w = max(0, self.body.width() - (self.sidebar.width() if hasattr(self, "sidebar") else 0))
            available_h = max(0, self.body.height())
            self.content.setMaximumSize(available_w, available_h)

        for scroll in getattr(self, "_containment_scrolls", ()):
            try:
                scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
                scroll.setWidgetResizable(True)
                scroll.setMinimumSize(0, 0)
                host = scroll.widget()
                if host is not None:
                    host.setMinimumSize(0, 0)
                    host.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
                    viewport_w = scroll.viewport().width()
                    if viewport_w > 0 and host.width() != viewport_w:
                        host.resize(viewport_w, max(host.minimumSizeHint().height(), scroll.viewport().height()))
            except RuntimeError:
                pass

        seen = set()
        for view in getattr(self, "_containment_views", ()):
            if id(view) in seen:
                continue
            seen.add(id(view))
            try:
                view.setMinimumSize(0, 0)
                view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            except RuntimeError:
                pass

        for layout in getattr(self, "_containment_layouts", ()):
            try:
                layout.invalidate()
            except RuntimeError:
                pass

    def updateMask(self):
        self._mask_size = None
        self._sync_rounded_mask()

    def _edge_mask_at(self, point):
        margin = self._resize_margin
        edges = 0
        if point.x() <= margin:
            edges |= 1
        elif point.x() >= self.width() - margin - 1:
            edges |= 2
        if point.y() <= margin:
            edges |= 4
        elif point.y() >= self.height() - margin - 1:
            edges |= 8
        return edges

    @staticmethod
    def _cursor_for_edges(edges):
        if edges in (1 | 4, 2 | 8):
            return Qt.SizeFDiagCursor
        if edges in (2 | 4, 1 | 8):
            return Qt.SizeBDiagCursor
        if edges & 3:
            return Qt.SizeHorCursor
        if edges & 12:
            return Qt.SizeVerCursor
        return Qt.ArrowCursor

    def _resize_to_global(self, global_pos):
        host = self.parentWidget()
        if host is None or not self._resize_edges:
            return
        delta = global_pos - self._resize_origin_global
        rect = QRect(self._resize_origin_geometry)
        minimum_w = max(420, self.minimumWidth())
        minimum_h = max(300, self.minimumHeight())
        max_w = max(minimum_w, host.width())
        max_h = max(minimum_h, host.height())

        if self._resize_edges & 1:
            new_left = min(rect.right() - minimum_w + 1, rect.left() + delta.x())
            new_left = max(0, new_left)
            rect.setLeft(new_left)
        if self._resize_edges & 2:
            new_right = max(rect.left() + minimum_w - 1, rect.right() + delta.x())
            new_right = min(host.width() - 1, new_right)
            rect.setRight(new_right)
        if self._resize_edges & 4:
            new_top = min(rect.bottom() - minimum_h + 1, rect.top() + delta.y())
            new_top = max(0, new_top)
            rect.setTop(new_top)
        if self._resize_edges & 8:
            new_bottom = max(rect.top() + minimum_h - 1, rect.bottom() + delta.y())
            new_bottom = min(host.height() - 1, new_bottom)
            rect.setBottom(new_bottom)

        rect.setWidth(min(rect.width(), max_w))
        rect.setHeight(min(rect.height(), max_h))
        self.setGeometry(rect)
        self._normal_geometry = QRect(rect)
        self._zoomed = False

    def eventFilter(self, watched, event):
        event_type = event.type()
        if event_type == QEvent.MouseMove:
            if self._resize_edges and event.buttons() & Qt.LeftButton:
                self._resize_to_global(event.globalPosition().toPoint())
                event.accept()
                return True
            point = self._local_point_from_watched(watched, event)
            edges = self._edge_mask_at(point)
            self.setCursor(self._cursor_for_edges(edges))
        elif event_type == QEvent.MouseButtonPress and event.button() == Qt.LeftButton:
            point = self._local_point_from_watched(watched, event)
            edges = self._edge_mask_at(point)
            if edges:
                self.desktop.activate_window(self)
                self._resize_edges = edges
                self._resize_origin_global = event.globalPosition().toPoint()
                self._resize_origin_geometry = QRect(self.geometry())
                self.raise_()
                event.accept()
                return True
        elif event_type == QEvent.MouseButtonRelease and self._resize_edges:
            self._resize_edges = 0
            self.unsetCursor()
            self.constrain_to_host()
            event.accept()
            return True
        elif event_type == QEvent.Leave and not self._resize_edges:
            self.unsetCursor()
        # This filter is installed on this window and all of its children.
        # Returning False lets the watched object continue normal processing.
        # Calling QWidget.eventFilter() here can re-enter the Python override on
        # macOS/PySide and turns one resize exception into dozens of nested
        # "Error calling Python override" messages.
        return False

    def constrain_to_host(self):
        host = self.parentWidget()
        if host is None or host.width() <= 0 or host.height() <= 0:
            return
        max_w = max(self.minimumWidth(), host.width() - 32)
        max_h = max(self.minimumHeight(), host.height() - 32)
        width = min(self.width(), max_w)
        height = min(self.height(), max_h)
        x = max(0, min(self.x(), host.width() - width))
        y = max(0, min(self.y(), host.height() - height))
        self.setGeometry(x, y, width, height)
        if self.isVisible() and self.animation is None:
            self._normal_geometry = self.geometry()

    def _ensure_drag_surfaces(self):
        if getattr(self, "_snap_picker", None) is None:
            self._snap_picker = SnapLayoutPicker(self.parentWidget())

    def _update_drag_feedback(self, global_pos: QPoint):
        self._ensure_drag_surfaces()
        now = time.monotonic()
        previous = getattr(self, "_drag_last_global", global_pos)
        elapsed = max(0.008, now - getattr(self, "_drag_last_time", now))
        vector = global_pos - previous
        speed = min(1.0, ((abs(vector.x()) + abs(vector.y())) / elapsed) / 1800.0)
        self._drag_last_global = QPoint(global_pos); self._drag_last_time = now

        host_local = self.parentWidget().mapFromGlobal(global_pos)
        picker = self._snap_picker
        inside_picker = picker.isVisible() and picker.geometry().contains(host_local)
        if host_local.y() <= 24 or inside_picker:
            picker.reveal(); picker.update_hover(global_pos)
        elif picker.isVisible() and host_local.y() > picker.geometry().bottom() + 22:
            picker.dismiss()

    def _apply_snap_choice(self, choice):
        host = self.parentWidget()
        if host is None or not choice:
            return
        layout_key, slot_index = choice
        gap = int(load_settings().get("widget_gap", 12))
        slots = SnapLayoutPicker.layout_rects(layout_key, host.rect(), gap)
        slot_index = max(0, min(int(slot_index), len(slots)-1))
        target = slots[slot_index]
        self._normal_geometry = QRect(target)
        self._zoomed = layout_key == "full"
        if load_settings().get("animations", True):
            self._animate(self.geometry(), target, 1.0, 1.0, 190)
        else:
            self.setGeometry(target)
        self.raise_()
        if load_settings().get("snap_assist", True) and len(slots) > 1:
            old = getattr(self.desktop, "_snap_assist", None)
            if old is not None:
                try:
                    if shiboken_is_valid(old):
                        old.close()
                except RuntimeError:
                    pass
                self.desktop._snap_assist = None
            overlay = SnapAssistOverlay(self.desktop, self, layout_key, slot_index)
            self.desktop._snap_assist = overlay
            overlay.destroyed.connect(lambda *_: setattr(self.desktop, "_snap_assist", None) if getattr(self.desktop, "_snap_assist", None) is overlay else None)

    def mousePressEvent(self, e):
        self.desktop.activate_window(self)
        if e.button() == Qt.LeftButton and self._edge_mask_at(e.position().toPoint()):
            self._resize_edges = self._edge_mask_at(e.position().toPoint())
            self._resize_origin_global = e.globalPosition().toPoint()
            self._resize_origin_geometry = QRect(self.geometry())
            e.accept(); return
        if e.button() == Qt.LeftButton and self.titlebar.geometry().contains(e.position().toPoint()):
            # AppWindow is a child of app_layer. frameGeometry().topLeft() is
            # parent-local, so mixing it with a global pointer adds the top
            # dock offset twice and makes the window jump upward.
            global_top_left = self.mapToGlobal(QPoint(0, 0))
            self.drag_offset = e.globalPosition().toPoint() - global_top_left
            self._drag_last_global = e.globalPosition().toPoint(); self._drag_last_time = time.monotonic()
            self._ensure_drag_surfaces(); self.raise_(); e.accept(); return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if e.buttons() & Qt.LeftButton and not self.drag_offset.isNull():
            if self._zoomed: self._zoomed = False
            global_pos = e.globalPosition().toPoint()
            pos = global_pos - self.drag_offset
            parent_global = self.parentWidget().mapToGlobal(QPoint(0,0)); pos -= parent_global
            x=max(0,min(pos.x(),self.parentWidget().width()-self.width()))
            y=max(0,min(pos.y(),self.parentWidget().height()-self.height()))
            self.move(x,y); self._normal_geometry=self.geometry()
            self._update_drag_feedback(global_pos)
            e.accept(); return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self,e):
        global_pos = e.globalPosition().toPoint()
        picker = getattr(self, "_snap_picker", None)
        choice = picker.chosen_at(global_pos) if picker is not None else None
        self.drag_offset=QPoint()
        if getattr(self, "_drag_warp_overlay", None) is not None:
            self._drag_warp_overlay.settle()
        if picker is not None: picker.dismiss()
        if choice: self._apply_snap_choice(choice)
        else: self.desktop.snap_window(self)
        super().mouseReleaseEvent(e)

    def toggle_zoom(self):
        if self.animation:
            return
        host = self.parentWidget()
        if host is None:
            return
        if self._zoomed:
            target = self._normal_geometry if self._normal_geometry.isValid() else QRect(24, 24, min(900, host.width()-48), min(620, host.height()-48))
            self._zoomed = False
        else:
            self._normal_geometry = self.geometry()
            target = QRect(12, 12, max(420, host.width()-24), max(300, host.height()-24))
            self._zoomed = True
        if load_settings().get("animations", True):
            self._animate(self.geometry(), target, 1.0, 1.0, 180)
        else:
            self.setGeometry(target)
        self.raise_()

    def toggle_pin(self):
        pinned=self.desktop.toggle_pin(self.path); self.pin_btn.setText("●" if pinned else "○"); self.pin_changed.emit(self,pinned)

    def _clear_animation_effect(self):
        effect = getattr(self, "_animation_effect", None)
        if effect is not None:
            try:
                self.setGraphicsEffect(None)
            except RuntimeError:
                pass
        self._animation_effect = None

    def _animate(self, start: QRect, end: QRect, opacity_start: float, opacity_end: float, duration: int, done=None):
        """Animate windows efficiently while preserving visible transitions.

        Position/opacity run at the display refresh cadence. Size changes are
        throttled to roughly 30 FPS because relaying out Settings/Files every
        frame is expensive on Intel macOS. The effect is removed immediately
        after completion, so normal window interaction stays fast.
        """
        if self.animation:
            try:
                self.animation.stop()
            except RuntimeError:
                pass
        self._clear_animation_effect()
        self.setGeometry(start)
        effect = QGraphicsOpacityEffect(self)
        effect.setOpacity(float(opacity_start))
        self.setGraphicsEffect(effect)
        self._animation_effect = effect
        duration = max(120, int(duration))
        size_changes = start.size() != end.size()

        if size_changes:
            animation = QVariantAnimation(self)
            animation.setStartValue(0.0)
            animation.setEndValue(1.0)
            animation.setDuration(duration)
            animation.setEasingCurve(enter_curve())
            last_layout_frame = [0.0]

            def frame(value):
                t = float(value)
                now = time.monotonic()
                # Geometry changes trigger complete child layout; cap only those
                # frames while opacity is still updated smoothly by Qt.
                if t < 1.0 and now - last_layout_frame[0] < 1.0 / 30.0:
                    effect.setOpacity(opacity_start + (opacity_end - opacity_start) * t)
                    return
                last_layout_frame[0] = now
                x = round(start.x() + (end.x() - start.x()) * t)
                y = round(start.y() + (end.y() - start.y()) * t)
                w = round(start.width() + (end.width() - start.width()) * t)
                h = round(start.height() + (end.height() - start.height()) * t)
                self.setGeometry(x, y, w, h)
                effect.setOpacity(opacity_start + (opacity_end - opacity_start) * t)

            animation.valueChanged.connect(frame)
        else:
            group = QParallelAnimationGroup(self)
            pos_anim = QPropertyAnimation(self, b"pos", group)
            pos_anim.setStartValue(start.topLeft())
            pos_anim.setEndValue(end.topLeft())
            pos_anim.setDuration(duration)
            pos_anim.setEasingCurve(enter_curve())
            opacity_anim = QPropertyAnimation(effect, b"opacity", group)
            opacity_anim.setStartValue(float(opacity_start))
            opacity_anim.setEndValue(float(opacity_end))
            opacity_anim.setDuration(duration)
            opacity_anim.setEasingCurve(enter_curve())
            group.addAnimation(pos_anim)
            group.addAnimation(opacity_anim)
            animation = group

        def finished():
            self.setGeometry(end)
            self._clear_animation_effect()
            self.animation = None
            if done:
                done()

        animation.finished.connect(finished)
        self.animation = animation
        animation.start()


    def animate_open(self):
        settings = load_settings()
        # The window is already shown by AppWindow.__init__. Calling show()
        # again caused an extra native compositor transaction on macOS.
        # Keep the opening motion deliberately short. AppWindow is a child
        # widget, so this transition does not create a native macOS window.
        app = QApplication.instance()
        if not settings.get("animations", True) or (app is not None and app.platformName().lower() == "offscreen"):
            self.setWindowOpacity(1.0)
            return
        end = QRect(self.geometry())
        start = end.translated(0, 16)
        self._animate(start, end, 0.18, 1.0, max(180, min(240, MOTION.window_open)))

    def _taskbar_animation_target(self) -> QRect:
        host = self.parentWidget()
        if host is None:
            return QRect(self.geometry())
        center_x = host.width() // 2
        target_y = max(0, host.height() - 52)
        return QRect(center_x - self.width() // 2, target_y, self.width(), self.height())

    def minimize_animated(self):
        if self.animation:
            return
        self._normal_geometry = self.geometry()
        if not load_settings().get("animations", True):
            self.hide(); self.minimized.emit(self); return
        start = QRect(self.geometry())
        end = self._taskbar_animation_target()
        self._animate(start, end, 1.0, 0.0, 165, lambda: (self.hide(), self.minimized.emit(self)))

    def restore_animated(self):
        if self.animation:
            return
        target = QRect(self._normal_geometry)
        self.show(); self.raise_()
        if load_settings().get("animations", True):
            self._animate(self._taskbar_animation_target(), target, 0.0, 1.0, 180)
        else:
            self.setGeometry(target)

    def close_animated(self):
        if self.animation:
            return
        if not load_settings().get("animations", True):
            self.closed.emit(self); return
        start = QRect(self.geometry())
        end = start.translated(0, 18)
        self._animate(start, end, 1.0, 0.0, 145, lambda: self.closed.emit(self))
