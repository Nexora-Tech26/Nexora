import logging
from .shared import *

class DesktopDockMixin:
    def set_app_badge(self, path, count=0):
        path = Path(path).resolve(); value = max(0, int(count))
        if value: self.app_badges[path] = value
        else: self.app_badges.pop(path, None)
        self.refresh_taskbar()

    def set_app_progress(self, path, value=None):
        path = Path(path).resolve()
        if value is None: self.app_progress.pop(path, None)
        else: self.app_progress[path] = max(0, min(100, int(value)))
        self.refresh_taskbar()

    def open_trash(self):
        files_path = next((path for path in self.app_paths if app_name(path) == "Files"), None)
        if files_path is None: return
        self.open_app(files_path); window = self.windows.get(Path(files_path).resolve())
        if window is not None and hasattr(window, "navigate_files"):
            window.navigate_files(NEXORA_HOME / ".Trash")

    def _dock_shell_hover(self, entered):
        # Geometry must never change on hover. Earlier builds resized the shell,
        # which made the taskbar appear to sink and become shorter.
        self._dock_hover_active = False
        self._dock_pointer_x = None
        self._dock_pointer_y = None
        if self._dock_anim_timer.isActive():
            self._dock_anim_timer.stop()

    def _dock_pointer_moved(self, pos):
        # Keep hover purely visual; do not animate icon or shell dimensions.
        self._dock_hover_active = False
        self._dock_pointer_x = None
        self._dock_pointer_y = None

    def _clear_dock_drop_target(self):
        previous = getattr(self, "_dock_drop_target", None)
        if previous is not None:
            button = self.task_buttons.get(previous)
            if button is not None:
                button.setStyleSheet(getattr(button, "_base_style", button.styleSheet()))
        self._dock_drop_target = None

    def _dock_drag_start(self, path, _global_pos):
        self._dock_drag_path = Path(path).resolve()
        self.dock_preview.cancel_request()
        self._clear_dock_drop_target()

    def _dock_target_at(self, global_pos):
        best = None
        best_distance = float("inf")
        profile = panel_profile()
        vertical = bool(profile.get("vertical"))
        for candidate, button in self.task_buttons.items():
            top_left = button.mapToGlobal(QPoint(0, 0))
            rect = QRect(top_left, button.size()).adjusted(-8, -8, 8, 8)
            center = rect.center()
            distance = abs(global_pos.y() - center.y()) if vertical else abs(global_pos.x() - center.x())
            if rect.contains(global_pos):
                return candidate
            if distance < best_distance:
                best, best_distance = candidate, distance
        return best if best_distance <= 80 else None

    def _dock_drag_move(self, path, global_pos):
        path = Path(path).resolve()
        target = self._dock_target_at(global_pos)
        if target == path:
            target = None
        if target == getattr(self, "_dock_drop_target", None):
            return
        self._clear_dock_drop_target()
        if target is not None:
            button = self.task_buttons.get(target)
            if button is not None:
                button.setStyleSheet(getattr(button, "_base_style", button.styleSheet()) + "QPushButton{background:rgba(255,255,255,48);}")
                self._dock_drop_target = target

    def _dock_drag_finish(self, path, global_pos):
        path = Path(path).resolve()
        target = self._dock_target_at(global_pos)
        self._clear_dock_drop_target()
        self._dock_drag_path = None
        if path not in self.pinned:
            self.pinned.append(path)
        if target is not None and target != path and target in self.pinned:
            self.pinned.remove(path)
            target_index = self.pinned.index(target)
            target_button = self.task_buttons.get(target)
            profile = panel_profile()
            vertical = bool(profile.get("vertical"))
            after = False
            if target_button is not None:
                center = target_button.mapToGlobal(target_button.rect().center())
                after = global_pos.y() > center.y() if vertical else global_pos.x() > center.x()
            self.pinned.insert(target_index + (1 if after else 0), path)
        self.pinned = list(dict.fromkeys(Path(item).resolve() for item in self.pinned if Path(item).exists()))
        self.save_pins()
        self.refresh_taskbar()
        self.menu.refresh()
        self.notch.notify(f"Pinned {app_name(path)}" if target is None else f"Moved {app_name(path)}")

    def _dock_targets_from_pointer(self):
        buttons = list(self.task_buttons.values())
        if not buttons:
            return []
        # Icon magnification is intentionally disabled. Hover keeps a light
        # color response but never changes geometry or shifts the dock.
        base, _gap, _ = self._taskbar_metrics()
        return [float(base)] * len(buttons)
        base, _gap, _ = self._taskbar_metrics()
        profile = panel_profile()
        vertical = bool(profile.get("vertical"))
        if not self._dock_hover_active or (vertical and self._dock_pointer_y is None) or (not vertical and self._dock_pointer_x is None):
            return [float(base)] * len(buttons)
        local_pointer = self.task_shell.mapFromGlobal(QCursor.pos())
        pointer_axis = float(local_pointer.y() if vertical else local_pointer.x())
        targets = []
        # Continuous cosine falloff based on the actual cursor coordinate.
        # At an icon edge or between icons the magnification is naturally lower.
        influence = max(78.0, base * 1.8)
        strength = max(0.0, min(1.5, float(load_settings().get("dock_magnification", 100)) / 100.0))
        max_extra = min(26.0, base * 0.52) * strength
        for button in buttons:
            center_point = button.geometry().center()
            center = float(center_point.y() if vertical else center_point.x())
            distance = abs(pointer_axis - center)
            if distance >= influence:
                weight = 0.0
            else:
                import math
                weight = 0.5 * (1.0 + math.cos(math.pi * distance / influence))
            targets.append(float(base) + max_extra * weight)
        return targets

    def _dock_animation_tick(self):
        if getattr(self, "task_shell", None) is None or getattr(self, "task_backdrop", None) is None:
            timer = getattr(self, "_dock_anim_timer", None)
            if timer is not None:
                timer.stop()
            return
        buttons = list(self.task_buttons.values())
        base, _gap, _ = self._taskbar_metrics()
        for button in buttons:
            button.setFixedSize(base, base)
            button.setIconSize(QSize(max(32, base - 2), max(32, base - 2)))
        if hasattr(self, "_task_base_geometry"):
            self.task_shell.setGeometry(self._task_base_geometry)
        if hasattr(self, "_start_base_geometry"):
            self.start_button.setGeometry(self._start_base_geometry)
        profile = panel_profile()
        edge = profile.get("edge", "bottom")
        rect = self.task_shell.rect()
        if profile.get("vertical"):
            self.task_backdrop.setGeometry(0, 0, rect.width(), rect.height())
        else:
            self.task_backdrop.setGeometry(0, 0, rect.width(), rect.height())
        self._dock_render_sizes = [float(base)] * len(buttons)
        self._dock_anim_timer.stop()
        return
        if not buttons:
            self._dock_anim_timer.stop()
            return
        base, gap, _ = self._taskbar_metrics()
        targets = self._dock_targets_from_pointer()
        if len(self._dock_render_sizes) != len(buttons):
            self._dock_render_sizes = [float(button.width() or base) for button in buttons]

        # Exponential smoothing is framerate-independent enough at 60 FPS and
        # avoids the wooden effect caused by restarting QPropertyAnimations.
        smoothing = 0.30
        settled = True
        for index, target in enumerate(targets):
            current = self._dock_render_sizes[index]
            value = current + (target - current) * smoothing
            if abs(target - value) > 0.18:
                settled = False
            self._dock_render_sizes[index] = value
            size = max(base, int(round(value)))
            button = buttons[index]
            if button.width() != size or button.height() != size:
                button.setFixedSize(size, size)
                button.setIconSize(QSize(max(34, size - 2), max(34, size - 2)))

        margins = self.task_layout.contentsMargins()
        profile = panel_profile()
        vertical = bool(profile.get("vertical"))
        base_shell = QRect(getattr(self, "_task_base_geometry", self.task_shell.geometry()))
        current = self.task_shell.geometry()
        if vertical:
            natural_extent = int(round(sum(self._dock_render_sizes))) + gap * max(0, len(buttons)-1) + margins.top() + margins.bottom()
            target_extent = max(base_shell.height(), natural_extent)
            height = int(round(current.height() + (target_extent-current.height())*0.24))
            edge = profile.get("edge","right")
            y = base_shell.center().y() - height//2
            if edge == "right":
                shell_rect = QRect(base_shell.right()-base_shell.width()+1, y, base_shell.width(), height)
            else:
                shell_rect = QRect(base_shell.x(), y, base_shell.width(), height)
            self.task_shell.setGeometry(shell_rect)
            self.task_backdrop.setGeometry(20 if edge=="right" else 0, 0, max(1,shell_rect.width()-20), height)
            target_width = base_shell.width(); width = shell_rect.width()
        else:
            natural_extent = int(round(sum(self._dock_render_sizes))) + gap * max(0, len(buttons)-1) + margins.left() + margins.right()
            target_width = max(base_shell.width(), natural_extent)
            width = int(round(current.width() + (target_width-current.width())*0.24))
            x = base_shell.center().x() - width//2
            shell_rect = QRect(x, base_shell.y(), width, base_shell.height())
            self.task_shell.setGeometry(shell_rect)
            edge = profile.get("edge","bottom")
            backdrop_y = 0 if edge=="top" else 20
            self.task_backdrop.setGeometry(0, backdrop_y, width, max(1,shell_rect.height()-20))

        start_base = QRect(getattr(self, "_start_base_geometry", self.start_button.geometry()))
        if profile.get("width") == "full":
            self.start_button.move(shell_rect.x()+8,start_base.y())
        elif not vertical:
            self.start_button.move(shell_rect.x()-start_base.width()-8,start_base.y())
        if not self._dock_hover_active and settled and ((vertical and abs(self.task_shell.height()-base_shell.height())<=1) or (not vertical and abs(width-base_shell.width())<=1)):
            for button in buttons:
                button.setFixedSize(base, base)
                button.setIconSize(QSize(max(32, base - 2), max(32, base - 2)))
            self._dock_render_sizes = [float(base)] * len(buttons)
            self.task_shell.setGeometry(base_shell)
            edge=profile.get("edge","bottom")
            if vertical: self.task_backdrop.setGeometry(20 if edge=="right" else 0,0,max(1,base_shell.width()-20),base_shell.height())
            else: self.task_backdrop.setGeometry(0,0 if edge=="top" else 20,base_shell.width(),max(1,base_shell.height()-20))
            self.start_button.setGeometry(start_base)
            self._dock_anim_timer.stop()
        elif self._dock_hover_active and settled and ((vertical and abs(self.task_shell.height()-target_extent)<=1) or (not vertical and abs(width-target_width)<=1)):
            # Stop polling once the cursor-driven geometry has settled.
            # The next mouseMoveEvent restarts the timer, so stationary hover
            # costs no continuous CPU and no longer delays keyboard/mouse input.
            self._dock_anim_timer.stop()

    def _magnify_taskbar(self, hovered_index, entered):
        # Kept for existing signal connections. Magnification is cursor-driven,
        # not index-driven; DockShell.mouseMoveEvent supplies the exact position.
        if entered and not self._dock_anim_timer.isActive():
            self._dock_anim_timer.start()

    def task_click(self, path):
        path = Path(path).resolve()
        if not self.window_groups.get(path):
            self.open_app(path);return
        window=self.window_groups[path][-1]
        if window.isVisible():
            window.minimize_animated()
        else:
            window.restore_animated()

    def _app_locks(self):
        file = DATA_DIR / "app_locks.json"
        try:
            payload = json.loads(file.read_text(encoding="utf-8"))
            return payload if isinstance(payload, dict) else {}
        except (OSError, ValueError, TypeError) as exc:
            logging.getLogger(__name__).debug("Application lock store unavailable: %s", exc)
            return {}

    def _save_app_locks(self, data):
        file = DATA_DIR / "app_locks.json"
        file.parent.mkdir(parents=True, exist_ok=True)
        temporary = file.with_suffix(file.suffix + ".tmp")
        temporary.write_text(json.dumps(data, indent=2), encoding="utf-8")
        os.replace(temporary, file)

    @staticmethod
    def _hash_app_password(password):
        import hashlib
        import secrets
        iterations = 240_000
        salt = secrets.token_bytes(16)
        digest = hashlib.pbkdf2_hmac("sha256", str(password).encode("utf-8"), salt, iterations)
        return {"schema": 1, "algorithm": "pbkdf2-sha256", "iterations": iterations, "salt": salt.hex(), "digest": digest.hex()}

    @staticmethod
    def _verify_app_password(stored, password):
        import hashlib
        import hmac
        if isinstance(stored, str):
            return hmac.compare_digest(stored, str(password))
        if not isinstance(stored, dict) or stored.get("algorithm") != "pbkdf2-sha256":
            return False
        try:
            iterations = max(100_000, min(1_000_000, int(stored.get("iterations", 240_000))))
            salt = bytes.fromhex(str(stored["salt"]))
            expected = bytes.fromhex(str(stored["digest"]))
        except (KeyError, TypeError, ValueError):
            return False
        actual = hashlib.pbkdf2_hmac("sha256", str(password).encode("utf-8"), salt, iterations)
        return hmac.compare_digest(actual, expected)

    def add_app_to_desktop(self, path):
        path = Path(path).resolve(); target = NEXORA_HOME / "Desktop" / (app_name(path) + ".nexora-app")
        temporary = target.with_suffix(target.suffix + ".tmp")
        temporary.write_text(json.dumps({"app": str(path)}), encoding="utf-8")
        os.replace(temporary, target)
        self.refresh_desktop_shortcuts()
        self.notch.notify(f"{app_name(path)} added to Desktop")

    def set_app_lock(self, path):
        key = str(Path(path).resolve()); locks = self._app_locks(); current = locks.get(key, "")
        overlay = SystemOverlay(self, "Application lock", f"Protect {app_name(path)} with a local Nexora password.")
        current_field = QLineEdit(); current_field.setEchoMode(QLineEdit.Password); current_field.setPlaceholderText("Current password" if current else "No current password")
        current_field.setEnabled(bool(current)); current_field.setStyleSheet(glass_input_css(ACCENT))
        new_field = QLineEdit(); new_field.setEchoMode(QLineEdit.Password); new_field.setPlaceholderText("New password — leave empty to remove"); new_field.setStyleSheet(glass_input_css(ACCENT))
        overlay.layout().insertWidget(2, current_field); overlay.layout().insertWidget(3, new_field)
        error = QLabel(); error.setStyleSheet("color:#FF7777;background:transparent;"); overlay.layout().insertWidget(4, error)
        cancel = QPushButton("Cancel"); cancel.setStyleSheet(oneui_button_css("#B9A7E8", radius=13)); cancel.clicked.connect(overlay.deleteLater)
        save = QPushButton("Save"); save.setStyleSheet(oneui_button_css("#8AB4F8", radius=13))
        def apply_lock():
            if current and not self._verify_app_password(current, current_field.text()):
                error.setText("Incorrect current password."); return
            password = new_field.text()
            if password: locks[key] = self._hash_app_password(password)
            else: locks.pop(key, None)
            self._save_app_locks(locks); self.notch.notify("Application lock updated"); overlay.deleteLater()
        save.clicked.connect(apply_lock); new_field.returnPressed.connect(apply_lock)
        overlay.buttons.addWidget(cancel); overlay.buttons.addWidget(save)
        (current_field if current else new_field).setFocus()

    def task_context(self, path, button, pos):
        path=Path(path).resolve(); windows=list(self.window_groups.get(path,[]))
        menu=create_nexora_menu(self)
        launch=menu.addAction("Open")
        new_window=menu.addAction("New window")
        pin_action=menu.addAction("Unpin from dock" if self.is_pinned(path) else "Pin to dock")
        desktop_action=menu.addAction("Add to desktop")
        settings_action=menu.addAction("App settings")
        lock_action=menu.addAction("Change application password")
        close_window=menu.addAction("Close window") if windows else None
        close_all=menu.addAction("Close all windows") if len(windows)>1 else None
        core=app_name(path) in {"Files","Settings","Store","Welcome"}
        uninstall=menu.addAction("Uninstall") if not core else None
        chosen=menu.exec(button.mapToGlobal(pos))
        if chosen==launch:self.open_app(path)
        elif chosen==new_window:self.open_app_new(path)
        elif chosen==pin_action:self.toggle_pin(path)
        elif chosen==desktop_action:self.add_app_to_desktop(path)
        elif chosen==settings_action:
            settings_path=next((p for p in self.app_paths if app_name(p)=="Settings"),None)
            if settings_path:self.open_app(settings_path)
            else:self.show_system_message("App settings","Settings is unavailable.")
        elif chosen==lock_action:self.set_app_lock(path)
        elif close_window is not None and chosen==close_window:windows[-1].close_animated()
        elif close_all is not None and chosen==close_all:
            for window in windows:window.close_animated()
        elif uninstall is not None and chosen==uninstall:
            def remove_app():
                quarantine = DATA_DIR / "uninstalled_apps"
                quarantine.mkdir(parents=True, exist_ok=True)
                target = quarantine / f"{path.stem}-{int(time.time())}{path.suffix}"
                try:
                    shutil.move(str(path), str(target))
                except OSError as exc:
                    self.show_system_message("Uninstall", str(exc)); return
                self.pinned = [item for item in self.pinned if Path(item).resolve() != path]
                self.save_pins()
                self.reload_app_catalog(); self.refresh_taskbar(); self.menu.refresh()
                self.notch.notify(f"{app_name(path)} moved to the Nexora uninstall archive")
            self.show_confirm("Uninstall",f"Move {app_name(path)} to the recoverable uninstall archive?",remove_app)
