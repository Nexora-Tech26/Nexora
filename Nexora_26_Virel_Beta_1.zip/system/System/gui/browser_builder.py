"""Embedded Chromium browser for Nexora AppWindow.

The browser is a child widget inside Nexora's desktop surface. Qt WebEngine still
uses Chromium renderer subprocesses, but no separate macOS/Windows top-level
window is created.
"""
from __future__ import annotations
import os
import urllib.parse
from pathlib import Path

from PySide6.QtCore import QUrl, Qt
from PySide6.QtWidgets import QLabel, QHBoxLayout, QLineEdit, QPushButton, QTabWidget, QVBoxLayout, QWidget
from .shared import *

try:
    from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile
    from PySide6.QtWebEngineWidgets import QWebEngineView
    WEBENGINE_AVAILABLE = True
    WEBENGINE_ERROR = ""
except Exception as exc:
    QWebEnginePage = QWebEngineProfile = QWebEngineView = None
    WEBENGINE_AVAILABLE = False
    WEBENGINE_ERROR = str(exc)


class BrowserApplicationMixin:
    def build_browser(self):
        self.heading("Browser", "Nexora web browser")
        self._browser_views = []
        self._browser_profile = None

        nav = QWidget()
        nav.setObjectName("BrowserNavigation")
        row = QHBoxLayout(nav)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(0)

        self.browser_back = QPushButton("←")
        self.browser_forward = QPushButton("→")
        self.browser_reload = QPushButton("↻")
        self.browser_home = QPushButton("⌂")
        self.browser_address = QLineEdit()
        self.browser_address.setPlaceholderText("Search or enter address")
        self.browser_new_tab = QPushButton("+")

        controls = (self.browser_back, self.browser_forward, self.browser_reload, self.browser_home)
        for i, button in enumerate(controls):
            left = 13 if i == 0 else 0
            right = 13 if i == len(controls)-1 else 0
            button.setFixedSize(40, 38)
            button.setStyleSheet(
                f"QPushButton{{background:{rgba(self.accent,58)};border:none;padding:0;"
                f"border-top-left-radius:{left}px;border-bottom-left-radius:{left}px;"
                f"border-top-right-radius:{right}px;border-bottom-right-radius:{right}px;}}"
                f"QPushButton:hover{{background:{rgba(self.accent,92)};}}"
                f"QPushButton:pressed{{background:{rgba(self.accent,128)};}}"
            )
            row.addWidget(button)

        row.addSpacing(8)
        self.browser_address.setMinimumHeight(38)
        self.browser_address.setStyleSheet(glass_input_css(self.accent))
        row.addWidget(self.browser_address, 1)
        row.addSpacing(8)
        self.browser_new_tab.setFixedSize(40, 38)
        self.browser_new_tab.setStyleSheet(oneui_button_css(self.accent, radius=13))
        row.addWidget(self.browser_new_tab)
        self.content_layout.addWidget(nav)

        if not WEBENGINE_AVAILABLE:
            error = QLabel(
                "Browser engine is being repaired. Restart Nexora after the automatic dependency installation.\n\n"
                + WEBENGINE_ERROR
            )
            error.setWordWrap(True)
            error.setAlignment(Qt.AlignCenter)
            error.setStyleSheet(f"background:{rgba(self.accent,28)};border:none;border-radius:14px;padding:28px;color:{TEXT};")
            self.content_layout.addWidget(error, 1)
            return

        self.browser_tabs = QTabWidget()
        self.browser_tabs.setTabsClosable(True)
        self.browser_tabs.setMovable(True)
        self.browser_tabs.setDocumentMode(True)
        self.browser_tabs.setStyleSheet(
            f"QTabWidget::pane{{border:none;background:transparent;}}"
            f"QTabBar::tab{{background:{rgba(self.accent,30)};border:none;padding:8px 14px;margin:0;min-height:26px;}}"
            f"QTabBar::tab:first{{border-top-left-radius:11px;border-bottom-left-radius:11px;}}"
            f"QTabBar::tab:last{{border-top-right-radius:11px;border-bottom-right-radius:11px;}}"
            f"QTabBar::tab:selected{{background:{rgba(self.accent,92)};}}"
        )
        self.content_layout.addWidget(self.browser_tabs, 1)

        profile_root = PROJECT_ROOT / "Home" / "User" / ".browser"
        cache_dir = profile_root / "cache"
        storage_dir = profile_root / "storage"
        downloads_dir = PROJECT_ROOT / "Home" / "User" / "Downloads"
        for path in (cache_dir, storage_dir, downloads_dir):
            path.mkdir(parents=True, exist_ok=True)

        self._browser_profile = QWebEngineProfile("NexoraBrowser", self)
        self._browser_profile.setHttpUserAgent("Mozilla/5.0 Nexora/26 AppleWebKit/537.36 Chrome/131 Safari/537.36")
        self._browser_profile.setCachePath(str(cache_dir))
        self._browser_profile.setPersistentStoragePath(str(storage_dir))
        self._browser_profile.setDownloadPath(str(downloads_dir))
        try:
            self._browser_profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.AllowPersistentCookies)
            self._browser_profile.setHttpCacheType(QWebEngineProfile.HttpCacheType.DiskHttpCache)
        except (AttributeError, RuntimeError):
            pass
        self._browser_profile.downloadRequested.connect(self._browser_download)

        self.browser_address.returnPressed.connect(self._browser_go)
        self.browser_back.clicked.connect(lambda: self._browser_current_call("back"))
        self.browser_forward.clicked.connect(lambda: self._browser_current_call("forward"))
        self.browser_reload.clicked.connect(lambda: self._browser_current_call("reload"))
        self.browser_home.clicked.connect(lambda: self._browser_open_url(load_settings().get("browser_home", "https://www.google.com")))
        self.browser_new_tab.clicked.connect(lambda: self._browser_add_tab(load_settings().get("browser_home", "https://www.google.com")))
        self.browser_tabs.currentChanged.connect(self._browser_tab_changed)
        self.browser_tabs.tabCloseRequested.connect(self._browser_close_tab)
        self._browser_add_tab(load_settings().get("browser_home", "https://www.google.com"))

    def _browser_normalize(self, text):
        text = str(text or "").strip()
        if not text:
            return QUrl("https://www.google.com")
        if " " in text or ("." not in text and not text.startswith(("http://", "https://", "file://"))):
            return QUrl(str(load_settings().get("browser_search", "https://www.google.com/search?q={query}")).replace("{query}", urllib.parse.quote_plus(text)))
        if not text.startswith(("http://", "https://", "file://")):
            text = "https://" + text
        return QUrl(text)

    def _browser_current(self):
        if not WEBENGINE_AVAILABLE or not hasattr(self, "browser_tabs"):
            return None
        widget = self.browser_tabs.currentWidget()
        return widget if isinstance(widget, QWebEngineView) else None

    def _browser_add_tab(self, target):
        if not WEBENGINE_AVAILABLE or self._browser_profile is None:
            return
        view = QWebEngineView(self.browser_tabs)
        page = QWebEnginePage(self._browser_profile, view)
        view.setPage(page)
        index = self.browser_tabs.addTab(view, "New tab")
        self.browser_tabs.setCurrentIndex(index)
        self._browser_views.append(view)
        view.titleChanged.connect(lambda title, browser=view: self._browser_update_title(browser, title))
        view.urlChanged.connect(lambda url, browser=view: self._browser_url_changed(browser, url))
        view.renderProcessTerminated.connect(lambda *_args, browser=view: self._browser_renderer_failed(browser))
        view.loadFinished.connect(lambda ok, browser=view: self._browser_load_finished(browser, ok))
        view.setUrl(self._browser_normalize(target))

    def _browser_renderer_failed(self, view):
        if view is not None:
            view.setHtml("<html><body style='font-family:sans-serif;padding:32px'><h2>Page renderer stopped</h2><p>Reload this tab. Nexora Desktop remains active.</p></body></html>")

    def _browser_update_title(self, view, title):
        index = self.browser_tabs.indexOf(view)
        if index >= 0:
            self.browser_tabs.setTabText(index, (title or "New tab")[:28])

    def _browser_url_changed(self, view, url):
        if view is self._browser_current():
            self.browser_address.setText(url.toString())

    def _browser_tab_changed(self, _index):
        view = self._browser_current()
        if view is not None:
            self.browser_address.setText(view.url().toString())

    def _browser_close_tab(self, index):
        if self.browser_tabs.count() <= 1:
            self._browser_add_tab(load_settings().get("browser_home", "https://www.google.com"))
        view = self.browser_tabs.widget(index)
        self.browser_tabs.removeTab(index)
        if view in self._browser_views:
            self._browser_views.remove(view)
        if view is not None:
            view.stop()
            page = view.page()
            view.setPage(None)
            if page is not None:
                page.deleteLater()
            view.deleteLater()

    def _browser_current_call(self, method):
        view = self._browser_current()
        fn = getattr(view, method, None) if view is not None else None
        if callable(fn):
            fn()

    def _browser_open_url(self, target):
        view = self._browser_current()
        if view is not None:
            view.setUrl(self._browser_normalize(target))

    def _browser_go(self):
        self._browser_open_url(self.browser_address.text())

    def _browser_download(self, item):
        try:
            item.accept()
        except RuntimeError:
            pass
