"""Asynchronous Task Manager with processes, performance, startup and services."""
from __future__ import annotations

import os
import platform
import subprocess
from collections import deque
from pathlib import Path

from .shared import *


class ResourceGraph(QWidget):
    def __init__(self, title, parent=None):
        super().__init__(parent); self.title = title; self.values = deque([0.0] * 60, maxlen=60)
        self.setMinimumHeight(125); self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def append(self, value):
        self.values.append(max(0.0, min(100.0, float(value)))); self.update()

    def paintEvent(self, _event):
        painter = QPainter(self); painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen); painter.setBrush(QColor(255, 255, 255, 18)); painter.drawRoundedRect(self.rect(), 15, 15)
        painter.setPen(QPen(QColor(255, 255, 255, 48), 1))
        for row in range(1, 4):
            y = self.height() * row / 4; painter.drawLine(10, round(y), self.width() - 10, round(y))
        values = list(self.values)
        if len(values) > 1:
            path = QPainterPath(); width = max(1, self.width() - 20); height = max(1, self.height() - 34)
            for index, value in enumerate(values):
                x = 10 + width * index / (len(values) - 1); y = self.height() - 12 - height * value / 100
                path.moveTo(x, y) if index == 0 else path.lineTo(x, y)
            painter.setPen(QPen(QColor(138, 180, 248), 2.2, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)); painter.drawPath(path)
        painter.setPen(QColor(TEXT)); painter.setFont(font(9, True)); latest = values[-1] if values else 0
        painter.drawText(12, 20, f"{self.title}  {latest:.0f}%")


def _page():
    widget = QWidget(); layout = QVBoxLayout(widget); layout.setContentsMargins(0, 0, 0, 0); layout.setSpacing(10)
    return widget, layout


def build_task_manager_ui(self):
    self.heading("Task Manager", "Processes, performance, startup items and platform services")
    self.task_manager_refreshing = False; self.task_manager_rows = []; self.task_manager_snapshot = {}
    self.task_manager_stack = QStackedWidget(); self.content_layout.addWidget(self.task_manager_stack, 1)

    # Processes page
    processes_page, processes_layout = _page()
    top = QHBoxLayout(); search = QLineEdit(); search.setPlaceholderText("Search processes"); search.setClearButtonEnabled(True)
    refresh_button = QPushButton("Refresh"); end_button = QPushButton("End process")
    actions_group = QHBoxLayout(); actions_group.setSpacing(0); actions_group.setContentsMargins(0, 0, 0, 0)
    apply_connected_group((refresh_button, end_button), "#8AB4F8", radius=13, height=38)
    actions_group.addWidget(refresh_button); actions_group.addWidget(end_button)
    top.addWidget(search, 1); top.addLayout(actions_group); processes_layout.addLayout(top)
    table = QTableWidget(0, 5); table.setHorizontalHeaderLabels(["Process", "PID", "CPU %", "Memory MB", "User"])
    table.setSelectionBehavior(QAbstractItemView.SelectRows); table.setSelectionMode(QAbstractItemView.SingleSelection); table.setEditTriggers(QAbstractItemView.NoEditTriggers)
    table.setSortingEnabled(True); table.verticalHeader().setVisible(False); table.horizontalHeader().setStretchLastSection(True)
    processes_layout.addWidget(table, 1); process_status = QLabel(); process_status.setStyleSheet(f"color:{MUTED};"); processes_layout.addWidget(process_status)
    self.task_manager_stack.addWidget(processes_page)

    # Performance page
    performance_page, performance_layout = _page()
    performance_header = QLabel("Live performance"); performance_header.setFont(font(18, True)); performance_layout.addWidget(performance_header)
    graphs_grid = QGridLayout(); graphs_grid.setSpacing(10)
    cpu_graph = ResourceGraph("CPU"); memory_graph = ResourceGraph("Memory"); disk_graph = ResourceGraph("Disk"); network_graph = ResourceGraph("Network")
    for index, graph in enumerate((cpu_graph, memory_graph, disk_graph, network_graph)): graphs_grid.addWidget(graph, index // 2, index % 2)
    performance_layout.addLayout(graphs_grid, 1)
    performance_details = QLabel(); performance_details.setWordWrap(True); performance_details.setStyleSheet(f"color:{MUTED};"); performance_layout.addWidget(performance_details)
    self.task_manager_stack.addWidget(performance_page)

    # Startup page
    startup_page, startup_layout = _page()
    startup_top = QHBoxLayout(); startup_title = QLabel("Startup items"); startup_title.setFont(font(18, True)); startup_top.addWidget(startup_title); startup_top.addStretch()
    startup_refresh = QPushButton("Refresh"); startup_open = QPushButton("Open location")
    startup_actions = QHBoxLayout(); startup_actions.setSpacing(0); startup_actions.setContentsMargins(0, 0, 0, 0)
    apply_connected_group((startup_refresh, startup_open), "#8AB4F8", radius=13, height=38)
    startup_actions.addWidget(startup_refresh); startup_actions.addWidget(startup_open)
    startup_top.addLayout(startup_actions); startup_layout.addLayout(startup_top)
    startup_table = QTableWidget(0, 3); startup_table.setHorizontalHeaderLabels(["Name", "Location", "Type"]); startup_table.setSelectionBehavior(QAbstractItemView.SelectRows); startup_table.setEditTriggers(QAbstractItemView.NoEditTriggers); startup_table.horizontalHeader().setStretchLastSection(True)
    startup_layout.addWidget(startup_table, 1); startup_status = QLabel(); startup_status.setStyleSheet(f"color:{MUTED};"); startup_layout.addWidget(startup_status)
    self.task_manager_stack.addWidget(startup_page)

    # Services page
    services_page, services_layout = _page()
    services_top = QHBoxLayout(); services_title = QLabel("Services"); services_title.setFont(font(18, True)); services_top.addWidget(services_title); services_top.addStretch()
    services_refresh = QPushButton("Refresh"); services_refresh.setStyleSheet(oneui_button_css("#8AB4F8", radius=12)); services_top.addWidget(services_refresh); services_layout.addLayout(services_top)
    services_table = QTableWidget(0, 3); services_table.setHorizontalHeaderLabels(["Service", "State", "Details"]); services_table.setEditTriggers(QAbstractItemView.NoEditTriggers); services_table.horizontalHeader().setStretchLastSection(True)
    services_layout.addWidget(services_table, 1); services_status = QLabel(); services_status.setWordWrap(True); services_status.setStyleSheet(f"color:{MUTED};"); services_layout.addWidget(services_status)
    self.task_manager_stack.addWidget(services_page)

    def collect_processes():
        import psutil
        processes = []
        for process in psutil.process_iter(["pid", "name", "username", "memory_info", "cpu_percent"]):
            try:
                info = process.info; memory = info.get("memory_info")
                processes.append({"name": info.get("name") or "Unknown", "pid": int(info.get("pid") or 0), "cpu": float(info.get("cpu_percent") or 0.0), "memory": float(memory.rss / 1024**2) if memory else 0.0, "user": info.get("username") or "—"})
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess): continue
        processes.sort(key=lambda row: (row["cpu"], row["memory"]), reverse=True)
        disk = psutil.disk_usage(str(PROJECT_ROOT)).percent
        net = psutil.net_io_counters()
        current = (net.bytes_sent + net.bytes_recv) if net is not None else 0
        previous = getattr(self, "_task_network_bytes", current)
        self._task_network_bytes = current
        network_percent = min(100.0, max(0.0, (current - previous) / (1024 * 1024) * 5.0))
        virtual = psutil.virtual_memory()
        return {"rows": processes, "cpu": psutil.cpu_percent(interval=0.08), "memory_percent": virtual.percent, "memory_used": virtual.used / 1024**3, "memory_total": virtual.total / 1024**3, "disk": disk, "network": network_percent, "load": getattr(os, "getloadavg", lambda: (0, 0, 0))()}

    def apply_snapshot(payload):
        widgets = (self, cpu_graph, memory_graph, disk_graph, network_graph, process_status, performance_details)
        if not all(qt_object_is_valid(widget) for widget in widgets):
            return
        self.task_manager_rows = payload["rows"]
        self.task_manager_snapshot = payload
        cpu_graph.append(payload["cpu"])
        memory_graph.append(payload["memory_percent"])
        disk_graph.append(payload["disk"])
        network_graph.append(payload["network"])
        render_rows()
        process_status.setText(
            f"{len(self.task_manager_rows)} processes · updated {datetime.now():%H:%M:%S}"
        )
        performance_details.setText(
            f"Memory: {payload['memory_used']:.1f} / {payload['memory_total']:.1f} GB\n"
            f"Load averages: {', '.join(f'{value:.2f}' for value in payload['load'])}\n"
            "Network graph represents recent aggregate transfer activity."
        )

    def render_rows(*_args):
        if not all(qt_object_is_valid(widget) for widget in (self, search, table)):
            return
        query = search.text().casefold().strip(); rows = [row for row in self.task_manager_rows if not query or query in row["name"].casefold() or query in str(row["pid"])]
        table.setSortingEnabled(False); table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            values = (row["name"], row["pid"], round(row["cpu"], 1), round(row["memory"], 1), row["user"])
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value)) if column in {0, 4} else QTableWidgetItem();
                if column not in {0, 4}: item.setData(Qt.DisplayRole, value)
                if column == 0: item.setData(Qt.UserRole, row["pid"])
                table.setItem(row_index, column, item)
        table.setSortingEnabled(True); table.resizeColumnsToContents()

    def refresh_processes():
        if not all(qt_object_is_valid(widget) for widget in (self, refresh_button, process_status)):
            return
        if self.task_manager_refreshing:
            return
        self.task_manager_refreshing = True
        refresh_button.setEnabled(False)
        process_status.setText("Refreshing processes…")

        def failed(message):
            if qt_object_is_valid(process_status):
                process_status.setText("Refresh failed: " + message)

        def done():
            if not qt_object_is_valid(self):
                return
            self.task_manager_refreshing = False
            if qt_object_is_valid(refresh_button):
                refresh_button.setEnabled(True)

        self.task_manager_task = submit(
            collect_processes,
            on_success=apply_snapshot,
            on_error=failed,
            on_finished=done,
        )

    def selected_pid():
        row = table.currentRow(); item = table.item(row, 0) if row >= 0 else None
        return int(item.data(Qt.UserRole)) if item else None

    def request_end_process():
        pid = selected_pid()
        if pid is None: self.desktop.show_system_message("Task Manager", "Select a process first."); return
        if pid in {0, 1, 2, 3, 4, os.getpid()}:
            self.desktop.show_system_message("Task Manager", "This critical or Nexora process cannot be ended here."); return
        name = table.item(table.currentRow(), 0).text()
        self.desktop.show_confirm("End process", f"End {name} (PID {pid})? Unsaved data in that process may be lost.", lambda: terminate(pid))

    def terminate(pid):
        def operation():
            import psutil
            process = psutil.Process(pid); process.terminate()
            try: process.wait(timeout=2.0); return "terminated"
            except psutil.TimeoutExpired: process.kill(); process.wait(timeout=2.0); return "killed"
        self.task_manager_end_task = submit(operation, on_success=lambda result: (process_status.setText(f"Process {pid} {result}"), QTimer.singleShot(250, refresh_processes)), on_error=lambda message: self.desktop.show_system_message("Task Manager", message))

    def collect_startup():
        system = platform.system().lower(); locations = []
        if system == "darwin":
            locations = [(Path.home() / "Library/LaunchAgents", "User LaunchAgent"), (Path("/Library/LaunchAgents"), "System LaunchAgent")]
        elif system == "windows":
            appdata = Path(os.environ.get("APPDATA", Path.home()))
            programdata = Path(os.environ.get("PROGRAMDATA", "C:/ProgramData"))
            locations = [(appdata / "Microsoft/Windows/Start Menu/Programs/Startup", "User Startup"), (programdata / "Microsoft/Windows/Start Menu/Programs/Startup", "System Startup")]
        else:
            locations = [(Path.home() / ".config/autostart", "User Autostart"), (Path("/etc/xdg/autostart"), "System Autostart")]
        rows = []
        for folder, kind in locations:
            if not folder.is_dir(): continue
            try:
                for entry in sorted(folder.iterdir(), key=lambda path: path.name.casefold()):
                    if entry.is_file(): rows.append((entry.stem, str(entry), kind))
            except OSError: continue
        return rows, [str(folder) for folder, _ in locations if folder.exists()]

    def apply_startup(payload):
        if not all(qt_object_is_valid(widget) for widget in (self, startup_table, startup_status)):
            return
        rows, locations = payload; self._startup_locations = locations; startup_table.setRowCount(len(rows))
        for row, values in enumerate(rows):
            for column, value in enumerate(values): startup_table.setItem(row, column, QTableWidgetItem(value))
        startup_table.resizeColumnsToContents(); startup_status.setText(f"{len(rows)} startup items found. Nexora lists entries without silently modifying OS startup configuration.")

    def refresh_startup():
        startup_status.setText("Scanning startup locations…"); submit(collect_startup, on_success=apply_startup, on_error=lambda message: startup_status.setText(message))

    def open_startup_location():
        row = startup_table.currentRow(); path = Path(startup_table.item(row, 1).text()).parent if row >= 0 and startup_table.item(row, 1) else None
        if path is None and getattr(self, "_startup_locations", []): path = Path(self._startup_locations[0])
        if path and path.exists(): QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
        else: self.desktop.show_system_message("Startup", "No startup location is available on this system.")

    def collect_services():
        system = platform.system().lower(); rows = []
        if system == "windows":
            import psutil
            try:
                for service in psutil.win_service_iter():
                    try:
                        info = service.as_dict(); rows.append((info.get("display_name") or info.get("name"), info.get("status") or "unknown", info.get("name") or ""))
                    except (OSError, psutil.Error): continue
            except AttributeError: pass
        elif system == "darwin":
            completed = subprocess.run(["launchctl", "list"], capture_output=True, text=True, timeout=4, check=False)
            if completed.returncode == 0:
                for line in completed.stdout.splitlines()[1:500]:
                    parts = line.split("\t");
                    if len(parts) >= 3: rows.append((parts[2], "running" if parts[0] != "-" else "loaded", f"PID {parts[0]}" if parts[0] != "-" else ""))
        else:
            if shutil.which("systemctl"):
                completed = subprocess.run(["systemctl", "list-units", "--type=service", "--all", "--no-pager", "--no-legend"], capture_output=True, text=True, timeout=5, check=False)
                if completed.returncode == 0:
                    for line in completed.stdout.splitlines()[:500]:
                        parts = line.split(None, 4)
                        if len(parts) >= 4: rows.append((parts[0], parts[3], parts[4] if len(parts) > 4 else parts[2]))
        return rows

    def apply_services(rows):
        if not all(qt_object_is_valid(widget) for widget in (self, services_table, services_status)):
            return
        services_table.setRowCount(len(rows))
        for row, values in enumerate(rows):
            for column, value in enumerate(values): services_table.setItem(row, column, QTableWidgetItem(str(value)))
        services_table.resizeColumnsToContents()
        services_status.setText(f"{len(rows)} services found." if rows else "Service enumeration is unavailable for this platform/session. No state was changed.")

    def refresh_services():
        services_status.setText("Reading platform services…"); submit(collect_services, on_success=apply_services, on_error=lambda message: services_status.setText(message))

    def show_page(index):
        self.task_manager_stack.setCurrentIndex(index); labels = ("Processes", "Performance", "Startup", "Services"); self.set_active_sidebar(labels[index])
        if index in {0, 1}: refresh_processes()
        elif index == 2: refresh_startup()
        else: refresh_services()

    for label, index in (("Processes", 0), ("Performance", 1), ("Startup", 2), ("Services", 3)):
        button = self.sidebar_buttons.get(label)
        if button is not None: button.clicked.connect(lambda _=False, i=index: show_page(i))
    search.textChanged.connect(render_rows); refresh_button.clicked.connect(refresh_processes); end_button.clicked.connect(request_end_process); table.doubleClicked.connect(request_end_process)
    startup_refresh.clicked.connect(refresh_startup); startup_open.clicked.connect(open_startup_location); services_refresh.clicked.connect(refresh_services)
    timer = QTimer(self); timer.setInterval(2000); timer.timeout.connect(lambda: refresh_processes() if self.task_manager_stack.currentIndex() in {0, 1} else None); timer.start(); self.task_manager_timer = timer
    refresh_processes()
