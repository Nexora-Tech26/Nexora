from __future__ import annotations
import csv, json, html, re
from pathlib import Path
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QTextCharFormat, QFont, QTextCursor
from PySide6.QtWidgets import (QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QPushButton, QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget,
    QSizePolicy, QHeaderView, QInputDialog)
from .shared import oneui_button_css, glass_input_css, rgba, TEXT, apply_connected_group
from System.services.safe_formula import FormulaError, SafeFormulaEvaluator

class DailyOfficeAppsMixin:
    def _office_button(self, text, callback, color=None):
        b=QPushButton(text); b.setMinimumHeight(36); b.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        b.clicked.connect(callback); b.setProperty("connectedAction", True); return b

    def _connected_bar(self, actions, accent=None):
        row=QHBoxLayout(); row.setSpacing(0); row.setContentsMargins(0,0,0,0)
        buttons=[]
        for text, callback in actions:
            button=self._office_button(text, callback, accent or self.accent); buttons.append(button); row.addWidget(button)
        apply_connected_group(buttons, accent or self.accent, radius=12, height=36)
        return row

    def _open_picker(self, title, extensions, callback):
        self.desktop.show_file_picker(title, "open", callback, extensions=set(extensions))

    def _save_picker(self, title, default_name, extensions, callback):
        self.desktop.show_file_picker(title, "save", callback, default_name=default_name, extensions=set(extensions))

    def build_documents(self):
        self.heading("Documents", "Write and format local documents")
        editor=QTextEdit(); editor.setStyleSheet(glass_input_css(self.accent)); editor.setAcceptRichText(True)
        editor.setMinimumHeight(320); editor.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        editor.setUndoRedoEnabled(True)
        status=QLabel("0 words • Not saved"); status.setProperty("nexoraMuted", True)
        current_path={"value":None}; dirty={"value":False}

        def update_status():
            words=len(re.findall(r"\b\w+\b", editor.toPlainText(), flags=re.UNICODE))
            name=Path(current_path["value"]).name if current_path["value"] else "Not saved"
            marker=" • Modified" if dirty["value"] else ""
            status.setText(f"{words} words • {name}{marker}")

        def fmt(weight=None, italic=None, underline=None, alignment=None):
            if alignment is not None:
                editor.setAlignment(alignment); editor.setFocus(); return
            char_format=QTextCharFormat()
            if weight is not None: char_format.setFontWeight(weight)
            if italic is not None: char_format.setFontItalic(italic)
            if underline is not None: char_format.setFontUnderline(underline)
            editor.mergeCurrentCharFormat(char_format); editor.setFocus()

        def load(path):
            try:
                source=Path(path); data=source.read_text(encoding="utf-8",errors="replace")
                editor.setHtml(data) if source.suffix.lower() in {".html",".htm",".nexdoc"} else editor.setPlainText(data)
                current_path["value"]=str(source); dirty["value"]=False; update_status()
                self.desktop.notch.notify(f"Opened {source.name}")
            except OSError as exc: self.desktop.show_system_message("Documents", str(exc))

        def save(path=None):
            try:
                target=Path(path or current_path["value"] or "")
                if not str(target):
                    self._save_picker("Save document","Document.nexdoc",{'.nexdoc','.html','.txt'},lambda chosen:save(chosen)); return
                if not target.suffix: target=target.with_suffix('.nexdoc')
                payload=editor.toPlainText() if target.suffix.lower()=='.txt' else editor.toHtml()
                target.write_text(payload,encoding='utf-8')
                current_path["value"]=str(target); dirty["value"]=False; update_status()
                self.desktop.notch.notify(f"Saved {target.name}")
            except OSError as exc: self.desktop.show_system_message("Documents", str(exc))

        def find_replace():
            needle, ok=QInputDialog.getText(self, "Find", "Text to find")
            if not ok or not needle:return
            replacement, ok=QInputDialog.getText(self, "Replace", "Replace with")
            if not ok:return
            cursor=editor.textCursor(); cursor.beginEditBlock(); cursor.movePosition(QTextCursor.Start)
            editor.setTextCursor(cursor); replaced=0
            while editor.find(needle):
                editor.textCursor().insertText(replacement); replaced+=1
            cursor=editor.textCursor(); cursor.endEditBlock(); editor.setTextCursor(cursor)
            self.desktop.notch.notify(f"Replaced {replaced} occurrence(s)")

        autosave=QTimer(editor); autosave.setInterval(30000)
        autosave.timeout.connect(lambda: save(current_path["value"]) if dirty["value"] and current_path["value"] else None)
        autosave.start()
        def changed(): dirty["value"]=True; update_status()
        editor.textChanged.connect(changed)

        bar=self._connected_bar([
            ("Bold",lambda:fmt(QFont.Bold)),("Italic",lambda:fmt(italic=True)),("Underline",lambda:fmt(underline=True)),
            ("Left",lambda:fmt(alignment=Qt.AlignLeft)),("Center",lambda:fmt(alignment=Qt.AlignCenter)),
            ("Undo",editor.undo),("Redo",editor.redo),("Find/Replace",find_replace),
            ("Open",lambda:self._open_picker("Open document",{'.nexdoc','.html','.htm','.txt'},load)),("Save",save),
        ])
        self.content_layout.addLayout(bar); self.content_layout.addWidget(editor,1); self.content_layout.addWidget(status)

    def build_sheets(self):
        self.heading("Sheets", "Edit CSV tables and calculate formulas")
        table=QTableWidget(60,18); table.setStyleSheet("QTableWidget{background:rgba(255,255,255,18);border:none;border-radius:14px;gridline-color:rgba(127,140,160,45);outline:none;}")
        table.setHorizontalHeaderLabels([chr(65+i) for i in range(18)]); table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        table.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding); table.setMinimumHeight(320)
        formula=QLineEdit(); formula.setPlaceholderText("Formula, e.g. =A1+B1 or =SUM(A1:A5)"); formula.setStyleSheet(glass_input_css(self.accent))
        def cell_value(ref):
            m=re.fullmatch(r'([A-R])(\d+)',ref.upper())
            if not m:return 0.0
            item=table.item(int(m.group(2))-1,ord(m.group(1))-65)
            try:return float(item.text()) if item else 0.0
            except:return 0.0
        evaluator=SafeFormulaEvaluator(cell_value)
        def evaluate():
            row=max(0,table.currentRow()); col=max(0,table.currentColumn()); cell=table.item(row,col)
            if cell is None: cell=QTableWidgetItem(); table.setItem(row,col,cell)
            try:
                value=evaluator.evaluate(formula.text())
                cell.setText(str(int(value)) if value.is_integer() else f"{value:.10g}")
            except (FormulaError, ZeroDivisionError, OverflowError, ValueError) as exc:
                self.desktop.show_system_message("Sheets",f"Formula error: {exc}")
        def load(path):
            try:
                rows=list(csv.reader(Path(path).open(encoding='utf-8',errors='replace')))
                table.clearContents(); table.setRowCount(max(60,len(rows))); table.setColumnCount(max(18,max((len(r) for r in rows),default=0)))
                table.setHorizontalHeaderLabels([chr(65+i) if i<26 else str(i+1) for i in range(table.columnCount())])
                for r,vals in enumerate(rows):
                    for c,val in enumerate(vals):table.setItem(r,c,QTableWidgetItem(val))
                self.desktop.notch.notify(f"Opened {Path(path).name}")
            except OSError as exc:self.desktop.show_system_message("Sheets",str(exc))
        def save(path):
            try:
                path=Path(path); path=path if path.suffix else path.with_suffix('.csv')
                with path.open('w',newline='',encoding='utf-8') as f:
                    w=csv.writer(f)
                    last_row=max([r for r in range(table.rowCount()) if any(table.item(r,c) for c in range(table.columnCount()))] or [0])
                    last_col=max([c for c in range(table.columnCount()) if any(table.item(r,c) for r in range(table.rowCount()))] or [0])
                    for r in range(last_row+1):w.writerow([(table.item(r,c).text() if table.item(r,c) else '') for c in range(last_col+1)])
                self.desktop.notch.notify(f"Saved {path.name}")
            except OSError as exc:self.desktop.show_system_message("Sheets",str(exc))
        top=QHBoxLayout(); top.setSpacing(0); top.addWidget(formula,1)
        actions=self._connected_bar([("Apply",evaluate),("Open",lambda:self._open_picker("Open sheet",{'.csv'},load)),("Save",lambda:self._save_picker("Save sheet","Sheet.csv",{'.csv'},save))])
        top.addLayout(actions); self.content_layout.addLayout(top); self.content_layout.addWidget(table,1)

    def build_presentations(self):
        self.heading("Presentations", "Create and save local slide decks")
        slides=QListWidget(); slides.setMinimumWidth(180); slides.setMaximumWidth(260)
        title=QLineEdit(); title.setPlaceholderText("Slide title")
        body=QTextEdit(); body.setPlaceholderText("Slide content"); body.setMinimumHeight(380); body.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        for w in (title,body):w.setStyleSheet(glass_input_css(self.accent))
        data=[]; syncing={"value":False}
        def sync_current():
            if syncing["value"]:return
            i=slides.currentRow()
            if 0<=i<len(data):data[i]={"title":title.text(),"body":body.toPlainText()}; slides.item(i).setText(title.text() or f"Slide {i+1}")
        def select(i):
            if 0<=i<len(data):
                syncing["value"]=True; title.setText(data[i].get('title','')); body.setPlainText(data[i].get('body','')); syncing["value"]=False
        def add():
            sync_current(); data.append({"title":f"Slide {len(data)+1}","body":""}); slides.addItem(data[-1]['title']); slides.setCurrentRow(len(data)-1)
        def remove():
            i=slides.currentRow()
            if i>=0 and len(data)>1:data.pop(i); slides.takeItem(i); slides.setCurrentRow(min(i,len(data)-1))
        def save_to(path):
            try:
                sync_current(); path=Path(path); path=path if path.suffix else path.with_suffix('.nexpres')
                if path.suffix.lower()=='.html':
                    sections=''.join(f"<section><h1>{html.escape(s['title'])}</h1><p>{html.escape(s['body']).replace(chr(10),'<br>')}</p></section>" for s in data)
                    path.write_text(f"<html><style>body{{font-family:sans-serif;background:#111;color:white}}section{{min-height:90vh;display:grid;place-content:center;text-align:center}}</style>{sections}</html>",encoding='utf-8')
                else:path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
                self.desktop.notch.notify(f"Saved {path.name}")
            except (OSError,ValueError) as exc:self.desktop.show_system_message("Presentations",str(exc))
        def load(path):
            try:
                loaded=json.loads(Path(path).read_text(encoding='utf-8')); data[:]=loaded if isinstance(loaded,list) else []
                slides.clear(); slides.addItems([s.get('title','Slide') for s in data]);
                if not data:add()
                else:slides.setCurrentRow(0)
                self.desktop.notch.notify(f"Opened {Path(path).name}")
            except (OSError,ValueError,TypeError) as exc:self.desktop.show_system_message("Presentations",str(exc))
        left=QVBoxLayout(); left.setSpacing(0); left.addWidget(slides,1)
        left.addLayout(self._connected_bar([("Add",add),("Remove",remove),("Open",lambda:self._open_picker("Open presentation",{'.nexpres'},load)),("Save",lambda:self._save_picker("Save presentation","Presentation.nexpres",{'.nexpres','.html'},save_to))]))
        host=QWidget(); layout=QHBoxLayout(host); layout.setContentsMargins(0,0,0,0); layout.setSpacing(10)
        panel=QWidget(); pl=QVBoxLayout(panel); pl.setContentsMargins(0,0,0,0); pl.addWidget(title); pl.addWidget(body,1)
        layout.addLayout(left); layout.addWidget(panel,1)
        slides.currentRowChanged.connect(select); title.textChanged.connect(sync_current); body.textChanged.connect(sync_current)
        self.content_layout.addWidget(host,1); add()
