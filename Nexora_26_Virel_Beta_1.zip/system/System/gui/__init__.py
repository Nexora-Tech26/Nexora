"""Modular Nexora Qt interface."""
