from __future__ import annotations
from difflib import SequenceMatcher
from .shared import *
from .components import GlassFrame
from System.services.action_registry import Action, ActionRegistry

class CommandPalette(GlassFrame):
    def __init__(self,desktop):
        super().__init__(desktop.ui_layer,radius=22,alpha=38,gradient=True,wallpaper_backdrop=True)
        self.desktop=desktop;self.registry=ActionRegistry();self.setFixedSize(620,430);self.hide()
        layout=QVBoxLayout(self);layout.setContentsMargins(18,18,18,18);layout.setSpacing(10)
        self.query=QLineEdit();self.query.setObjectName("PaletteSearch");self.query.setPlaceholderText("Type a command, app or setting…");self.query.setClearButtonEnabled(True);self.query.setFixedHeight(44);self.query.setStyleSheet("QLineEdit#PaletteSearch{background:rgba(246,249,252,220);border:none;border-radius:22px;padding:10px 15px;color:#17191F;}QLineEdit#PaletteSearch:hover{background:rgba(250,252,254,234);}QLineEdit#PaletteSearch:focus{background:rgba(252,253,255,244);border:none;}");layout.addWidget(self.query)
        self.results=QListWidget();self.results.setIconSize(QSize(28,28));layout.addWidget(self.results,1)
        self.query.textChanged.connect(self.refresh);self.query.returnPressed.connect(self.activate);self.results.itemActivated.connect(lambda *_:self.activate())
        self.refresh()
    def commands(self):
        self.registry = ActionRegistry()
        icons = {}
        for path in self.desktop.app_paths:
            name = app_name(path)
            action_id = f"nexora.app.{name.casefold().replace(' ', '_')}"
            icons[action_id] = qt_icon(name)
            self.registry.register(Action(action_id, f"Open {name}", lambda p=path: self.desktop.open_app(p), aliases=(name, f"otwórz {name}")))
        system_actions = [
            Action("nexora.windows.overview", "Show all open windows", self.desktop.toggle_overview, aliases=("overview", "widok okien")),
            Action("nexora.focus.toggle", "Toggle Focus mode", self.desktop.toggle_focus_mode, aliases=("focus", "tryb skupienia")),
            Action("nexora.display.night_light", "Toggle Night Light", self.desktop.toggle_night_light, aliases=("night light", "światło nocne")),
            Action("nexora.clipboard.history", "Show clipboard history", self.desktop.show_clipboard_history, aliases=("clipboard history", "historia schowka")),
            Action("nexora.settings.personalization", "Open Personalization", self._open_settings, aliases=("settings", "ustawienia", "personalizacja")),
        ]
        self.registry.register_many(system_actions)
        return [(action.action_id + " " + " ".join(action.aliases), action.title, icons.get(action.action_id, QIcon()), action.callback) for action in self.registry.all()]
    def _open_settings(self):
        path=next((p for p in self.desktop.app_paths if app_name(p)=="Settings"),None)
        if path:self.desktop.open_app(path)
        else:self.desktop.show_system_message("Settings","Settings is unavailable.")
    def refresh(self):
        query=self.query.text().strip().casefold();scored=[]
        for key,label,icon,callback in self.commands():
            hay=f"{key} {label}".casefold();score=1.0 if not query else max(SequenceMatcher(None,query,hay).ratio(),1.0 if query in hay else 0.0)
            if not query or score>=0.28:scored.append((score,label,icon,callback))
        self.results.clear()
        for _,label,icon,callback in sorted(scored,key=lambda row:(-row[0],row[1]))[:30]:
            item=QListWidgetItem(icon,label);item.setData(Qt.UserRole,callback);item.setSizeHint(QSize(0,46));self.results.addItem(item)
        if self.results.count():self.results.setCurrentRow(0)
    def activate(self):
        item=self.results.currentItem()
        if item:
            callback=item.data(Qt.UserRole);self.hide();callback()
    def show_palette(self):
        self.desktop.raise_shells();self.move(max(12,(self.desktop.ui_layer.width()-self.width())//2),max(42,(self.desktop.ui_layer.height()-self.height())//4));self.show();self.raise_();self.query.setFocus();self.query.selectAll()
