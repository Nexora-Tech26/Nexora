"""Compact Control Center for Nexora 26 Beta 1."""
from __future__ import annotations

from .shared import *
from .components import GlassFrame, NexoraButton, NexoraIconButton, NexoraSlider, NexoraToggle


class ControlCenterPanel(GlassFrame):
    """One small frosted popup; no permanent Wi-Fi/Bluetooth strip."""

    def __init__(self, desktop):
        super().__init__(desktop.ui_layer, radius=30, alpha=224, gradient=False, wallpaper_backdrop=True)
        self.tint_color = "#7A8FE0"
        self.desktop = desktop
        self.setFixedSize(350, 350)
        self.hide()
        self._animation = None

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 12, 16, 12)
        root.setSpacing(7)

        header = QHBoxLayout()
        title = QLabel("Control Center")
        title.setFont(font(15, True))
        title.setStyleSheet("background:transparent;border:none;")
        header.addWidget(title)
        header.addStretch()
        self.close_button = NexoraIconButton("×", size=32)
        self.close_button.clicked.connect(self.hide_animated)
        header.addWidget(self.close_button)
        root.addLayout(header)

        self.volume = NexoraSlider()
        self.volume.setRange(0, 100)
        self.brightness = NexoraSlider()
        self.brightness.setRange(10, 100)
        volume_label = QLabel("Volume")
        brightness_label = QLabel("Brightness")
        for label in (volume_label, brightness_label):
            label.setStyleSheet("background:transparent;border:none;")
        root.addWidget(volume_label)
        root.addWidget(self.volume)
        root.addWidget(brightness_label)
        root.addWidget(self.brightness)

        mode_row = QHBoxLayout()
        mode_row.setSpacing(0)
        self.light = NexoraButton("Light", primary=True)
        self.dark = NexoraButton("Dark", primary=True)
        self.focus = NexoraButton("Focus", primary=True)
        self.light.clicked.connect(lambda: self._set_theme("light"))
        self.dark.clicked.connect(lambda: self._set_theme("dark"))
        self.focus.clicked.connect(self._toggle_focus)
        mode_row.addWidget(self.light)
        mode_row.addWidget(self.dark)
        mode_row.addWidget(self.focus)
        root.addLayout(mode_row)

        actions = QHBoxLayout()
        actions.setSpacing(0)
        self.audio = NexoraButton("Audio", primary=True)
        self.settings = NexoraButton("Settings", primary=True)
        self.audio.clicked.connect(self._open_audio)
        self.settings.clicked.connect(self._open_settings)
        for button, icon_name in ((self.light, "Display"), (self.dark, "Sleep"), (self.focus, "Focus"), (self.audio, "Sound"), (self.settings, "Settings")):
            button.setIcon(qt_icon(icon_name))
            button.setIconSize(QSize(22, 22))
        actions.addWidget(self.audio)
        actions.addWidget(self.settings)
        root.addLayout(actions)

        apply_connected_group((self.light, self.dark, self.focus), "#6F9FF8", radius=16, height=40, dark_text=False)
        apply_connected_group((self.audio, self.settings), "#7C83C9", radius=16, height=40, dark_text=False)

        self.status = QLabel()
        self.status.setWordWrap(True)
        self.status.setStyleSheet(f"color:{MUTED};background:transparent;")
        root.addWidget(self.status)
        root.addStretch()

        self._volume_timer = QTimer(self)
        self._volume_timer.setSingleShot(True)
        self._volume_timer.setInterval(100)
        self._volume_timer.timeout.connect(lambda: submit(system_services.set_volume, self.volume.value()))
        self._brightness_timer = QTimer(self)
        self._brightness_timer.setSingleShot(True)
        self._brightness_timer.setInterval(120)
        self._brightness_timer.timeout.connect(lambda: submit(system_services.set_brightness, self.brightness.value()))
        self.volume.valueChanged.connect(self._volume_changed)
        self.brightness.valueChanged.connect(self._brightness_changed)
        self.refresh()


    def apply_theme(self, theme=None) -> None:
        theme = theme or getattr(self.desktop.theme_engine, "current", None)
        if theme is None:
            return
        self.tint_color = theme.surface
        self.alpha = 224 if str(theme.mode) != "dark" else 214
        self.use_gradient = False
        text = theme.text
        muted = theme.muted
        accent = theme.accent
        for label in self.findChildren(QLabel):
            label.setStyleSheet(f"background:transparent;border:none;color:{text};")
        self.status.setStyleSheet(f"background:transparent;border:none;color:{muted};")
        apply_connected_group((self.light, self.dark, self.focus), accent, radius=16, height=38, dark_text=(QColor(text).lightness() < 150))
        apply_connected_group((self.audio, self.settings), accent, radius=16, height=38, dark_text=(QColor(text).lightness() < 150))
        self.update()

    def _volume_changed(self, value: int) -> None:
        self._store_value("volume", value)
        self._volume_timer.start()

    def _brightness_changed(self, value: int) -> None:
        self._store_value("brightness", value)
        self.desktop.apply_brightness(value)
        self._brightness_timer.start()

    def _store_value(self, key: str, value) -> None:
        settings = load_settings()
        settings[key] = value
        save_settings(settings)

    def refresh(self) -> None:
        settings = load_settings()
        for widget, key, default in (
            (self.volume, "volume", 65),
            (self.brightness, "brightness", 100),
        ):
            widget.blockSignals(True)
            widget.setValue(int(settings.get(key, default)))
            widget.blockSignals(False)
        mode = str(settings.get("theme_mode", "light"))
        self.light.setProperty("nexoraPrimary", mode == "light")
        self.dark.setProperty("nexoraPrimary", mode == "dark")
        self.focus.setProperty("nexoraPrimary", bool(settings.get("focus_mode", False)))
        for button in (self.light, self.dark, self.focus):
            button.style().unpolish(button)
            button.style().polish(button)
        output = self.desktop.platform_adapter.audio_output() if hasattr(self.desktop.platform_adapter, "audio_output") else None
        self.status.setText(f"Output: {output or 'System default'}")

    def toggle(self) -> None:
        if self.isVisible():
            self.hide_animated()
        else:
            self.show_animated()

    def show_animated(self) -> None:
        self.refresh()
        self.desktop.position_shells()
        self.show()
        self.raise_()
        effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(effect)
        animation = QPropertyAnimation(effect, b"opacity", self)
        animation.setDuration(MOTION.menu_open)
        animation.setStartValue(0.0)
        animation.setEndValue(1.0)
        animation.setEasingCurve(enter_curve())
        animation.finished.connect(lambda: self.setGraphicsEffect(None))
        self._animation = animation
        animation.start()

    def hide_animated(self) -> None:
        if not self.isVisible():
            return
        effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(effect)
        animation = QPropertyAnimation(effect, b"opacity", self)
        animation.setDuration(max(90, MOTION.menu_close))
        animation.setStartValue(1.0)
        animation.setEndValue(0.0)
        animation.setEasingCurve(exit_curve())

        def finish() -> None:
            self.hide()
            self.setGraphicsEffect(None)

        animation.finished.connect(finish)
        self._animation = animation
        animation.start()

    def _set_theme(self, mode: str) -> None:
        settings = load_settings()
        settings["theme_mode"] = mode
        save_settings(settings)
        self.desktop.apply_settings(settings)
        self.refresh()

    def _toggle_focus(self) -> None:
        settings = load_settings()
        settings["focus_mode"] = not bool(settings.get("focus_mode", False))
        save_settings(settings)
        self.desktop.apply_settings(settings)
        self.refresh()

    def _open_audio(self) -> None:
        result = self.desktop.platform_adapter.open_audio_settings()
        if not result.success:
            self.desktop.show_system_message("Audio output", result.message or "Audio settings are unavailable.")

    def _open_settings(self) -> None:
        path = next((candidate for candidate in self.desktop.app_paths if app_name(candidate) == "Settings"), None)
        if path is not None:
            self.desktop.open_app(path)
        self.hide_animated()
