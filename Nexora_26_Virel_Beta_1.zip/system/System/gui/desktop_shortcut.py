from __future__ import annotations
from .shared import *

class DesktopShortcut(QToolButton):
    """Selectable, group-draggable desktop application shortcut."""
    def __init__(self, desktop, app_path: Path, shortcut_file: Path, position: QPoint, size_mode="medium"):
        super().__init__(desktop.app_layer)
        self.desktop=desktop; self.app_path=Path(app_path).resolve(); self.shortcut_file=Path(shortcut_file); self.size_mode=size_mode
        self._drag_origin_global=QPoint(); self._drag_start_positions={}; self._dragging=False
        self.setToolButtonStyle(Qt.ToolButtonTextUnderIcon); self.setAutoRaise(True); self.setCursor(Qt.PointingHandCursor)
        self.setContextMenuPolicy(Qt.CustomContextMenu); self.customContextMenuRequested.connect(self._menu)
        self.clicked.connect(lambda: self.desktop.open_app(self.app_path) if not self._dragging else None)
        self.set_position(position); self.apply_size(size_mode); self.set_selected(False)

    def apply_size(self, mode):
        sizes={"small":(72,68,34),"medium":(96,92,48),"large":(124,116,64)}
        mode=mode if mode in sizes else "medium"; self.size_mode=mode
        w,h,icon=sizes[mode]; self.setFixedSize(w,h); self.setIconSize(QSize(icon,icon)); self.setIcon(qt_icon(app_name(self.app_path))); self.setText(app_name(self.app_path))

    def set_position(self, point): self.move(QPoint(max(0,point.x()),max(0,point.y())))
    def set_selected(self, selected):
        self.setProperty("selected",bool(selected)); self.style().unpolish(self); self.style().polish(self); self.update()
        theme = getattr(getattr(self.desktop, "theme_engine", None), "current", None)
        text = getattr(theme, "text", TEXT)
        self.setStyleSheet(f'''QToolButton{{background:{"rgba(63,140,255,70)" if selected else "transparent"};border:{"1px solid rgba(120,190,255,180)" if selected else "1px solid transparent"};border-radius:24px;color:{text};padding:6px;}}QToolButton:hover{{background:rgba(92,169,255,46);border:none;}}''')

    def mousePressEvent(self,event):
        if event.button()==Qt.LeftButton:
            modifiers=event.modifiers(); additive=bool(modifiers & (Qt.ControlModifier|Qt.MetaModifier)); range_select=bool(modifiers & Qt.ShiftModifier)
            self.desktop.select_desktop_shortcut(self, additive=additive, range_select=range_select)
            self._drag_origin_global=event.globalPosition().toPoint(); self._drag_start_positions={item:QPoint(item.pos()) for item in self.desktop.selected_desktop_shortcuts()}; self._dragging=False
        super().mousePressEvent(event)

    def mouseMoveEvent(self,event):
        if event.buttons() & Qt.LeftButton and not self._drag_origin_global.isNull():
            delta=event.globalPosition().toPoint()-self._drag_origin_global
            if delta.manhattanLength()>=QApplication.startDragDistance(): self._dragging=True
            if self._dragging: self.desktop.move_selected_desktop_shortcuts(self._drag_start_positions,delta); event.accept(); return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self,event):
        if self._dragging: self.desktop.finish_desktop_shortcut_drag()
        self._drag_origin_global=QPoint(); QTimer.singleShot(0,lambda:setattr(self,"_dragging",False)); super().mouseReleaseEvent(event)

    def _menu(self,pos):
        menu=create_nexora_menu(self); open_action=menu.addAction("Open"); new_action=menu.addAction("New window"); size_menu=menu.addMenu("Icon size")
        size_actions={size_menu.addAction("Small"):"small",size_menu.addAction("Medium"):"medium",size_menu.addAction("Large"):"large"}
        remove_action=menu.addAction("Remove shortcut"); chosen=menu.exec(self.mapToGlobal(pos))
        if chosen==open_action:self.desktop.open_app(self.app_path)
        elif chosen==new_action:self.desktop.open_app_new(self.app_path)
        elif chosen in size_actions:self.apply_size(size_actions[chosen]);self.desktop.save_desktop_shortcut_layout()
        elif chosen==remove_action:
            try:self.shortcut_file.unlink()
            except OSError:pass
            self.desktop.refresh_desktop_shortcuts()
