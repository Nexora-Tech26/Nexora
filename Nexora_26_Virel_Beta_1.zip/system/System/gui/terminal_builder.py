"""Multi-tab, non-blocking terminal application for Nexora."""
from __future__ import annotations

import os
import re
import shutil
import sys
from pathlib import Path

from PySide6.QtCore import QProcess, QTimer, Qt
from PySide6.QtGui import QColor, QFont, QKeySequence, QShortcut, QTextCharFormat, QTextCursor
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QTabWidget,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from .shared import BORDER, MUTED, TEXT, font, glass_input_css, oneui_button_css, rgba

_ANSI = re.compile(r"\x1b\[([0-9;]*)m")
_ANSI_COLORS = {
    30: "#16181D", 31: "#FF7B86", 32: "#88D498", 33: "#FFD166",
    34: "#7AA7FF", 35: "#C792EA", 36: "#66D9EF", 37: "#E9EEF5",
    90: "#788392", 91: "#FF9AA4", 92: "#A7E3B3", 93: "#FFE39A",
    94: "#9DBBFF", 95: "#D8A7F2", 96: "#9BE7F3", 97: "#FFFFFF",
}


def _available_shells() -> list[tuple[str, str, list[str]]]:
    """Return display name, executable and per-command argument prefix."""
    result: list[tuple[str, str, list[str]]] = []
    if sys.platform == "win32":
        for label, candidate, args in (
            ("PowerShell", shutil.which("pwsh"), ["-NoLogo", "-NoProfile", "-Command"]),
            ("Windows PowerShell", shutil.which("powershell"), ["-NoLogo", "-NoProfile", "-Command"]),
            ("Command Prompt", shutil.which("cmd"), ["/d", "/s", "/c"]),
        ):
            if candidate and candidate not in {item[1] for item in result}:
                result.append((label, candidate, args))
    else:
        candidates = [os.environ.get("SHELL"), "/bin/zsh", "/bin/bash", "/bin/sh"]
        for candidate in candidates:
            if not candidate:
                continue
            path = str(Path(candidate).expanduser())
            if Path(path).is_file() and path not in {item[1] for item in result}:
                result.append((Path(path).name, path, ["-lc"]))
    if not result:
        fallback = shutil.which("sh") or shutil.which("cmd")
        if fallback:
            result.append((Path(fallback).name, fallback, ["-lc"] if sys.platform != "win32" else ["/c"]))
    return result


def build_terminal_ui(window) -> None:
    """Build a tabbed QProcess terminal without blocking the Qt event loop."""
    window.heading("Terminal", "Shell tabs, history, ANSI output and safe process control")
    shells = _available_shells()
    if not shells:
        error = QLabel("No supported shell executable is available on this platform.")
        error.setWordWrap(True)
        error.setStyleSheet("color:#FF7777;padding:20px;")
        window.content_layout.addWidget(error)
        return

    top = QHBoxLayout()
    shell_selector = QComboBox()
    for label, executable, args in shells:
        shell_selector.addItem(label, (executable, args))
    shell_selector.setToolTip("Shell used for new tabs")
    shell_selector.setStyleSheet(glass_input_css(window.accent))
    new_tab_button = QPushButton("New tab")
    new_tab_button.setStyleSheet(oneui_button_css("#8AB4F8"))
    top.addWidget(QLabel("New tab shell:"))
    top.addWidget(shell_selector, 1)
    top.addWidget(new_tab_button)
    window.content_layout.addLayout(top)

    tabs = QTabWidget()
    tabs.setTabsClosable(True)
    tabs.setMovable(True)
    tabs.setDocumentMode(True)
    tabs.setStyleSheet(
        "QTabWidget::pane{border:none;border-radius:20px;}"
        "QTabBar::tab{padding:8px 14px;margin:2px;border-radius:20px;background:rgba(255,255,255,24);}"
        "QTabBar::tab:selected{background:rgba(138,180,248,120);font-weight:700;}"
    )
    window.content_layout.addWidget(tabs, 1)
    window.terminal_tabs = tabs
    window.terminal_processes = []
    states: dict[QWidget, dict] = {}

    def append_ansi(output: QTextEdit, text: str) -> None:
        if not text:
            return
        cursor = output.textCursor()
        cursor.movePosition(QTextCursor.End)
        current = QTextCharFormat()
        current.setForeground(QColor("#F3F6FA"))
        position = 0
        for match in _ANSI.finditer(text):
            if match.start() > position:
                cursor.insertText(text[position:match.start()], current)
            codes = [int(value) for value in match.group(1).split(";") if value] or [0]
            for code in codes:
                if code == 0:
                    current = QTextCharFormat(); current.setForeground(QColor("#F3F6FA"))
                elif code == 1:
                    current.setFontWeight(QFont.Bold)
                elif code == 22:
                    current.setFontWeight(QFont.Normal)
                elif code in _ANSI_COLORS:
                    current.setForeground(QColor(_ANSI_COLORS[code]))
            position = match.end()
        if position < len(text):
            cursor.insertText(text[position:], current)
        output.setTextCursor(cursor)
        output.ensureCursorVisible()

    def stop_state(state: dict) -> None:
        process = state.get("process")
        if process is None or process.state() == QProcess.NotRunning:
            return
        process.terminate()
        QTimer.singleShot(800, lambda proc=process: proc.state() != QProcess.NotRunning and proc.kill())

    def close_tab(index: int) -> None:
        page = tabs.widget(index)
        if page is None:
            return
        state = states.pop(page, None)
        if state:
            stop_state(state)
        tabs.removeTab(index)
        page.deleteLater()
        if tabs.count() == 0:
            create_tab()

    def create_tab() -> None:
        shell_data = shell_selector.currentData()
        if not shell_data:
            return
        executable, command_prefix = shell_data
        page = QWidget()
        page.setAttribute(Qt.WA_TranslucentBackground, True)
        layout = QVBoxLayout(page)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        state = {
            "cwd": Path.home(), "previous_cwd": None, "history": [], "history_index": 0,
            "process": None, "shell": executable, "prefix": list(command_prefix),
        }
        states[page] = state

        toolbar = QHBoxLayout()
        cwd_label = QLabel(str(state["cwd"]))
        cwd_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        cwd_label.setStyleSheet(
            f"background:{rgba('#FFFFFF', 26)};border:none;"
            f"border-radius:24px;padding:7px 10px;color:{MUTED};"
        )
        clear_button = QPushButton("Clear")
        stop_button = QPushButton("Stop")
        clear_button.setStyleSheet(oneui_button_css("#8C97A8"))
        stop_button.setStyleSheet(oneui_button_css("#F47C8C"))
        stop_button.setEnabled(False)
        toolbar.addWidget(cwd_label, 1)
        toolbar.addWidget(clear_button)
        toolbar.addWidget(stop_button)
        layout.addLayout(toolbar)

        output = QTextEdit()
        output.setReadOnly(True)
        output.setAcceptRichText(True)
        output.setLineWrapMode(QTextEdit.NoWrap)
        output.setStyleSheet(
            "QTextEdit{background:rgba(20,24,31,220);border:none;"
            "border-radius:24px;color:#F3F6FA;padding:12px;selection-background-color:#5B8DEF;}"
        )
        terminal_font = QFont("Menlo")
        terminal_font.setStyleHint(QFont.Monospace)
        terminal_font.setPointSize(11)
        output.setFont(terminal_font)
        append_ansi(output, f"Nexora Terminal\nShell: {executable}\n")
        layout.addWidget(output, 1)

        command_row = QHBoxLayout()
        prompt = QLabel("❯")
        prompt.setFont(font(16, True))
        prompt.setStyleSheet("color:#8AB4F8;padding:0 3px;")
        command = QLineEdit()
        command.setPlaceholderText("Enter a shell command")
        command.setClearButtonEnabled(True)
        command.setStyleSheet(glass_input_css(window.accent))
        command_row.addWidget(prompt)
        command_row.addWidget(command, 1)
        layout.addLayout(command_row)

        def finish_process(exit_code: int, _status) -> None:
            append_ansi(output, f"\n\x1b[90m[exit {exit_code}]\x1b[0m\n")
            command.setEnabled(True)
            stop_button.setEnabled(False)
            state["process"] = None
            command.setFocus()

        def read_channel(error: bool = False) -> None:
            process = state.get("process")
            if process is None:
                return
            data = process.readAllStandardError() if error else process.readAllStandardOutput()
            append_ansi(output, bytes(data).decode("utf-8", errors="replace"))

        def change_directory(raw_path: str) -> None:
            raw_path = raw_path.strip()
            if raw_path == "-":
                target = state.get("previous_cwd") or state["cwd"]
            elif not raw_path:
                target = Path.home()
            else:
                import shlex
                try:
                    parts = shlex.split(raw_path)
                except ValueError as exc:
                    append_ansi(output, f"\x1b[31mcd: {exc}\x1b[0m\n")
                    return
                target_text = parts[0] if parts else str(Path.home())
                target = Path(os.path.expandvars(os.path.expanduser(target_text)))
                if not target.is_absolute():
                    target = state["cwd"] / target
            try:
                resolved = target.resolve()
                if not resolved.is_dir():
                    raise NotADirectoryError(str(resolved))
                state["previous_cwd"], state["cwd"] = state["cwd"], resolved
                cwd_label.setText(str(resolved))
            except (OSError, RuntimeError) as exc:
                append_ansi(output, f"\x1b[31mcd: {exc}\x1b[0m\n")

        def run_command() -> None:
            text = command.text().strip()
            if not text or state.get("process") is not None:
                return
            command.clear()
            state["history"].append(text)
            state["history_index"] = len(state["history"])
            append_ansi(output, f"\x1b[94m{state['cwd']} ❯\x1b[0m {text}\n")
            if text in {"clear", "cls"}:
                output.clear(); return
            if text in {"exit", "quit"}:
                append_ansi(output, "Close this tab with its × button.\n"); return
            if text == "cd" or text.startswith("cd "):
                change_directory(text[2:]); return

            process = QProcess(page)
            state["process"] = process
            window.terminal_processes.append(process)
            process.setWorkingDirectory(str(state["cwd"]))
            process.setProcessChannelMode(QProcess.SeparateChannels)
            process.readyReadStandardOutput.connect(lambda: read_channel(False))
            process.readyReadStandardError.connect(lambda: read_channel(True))
            process.finished.connect(finish_process)
            process.finished.connect(lambda *_args, proc=process: window.terminal_processes.remove(proc) if proc in window.terminal_processes else None)
            process.errorOccurred.connect(
                lambda error, proc=process: append_ansi(output, f"\x1b[31mProcess error: {proc.errorString()} ({int(error)})\x1b[0m\n")
            )
            command.setEnabled(False)
            stop_button.setEnabled(True)
            process.start(state["shell"], state["prefix"] + [text])

        def history_step(delta: int) -> None:
            history = state["history"]
            if not history:
                return
            state["history_index"] = max(0, min(len(history), state["history_index"] + delta))
            command.setText("" if state["history_index"] == len(history) else history[state["history_index"]])

        clear_button.clicked.connect(output.clear)
        stop_button.clicked.connect(lambda: stop_state(state))
        command.returnPressed.connect(run_command)
        QShortcut(QKeySequence("Ctrl+C"), page, activated=lambda: stop_state(state))
        QShortcut(QKeySequence(Qt.Key_Up), command, activated=lambda: history_step(-1))
        QShortcut(QKeySequence(Qt.Key_Down), command, activated=lambda: history_step(1))

        index = tabs.addTab(page, Path(executable).name)
        tabs.setCurrentIndex(index)
        command.setFocus()

    new_tab_button.clicked.connect(create_tab)
    tabs.tabCloseRequested.connect(close_tab)
    create_tab()
