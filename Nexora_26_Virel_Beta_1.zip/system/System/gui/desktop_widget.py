"""Configurable, non-blocking desktop widgets for Nexora 26 Beta 1 ."""
from __future__ import annotations

import math
import time
import uuid
from pathlib import Path

from .shared import *
from .components import GlassFrame
from System.widgets import WidgetSize


LEGACY_WIDGET_ALIASES = {
    "Clock": "digital_clock",
    "Calendar": "calendar",
    "Weather": "weather",
    "System": "cpu",
    "Battery": "battery",
    "Storage": "disk",
    "Notes": "notes",
    "Files": "recent_files",
    "Downloads": "recent_files",
    "Gallery": "photos",
    "Maps": "shortcuts",
}

SIZE_PIXELS = {
    "small": (180, 180),
    "medium": (380, 180),
    "large": (380, 380),
    "wide": (780, 180),
}


class AnalogClockFace(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(90, 90)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def paintEvent(self, _event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        center = QPointF(self.width() / 2, self.height() / 2)
        radius = max(18.0, min(self.width(), self.height()) / 2 - 8)
        painter.setPen(QPen(QColor(255, 255, 255, 150), 2))
        painter.setBrush(QColor(255, 255, 255, 18))
        painter.drawEllipse(center, radius, radius)
        for minute in range(0, 60, 5):
            angle = math.radians(minute * 6 - 90)
            inner = radius - (9 if minute % 15 else 13)
            start = QPointF(center.x() + math.cos(angle) * inner, center.y() + math.sin(angle) * inner)
            end = QPointF(center.x() + math.cos(angle) * (radius - 3), center.y() + math.sin(angle) * (radius - 3))
            painter.drawLine(start, end)
        now = datetime.now()
        hour = (now.hour % 12 + now.minute / 60) * 30 - 90
        minute = (now.minute + now.second / 60) * 6 - 90
        second = now.second * 6 - 90
        self._hand(painter, center, radius * 0.50, hour, 5, QColor(245, 248, 252))
        self._hand(painter, center, radius * 0.72, minute, 3, QColor(220, 230, 244))
        self._hand(painter, center, radius * 0.80, second, 1.5, QColor(138, 180, 248))
        painter.setBrush(QColor(138, 180, 248))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(center, 4, 4)

    @staticmethod
    def _hand(painter, center, length, degrees, width, color):
        angle = math.radians(degrees)
        end = QPointF(center.x() + math.cos(angle) * length, center.y() + math.sin(angle) * length)
        painter.setPen(QPen(color, width, Qt.SolidLine, Qt.RoundCap))
        painter.drawLine(center, end)


class DesktopWidget(GlassFrame):
    GRID = 12
    GAP = 12
    SIZES = SIZE_PIXELS

    def __init__(self, desktop, kind, pos=None, size="small", *, widget_id=None, locked=False, config=None):
        super().__init__(desktop.app_layer, radius=24, alpha=29, gradient=True, wallpaper_backdrop=True)
        self.desktop = desktop
        self.kind = LEGACY_WIDGET_ALIASES.get(str(kind), str(kind))
        self.widget_id = str(widget_id or uuid.uuid4())
        self.config = dict(config or {})
        self.locked = bool(locked)
        self.edit_mode = bool(getattr(desktop, "widget_edit_mode", False))
        self.drag_offset = QPoint()
        self._refresh_pending = False
        self._task = None
        self._stopwatch_started = None
        self._stopwatch_elapsed = float(self.config.get("elapsed", 0.0))
        self._timer_remaining = int(self.config.get("remaining", 300))
        self._timer_running = False

        spec = self._spec()
        allowed = {entry.value for entry in spec.sizes}
        normalized = "large" if size == "big" else str(size)
        self.size_mode = normalized if normalized in allowed else next(iter(allowed), "small")
        self.resize(*self.SIZES[self.size_mode])
        if pos is None:
            pos = QPoint(24 + len(desktop.desktop_widgets) * 28, 24 + len(desktop.desktop_widgets) * 24)
        self.move(pos)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.show_menu)
        self.setFocusPolicy(Qt.StrongFocus)

        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(16, 13, 16, 14)
        self.root.setSpacing(7)
        top = QHBoxLayout()
        self.title_label = QLabel(spec.title)
        self.title_label.setFont(font(10, True))
        self.title_label.setStyleSheet("background:transparent;border:none;")
        self.lock_label = QLabel("🔒" if self.locked else "")
        self.lock_label.setStyleSheet(f"color:{MUTED};background:transparent;border:none;")
        top.addWidget(self.title_label)
        top.addStretch()
        top.addWidget(self.lock_label)
        self.root.addLayout(top)
        self.body = QWidget()
        self.body.setStyleSheet("background:transparent;border:none;")
        self.body_layout = QVBoxLayout(self.body)
        self.body_layout.setContentsMargins(0, 0, 0, 0)
        self.body_layout.setSpacing(6)
        self.root.addWidget(self.body, 1)
        self.value = QLabel()
        self.value.setAlignment(Qt.AlignCenter)
        self.value.setFont(font(18, True))
        self.value.setWordWrap(True)
        self.value.setStyleSheet("background:transparent;border:none;")
        self.body_layout.addWidget(self.value, 1)
        self._build_interactive_content()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self._apply_refresh_interval()
        self.refresh()
        self.set_edit_mode(self.edit_mode)
        self.show()
        self.raise_()

    def _spec(self):
        try:
            return self.desktop.widget_registry.get(self.kind)
        except KeyError:
            return self.desktop.widget_registry.get("digital_clock")

    def _apply_refresh_interval(self):
        base = self._spec().refresh_seconds or int(load_settings().get("widget_refresh", 5))
        profile = str(load_settings().get("performance_mode", "balanced"))
        multiplier = {"quality": 1.0, "balanced": 1.25, "performance": 2.0, "battery_saver": 4.0}.get(profile, 1.25)
        interval = max(500, round(base * multiplier * 1000))
        self.timer.setInterval(interval)
        if base > 0:
            self.timer.start()
        else:
            self.timer.stop()

    def _build_interactive_content(self):
        if self.kind == "analog_clock":
            self.value.hide()
            self.clock_face = AnalogClockFace(self.body)
            self.body_layout.addWidget(self.clock_face, 1)
        elif self.kind == "notes":
            self.value.hide()
            self.notes = QTextEdit()
            self.notes.setPlaceholderText("Quick notes…")
            self.notes.setPlainText(str(self.config.get("text", "")))
            self.notes.setStyleSheet(glass_input_css("#FFD18A"))
            self.notes.textChanged.connect(self._save_notes_debounced)
            self.body_layout.addWidget(self.notes, 1)
            self._notes_timer = QTimer(self)
            self._notes_timer.setSingleShot(True)
            self._notes_timer.setInterval(350)
            self._notes_timer.timeout.connect(self._save_notes)
        elif self.kind == "tasks":
            self.value.hide()
            self.tasks = QListWidget()
            self.tasks.setStyleSheet("QListWidget{background:transparent;border:none;}QListWidget::item{padding:4px;}")
            for task in self.config.get("items", []):
                self._add_task_item(str(task))
            row = QHBoxLayout()
            self.task_entry = QLineEdit()
            self.task_entry.setPlaceholderText("Add task")
            add = QPushButton("+")
            add.setFixedWidth(34)
            add.clicked.connect(self._add_task_from_entry)
            self.task_entry.returnPressed.connect(self._add_task_from_entry)
            row.addWidget(self.task_entry, 1)
            row.addWidget(add)
            self.body_layout.addWidget(self.tasks, 1)
            self.body_layout.addLayout(row)
        elif self.kind == "timer":
            controls = QHBoxLayout()
            start = QPushButton("Start / pause")
            reset = QPushButton("Reset")
            start.clicked.connect(self._toggle_timer)
            reset.clicked.connect(self._reset_timer)
            controls.addWidget(start)
            controls.addWidget(reset)
            self.body_layout.addLayout(controls)
        elif self.kind == "stopwatch":
            controls = QHBoxLayout()
            start = QPushButton("Start / pause")
            reset = QPushButton("Reset")
            start.clicked.connect(self._toggle_stopwatch)
            reset.clicked.connect(self._reset_stopwatch)
            controls.addWidget(start)
            controls.addWidget(reset)
            self.body_layout.addLayout(controls)
        elif self.kind == "music":
            open_music = QPushButton("Open Music folder")
            open_music.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(NEXORA_HOME / "Music"))))
            self.body_layout.addWidget(open_music)
        elif self.kind == "shortcuts":
            self.value.hide()
            grid = QGridLayout()
            for index, path in enumerate(self.desktop.app_paths[:8]):
                button = QToolButton()
                button.setText(app_name(path))
                button.setIcon(qt_icon(app_name(path)))
                button.setIconSize(QSize(28, 28))
                button.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
                button.clicked.connect(lambda _=False, target=path: self.desktop.open_app(target))
                grid.addWidget(button, index // 4, index % 4)
            self.body_layout.addLayout(grid)
        elif self.kind in {"quick_actions", "ai", "terminal"}:
            self.value.hide()
            grid = QGridLayout()
            if self.kind == "quick_actions":
                actions = (
                    ("Focus", self.desktop.toggle_focus_mode),
                    ("Night Light", self.desktop.toggle_night_light),
                    ("Control Center", self.desktop.control_center.toggle),
                    ("Command Palette", self.desktop.command_palette.show_palette),
                )
            else:
                target_name = "Welcome" if self.kind == "ai" else "Terminal Pro"
                def open_target(name=target_name):
                    target = next((path for path in self.desktop.app_paths if app_name(path) == name), None)
                    if target:
                        self.desktop.open_app(target)
                actions = ((f"Open {target_name}", open_target), ("Command Palette", self.desktop.command_palette.show_palette))
            for index, (label, callback) in enumerate(actions):
                button = QPushButton(label)
                button.setMinimumHeight(38)
                button.clicked.connect(callback)
                grid.addWidget(button, index // 2, index % 2)
            self.body_layout.addLayout(grid)

    # -------------------------------------------------------------- persistence
    def _save_notes_debounced(self):
        if hasattr(self, "_notes_timer"):
            self._notes_timer.start()

    def _save_notes(self):
        if hasattr(self, "notes"):
            self.config["text"] = self.notes.toPlainText()
            self.desktop.save_widget_layout()

    def _add_task_item(self, text):
        item = QListWidgetItem(text)
        item.setFlags(item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEditable)
        item.setCheckState(Qt.Unchecked)
        self.tasks.addItem(item)

    def _add_task_from_entry(self):
        text = self.task_entry.text().strip()
        if not text:
            return
        self._add_task_item(text)
        self.task_entry.clear()
        self._save_tasks()

    def _save_tasks(self):
        self.config["items"] = [self.tasks.item(index).text() for index in range(self.tasks.count())]
        self.desktop.save_widget_layout()

    # ------------------------------------------------------------------- refresh
    def refresh(self):
        now = datetime.now()
        if self.kind == "digital_clock":
            self.value.setText(now.strftime("%H:%M\n%d %b"))
        elif self.kind == "analog_clock":
            self.clock_face.update()
        elif self.kind == "calendar":
            self.value.setText(now.strftime("%A\n%d %B %Y"))
        elif self.kind == "timer":
            if self._timer_running:
                self._timer_remaining = max(0, self._timer_remaining - max(1, self.timer.interval() // 1000))
                if self._timer_remaining == 0:
                    self._timer_running = False
                    self.desktop.notification_service.post("timer", "Timer complete", "Desktop timer finished", priority="normal")
            minutes, seconds = divmod(self._timer_remaining, 60)
            self.value.setText(f"{minutes:02d}:{seconds:02d}")
        elif self.kind == "stopwatch":
            elapsed = self._stopwatch_elapsed
            if self._stopwatch_started is not None:
                elapsed += time.monotonic() - self._stopwatch_started
            minutes, seconds = divmod(int(elapsed), 60)
            self.value.setText(f"{minutes:02d}:{seconds:02d}.{int((elapsed % 1) * 10)}")
        elif self.kind in {"notes", "tasks", "shortcuts", "quick_actions", "ai", "terminal"}:
            return
        elif self.kind == "music":
            self.value.setText("System media session unavailable\nUse the Music folder or a platform player")
        elif not self._refresh_pending:
            self._refresh_pending = True
            self._task = submit(
                self._collect_background_value,
                on_success=self._apply_background_value,
                on_error=lambda message: self._apply_background_value(f"Unavailable\n{message}"),
                on_finished=lambda: setattr(self, "_refresh_pending", False),
            )

    def _collect_background_value(self):
        import psutil
        if self.kind == "cpu":
            return f"CPU\n{psutil.cpu_percent(interval=0.08):.0f}%"
        if self.kind == "ram":
            memory = psutil.virtual_memory()
            return f"RAM\n{memory.percent:.0f}%\n{memory.available / 1024**3:.1f} GB free"
        if self.kind == "disk":
            disk = psutil.disk_usage(str(PROJECT_ROOT))
            return f"Disk\n{disk.percent:.0f}% used\n{disk.free / 1024**3:.1f} GB free"
        if self.kind == "battery":
            battery = psutil.sensors_battery()
            return f"{battery.percent:.0f}%\n{'Charging' if battery.power_plugged else 'Battery'}" if battery else "No battery detected"
        if self.kind == "network":
            counters = psutil.net_io_counters()
            return f"Network\n↑ {counters.bytes_sent / 1024**2:.1f} MB\n↓ {counters.bytes_recv / 1024**2:.1f} MB"
        if self.kind == "recent_files":
            files = []
            for folder_name in ("Desktop", "Documents", "Downloads"):
                folder = NEXORA_HOME / folder_name
                try:
                    files.extend(path for path in folder.iterdir() if path.is_file())
                except OSError:
                    pass
            files.sort(key=lambda path: path.stat().st_mtime if path.exists() else 0, reverse=True)
            return "Recent files\n" + ("\n".join(path.name for path in files[:4]) if files else "No recent files")
        if self.kind in {"photos", "gallery"}:
            folder = NEXORA_HOME / "Images"
            count = sum(1 for path in folder.iterdir() if path.is_file()) if folder.exists() else 0
            return f"Photos\n{count} images"
        if self.kind == "downloads":
            folder = NEXORA_HOME / "Downloads"
            files = [path for path in folder.iterdir() if path.is_file()] if folder.exists() else []
            files.sort(key=lambda path: path.stat().st_mtime, reverse=True)
            return "Downloads\n" + ("\n".join(path.name for path in files[:3]) if files else "No downloads")
        if self.kind == "gpu":
            import platform
            return f"GPU\n{platform.machine()} graphics\nOpen System Monitor for details"
        if self.kind in {"wifi", "bluetooth", "vpn"}:
            capability = "wifi" if self.kind in {"wifi", "vpn"} else "bluetooth"
            available = bool(self.desktop.platform_adapter.capabilities().get(capability))
            return f"{self._spec().title}\n{'Controls available' if available else 'Integration unavailable'}"
        if self.kind == "clipboard":
            history = getattr(self.desktop.clipboard_service, "history", None)
            items = list(history()) if callable(history) else []
            latest = str(getattr(items[0], "text", items[0]))[:80] if items else "Empty"
            return f"Clipboard\n{len(items)} item(s)\n{latest}"
        if self.kind == "github":
            roots = [path for path in (NEXORA_HOME / "Documents").rglob(".git") if path.is_dir()]
            return f"GitHub\n{len(roots)} local Git repositories"
        if self.kind in {"discord", "spotify", "steam"}:
            return f"{self._spec().title}\nNo account integration configured"
        if self.kind in {"news", "rss"}:
            return f"{self._spec().title}\nAdd a feed provider in widget configuration"
        if self.kind == "system_health":
            report = self.desktop.health_monitor.collect()
            return f"System Health\n{report['status'].title()}\n{len(report['issues'])} finding(s)"
        if self.kind == "weather":
            return f"Weather · {load_settings().get('weather_city', 'Warsaw')}\nOpen Weather for live forecast"
        return self._spec().title

    def _apply_background_value(self, value):
        if not self.isVisible() and self.parent() is None:
            return
        self.value.setText(str(value))

    # ---------------------------------------------------------------- controls
    def _toggle_timer(self):
        self._timer_running = not self._timer_running
        self.timer.setInterval(1000)
        self.timer.start()

    def _reset_timer(self):
        self._timer_running = False
        self._timer_remaining = int(self.config.get("duration", 300))
        self.refresh()

    def _toggle_stopwatch(self):
        if self._stopwatch_started is None:
            self._stopwatch_started = time.monotonic()
            self.timer.setInterval(100)
            self.timer.start()
        else:
            self._stopwatch_elapsed += time.monotonic() - self._stopwatch_started
            self._stopwatch_started = None

    def _reset_stopwatch(self):
        self._stopwatch_started = None
        self._stopwatch_elapsed = 0.0
        self.refresh()

    def show_menu(self, pos):
        menu = create_nexora_menu(self)
        sizes = menu.addMenu("Size")
        size_actions = {}
        labels = {"small": "Small · 1×1", "medium": "Medium · 2×1", "large": "Large · 2×2", "wide": "Wide · 4×1"}
        allowed = {size.value for size in self._spec().sizes}
        for size in ("small", "medium", "large", "wide"):
            if size in allowed:
                action = sizes.addAction(labels[size])
                action.setCheckable(True)
                action.setChecked(size == self.size_mode)
                size_actions[action] = size
        edit = menu.addAction("Exit edit mode" if self.edit_mode else "Enter edit mode")
        lock = menu.addAction("Unlock position" if self.locked else "Lock position")
        configure = menu.addAction("Configure")
        refresh = menu.addAction("Refresh")
        remove = menu.addAction("Remove widget")
        chosen = menu.exec(self.mapToGlobal(pos))
        if chosen == remove:
            self.desktop.remove_desktop_widget(self)
        elif chosen == edit:
            self.desktop.toggle_widget_edit_mode()
        elif chosen == lock:
            self.locked = not self.locked
            self.lock_label.setText("🔒" if self.locked else "")
            self.desktop.save_widget_layout()
        elif chosen == configure:
            self.configure_widget()
        elif chosen == refresh:
            self.refresh()
        elif chosen in size_actions:
            self.set_size_mode(size_actions[chosen])

    def configure_widget(self):
        if self.kind == "weather":
            self.desktop.show_text_prompt(
                "Weather widget",
                "City",
                lambda value: self._set_config("city", value.strip() or "Warsaw"),
                str(self.config.get("city", load_settings().get("weather_city", "Warsaw"))),
            )
        elif self.kind == "timer":
            self.desktop.show_text_prompt(
                "Timer widget",
                "Duration in minutes",
                self._configure_timer,
                str(max(1, int(self.config.get("duration", 300)) // 60)),
            )
        elif self.kind == "tasks":
            current = self.tasks.currentRow()
            if current >= 0:
                self.tasks.takeItem(current)
                self._save_tasks()
            else:
                self.desktop.show_system_message("Tasks widget", "Select a task and choose Configure to remove it.")
        else:
            self.desktop.show_system_message("Widget configuration", "This widget has no additional options.")

    def _configure_timer(self, value):
        try:
            seconds = max(60, min(24 * 3600, int(float(value) * 60)))
        except (TypeError, ValueError):
            self.desktop.show_system_message("Timer widget", "Enter a valid number of minutes.")
            return
        self.config["duration"] = seconds
        self._timer_remaining = seconds
        self.desktop.save_widget_layout()
        self.refresh()

    def _set_config(self, key, value):
        self.config[key] = value
        self.desktop.save_widget_layout()
        self.refresh()

    def set_size_mode(self, mode):
        if mode not in {size.value for size in self._spec().sizes}:
            return
        self.size_mode = mode
        self.resize(*self.SIZES[mode])
        self.desktop.snap_widget(self)
        self.desktop.save_widget_layout()

    def set_edit_mode(self, enabled):
        self.edit_mode = bool(enabled)
        border = "2px dashed rgba(138,180,248,180)" if enabled else "1px solid rgba(255,255,255,55)"
        self.setStyleSheet(
            f"DesktopWidget{{border:{border};border-radius:{self.radius}px;}}"
            "DesktopWidget QLabel{background:transparent;border:none;}"
        )
        self.setCursor(Qt.SizeAllCursor if enabled and not self.locked else Qt.ArrowCursor)

    # ------------------------------------------------------------------- events
    def mousePressEvent(self, event):
        self.desktop.activate_widget(self)
        if event.button() == Qt.LeftButton and not self.locked:
            self.drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if event.buttons() & Qt.LeftButton and not self.drag_offset.isNull() and not self.locked:
            root = self.parentWidget().mapToGlobal(QPoint(0, 0))
            point = event.globalPosition().toPoint() - self.drag_offset - root
            self.move(
                max(0, min(point.x(), self.parentWidget().width() - self.width())),
                max(0, min(point.y(), self.parentWidget().height() - self.height())),
            )
            self.desktop.snap_widget(self, live=True)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if not self.locked:
            self.drag_offset = QPoint()
            self.desktop.snap_widget(self)
            self.desktop.save_widget_layout()
        super().mouseReleaseEvent(event)

    def shutdown(self):
        self.timer.stop()
        if hasattr(self, "_notes_timer"):
            self._notes_timer.stop()
        self.config["elapsed"] = self._stopwatch_elapsed
        self.config["remaining"] = self._timer_remaining
        if hasattr(self, "tasks"):
            self._save_tasks()
