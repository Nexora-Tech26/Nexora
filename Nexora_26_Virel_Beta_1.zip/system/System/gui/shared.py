from __future__ import annotations

import json
import os
import sys
import time
import subprocess
import shutil
import zipfile
import urllib.parse
import urllib.request
import webbrowser
from datetime import datetime
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter
from PIL.ImageQt import ImageQt
from System.foundation import system_services
from System.func.system.safe_calculator import evaluate as evaluate_calculation, CalculatorError
from nexora.core.tasks import submit
from nexora.paths import DATA_DIR, HOME_DIR, ensure_runtime_paths
from System.foundation.version import CODENAME, DISPLAY_NAME, NEXORA_VERSION
from System.visual.nexora_ui import apply_shadow, glass_panel_style, gradient_button_style, dock_button_style
from System.visual.premium_motion import MOTION, enter_curve, exit_curve
from System.settings import DEFAULTS as SETTINGS_DEFAULTS, get_settings_store
from System.theme import THEMES
from PySide6 import __version__ as PYSIDE_VERSION
from PySide6.QtCore import qVersion
from PySide6.QtCore import QAbstractAnimation, QEasingCurve, QObject, QPoint, QPointF, QRect, QParallelAnimationGroup, QPauseAnimation, QPropertyAnimation, QSequentialAnimationGroup, QVariantAnimation, QSize, Qt, Signal, QTimer, QUrl, QEvent, QThread, QThreadPool, QProcess, QSignalBlocker
from PySide6.QtGui import QAction, QColor, QFont, QFontDatabase, QIcon, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap, QDesktopServices, QCursor
try:
    from shiboken6 import isValid as _shiboken_is_valid
except Exception:  # pragma: no cover - only used with alternate Qt bindings
    def _shiboken_is_valid(_obj):
        return True


def qt_object_is_valid(obj) -> bool:
    """Return False after the wrapped C++ Qt object has been deleted."""
    try:
        return obj is not None and bool(_shiboken_is_valid(obj))
    except RuntimeError:
        return False

from PySide6.QtWidgets import (
    QApplication, QAbstractButton, QCheckBox, QDialog, QFileDialog, QFrame, QGraphicsDropShadowEffect,
    QGraphicsOpacityEffect, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListView,
    QListWidgetItem, QMenu, QMessageBox, QPushButton, QScrollArea, QSizePolicy,
    QStackedWidget, QTextEdit, QTextBrowser, QPlainTextEdit, QVBoxLayout, QWidget, QCalendarWidget, QProgressBar,
    QTableWidget, QTableWidgetItem, QComboBox, QSlider, QColorDialog, QInputDialog,
    QButtonGroup, QRadioButton, QFormLayout, QSpinBox, QGroupBox, QTabWidget, QTabBar, QSplitter, QBoxLayout,
    QToolButton, QTreeWidget, QLayout, QAbstractItemView
)

SYSTEM_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = SYSTEM_ROOT.parent
NEXORA_HOME = HOME_DIR
APPS_DIR = SYSTEM_ROOT / "sys" / "resources" / "apps"
ICONS_DIR = SYSTEM_ROOT / "sys" / "resources" / "Icons"
WALLPAPERS_DIR = SYSTEM_ROOT / "UI" / "Wallpapers"
DEFAULT_WALLPAPER = SYSTEM_ROOT / "UI" / "wallpaper.png"
PINNED_FILE = DATA_DIR / "pinned_apps.json"
PINNED_FOLDERS_FILE = DATA_DIR / "pinned_folders.json"
ensure_runtime_paths(legacy_data=SYSTEM_ROOT / "data", legacy_home=PROJECT_ROOT / "Home" / "User")
SETTINGS_FILE = DATA_DIR / "settings.json"

DEFAULT_SETTINGS = dict(SETTINGS_DEFAULTS)

def load_settings() -> dict:
    """Return the cached, schema-migrated settings snapshot."""
    return get_settings_store(SETTINGS_FILE).snapshot()

def save_settings(values: dict) -> None:
    """Validate settings and schedule one debounced atomic write."""
    get_settings_store(SETTINGS_FILE).replace(values, save=True)

WALLPAPER_EXTENSIONS = {".svg", ".png", ".jpg", ".jpeg", ".webp", ".bmp"}

def wallpaper_files() -> list[Path]:
    """Return every supported image in Wallpapers, regardless of its name."""
    try:
        WALLPAPERS_DIR.mkdir(parents=True, exist_ok=True)
        return sorted(
            (path for path in WALLPAPERS_DIR.iterdir()
             if path.is_file() and path.suffix.lower() in WALLPAPER_EXTENSIONS),
            key=lambda path: path.name.casefold(),
        )
    except OSError:
        return []

def wallpaper_details(path: Path) -> tuple[int, int, str]:
    """Return source dimensions and a user-facing resolution tier."""
    target = Path(path)
    try:
        if target.suffix.casefold() == ".svg":
            pixmap = QPixmap(str(target))
            width, height = pixmap.width(), pixmap.height()
        else:
            with Image.open(target) as image:
                width, height = image.size
    except (OSError, ValueError):
        width, height = 0, 0
    if width >= 3840 or height >= 2160:
        tier = "4K"
    elif width >= 2560 or height >= 1440:
        tier = "QHD"
    elif width >= 1920 or height >= 1080:
        tier = "Full HD"
    elif width > 0:
        tier = "HD"
    else:
        tier = "Unknown"
    return int(width), int(height), tier

def current_wallpaper_path() -> Path:
    configured = str(load_settings().get("wallpaper", "")).strip()
    if configured:
        candidate = Path(configured).expanduser()
        if not candidate.is_absolute():
            candidate = (PROJECT_ROOT.parent / candidate).resolve()
        if candidate.exists() and candidate.is_file():
            return candidate
    files = wallpaper_files()
    return files[0] if files else DEFAULT_WALLPAPER

WALLPAPER = current_wallpaper_path()

def inside_home(path: Path) -> bool:
    try:
        path.resolve().relative_to(NEXORA_HOME.resolve())
        return True
    except (OSError, ValueError):
        return False

BG = "#DDE7F2"
BG2 = "#EEF2F7"
SURFACE = "rgba(224,232,241,82)"
SIDEBAR = "rgba(216,226,237,92)"
BUTTON = "rgba(230,236,244,86)"
HOVER = "rgba(247,250,253,118)"
BORDER = "rgba(255,255,255,138)"
TEXT = "#17191F"
MUTED = "#596170"
ACCENT = "#3F8CFF"
RED = "#FF5F57"
YELLOW = "#FEBC2E"
GREEN = "#28C840"

APP_COLORS = {
    "AboutPC": "#7C83FD", "BackUp": "#45C4B0", "Calculator": "#59C36A",
    "Calendar": "#F47C8C", "Clock": "#6C7CFF", "Files": "#5B9DF5",
    "Gallery": "#A879E8", "Maps": "#45BFA9", "Notepad": "#F2C85B",
    "Paint": "#E879A8", "Screenshot": "#72A4F7", "Continuum": "#8066D8", "Settings": "#8C97A8",
    "Store": "#579DE8", "Task Manager": "#4DB9B2", "Terminal": "#65758A",
    "Weather": "#55B5D6", "Welcome": "#9B82E5", "Widgets": "#E87991", "Browser": "#66A8F0",
    "Image Editor": "#7C83FD", "Video Editor": "#E879A8", "Code Editor": "#66A8F0",
    "Documents": "#4F8EF7", "Sheets": "#42B96B", "Spreadsheets": "#42B96B", "Presentations": "#F06D5E",
    "Virtual Machine": "#9B82E5", "Database": "#45BFA9", "PDF Editor": "#F2C85B",
    "Audio Editor": "#55B5D6", "Whiteboard": "#B9A7E8", "Archives": "#F6C177",
"Notes": "#F2C85B", "Markdown Editor": "#6C9FF8",
    "Mail": "#5B9DF5", "Music Player": "#E879A8", "Camera": "#4DB9B2",
    "Recorder": "#F47C8C", "Screen Recorder": "#E87991", "Developer Hub": "#66A8F0",
    "Package Manager": "#45BFA9", "PDF Viewer": "#F05B64", "System Monitor": "#4DB9B2",
    "Performance Monitor": "#55B5D6", "System Health": "#59C36A", "Disk Manager": "#F2C85B",
    "Backup Manager": "#45C4B0", "Clipboard Manager": "#B9A7E8", "Password Manager": "#7C83FD",
    "Color Picker": "#E879A8", "Download Manager": "#579DE8", "Game Launcher": "#59C36A",
    "File Sharing": "#45BFA9", "Git Client": "#65758A",
    "SSH Client": "#65758A", "FTP Client": "#579DE8", "Remote Desktop": "#7C83FD",
    "Screen Mirroring": "#B9A7E8", "Focus Mode": "#89D4CF", "Studio": "#9B82E5",
    "Media Center": "#E879A8", "Terminal Pro": "#65758A",
    "Spaces": "#8AB4F8", "Automation": "#FFD18A", "Extensions": "#B9A7E8",
    "Photo Editor": "#7C83FD", 
    "Task Manager Pro": "#4DB9B2", "Virtual Machine Manager": "#9B82E5",
}

ONE_UI_TILES = [
    "#8AB4F8", "#A7D8A1", "#FFD18A", "#F4A7B9", "#B9A7E8",
    "#89D4CF", "#F3B4E2", "#A8C7FA", "#F6C177", "#9ED0C8",
]


PANEL_STYLES = {
    key: {
        "name": theme.name, "edge": theme.dock_position, "width": "content",
        "align": "center", "launcher": "N",
        "vertical": theme.dock_position in {"left", "right"},
        "radius": theme.panel_radius, "gap": round(7 * theme.spacing_scale),
        "title_height": theme.titlebar_height, "sidebar_width": theme.sidebar_width,
        "menu_size": (460, 650), "window_radius": theme.window_radius,
        "density": "compact" if theme.key in {"macos", "windows", "minimal"} else "balanced",
    }
    for key, theme in THEMES.items()
}
PANEL_STYLES["custom"] = dict(PANEL_STYLES["nexora_glass"], name="Custom")

def current_ui_style(settings=None):
    settings = settings or load_settings()
    key = str(settings.get("ui_style", "cloud_light"))
    return key if key in PANEL_STYLES else "cloud_light"

def panel_profile(settings=None):
    settings = settings or load_settings()
    profile = dict(PANEL_STYLES[current_ui_style(settings)])
    edge = str(settings.get("dock_position", profile.get("edge", "bottom")))
    if edge not in {"bottom", "top", "left", "right"}:
        edge = "bottom"
    profile["edge"] = edge
    profile["vertical"] = edge in {"left", "right"}
    profile["radius"] = int(settings.get("panel_radius", profile.get("radius", 20)))
    profile["window_radius"] = int(settings.get("window_radius", profile.get("window_radius", 24)))
    return profile


ONE_UI_ACCENTS = {
    "blue": ("#8AB4F8", "#5B8DEF"),
    "green": ("#A7D8A1", "#58A86B"),
    "orange": ("#FFD18A", "#F5A646"),
    "pink": ("#F4A7B9", "#E46F90"),
    "purple": ("#B9A7E8", "#8767CC"),
    "cyan": ("#89D4CF", "#3BA9A1"),
}

def rgba(hex_color: str, alpha: int) -> str:
    color = QColor(hex_color)
    return f"rgba({color.red()},{color.green()},{color.blue()},{alpha})"

def apply_theme_palette(settings=None, *, theme=None, propagate=True):
    """Apply a resolved theme to legacy compatibility globals.

    Older UI modules imported palette names with ``from shared import *``.  To
    keep live preview reliable, the resolved values are also propagated to
    already-loaded ``System.gui`` modules instead of leaving stale string
    copies behind.
    """
    global BG, BG2, SURFACE, SIDEBAR, BUTTON, HOVER, BORDER, TEXT, MUTED, ACCENT
    settings = settings or load_settings()
    if theme is None:
        base = THEMES.get(current_ui_style(settings), THEMES["nexora_glass"])
        from System.theme.engine import ThemeEngine
        class _SnapshotStore:
            def snapshot(self): return dict(settings)
        theme = ThemeEngine(_SnapshotStore()).resolve(settings)
    old = {name: globals()[name] for name in ("BG", "BG2", "SURFACE", "SIDEBAR", "BUTTON", "HOVER", "BORDER", "TEXT", "MUTED", "ACCENT")}
    BG, BG2 = theme.background, theme.background_alt
    TEXT, MUTED, ACCENT = theme.text, theme.muted, theme.accent
    alpha = max(12, min(235, round(255 * (100 - int(theme.transparency)) / 100)))
    surface = QColor(theme.surface); sidebar = QColor(theme.sidebar); border = QColor(theme.border)
    SURFACE = f"rgba({surface.red()},{surface.green()},{surface.blue()},{alpha})"
    SIDEBAR = f"rgba({sidebar.red()},{sidebar.green()},{sidebar.blue()},{min(245, alpha+14)})"
    BUTTON = f"rgba({surface.red()},{surface.green()},{surface.blue()},{min(250, alpha+24)})"
    HOVER = f"rgba({surface.red()},{surface.green()},{surface.blue()},{min(255, alpha+50)})"
    BORDER = f"rgba({border.red()},{border.green()},{border.blue()},{max(45,min(220,alpha+72))})"
    if propagate:
        palette = {name: globals()[name] for name in old}
        for module_name, module in tuple(sys.modules.items()):
            if module is None or not (module_name.startswith("System.gui") or module_name in {"gui", "qt_ui"}):
                continue
            namespace = getattr(module, "__dict__", {})
            for name, value in palette.items():
                if name in namespace:
                    namespace[name] = value
    return str(theme.mode).lower() == "dark" or (str(theme.mode).lower() == "auto" and QColor(theme.background).lightness() < 128)

def rounded_control_stylesheet(settings=None, *, theme=None) -> str:
    settings = settings or load_settings()
    if theme is None:
        from System.theme.engine import ThemeEngine
        class _SnapshotStore:
            def snapshot(self): return dict(settings)
        theme = ThemeEngine(_SnapshotStore()).resolve(settings)
    dark = QColor(theme.background).lightness() < 128
    high = bool(settings.get("high_contrast", False))
    opaque = bool(settings.get("disable_transparency", False))
    radius = max(18, min(24, int(getattr(theme, "control_radius", 22) or 22)))
    border_width = 0
    panel_color = QColor(theme.surface)
    border_color = QColor(theme.border)
    alpha = 255 if opaque or high else max(28, min(88, round(255 * (100 - int(theme.transparency)) / 100) + 18))
    panel = f"rgba({panel_color.red()},{panel_color.green()},{panel_color.blue()},{alpha})"
    hover_alpha = min(132, alpha + 38)
    panel_hover = f"rgba({panel_color.red()},{panel_color.green()},{panel_color.blue()},{hover_alpha})"
    border = f"rgba({border_color.red()},{border_color.green()},{border_color.blue()},{220 if high else 126})"
    text = theme.text
    muted = theme.muted
    underline = "text-decoration:underline;" if settings.get("underline_buttons") else ""
    focus = "transparent"
    return f"""
    QWidget {{ color:{text}; }}
    QLabel {{ color:{text}; background:transparent; border:none; }}
    QPushButton, QToolButton {{ background:{panel}; color:{text}; border:none; border-radius:{radius}px; min-height:28px; max-height:28px; padding:0 9px; {underline} }}
    QPushButton[flat="true"], QToolButton[autoRaise="true"] {{ background:transparent; border:none; border-radius:{max(4,radius-2)}px; }}
    QPushButton:hover, QToolButton:hover {{ background:{panel_hover}; border:none; border-radius:{radius}px; }}
    QPushButton:focus, QToolButton:focus, QLineEdit:focus, QTextEdit:focus, QComboBox:focus, QListWidget:focus, QTreeWidget:focus, QTableWidget:focus {{ border:none; }}
    QPushButton:pressed, QToolButton:pressed {{ background:rgba(127,127,127,32); border:none; border-radius:{radius}px; }}
    QPushButton:disabled, QToolButton:disabled {{ color:{muted}; background:rgba(127,127,127,20); }}
    QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {{ background:{panel}; color:{text}; border:none; border-radius:{radius}px; min-height:30px; max-height:34px; padding:0 9px; selection-background-color:{theme.accent}; }}
    QTextEdit, QTextBrowser, QPlainTextEdit {{ background:{panel}; color:{text}; border:none; border-radius:{radius}px; min-height:150px; padding:12px 14px; selection-background-color:{theme.accent}; }}
    QComboBox::drop-down {{ border:none; width:28px; }}
    QComboBox QAbstractItemView, QMenu {{ background:rgba(224,236,248,226); color:#142033; border:none; border-radius:20px; padding:6px; outline:none; }}
    QComboBox QAbstractItemView::item {{ min-height:34px; border:none; border-radius:15px; padding:4px 10px; margin:2px; }}
    QComboBox QAbstractItemView::item:hover, QComboBox QAbstractItemView::item:selected {{ background:{rgba(theme.accent, 96)}; color:#142033; border:none; border-radius:15px; }}
    QListWidget, QListView, QTreeWidget, QTreeView, QTableWidget, QTableView, QCalendarWidget {{ background:{panel}; color:{text}; border:none; border-radius:22px; outline:none; }}
    QListWidget::item, QListView::item, QTreeWidget::item, QTreeView::item, QTableWidget::item, QTableView::item {{ border:none; border-radius:16px; padding:3px 5px; margin:1px; }}
    QListWidget::item:selected, QListView::item:selected, QTreeWidget::item:selected, QTreeView::item:selected, QTableWidget::item:selected, QTableView::item:selected {{ background:{rgba(theme.accent, 118)}; }}
    QTabWidget::pane {{ border:none; border-radius:24px; background:transparent; top:-1px; }}
    QTabBar {{ background:transparent; border:none; outline:none; }}
    QGroupBox {{ background:{panel}; border:none; border-radius:22px; margin-top:8px; padding:8px; }}
    QGroupBox::title {{ subcontrol-origin:margin; left:14px; padding:0 6px; }}
    QProgressBar {{ background:{panel}; border:none; border-radius:9px; min-height:18px; max-height:18px; text-align:center; }}
    QProgressBar::chunk {{ background:{rgba(theme.accent, 150)}; border-radius:9px; }}
    QTabBar::tab {{ background:rgba(255,255,255,16); color:{text}; border:none; outline:none; border-radius:17px; min-height:34px; max-height:34px; padding:0 14px; margin:2px 4px; }}
    QTabBar::tab:hover {{ background:rgba(127,127,127,28); border:none; border-radius:17px; }}
    QTabBar::tab:selected {{ background:{panel_hover}; border:none; outline:none; border-radius:17px; }}
    QTabBar::close-button {{ border:none; background:transparent; border-radius:7px; margin:3px; }}
    QMenu::item {{ border:none; border-radius:16px; min-height:28px; padding:5px 28px 5px 12px; margin:2px; }}
    QMenu::item:selected {{ background:{rgba(theme.accent, 92)}; }}
    QMenu::item:disabled {{ color:{muted}; background:transparent; }}
    QMenu::separator {{ height:7px; background:transparent; margin:0 8px; }}
    QMenu::icon {{ padding-left:6px; }}
    QMenu::item:selected {{ background:{rgba(theme.accent, 104)}; border:none; border-radius:16px; }}
    QScrollBar:vertical {{ background:transparent; width:10px; margin:3px; }}
    QScrollBar::handle:vertical {{ background:{rgba(theme.muted, 92)}; min-height:32px; border-radius:5px; }}
    QScrollBar::handle:vertical:hover {{ background:{rgba(theme.muted, 138)}; }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height:0px; }}
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background:transparent; }}
    QScrollBar:horizontal {{ background:transparent; height:10px; margin:3px; }}
    QScrollBar::handle:horizontal {{ background:{rgba(theme.muted, 92)}; min-width:32px; border-radius:5px; }}
    QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width:0px; }}
    QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{ background:transparent; }}
    QSlider::groove:horizontal {{ height:8px; background:{panel}; border:none; border-radius:4px; }}
    QSlider::sub-page:horizontal {{ background:{rgba(theme.accent,150)}; border:none; border-radius:4px; }}
    QSlider::handle:horizontal {{ width:18px; margin:-5px 0; background:{text}; border:none; border-radius:9px; }}
    QCheckBox, QRadioButton {{ spacing:8px; background:transparent; }}
    QCheckBox::indicator, QRadioButton::indicator {{ width:20px; height:20px; border:none; border-radius:10px; background:{panel}; }}
    QCheckBox::indicator:checked, QRadioButton::indicator:checked {{ background:{theme.accent}; }}
    QHeaderView::section {{ background:{panel}; color:{text}; border:none; border-radius:12px; padding:6px; margin:1px; }}
    QDateEdit, QTimeEdit, QDateTimeEdit {{ background:{panel}; color:{text}; border:none; border-radius:{radius}px; min-height:30px; padding:0 9px; }}
    QToolTip {{ background:{panel}; color:{text}; border:none; border-radius:10px; padding:7px 10px; }}
    """

def connected_button_css(primary: str, position: str = "single", *, radius: int = 14, height: int = 38, dark_text: bool = True) -> str:
    """Canonical Nexora Connected Controls segment stylesheet.

    ``position`` is one of: single, first, middle, last. Adjacent segments use
    zero margins and only the outside corners are rounded.
    """
    position = position if position in {"single", "first", "middle", "last"} else "single"
    radius = max(8, min(24, int(radius)))
    height = max(30, min(52, int(height)))
    c = QColor(primary if QColor(primary).isValid() else "#73A7FF")
    r, g, b = c.red(), c.green(), c.blue()
    text = "#182235" if dark_text else "#F8FBFF"
    left = radius if position in {"single", "first"} else 0
    right = radius if position in {"single", "last"} else 0
    common = (
        f"border:none;outline:none;margin:0;min-height:{height}px;max-height:{height}px;"
        f"border-top-left-radius:{left}px;border-bottom-left-radius:{left}px;"
        f"border-top-right-radius:{right}px;border-bottom-right-radius:{right}px;"
    )
    return (
        f"QPushButton,QToolButton{{background:rgba({r},{g},{b},54);color:{text};{common}"
        "padding:0 14px;font-weight:650;}"
        f"QPushButton:hover,QToolButton:hover{{background:rgba({r},{g},{b},84);{common}}}"
        f"QPushButton:pressed,QToolButton:pressed{{background:rgba({max(0,r-12)},{max(0,g-12)},{max(0,b-12)},108);{common}padding:1px 14px 0 14px;}}"
        f"QPushButton:checked,QToolButton:checked{{background:rgba({r},{g},{b},118);{common}}}"
        f"QPushButton:disabled,QToolButton:disabled{{background:rgba(160,174,196,28);color:rgba(70,80,96,90);{common}}}"
    )


def apply_connected_group(buttons, primary: str = "#73A7FF", *, radius: int = 14, height: int = 38, dark_text: bool = True) -> None:
    """Style an ordered button collection as one borderless connected control."""
    widgets = [button for button in buttons if button is not None]
    total = len(widgets)
    for index, button in enumerate(widgets):
        position = "single" if total == 1 else ("first" if index == 0 else "last" if index == total - 1 else "middle")
        button.setProperty("nexoraConnected", True)
        button.setProperty("connectedPosition", position)
        button.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        button.setStyleSheet(connected_button_css(primary, position, radius=radius, height=height, dark_text=dark_text))


def connected_tabbar_css(accent: str = "#73A7FF", *, radius: int = 14, height: int = 38) -> str:
    """One continuous QTabBar capsule instead of separate floating pills."""
    return (
        "QTabBar{background:transparent;border:none;outline:none;}"
        f"QTabBar::tab{{background:rgba(255,255,255,28);border:none;outline:none;margin:0;padding:0 14px;min-height:{height}px;max-height:{height}px;border-radius:0;}}"
        f"QTabBar::tab:first{{border-top-left-radius:{radius}px;border-bottom-left-radius:{radius}px;}}"
        f"QTabBar::tab:last{{border-top-right-radius:{radius}px;border-bottom-right-radius:{radius}px;}}"
        "QTabBar::tab:hover:!selected{background:rgba(255,255,255,48);}"
        f"QTabBar::tab:selected{{background:{rgba(accent, 112)};border:none;outline:none;}}"
    )


def oneui_button_css(primary: str, *, dark_text: bool = True, radius: int = 24) -> str:
    """Nexora Aurora flat material. Connected groups keep zero gaps and shared edges."""
    radius = max(12, min(22, int(radius)))
    c = QColor(primary if QColor(primary).isValid() else "#73A7FF")
    r, g, b = c.red(), c.green(), c.blue()
    text = "#182235" if dark_text else "#F8FBFF"
    return (
        f"QPushButton{{background:rgba({r},{g},{b},54);color:{text};border:none;"
        f"border-radius:{radius}px;padding:7px 14px;min-height:32px;max-height:40px;font-weight:600;}}"
        f"QPushButton:hover{{background:rgba({r},{g},{b},86);border:none;border-radius:{radius}px;}}"
        f"QPushButton:pressed{{background:rgba({max(0,r-14)},{max(0,g-14)},{max(0,b-14)},112);border:none;border-radius:{radius}px;padding-top:8px;padding-bottom:6px;}}"
        f"QPushButton:checked{{background:rgba({r},{g},{b},118);}}"
        f"QPushButton:disabled{{background:rgba(210,220,232,34);color:rgba(70,80,96,90);}}"
    )

def glass_input_css(accent: str) -> str:
    return (
        "QLineEdit,QTextEdit,QListWidget{background:rgba(255,255,255,18);"
        f"border:none;border-radius:12px;color:{TEXT};"
        f"selection-background-color:{accent};padding:10px;}}"
        "QLineEdit:focus,QTextEdit:focus,QListWidget:focus{border:none;}"
    )


def add_soft_shadow(widget, blur=28, y_offset=7, alpha=62):
    """Disabled in performance mode: Qt graphics effects cause severe Intel macOS lag."""
    return
    app = QApplication.instance()
    if app is not None and app.platformName().casefold() == "offscreen":
        return
    if widget is None or getattr(widget, "_nexora_shadow", None) is not None:
        return
    if widget.graphicsEffect() is not None:
        return
    effect = QGraphicsDropShadowEffect(widget)
    effect.setBlurRadius(float(blur))
    effect.setOffset(0, float(y_offset))
    effect.setColor(QColor(35, 48, 66, int(alpha)))
    widget.setGraphicsEffect(effect)
    widget._nexora_shadow = effect

def add_control_shadows(root):
    """Give the complete window and its cards restrained, stable depth."""
    add_soft_shadow(root, blur=32, y_offset=9, alpha=76)
    for card in root.findChildren(QFrame, "SettingsSection"):
        add_soft_shadow(card, blur=18, y_offset=5, alpha=48)


class _InteractionGlow(QWidget):
    """Paint-only interaction layer; it does not replace widget graphics effects."""

    def __init__(self, parent):
        super().__init__(parent)
        self.progress = 0.0
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setGeometry(parent.rect())
        self.hide()

    def set_progress(self, value):
        self.progress = max(0.0, min(1.0, float(value)))
        self.setVisible(self.progress > 0.005)
        if self.isVisible():
            self.raise_()
        self.update()

    def paintEvent(self, event):
        if self.progress <= 0:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        radius = max(7, min(15, self.height() // 3))
        fill = QColor(255, 255, 255, round(34 * self.progress))
        edge = QColor(107, 161, 255, round(115 * self.progress))
        painter.setBrush(fill)
        painter.setPen(QPen(edge, 1.2))
        painter.drawRoundedRect(self.rect().adjusted(1, 1, -1, -1), radius, radius)


class InteractionAnimator(QObject):
    """Shared hover, press, focus and selection motion for Nexora controls."""

    CONTROL_TYPES = (QAbstractButton, QLineEdit, QComboBox, QSlider, QListWidget)

    def __init__(self, root):
        super().__init__(root)
        self.enabled = bool(load_settings().get("animations", True)) and not bool(load_settings().get("reduce_motion", False))
        self._overlays = {}
        self._animations = {}
        if self.enabled:
            self.install(root)

    def install(self, root):
        controls = []
        for control_type in self.CONTROL_TYPES:
            controls.extend(root.findChildren(control_type))
        for control in dict.fromkeys(controls):
            if control.property("nexoraAnimated"):
                continue
            control.setProperty("nexoraAnimated", True)
            control.installEventFilter(self)
            if isinstance(control, QComboBox):
                control.currentIndexChanged.connect(lambda _value, widget=control: self.pulse(widget))
            elif isinstance(control, QListWidget):
                control.currentRowChanged.connect(lambda _value, widget=control: self.pulse(widget))

    def _overlay(self, widget):
        overlay = self._overlays.get(widget)
        if overlay is None:
            overlay = _InteractionGlow(widget)
            self._overlays[widget] = overlay
        overlay.setGeometry(widget.rect())
        return overlay

    def animate(self, widget, target, duration=130):
        if not self.enabled or not qt_object_is_valid(widget):
            return
        overlay = self._overlay(widget)
        previous = self._animations.pop(widget, None)
        if previous is not None:
            previous.stop()
        animation = QVariantAnimation(self)
        animation.setStartValue(float(overlay.progress))
        animation.setEndValue(float(target))
        animation.setDuration(max(70, int(duration)))
        animation.setEasingCurve(QEasingCurve.OutCubic)
        animation.valueChanged.connect(overlay.set_progress)
        animation.finished.connect(lambda current=animation, owner=widget: self._animations.pop(owner, None) if self._animations.get(owner) is current else None)
        self._animations[widget] = animation
        animation.start()

    def pulse(self, widget):
        self.animate(widget, 0.42, 90)
        QTimer.singleShot(95, lambda target=widget: self.animate(target, 0.12 if target.underMouse() else 0.0, 150))

    def eventFilter(self, watched, event):
        kind = event.type()
        if kind == QEvent.Resize:
            overlay = self._overlays.get(watched)
            if overlay is not None:
                overlay.setGeometry(watched.rect())
        elif kind == QEvent.Enter:
            self.animate(watched, 0.18, 150)
        elif kind == QEvent.Leave:
            self.animate(watched, 0.0, 180)
        elif kind == QEvent.MouseButtonPress:
            self.animate(watched, 0.48, 85)
        elif kind == QEvent.MouseButtonRelease:
            self.animate(watched, 0.18 if watched.underMouse() else 0.0, 150)
        elif kind == QEvent.FocusIn:
            self.animate(watched, 0.24, 160)
        elif kind == QEvent.FocusOut and not watched.underMouse():
            self.animate(watched, 0.0, 170)
        return False


def install_interaction_animations(root):
    """Performance mode: native Qt hover/pressed states only; no overlay widgets or event-filter scans."""
    return None

def app_name(path: Path) -> str:
    name = path.stem.replace("_", " ")
    return {"ScreenShots": "Screenshot"}.get(name, name)


APP_ICON_NAMES = {
    "AboutPC", "About PC", "Browser", "Calculator", "Calendar", "Clock", "Files",
    "Gallery", "Maps", "Notepad", "Paint", "Screenshot", "Continuum", "Settings",
    "Store", "Task Manager", "Terminal", "Weather", "Welcome", "Widgets",
    "Notes", "Documents", "Sheets", "Presentations", "Mail", "PDF Viewer", "Recorder", "Spreadsheets", "Image Editor",
    "Video Editor", "Virtual Machine", "Database", "PDF Editor",
    "Audio Editor", "Whiteboard", "Archives", "AboutPC",
}

FLAT_ICON_COLORS = {
    "Files": "#F2C94C", "Folder": "#F2C94C", "DesktopFolder": "#F2C94C",
    "Terminal": "#171A20", "Terminal Pro": "#171A20", "Settings": "#707987",
    "Browser": "#3D8BFF", "Store": "#347DE8", "Calculator": "#3DBE74",
    "Calendar": "#EF5D68", "Gallery": "#8B67DE", "Notepad": "#E5B83D",
    "Notes": "#E5B83D", "Weather": "#39A9D6", "Task Manager": "#35A7A0",
    "Welcome": "#8066D8", "Widgets": "#DD5D8C", "Trash": "#687383",
    "Home": "#397DDF", "Search": "#397DDF", "Apps": "#5865D8",
    "Power": "#E25662", "Sound": "#E08A3E", "Appearance": "#8B67DE",
    "Accessibility": "#397DDF", "Privacy": "#53657A", "User": "#6577D8",
    "Documents": "#397DDF", "Downloads": "#3BAA91", "Images": "#B05BC7",
    "Music": "#DD5D8C", "Videos": "#E26464", "Clock": "#D59A2E",
    "Screenshot": "#6C7CFF", "Continuum": "#8B67DE", "Start": "#397DDF",
    "Calculator": "#3DBE74", "Calendar": "#EF5D68", "Gallery": "#A879E8",
    "AboutPC":"#6E7FE8",
}

ICON_GLYPHS = {
    "Home": "⌂", "Start": "⌂", "Browser": "◎", "Files": "▰", "Settings": "⚙",
    "Terminal": ">_", "Calculator": "÷", "Calendar": "▦", "Clock": "◷",
    "Gallery": "▧", "Notepad": "✎", "Notes": "✎", "Screenshot": "⌗",
    "Continuum": "∞", "Store": "▣", "Task Manager": "▥", "Weather": "☀",
    "Welcome": "N", "Widgets": "◫", "Trash": "♲", "Downloads": "↓",
    "Documents": "≡", "Images": "◇", "Music": "♫", "Videos": "▶",
    "Privacy": "◆", "Sound": "♪", "Accessibility": "♿", "User": "●",
    "Appearance": "◐", "Dock": "▱", "System": "⚙", "Apps": "▦",
    "AboutPC":"i", "Backup":"↻", "Browser":"◎",
}



def icon_path_for(name: str) -> Path | None:
    candidates = {name.replace(" ", ""), name.replace(" ", "_"), name}
    normalized = {value.casefold() for value in candidates}
    generated = ICONS_DIR / "nexora_circles"
    # Main applications keep the original Nexora artwork.  Shell, Files,
    # Settings and widget actions use the newly generated circular library.
    search_roots = (ICONS_DIR, generated) if name in APP_ICON_NAMES else (generated, ICONS_DIR)
    for root in search_roots:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if path.is_file() and path.suffix.lower() in {".png", ".svg", ".ico"} and path.stem.casefold() in normalized:
                return path
    return None


@lru_cache(maxsize=256)
def qt_icon(name: str) -> QIcon:
    path = icon_path_for(name)
    if path is None:
        pixmap = QPixmap(256, 256)
        pixmap.fill(Qt.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(FLAT_ICON_COLORS.get(name, APP_COLORS.get(name, "#4F7ED8"))))
        painter.drawEllipse(8, 8, 240, 240)
        painter.setPen(QColor("#FFFFFF"))
        fallback_font = QFont(QApplication.font().family(), 74)
        fallback_font.setBold(True)
        painter.setFont(fallback_font)
        label = ICON_GLYPHS.get(name, "✦")
        painter.drawText(pixmap.rect(), Qt.AlignCenter, label)
        painter.end()
        return QIcon(pixmap)
    if path.suffix.lower() != ".png":
        return QIcon(str(path))
    try:
        with Image.open(path) as source:
            source = source.convert("RGBA").resize((256, 256), Image.Resampling.LANCZOS)
            pixels = source.load()
            mask = Image.new("L", source.size, 0)
            mask_pixels = mask.load()
            for y in range(source.height):
                for x in range(source.width):
                    red, green, blue, alpha = pixels[x, y]
                    if alpha > 32 and min(red, green, blue) >= 222 and max(red, green, blue) - min(red, green, blue) <= 28:
                        mask_pixels[x, y] = alpha
        if name == "Welcome":
            mask = Image.new("L", (256, 256), 0)
            logo = ImageDraw.Draw(mask)
            logo.line(((78, 174), (78, 82), (178, 174), (178, 82)), fill=255, width=24, joint="curve")
        elif name in {"Apps", "Show Apps"}:
            mask = Image.new("L", (256, 256), 0)
            logo = ImageDraw.Draw(mask)
            for left, top in ((72, 72), (136, 72), (72, 136), (136, 136)):
                logo.rounded_rectangle((left, top, left + 48, top + 48), radius=12, fill=255)
        elif mask.getbbox():
            glyph = mask.crop(mask.getbbox())
            scale = min(156 / max(1, glyph.width), 156 / max(1, glyph.height))
            target = (max(1, round(glyph.width * scale)), max(1, round(glyph.height * scale)))
            glyph = glyph.resize(target, Image.Resampling.LANCZOS)
            centered = Image.new("L", (256, 256), 0)
            centered.paste(glyph, ((256 - glyph.width) // 2, (256 - glyph.height) // 2))
            mask = centered
        color = FLAT_ICON_COLORS.get(name, APP_COLORS.get(name, "#4F7ED8"))
        image = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        draw.ellipse((8, 8, 248, 248), fill=color)
        glyph = Image.new("RGBA", image.size, "#FFFFFF")
        image.alpha_composite(Image.composite(glyph, Image.new("RGBA", image.size), mask))
        return QIcon(QPixmap.fromImage(ImageQt(image)))
    except (OSError, ValueError):
        return QIcon(str(path))


PRIMARY_FONT = "Gugi"

def font(size: int, bold: bool = False) -> QFont:
    app = QApplication.instance()
    settings = load_settings()
    requested = str(settings.get("font_family", "system"))
    if app is not None:
        families = set(QFontDatabase.families())
        if requested not in {"", "system"} and requested in families:
            family = requested
        else:
            family = PRIMARY_FONT if PRIMARY_FONT in families else app.font().family()
    else:
        family = requested if requested not in {"", "system"} else PRIMARY_FONT
    scale = float(settings.get("ui_scale", 1.0)) * (1.15 if settings.get("large_text") else 1.0)
    f = QFont(family, max(7, round(size * scale)))
    f.setBold(bold)
    return f


def rounded_css(bg: str, radius: int = 24, border: str = BORDER) -> str:
    return f"background:{bg}; border:none; border-radius:{radius}px; color:{TEXT};"




def create_nexora_menu(parent=None) -> QMenu:
    """Create a system menu using the same Basic glass tokens as windows."""
    dark = str(load_settings().get("theme_mode", "light")).lower() == "dark"
    menu = QMenu(parent)
    menu.setObjectName("NexoraMenu")
    menu.setWindowFlag(Qt.FramelessWindowHint, True)
    menu.setAttribute(Qt.WA_TranslucentBackground, True)
    panel = "rgba(22,27,36,176)" if dark else "rgba(230,239,247,174)"
    text = "#FFFFFF" if dark else "#111318"
    border = "rgba(255,255,255,92)" if dark else "rgba(255,255,255,172)"
    menu.setStyleSheet(f"""
        QMenu#NexoraMenu {{ background:{panel}; color:{text}; border:none; border-radius:14px; padding:8px; }}
        QMenu#NexoraMenu::item {{ min-width:220px; padding:10px 16px; margin:2px; border-radius:10px; background:transparent; }}
        QMenu#NexoraMenu::item:selected {{ background:rgba(63,140,255,118); color:{text}; }}
        QMenu#NexoraMenu::separator {{ height:1px; background:rgba(255,255,255,52); margin:7px 10px; }}
    """)
    return menu



def scaled_wallpaper(pixmap: QPixmap, widget: QWidget, mode=Qt.KeepAspectRatioByExpanding) -> QPixmap:
    """Scale wallpaper for the widget's physical pixel density.

    Qt widgets use logical pixels on Retina/HiDPI displays. Scaling only to the
    logical widget size makes a Full HD or 4K source look soft because Qt then
    stretches it again to physical pixels. This helper renders directly for the
    device pixel ratio and tags the result correctly.
    """
    if pixmap.isNull() or widget.width() <= 0 or widget.height() <= 0:
        return QPixmap()
    dpr = max(1.0, float(widget.devicePixelRatioF()))
    target = QSize(max(1, round(widget.width() * dpr)), max(1, round(widget.height() * dpr)))
    result = pixmap.scaled(target, mode, Qt.SmoothTransformation)
    result.setDevicePixelRatio(dpr)
    return result

def scaled_wallpaper_logical(pixmap: QPixmap, widget: QWidget, mode=Qt.KeepAspectRatioByExpanding) -> QPixmap:
    """Return a DPR-neutral desktop-sized canvas for exact backdrop sampling.

    GlassFrame coordinates are QWidget logical coordinates. Keeping this cache at
    devicePixelRatio 1 avoids mixing Retina physical pixels with logical widget
    positions, while the visible wallpaper can still use the HiDPI helper.
    """
    if pixmap.isNull() or widget.width() <= 0 or widget.height() <= 0:
        return QPixmap()
    target = QSize(max(1, widget.width()), max(1, widget.height()))
    result = pixmap.scaled(target, mode, Qt.SmoothTransformation)
    result.setDevicePixelRatio(1.0)
    return result


def ensure_blurred_wallpaper() -> Path:
    wallpaper = current_wallpaper_path()
    radius = max(10, min(60, int(load_settings().get("blur_radius", 48))))
    target = DATA_DIR / f"wallpaper_blurred_{wallpaper.stem}_{radius}.png"
    try:
        if target.exists() and target.stat().st_mtime >= wallpaper.stat().st_mtime:
            return target
        with Image.open(wallpaper) as image:
            image.convert("RGB").filter(ImageFilter.GaussianBlur(radius)).save(target, optimize=True)
    except Exception:
        return wallpaper
    return target


def nexora_tooltip_text(title: str, description: str = "") -> str:
    """Consistent concise tooltip copy for Nexora-owned controls."""
    title = str(title or "").strip()
    description = str(description or "").strip()
    return f"{title} — {description}" if description else title
