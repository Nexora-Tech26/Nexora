from .shared import *
from .components import (
    AnimatedNotch, DockHoverButton, DockShell, GlassFrame, NotificationToast,
    PowerOverlay, QuickControls,
)
from .app_window import AppWindow
from .start_menu import StartMenu
from .desktop_widget import DesktopWidget
from .command_palette import CommandPalette
from .notification_center import NotificationCenter
from .control_center import ControlCenterPanel
from .dock_preview import DockPreview
from System.settings import get_settings_store
from System.theme import ThemeEngine
from System.services import ClipboardService, MotionEngine, SessionRecoveryService, SoundService, UsageService, WallpaperRenderService
from System.notifications import NotificationService
from System.widgets import create_default_registry
from System.apps.catalog import visible_app_paths
from System.platform_support import PlatformAdapter
from System.windowing import WindowStateStore
from System.pro import (SpaceManager, ScenarioEngine, SnapshotManager, PermissionManager, ExtensionManager, HealthMonitor, CacheManager)

from .desktop_state import DesktopStateMixin
from .desktop_dock import DesktopDockMixin
from System.platform_support.touchbar import TouchBarController
from .desktop_settings import DesktopSettingsMixin
from .shortcut_manager import ShortcutManagerMixin

class Desktop(ShortcutManagerMixin, DesktopStateMixin, DesktopDockMixin, DesktopSettingsMixin, QWidget):
    lockRequested = Signal()
    startupReady = Signal()
    startupFailed = Signal(str)
    """Main desktop with a strict two-layer composition.

    The wallpaper is a real child widget at the very bottom. Every interactive
    element lives in ``ui_layer`` above it. This avoids platform-dependent
    paintEvent/child stacking behaviour in fullscreen mode.
    """

    def __init__(self):
        super().__init__()
        apply_theme_palette()
        self.setWindowTitle("Nexora Desktop")
        self.setWindowFlag(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_OpaquePaintEvent, True)
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.setStyleSheet(f"background:{BG};")

        self.settings_store = get_settings_store(SETTINGS_FILE)
        if os.environ.get("NEXORA_SAFE_MODE") == "1":
            self.settings_store.update({
                "animations": False, "reduce_motion": True, "disable_transparency": True,
                "performance_mode": "battery_saver", "blur_radius": 0, "shadow_strength": 0,
            }, save=False)
        self.theme_engine = ThemeEngine(self.settings_store, self)
        self.motion_engine = MotionEngine(self.settings_store, self)
        self.notification_service = NotificationService(DATA_DIR / "notifications.json", self.settings_store, self)
        self.sound_service = SoundService(self.settings_store, SYSTEM_ROOT / "sys" / "resources" / "Sounds", self)
        self.platform_adapter = PlatformAdapter()
        self.widget_registry = create_default_registry()
        self.clipboard_service = ClipboardService(self)
        self.usage_service = UsageService(DATA_DIR / "app_usage.json")
        self.wallpaper_service = WallpaperRenderService(DATA_DIR, self)
        self.window_state = WindowStateStore(DATA_DIR / "window_state.json")
        # Nexora 26 Beta 1 platform services. These services are persistent and UI-agnostic,
        # so applications can use them without duplicating storage or validation.
        self.space_manager = SpaceManager(DATA_DIR)
        self.scenario_engine = ScenarioEngine(DATA_DIR)
        self.snapshot_manager = SnapshotManager(DATA_DIR, NEXORA_HOME)
        self.permission_manager = PermissionManager(DATA_DIR)
        self.extension_manager = ExtensionManager(DATA_DIR)
        self.health_monitor = HealthMonitor(PROJECT_ROOT, DATA_DIR)
        self.cache_manager = CacheManager(DATA_DIR)
        self.wallpaper_path = current_wallpaper_path()
        self.wallpaper_service.set_wallpaper(self.wallpaper_path, fit=str(load_settings().get("wallpaper_fit", "cover")), saturation=int(load_settings().get("material_saturation", 100)))
        self.wallpaper = self.wallpaper_service.original
        self.blurred_wallpaper = QPixmap()
        self.blurred_scaled = QPixmap()
        self.theme_engine.transitionFrame.connect(self._on_theme_frame)
        self.theme_engine.themeChanged.connect(self._on_theme_complete)
        self.app_paths = self._visible_app_catalog()
        self.session_recovery = SessionRecoveryService(DATA_DIR, APPS_DIR)
        self._recover_previous_session = self.session_recovery.begin()
        # The offscreen Qt plugin is used by automated smoke tests and has no
        # compositor/session concept. Restoring persisted windows there can race
        # with teardown from a previous QApplication and produce false failures.
        if os.environ.get("QT_QPA_PLATFORM", "").casefold() == "offscreen":
            self._recover_previous_session = False
        self.windows = {}
        self.window_groups = {}
        self.window_z = []
        self.desktop_widgets = []
        self.widget_edit_mode = False
        self.desktop_shortcuts = []
        self.task_buttons = {}
        self.app_badges = {}
        self.app_progress = {}
        self.search_workers = []
        self.browser_process = None
        self.pinned = self.load_pins()
        self._clock_timer = None
        self._session_save_timer = None
        self._theme_frame_clock = 0.0
        self._ui_ready = False
        self._startup_error = None
        self._startup_validation_attempts = 0
        self.command_palette = None
        # Predeclare dock members because macOS/Qt may deliver resize/show events
        # re-entrantly while child widgets are still being constructed.
        self.task_shell = None
        self.task_backdrop = None
        self.quick_shell = None
        self.clock_shell = None
        self.start_button = None
        self.notch = None
        self.menu = None
        self.background = None
        self.ui_layer = None
        self.app_layer = None
        self.clock = None
        self.touchbar = None  # Disabled by default in performance build; avoids global macOS focus polling

        # Resolve the theme before creating any shell. Several child builders
        # need text/surface colors during construction, before the first live
        # theme refresh is emitted.
        self._startup_theme = getattr(self.theme_engine, "current", None) or self.theme_engine.resolve(self.settings_store.snapshot())

        # Build while the desktop is hidden behind the dedicated loading screen.
        self._build_layers()
        app = QApplication.instance()
        if app is not None:
            app.setStyleSheet(rounded_control_stylesheet(self.settings_store.snapshot(), theme=self._startup_theme))
            app.installEventFilter(self)

        # Startup is staged through the event loop. The core does not reveal the
        # desktop until these essential stages finish without an exception.
        QTimer.singleShot(0, lambda: self._run_startup_stage(0))


    def _run_startup_stage(self, stage: int) -> None:
        """Prepare essential desktop state without exposing a half-built shell."""
        try:
            if stage == 0:
                self.refresh_desktop_shortcuts()
                QTimer.singleShot(35, lambda: self._run_startup_stage(1))
                return
            if stage == 1:
                self.apply_wallpaper_variant()
                QTimer.singleShot(35, lambda: self._run_startup_stage(2))
                return
            if stage == 2:
                self.apply_ui_style()
                self.position_shells()
                self.raise_shells()
                QApplication.processEvents()
                QTimer.singleShot(55, lambda: self._run_startup_stage(3))
                return
            if stage == 3:
                required = ("ui_layer", "app_layer", "start_button", "task_shell", "task_backdrop", "quick_shell", "clock_shell", "command_palette")
                missing = [name for name in required if not hasattr(self, name) or getattr(self, name, None) is None]
                if getattr(self, "_startup_error", None) is not None:
                    raise RuntimeError(f"Desktop UI initialization failed: {self._startup_error}")
                if missing or not self._ui_ready:
                    self._startup_validation_attempts += 1
                    if self._startup_validation_attempts < 80:
                        QTimer.singleShot(50, lambda: self._run_startup_stage(3))
                        return
                    raise RuntimeError("Desktop startup validation timed out: " + ", ".join(missing or ["UI not ready"]))
                # Two event-loop heartbeats ensure pending layouts and queued
                # style operations have completed before the loading screen exits.
                QTimer.singleShot(80, self._confirm_startup_responsive)
        except Exception as exc:
            self.startupFailed.emit(str(exc))

    def _confirm_startup_responsive(self) -> None:
        try:
            if not self._ui_ready or not self.isEnabled():
                raise RuntimeError("Desktop did not become responsive")
            self.startupReady.emit()
        except Exception as exc:
            self.startupFailed.emit(str(exc))

    def start_background_services(self) -> None:
        """Start optional work only after the usable desktop is visible."""
        if bool(self.settings_store.get("automation_enabled", True)) and os.environ.get("NEXORA_SAFE_MODE") != "1":
            QTimer.singleShot(900, self._process_startup_automations)
        if os.environ.get("NEXORA_SAFE_MODE") != "1":
            if self._recover_previous_session:
                QTimer.singleShot(650, self._restore_previous_session)
            self._session_save_timer = QTimer(self)
            self._session_save_timer.setInterval(1200)
            self._session_save_timer.timeout.connect(self.save_window_session)
            self._session_save_timer.start()

    def save_window_session(self) -> None:
        service = getattr(self, "session_recovery", None)
        if service is None:
            return
        windows = [w for w in getattr(self, "window_z", []) if qt_object_is_valid(w)]
        try:
            service.save_windows(windows)
        except (OSError, RuntimeError, TypeError, ValueError):
            pass


    def _find_app_path(self, name: str):
        target = str(name).casefold().strip()
        return next((path for path in self.app_paths if app_name(path).casefold() == target), None)

    def activate_space(self, key: str, *, launch_apps: bool = False):
        """Activate a persistent Space and apply its theme/performance profile."""
        space = self.space_manager.activate(str(key))
        snapshot = self.settings_store.update({
            "ui_style": space.theme,
            "performance_mode": space.performance,
        })
        self.theme_engine.apply(space.theme, overrides=snapshot, animate=bool(snapshot.get("animations", True)))
        self.apply_settings(snapshot)
        if launch_apps:
            for name in space.apps:
                path = self._find_app_path(name)
                if path is not None:
                    self.open_app(path)
        self.notification_service.post("spaces", f"Space: {space.name}", "Desktop profile activated", expires_ms=3500)
        return space

    def _execute_automation_action(self, action):
        action_type = str(action.get("type", ""))
        if action_type == "set_setting":
            key = str(action.get("key", "")).strip()
            if key not in self.settings_store.snapshot():
                raise ValueError(f"Unknown setting: {key}")
            snapshot = self.settings_store.update({key: action.get("value")})
            self.apply_settings(snapshot)
        elif action_type == "open_app":
            path = self._find_app_path(str(action.get("app", "")))
            if path is None:
                raise ValueError(f"Application not found: {action.get('app', '')}")
            self.open_app(path)
        elif action_type == "activate_space":
            self.activate_space(str(action.get("space", "work")), launch_apps=bool(action.get("launch_apps", False)))
        elif action_type == "notify":
            self.notification_service.post(
                "automation",
                str(action.get("title", "Automation")),
                str(action.get("message", "Scenario completed")),
                expires_ms=max(1500, min(15000, int(action.get("expires_ms", 4500)))),
            )
        elif action_type == "set_wallpaper":
            target = Path(str(action.get("path", ""))).expanduser()
            if not target.is_file() or target.suffix.casefold() not in {".svg", ".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
                raise ValueError("Automation wallpaper path is not a supported image")
            self.set_wallpaper(target)
        else:
            raise ValueError(f"Unsupported automation action: {action_type}")

    def _process_startup_automations(self):
        try:
            executed = self.scenario_engine.process({"type": "startup"}, self._execute_automation_action)
        except (OSError, RuntimeError, TypeError, ValueError, KeyError) as exc:
            self.notification_service.post("automation", "Automation error", str(exc), priority="high", expires_ms=7000)
            return
        if executed:
            self.notification_service.post("automation", "Automations completed", f"Ran {len(executed)} startup scenario(s).", expires_ms=4000)

    def _restore_previous_session(self):
        restored = 0
        area = self.app_layer.rect()
        for state in self.session_recovery.restore_windows():
            try:
                window = self.open_app(state["path"])
                if window is None:
                    continue
                if all(key in state for key in ("x", "y", "width", "height")):
                    width = max(window.minimumWidth(), min(int(state["width"]), max(window.minimumWidth(), area.width())))
                    height = max(window.minimumHeight(), min(int(state["height"]), max(window.minimumHeight(), area.height())))
                    x = max(0, min(int(state["x"]), max(0, area.width() - width)))
                    y = max(0, min(int(state["y"]), max(0, area.height() - height)))
                    window.setGeometry(x, y, width, height)
                    window._normal_geometry = QRect(window.geometry())
                if bool(state.get("zoomed", False)) and not getattr(window, "_zoomed", False):
                    window.toggle_zoom()
                if bool(state.get("minimized", False)):
                    window.minimize_animated()
                restored += 1
            except (OSError, RuntimeError, ValueError, TypeError, KeyError):
                continue
        if restored:
            self.notification_service.post("system", "Workspace restored", f"Restored {restored} window(s) with their previous size and position.", expires_ms=6000)

    def _on_theme_frame(self, theme):
        now = time.monotonic()
        if now - getattr(self, "_theme_frame_clock", 0.0) < 1.0 / 30.0:
            return
        self._theme_frame_clock = now
        settings = self.settings_store.snapshot()
        apply_theme_palette(settings, theme=theme)
        self.setStyleSheet(f"background:{theme.background};")
        if hasattr(self, "background"):
            self.background.setStyleSheet(f"background:{theme.background};border:none;")
        quick_shell = getattr(self, "quick_shell", None)
        if qt_object_is_valid(quick_shell) and hasattr(quick_shell, "apply_theme"):
            quick_shell.apply_theme(theme)
        clock = getattr(self, "clock", None)
        if qt_object_is_valid(clock):
            dark = QColor(theme.background).lightness() < 128
            fallback_text = "#F7F8FC" if dark else "#17191F"
            clock_color = getattr(theme, "text", fallback_text) or fallback_text
            clock.setStyleSheet(f"background:transparent;border:none;color:{clock_color};")
        for widget in self.findChildren(GlassFrame):
            if qt_object_is_valid(widget):
                widget.update()

    def _on_theme_complete(self, theme):
        """Apply expensive global/window styles once after interpolation."""
        self._theme_frame_clock = 0.0
        self._on_theme_frame(theme)
        settings = self.settings_store.snapshot()
        app = QApplication.instance()
        if app is not None:
            app.setStyleSheet(rounded_control_stylesheet(settings, theme=theme))
        if hasattr(self, "wallpaper_service") and self.size().isValid():
            self.blurred_scaled = self.wallpaper_service.blurred_pixmap(int(theme.blur))
        for group in getattr(self, "window_groups", {}).values():
            for window in tuple(group):
                if qt_object_is_valid(window) and hasattr(window, "apply_theme_skin"):
                    window.apply_theme_skin(theme)
        for shortcut in getattr(self, "desktop_shortcuts", []):
            if qt_object_is_valid(shortcut):
                shortcut.set_selected(bool(shortcut.property("selected")))
        for widget in self.findChildren(GlassFrame):
            if qt_object_is_valid(widget):
                widget.update()

    def _visible_app_catalog(self):
        try:
            paths = [path for path in APPS_DIR.glob("*.py") if not path.name.startswith("_")]
        except OSError:
            paths = []
        return sorted(dict.fromkeys(paths), key=lambda path: app_name(path).casefold())

    def reload_app_catalog(self):
        """Reload the installed application manifests."""
        paths = self._visible_app_catalog()
        if paths:
            self.app_paths = paths
        elif not getattr(self, "app_paths", None):
            self.app_paths = []
        return self.app_paths

    def _build_layers(self):
        try:
            self.background = QLabel(self)
            self.background.setObjectName("WallpaperLayer")
            self.background.setScaledContents(False)
            self.background.setStyleSheet(f"background:{BG};border:none;")
            if not self.wallpaper.isNull():
                self.background.setPixmap(self.wallpaper)
            self.background.show()
            self.background.lower()

            self.ui_layer = QWidget(self)
            self.ui_layer.setObjectName("DesktopUiLayer")
            self.ui_layer.setAttribute(Qt.WA_TranslucentBackground, True)
            self.ui_layer.setStyleSheet("#DesktopUiLayer{background:transparent;}")
            self.ui_layer.show()

            self.brightness_overlay = QFrame(self.ui_layer)
            self.brightness_overlay.setObjectName("BrightnessOverlay")
            self.brightness_overlay.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            self.brightness_overlay.setStyleSheet("background:transparent;border:none;")
            self.brightness_overlay.hide()
            self.night_light_overlay = QFrame(self.ui_layer)
            self.night_light_overlay.setObjectName("NightLightOverlay")
            self.night_light_overlay.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            self.night_light_overlay.setStyleSheet("background:transparent;border:none;")
            self.night_light_overlay.hide()

            self.app_layer = QWidget(self.ui_layer)
            self.app_layer.setObjectName("AppLayer")
            self.app_layer.setAttribute(Qt.WA_TranslucentBackground, True)
            self.app_layer.setStyleSheet("#AppLayer{background:transparent;}")
            self.app_layer.show()

            self.selection_glass = GlassFrame(self.app_layer, radius=14, alpha=38, gradient=False, wallpaper_backdrop=True)
            self.selection_glass.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            self.selection_glass.setStyleSheet("QFrame{background:rgba(55,145,255,48);border:none;border-radius:22px;}")
            self.selection_glass.hide()
            self._selection_origin = None

            self.global_menu_bar = QFrame(self.ui_layer)
            self.global_menu_bar.setObjectName("GlobalMenuBar")
            self.global_menu_bar.setFixedHeight(34)
            self.global_menu_bar.setStyleSheet("#GlobalMenuBar{background:rgba(238,242,247,44);border:none;}")
            self.global_menu_layout = QHBoxLayout(self.global_menu_bar)
            self.global_menu_layout.setContentsMargins(14, 0, 14, 0); self.global_menu_layout.setSpacing(4)
            self.global_app_name = QLabel("Nexora"); self.global_app_name.setFont(font(10, True))
            self.global_menu_layout.addWidget(self.global_app_name)
            self.global_menu_actions = QFrame(); self.global_menu_actions_layout = QHBoxLayout(self.global_menu_actions)
            self.global_menu_actions_layout.setContentsMargins(4,0,4,0); self.global_menu_actions_layout.setSpacing(2)
            self.global_menu_layout.addWidget(self.global_menu_actions)
            self.global_menu_layout.addStretch()
            self.global_menu_bar.hide()

            self.start_button = QPushButton(self.ui_layer)
            self.start_button.setIcon(qt_icon("Home")); self.start_button.setIconSize(QSize(24, 24))
            self.start_button.setFixedSize(40, 40)
            self.start_button.setFocusPolicy(Qt.NoFocus)
            self.start_button.setStyleSheet(
                "QPushButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #72B8FF,stop:1 #8B67DE);border:none;outline:none;border-radius:20px;color:white;}"
                "QPushButton:hover{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #91CAFF,stop:1 #A77DE9);border:none;outline:none;border-radius:20px;}"
                "QPushButton:pressed,QPushButton:focus,QPushButton:checked{border:none;outline:none;}"
            )

            # The dock is a transparent interaction container with a separate
            # glass backdrop anchored to its bottom.  Icons can therefore rise
            # above the bar without changing the bar height.
            self.task_shell = DockShell(self.ui_layer)
            self.task_backdrop = GlassFrame(self.task_shell, radius=24, alpha=52, gradient=False, wallpaper_backdrop=True)
            self.task_backdrop.tint_color = "#607DB8"
            self.task_backdrop.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            self.task_backdrop.setStyleSheet("background:transparent;border:none;")
            self.task_layout = QHBoxLayout(self.task_shell)
            self.task_layout.setContentsMargins(7, 4, 7, 4)
            self.task_layout.setSpacing(2)
            self.task_layout.setAlignment(Qt.AlignCenter)
            self.task_shell.hoverChanged.connect(self._dock_shell_hover)
            self.task_shell.pointerMoved.connect(self._dock_pointer_moved)
            self._dock_current_index = None
            self._dock_pointer_x = None
            self._dock_hover_active = False
            self._dock_render_sizes = []
            self._dock_target_sizes = []
            self._dock_anim_timer = QTimer(self)
            self._dock_anim_timer.setInterval(16)
            self._dock_anim_timer.timeout.connect(self._dock_animation_tick)
            self._task_count = 0

            self.quick_shell = QuickControls(self)
            self.quick_shell.tint_color = "#5878D8"

            self.notch = AnimatedNotch(self.ui_layer, "Nexora")
            self.notch.show()
            # notch metrics polling disabled; static notch is cheaper
            self.notification_toast = NotificationToast(self)
            self.dock_preview = DockPreview(self)
            self.notification_center = NotificationCenter(self)
            self.control_center = ControlCenterPanel(self)
            self.notification_service.notificationAdded.connect(self._present_notification)

            self.clock_shell = GlassFrame(self.ui_layer, radius=22, alpha=52, gradient=False, wallpaper_backdrop=True)
            self.clock_shell.tint_color = "#E9B94E"
            clock_layout = QVBoxLayout(self.clock_shell)
            clock_layout.setContentsMargins(12, 3, 12, 3)
            self.clock = QLabel()
            self.clock.setAlignment(Qt.AlignCenter)
            self.clock.setFont(font(10, True))
            self.clock.setStyleSheet(f"background:transparent;border:none;color:{self._startup_theme.text};")
            clock_layout.addWidget(self.clock)

            self.command_palette = CommandPalette(self)
            self.menu = StartMenu(self)
            self.menu.setParent(self.ui_layer)
            self.menu.desktop = self
            self.menu.launch.connect(self.open_app)
            self.menu.pin.connect(self.toggle_pin)
            self.menu.folder.connect(self.open_folder)
            self.menu.power.connect(self.show_power_overlay)
            self.start_button.clicked.connect(self.toggle_start)
            self.power_overlay = PowerOverlay(self)
            self.menu.hide()

            for widget in (self.ui_layer, self.app_layer, self.start_button, self.task_shell, self.quick_shell, self.clock_shell, self.notch):
                widget.show()

            self._ui_ready = True
            self.refresh_taskbar()
            self.update_clock()
            self.apply_ui_style()
            self.position_shells()
            self.apply_brightness(int(load_settings().get("brightness", 100)))
            self.apply_night_light()
            self.raise_shells()
        except Exception as exc:
            import traceback
            log = DATA_DIR / "nexora.log"
            log.write_text(traceback.format_exc(), encoding="utf-8")
            self._ui_ready = False
            self._startup_error = f"{type(exc).__name__}: {exc}"
            self.fallback = QLabel(
                "Nexora UI failed to initialize.\n"
                f"{type(exc).__name__}: {exc}\n"
                f"Log: {log}", self
            )
            self.fallback.setAlignment(Qt.AlignCenter)
            self.fallback.setWordWrap(True)
            self.fallback.setStyleSheet(
                "background:#1B1B1F;color:#FF7777;border:none;"
                "border-radius:22px;padding:24px;font-size:16px;"
            )
            self.fallback.resize(680, 220)
            self.fallback.show()
            self.fallback.raise_()

    def _present_notification(self, notification):
        if not bool(self.settings_store.get("notifications", True)):
            return
        self.notification_toast.title.setText(notification.title)
        self.notification_toast.present(notification.message, duration=max(1600, min(7000, notification.expires_ms or 3500)))
        self.sound_service.play("notification")
        key = notification.app_id.replace("_", " ").casefold()
        path = next((item for item in self.app_paths if app_name(item).casefold() == key), None)
        if path is not None:
            self.set_app_badge(path, int(self.app_badges.get(Path(path).resolve(), 0)) + 1)

    def toggle_notification_center(self):
        if hasattr(self, "notification_center"):
            self.notification_center.toggle()

    def toggle_control_center(self):
        if hasattr(self, "control_center"):
            self.control_center.toggle()

    def showEvent(self, event):
        super().showEvent(event)
        self.position_shells()
        self.raise_shells()

    def apply_display_viewport(self):
        """Apply the logical desktop viewport without recreating Qt widgets.

        The no-styles build still supports the display_mode setting.  Earlier
        cleanup removed this method but left calls in resizeEvent/apply_settings,
        which raised AttributeError while Qt was showing the fullscreen desktop.
        """
        if not hasattr(self, "ui_layer"):
            return

        available = self.rect()
        if available.width() <= 0 or available.height() <= 0:
            return

        # A logical resolution must never create letterboxing.  The complete
        # Nexora desktop always fills the physical window/screen; display_mode
        # only describes the logical workspace used by settings and apps.
        old_size = getattr(self, "_last_full_viewport_size", QSize())
        viewport = QRect(0, 0, available.width(), available.height())
        self.ui_layer.setGeometry(viewport)
        if hasattr(self, "brightness_overlay"):
            self.brightness_overlay.setGeometry(self.ui_layer.rect())
        if hasattr(self, "night_light_overlay"):
            self.night_light_overlay.setGeometry(self.ui_layer.rect())
        if hasattr(self, "app_layer") and not self._ui_ready:
            self.app_layer.setGeometry(self.ui_layer.rect())

        new_size = QSize(available.width(), available.height())
        if old_size.isValid() and old_size.width() > 0 and old_size.height() > 0 and old_size != new_size:
            sx = new_size.width() / old_size.width()
            sy = new_size.height() / old_size.height()
            for window in list(getattr(self, "windows", {}).values()):
                if not window or window._zoomed:
                    continue
                g = window.geometry()
                scaled = QRect(
                    round(g.x() * sx), round(g.y() * sy),
                    max(window.minimumWidth(), round(g.width() * sx)),
                    max(window.minimumHeight(), round(g.height() * sy)),
                )
                window.setGeometry(scaled)
                window.constrain_to_host()
        self._last_full_viewport_size = new_size

    def apply_brightness(self, value):
        """Apply Nexora's simulated brightness safely.

        Brightness is implemented as a mouse-transparent black overlay so it
        does not recreate desktop widgets or interfere with the selected UI
        profile.  Physical display control remains optional and is handled by
        the existing system service when available.
        """
        try:
            level = max(20, min(100, int(value)))
        except (TypeError, ValueError):
            level = 100

        overlay = getattr(self, "brightness_overlay", None)
        if overlay is None:
            return

        darkness = round((100 - level) * 2.25)
        overlay.setGeometry(self.ui_layer.rect() if hasattr(self, "ui_layer") else self.rect())
        overlay.setStyleSheet(
            f"QFrame{{background:rgba(0,0,0,{darkness});border:none;}}"
        )
        overlay.setVisible(darkness > 0)
        if darkness > 0:
            overlay.raise_()
            self.raise_shells()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "background"):
            self.background.setGeometry(self.rect())
        if hasattr(self, "wallpaper_service") and self.width() > 0 and self.height() > 0:
            self.wallpaper_service.update_viewport(self.size(), self.devicePixelRatioF())
            self.wallpaper = self.wallpaper_service.original
            self.blurred_scaled = self.wallpaper_service.blurred_pixmap(int(load_settings().get("blur_radius", 48)))
            if hasattr(self, "background"):
                self.background.setPixmap(self.wallpaper_service.scaled)
        if hasattr(self, "ui_layer"):
            self.apply_display_viewport()
        if hasattr(self, "app_layer"):
            for window in list(self.windows.values()):
                window.constrain_to_host()
        if hasattr(self, "fallback"):
            self.fallback.move(max(20, (self.width()-self.fallback.width())//2), max(20, (self.height()-self.fallback.height())//2))
        self.position_shells()
        self.raise_shells()

    def rebuild_global_menu(self, window=None):
        if not hasattr(self, "global_menu_actions_layout"):
            return
        while self.global_menu_actions_layout.count():
            item = self.global_menu_actions_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        name = getattr(window, "title", "Nexora") if window is not None else "Nexora"
        self.global_app_name.setText(name)
        actions = list(getattr(window, "_toolbar_actions", [])) if window is not None else []
        standard = [("File", None), ("Edit", None), ("View", None), ("Window", None), ("Help", None)]
        for label, callback in standard + actions:
            button = QPushButton(label)
            button.setFlat(True); button.setProperty("flat", True); button.setFont(font(9))
            dark = str(load_settings().get("theme_mode", "light")).lower() == "dark"
            menu_fg = "#F7F8FC" if dark else "#17191F"
            menu_bg = "rgba(255,255,255,10)" if dark else "rgba(255,255,255,65)"
            button.setStyleSheet(f"QPushButton{{background:transparent;border:none;padding:5px 10px;color:{menu_fg};border-radius:24px;}}QPushButton:hover{{background:{menu_bg};}}")
            if callback:
                button.clicked.connect(callback)
            self.global_menu_actions_layout.addWidget(button)

    def apply_ui_style(self):
        style = current_ui_style()
        mac = False
        if hasattr(self, "global_menu_bar"):
            self.global_menu_bar.setVisible(mac)
        menu = getattr(self, "menu", None)
        if menu is not None and hasattr(menu, "apply_profile"):
            menu.apply_profile()
        for group in self.window_groups.values():
            for window in group:
                if hasattr(window, "toolbar"):
                    window.toolbar.setVisible(not mac)
        active = self.window_z[-1] if self.window_z else None
        self.rebuild_global_menu(active if mac else None)
        self._apply_common_glass_skin()
        self.refresh_taskbar()
        self.position_shells()
        self.raise_shells()

    def _apply_common_glass_skin(self):
        """Use exactly one Nexora glass/color system for every layout profile."""
        theme = getattr(self.theme_engine, "current", None)
        if theme is None:
            theme = self.theme_engine.resolve(load_settings())
        dark = QColor(theme.background).lightness() < 128
        shell_fg = "#F7F8FC" if dark else "#17191F"
        settings = load_settings()
        transparency = max(0, min(96, int(settings.get("glass_transparency", 80))))
        shell_alpha = max(30, min(220, round(255 * (100 - transparency) / 100)))
        shell_fill = rgba(theme.surface, shell_alpha)
        shell_hover = rgba(theme.accent, 42 if dark else 34)
        shell_border = "rgba(255,255,255,132)"
        launcher_css = (
            f"QPushButton{{background:{shell_fill};border:none;"
            f"border-radius:20px;color:{shell_fg};font-size:19px;font-weight:800;}}"
            f"QPushButton:hover{{background:{shell_hover};border:none;}}"
            f"QPushButton:pressed{{background:{shell_fill};padding-top:1px;}}"
        )
        start_button = getattr(self, "start_button", None)
        if start_button is not None:
            start_button.setStyleSheet(launcher_css)
        task_backdrop = getattr(self, "task_backdrop", None)
        if task_backdrop is not None:
            task_backdrop.alpha = shell_alpha
            task_backdrop.radius = int(settings.get("panel_radius", 25))
            task_backdrop.tint_color = theme.surface
            task_backdrop.update()
        quick_shell = getattr(self, "quick_shell", None)
        clock_shell = getattr(self, "clock_shell", None)
        if quick_shell is not None:
            quick_shell.alpha = shell_alpha
            quick_shell.radius = int(settings.get("panel_radius", 25))
            quick_shell.tint_color = theme.surface
            quick_shell.update()
        if clock_shell is not None:
            clock_shell.alpha = shell_alpha
            clock_shell.radius = int(settings.get("panel_radius", 25))
            clock_shell.tint_color = theme.surface
            clock_shell.update()
        quick_shell = getattr(self, "quick_shell", None)
        if quick_shell is not None and hasattr(quick_shell, "apply_theme"):
            quick_shell.apply_theme(theme)
        if hasattr(self, "control_center") and hasattr(self.control_center, "apply_theme"):
            self.control_center.apply_theme(theme)
        clock = getattr(self, "clock", None)
        if clock is not None:
            startup_theme = getattr(self, "_startup_theme", None) or theme
            clock_color = getattr(startup_theme, "text", shell_fg)
            clock.setStyleSheet(f"background:transparent;border:none;color:{clock_color};")
        menu = getattr(self, "menu", None)
        if menu is not None:
            if hasattr(menu, "radius"):
                menu.radius = 24
            menu.alpha = 64 if dark else 52
            menu.use_gradient = False
            menu.wallpaper_backdrop = True
            menu.update()
        if hasattr(self, "global_menu_bar"):
            menu_bg = "rgba(18,22,31,76)" if dark else "rgba(238,242,247,48)"
            menu_fg = "#F7F8FC" if dark else "#17191F"
            self.global_menu_bar.setStyleSheet(
                f"#GlobalMenuBar{{background:{menu_bg};border:none;color:{menu_fg};border-bottom-left-radius:12px;border-bottom-right-radius:12px;}}"
                f"QLabel{{color:{menu_fg};background:transparent;}}"
            )

    def raise_shells(self):
        if not self._ui_ready:
            if hasattr(self, "fallback"):
                self.fallback.raise_()
            return
        background = getattr(self, "background", None)
        ui_layer = getattr(self, "ui_layer", None)
        app_layer = getattr(self, "app_layer", None)
        if background is not None:
            background.lower()
        if ui_layer is not None:
            ui_layer.raise_()
        if app_layer is not None:
            app_layer.raise_()
        for widget in self.desktop_widgets:
            if widget.isVisible():
                widget.raise_()
        for window in self.window_z:
            if window.isVisible():
                window.raise_()
        if getattr(self, "task_shell", None) is not None:
            self.task_shell.raise_()
        for shell in (getattr(self, "start_button", None), getattr(self, "quick_shell", None), getattr(self, "clock_shell", None), getattr(self, "notch", None)):
            if shell is not None:
                shell.raise_()
        if hasattr(self, "notification_center") and self.notification_center.isVisible():
            self.notification_center.raise_()
        if hasattr(self, "control_center") and self.control_center.isVisible():
            self.control_center.raise_()
        if hasattr(self, "dock_preview") and self.dock_preview.isVisible():
            self.dock_preview.raise_()
        if hasattr(self, "global_menu_bar") and self.global_menu_bar.isVisible():
            self.global_menu_bar.raise_()
        menu = getattr(self, "menu", None)
        if menu is not None and menu.isVisible():
            menu.raise_()
        if hasattr(self, "power_overlay") and self.power_overlay.isVisible():
            self.power_overlay.raise_()
        if hasattr(self,"brightness_overlay") and self.brightness_overlay.isVisible():
            self.brightness_overlay.raise_()
        if hasattr(self,"night_light_overlay") and self.night_light_overlay.isVisible():
            self.night_light_overlay.raise_()

    def _panel_profile(self):
        return panel_profile(load_settings())

    def _taskbar_metrics(self, viewport_width=None):
        profile = self._panel_profile()
        w = max(640, int(viewport_width or getattr(self, "ui_layer", self).width()))
        count = max(1, int(getattr(self, "_task_count", len(getattr(self, "task_buttons", {})))))
        icon = max(34, min(40, int(load_settings().get("taskbar_size", 38))))
        gap = max(1, min(2, int(profile.get("gap", 2))))
        required = 12 + count * icon + max(0, count - 1) * gap
        if profile["width"] == "full":
            extent = max(320, w - 24)
        elif profile["width"] == "wide":
            extent = min(max(520, required + 180), max(520, w - 180))
        elif profile["width"] == "rail":
            extent = max(94, required)
        else:
            extent = max(94, required)
        return icon, gap, extent

    def _layout_taskbar_buttons(self):
        if not hasattr(self, "task_layout"):
            return
        profile = self._panel_profile()
        style = current_ui_style()
        self.task_layout.setDirection(QBoxLayout.TopToBottom if profile["vertical"] else QBoxLayout.LeftToRight)
        button_size, gap, _ = self._taskbar_metrics()
        self.task_layout.setSpacing(gap)

        # macOS and Windows use one coherent centered glass surface.  The N
        # launcher is overlaid inside the same capsule, so reserve its slot in
        # the layout instead of placing it as a detached button to the left.
        if style in {"horizon"}:
            self.task_layout.setContentsMargins(48, 3, 6, 3)
            self.task_layout.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        elif style in {"nova", "aurora", "crystal", "zenith"}:
            self.task_layout.setContentsMargins(6, 3, 6, 3)
            self.task_layout.setAlignment(Qt.AlignCenter)
        elif style in {"graphite", "orbit"}:
            self.task_layout.setContentsMargins(6, 3, 6, 3)
            self.task_layout.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        else:
            self.task_layout.setContentsMargins(6, 3, 6, 3)
            self.task_layout.setAlignment(Qt.AlignCenter)

        if profile["vertical"]:
            if profile.get("align") == "top": self.task_layout.setAlignment(Qt.AlignTop | Qt.AlignHCenter)
            else: self.task_layout.setAlignment(Qt.AlignVCenter | Qt.AlignHCenter)
        elif profile.get("edge") == "top":
            self.task_layout.setAlignment(Qt.AlignCenter | Qt.AlignTop)
        else:
            self.task_layout.setAlignment(Qt.AlignCenter)
        for button in self.task_buttons.values():
            button.setFixedSize(button_size, button_size)
            button.setIconSize(QSize(max(26, button_size - 10), max(26, button_size - 10)))

    def position_shells(self):
        if not self._ui_ready:
            return
        if any(getattr(self, name, None) is None for name in ("task_shell", "task_backdrop", "quick_shell", "clock_shell", "start_button")):
            return
        profile = self._panel_profile()
        style = current_ui_style()
        w = max(640, self.ui_layer.width())
        h = max(480, self.ui_layer.height())
        icon, gap, extent = self._taskbar_metrics(w)
        bar_h = max(44, icon + 6)
        margin = 18
        launcher_w = 40
        quick_w = self.quick_shell.recommended_width(w) if hasattr(self.quick_shell, "recommended_width") else 190
        clock_w = 118
        bottom_y = h - bar_h - margin
        dock_lift = 0

        def set_dock_geometry(x, y, width, height):
            # Fixed capsule: no invisible lift area and no geometry change on hover.
            self.task_shell.setGeometry(x, y, width, height)
            self.task_backdrop.setGeometry(0, 0, width, height)
        top_inset = 0

        if hasattr(self, "global_menu_bar"):
            self.global_menu_bar.setGeometry(0, 0, w, 34)
            self.global_menu_bar.setVisible(False)

        self.start_button.setText(""); self.start_button.setIcon(qt_icon("Home")); self.start_button.setIconSize(QSize(max(20, launcher_w-16), max(20, launcher_w-16)))
        self.start_button.setToolTip(str(profile["launcher"]))
        self.start_button.setFixedSize(launcher_w, launcher_w)
        task_backdrop = getattr(self, "task_backdrop", None)
        if task_backdrop is not None and hasattr(task_backdrop, "radius"):
            task_backdrop.radius = max(18, bar_h // 2)

        # Status controls always retain the same Nexora glass treatment.  Only
        # their layout changes between profiles.
        group_gap = 12
        right_x = w - (quick_w + group_gap + clock_w) - margin
        status_h = bar_h
        self.quick_shell.setMinimumHeight(status_h); self.quick_shell.setMaximumHeight(status_h)
        self.quick_shell.setGeometry(right_x, bottom_y, quick_w, status_h)
        self.clock_shell.setGeometry(right_x + quick_w + group_gap, bottom_y, clock_w, status_h)
        safe_right = right_x - 12

        edge = profile.get("edge", "bottom")
        if profile.get("vertical"):
            rail_w=max(72,icon+24); rail_h=min(max(360,extent),h-112); rail_y=max(64,(h-rail_h)//2)
            if edge=="left":
                rail_x=margin; self.task_shell.setGeometry(rail_x,rail_y,rail_w+dock_lift,rail_h); self.task_backdrop.setGeometry(0,0,rail_w,rail_h)
                self.start_button.move(rail_x+(rail_w-launcher_w)//2,max(12,rail_y-launcher_w-8))
            else:
                rail_x=w-rail_w-margin; self.task_shell.setGeometry(rail_x-dock_lift,rail_y,rail_w+dock_lift,rail_h); self.task_backdrop.setGeometry(dock_lift,0,rail_w,rail_h)
                self.start_button.move(rail_x+(rail_w-launcher_w)//2,max(12,rail_y-launcher_w-8))
            status_y = h - bar_h - margin
            self.quick_shell.setGeometry(margin, status_y, quick_w, bar_h); self.clock_shell.setGeometry(margin + quick_w + group_gap, status_y, clock_w, bar_h)
        elif edge == "top":
            # Crystal/Zenith: command surface at the top with apps below it.
            top_y = margin
            self.quick_shell.setGeometry(right_x, top_y, quick_w, bar_h)
            self.clock_shell.setGeometry(right_x + quick_w + group_gap, top_y, clock_w, bar_h)
            if profile.get("width") == "full":
                bar_w = w - 2 * margin
                bar_x = margin
            else:
                bar_w = min(max(340, extent + 20), max(340, safe_right - 2 * margin))
                bar_x = max(margin + launcher_w + 12, (w - bar_w) // 2)
            if bar_x + bar_w > safe_right:
                bar_x = max(margin + launcher_w + 12, safe_right - bar_w)
            self.task_shell.setGeometry(bar_x, top_y, bar_w, bar_h + dock_lift)
            self.task_backdrop.setGeometry(0, 0, bar_w, bar_h)
            self.start_button.move(max(margin, bar_x - launcher_w + 6), top_y + (bar_h - launcher_w) // 2)
        elif profile.get("width") == "full":
            # Horizon: a single full-width taskbar with an embedded launcher.
            bar_x, bar_w = margin, w - 2 * margin
            set_dock_geometry(bar_x, bottom_y, bar_w, bar_h)
            self.start_button.move(bar_x + 8, bottom_y + (bar_h - launcher_w) // 2)
        elif profile.get("width") == "wide":
            # Aurora: a wider floating dock with generous breathing room.
            bar_w = min(max(520, extent + 160), max(520, safe_right - 2 * margin))
            bar_x = max(margin, (w - bar_w) // 2)
            set_dock_geometry(bar_x, bottom_y, bar_w, bar_h)
            self.start_button.move(max(margin, bar_x - launcher_w + 6), bottom_y + (bar_h - launcher_w) // 2)
        else:
            # Nova: centered compact dock and a separate Nexora launcher capsule.
            bar_w = min(max(320, extent + 20), max(320, safe_right - 2 * margin))
            bar_x = max(margin + launcher_w + 12, (w - bar_w) // 2)
            if profile.get("align") == "right": bar_x = max(margin+launcher_w+12, safe_right-bar_w)
            if bar_x + bar_w > safe_right:
                bar_x = max(margin + launcher_w + 12, safe_right - bar_w)
            set_dock_geometry(bar_x, bottom_y, bar_w, bar_h)
            self.start_button.move(max(margin, bar_x - launcher_w + 6), bottom_y + (bar_h - launcher_w) // 2)

        # Start and taskbar are intentionally separate floating controls.
        if not profile.get("vertical") and edge != "top":
            self.start_button.move(
                self.task_shell.x() - self.start_button.width() - 12,
                bottom_y + (bar_h - self.start_button.height()) // 2,
            )

        app_top = (bar_h + 24) if edge == "top" else 0
        app_right = (max(72, icon + 24) + 18) if profile.get("vertical") and edge=="right" else 0
        app_left = (max(72, icon + 24) + 18) if profile.get("vertical") and edge=="left" else 0
        app_bottom = 0 if edge == "top" or profile.get("vertical") else (bar_h + margin + 4)
        self.app_layer.setGeometry(app_left, app_top, max(320, w-app_left-app_right), max(100,h-app_top-app_bottom))
        self._layout_taskbar_buttons()

        # Store the non-magnified dock geometry. Hover animations use this as
        # an immutable anchor, so the complete Start + dock group remains
        # centered and its bottom edge never moves down.
        if not getattr(self, "_dock_hover_active", False):
            self._task_base_geometry = QRect(self.task_shell.geometry())
            self._start_base_geometry = QRect(self.start_button.geometry())

        menu_w, menu_h = profile.get("menu_size", (440, 620))
        self.menu.setFixedSize(int(menu_w), int(menu_h))
        if profile.get("vertical"):
            menu_x = max(12, w - self.menu.width() - 100)
            menu_y = max(20, (h - self.menu.height()) // 2)
        elif edge == "top":
            menu_x = max(12, (w - self.menu.width()) // 2)
            menu_y = bar_h + 26
        elif profile.get("width") in {"wide", "full"}:
            menu_x = max(12, (w - self.menu.width()) // 2)
            menu_y = max(42, bottom_y - self.menu.height() - 14)
        else:
            menu_x = max(10, self.start_button.x())
            menu_y = max(10, bottom_y - self.menu.height() - 12)

        self._start_target_rect = QRect(menu_x, menu_y, self.menu.width(), self.menu.height())
        if not self.menu.isVisible() or not getattr(self.menu, "_animating", False):
            self.menu.setGeometry(self._start_target_rect)
        self.notch.move(max(10, (w - self.notch.width()) // 2), 12)
        if hasattr(self, "power_overlay"):
            self.power_overlay.setGeometry(self.ui_layer.rect())
        if hasattr(self, "notification_center"):
            panel_x = max(12, w - self.notification_center.width() - 14)
            panel_y = 46 if edge != "top" else bar_h + 28
            if edge == "bottom":
                panel_y = max(42, bottom_y - self.notification_center.height() - 14)
            self.notification_center.move(panel_x, panel_y)
        if hasattr(self, "control_center"):
            center_x = max(12, w - self.control_center.width() - 14)
            center_y = 46 if edge != "top" else bar_h + 28
            if edge == "bottom":
                center_y = max(42, bottom_y - self.control_center.height() - 14)
            self.control_center.move(center_x, center_y)
