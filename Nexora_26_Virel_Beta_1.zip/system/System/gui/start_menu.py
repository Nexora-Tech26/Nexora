"""Nexora Start launcher with progressive, cancellable search."""
from __future__ import annotations

from difflib import SequenceMatcher

from .shared import *
from .components import GlassFrame
from System.launcher import FileSearchThread, LauncherResult, fuzzy_score


SETTINGS_DESTINATIONS = (
    "Personalization", "Themes", "Colors", "Glass", "Dock & Taskbar", "Start",
    "Desktop", "Windows", "Animations", "Sounds", "Fonts", "Accessibility",
    "Applications", "Accounts", "System", "Diagnostics",
)

APP_CATEGORIES = {
    "System": {"Files", "Settings", "Terminal", "Task Manager", "Welcome"},
    "Work": {"Notepad", "Calendar", "Continuum", "Documents", "Sheets", "Presentations", "Mail"},
    "Internet": {"Browser", "Maps", "Weather"},
    "Media": {"Gallery", "Screenshot", "Paint", "Recorder"},
    "Tools": {"Calculator", "Widgets", "Clock", "PDF Viewer"},
}

START_TABS = (
    ("All", "all"),
    ("Pinned", "pinned"),
    ("Recent", "recent"),
    ("System", "System"),
    ("Work", "Work"),
    ("Internet", "Internet"),
    ("Media", "Media"),
    ("Tools", "Tools"),
)


class StartMenu(GlassFrame):
    launch = Signal(Path)
    pin = Signal(Path)
    folder = Signal(Path)
    power = Signal()

    def __init__(self, desktop):
        super().__init__(desktop, radius=24, alpha=204, gradient=True, wallpaper_backdrop=True)
        self.desktop = desktop
        self.hide()
        self._generation = 0
        self._workers: list[FileSearchThread] = []
        self._local_results: list[LauncherResult] = []
        self._file_results: list[LauncherResult] = []
        self._history_path = DATA_DIR / "start_search_history.json"
        self._history = self._load_history()
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(180)
        self._search_timer.timeout.connect(self._start_file_search)

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 22, 24, 20)
        root.setSpacing(12)
        self.root = root

        header = QHBoxLayout()
        self.title = QLabel("Nexora")
        self.title.setFont(font(28, True))
        self.profile_button = QPushButton(os.environ.get("USER") or os.environ.get("USERNAME") or "User")
        self.profile_button.setIcon(qt_icon("Welcome"))
        self.profile_button.setStyleSheet(oneui_button_css("#B9A7E8", radius=12))
        self.profile_button.clicked.connect(self._profile_menu)
        header.addWidget(self.title)
        header.addStretch()
        header.addWidget(self.profile_button)
        root.addLayout(header)

        self.search = QLineEdit()
        self.search.setPlaceholderText("Search apps, files, settings and actions")
        self.search.setObjectName("StartSearch")
        self.search.setClearButtonEnabled(True)
        self.search.setFixedHeight(50)
        self.search.textChanged.connect(self._on_query_changed)
        self.search.returnPressed.connect(self._activate_first)
        root.addWidget(self.search)

        filter_row = QHBoxLayout()
        # Hidden data model keeps filtering stable; the visible control is a
        # proper tab strip grouped by purpose.
        self.category = QComboBox(self)
        for label, value in START_TABS:
            self.category.addItem(label, value)
        self.category.hide()

        self.category_tabs = QTabBar()
        self.category_tabs.setObjectName("StartCategoryTabs")
        self.category_tabs.setExpanding(False)
        self.category_tabs.setUsesScrollButtons(True)
        self.category_tabs.setDrawBase(False)
        for label, value in START_TABS:
            index = self.category_tabs.addTab(label)
            self.category_tabs.setTabData(index, value)
        self.category_tabs.currentChanged.connect(self._category_tab_changed)
        self.category.currentIndexChanged.connect(self.refresh)
        self.category_tabs.setStyleSheet(connected_tabbar_css("#8AB4F8", radius=14, height=38))
        self.history_button = QPushButton("History")
        self.history_button.setIcon(qt_icon("RecentFiles"))
        self.history_button.setIconSize(QSize(22, 22))
        self.history_button.setStyleSheet(oneui_button_css("#89D4CF", radius=11))
        self.history_button.clicked.connect(self._show_history)
        filter_row.addWidget(self.category_tabs, 1)
        filter_row.addWidget(self.history_button)
        root.addLayout(filter_row)

        self.folder_host = QWidget()
        self.folder_row = QHBoxLayout(self.folder_host)
        self.folder_row.setContentsMargins(0, 0, 0, 0)
        self.folder_row.setSpacing(0)
        root.addWidget(self.folder_host)

        self.status = QLabel()
        self.status.setStyleSheet(f"color:{MUTED};background:transparent;border:none;")
        root.addWidget(self.status)

        self.list = QListWidget()
        self.list.setIconSize(QSize(44, 44))
        self.list.setSpacing(0)
        self.list.setVerticalScrollMode(QListWidget.ScrollPerPixel)
        self.list.itemActivated.connect(self._activate_item)
        self.list.itemClicked.connect(lambda item: self._activate_item(item) if item.data(Qt.UserRole + 4) == "quick" else None)
        self.list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self.context)
        root.addWidget(self.list, 1)

        bottom = QHBoxLayout()
        bottom.setSpacing(0)
        bottom.setContentsMargins(0, 0, 0, 0)
        self.all_apps = QPushButton("All apps")
        self.all_apps.setIcon(qt_icon("Apps"))
        self.all_apps.setIconSize(QSize(22, 22))
        self.all_apps.setStyleSheet(oneui_button_css("#8AB4F8", radius=12))
        self.all_apps.clicked.connect(lambda: self._select_category("all"))
        self.power_button = QPushButton("Power")
        self.power_button.setIcon(qt_icon("Power"))
        self.power_button.setIconSize(QSize(22, 22))
        self.power_button.setStyleSheet(oneui_button_css("#F4A7B9", radius=12))
        self.power_button.clicked.connect(self.power.emit)
        apply_connected_group((self.all_apps, self.power_button), "#8AB4F8", radius=14, height=40)
        bottom.addWidget(self.all_apps)
        bottom.addWidget(self.power_button)
        bottom.addStretch()
        root.addLayout(bottom)

        # Apply only after every StartMenu child exists. Desktop itself may still
        # be inside its staged constructor, so profile refresh must not assume
        # that the full desktop catalogue and shell graph are ready yet.
        self.apply_profile(refresh_content=False)
        self.refresh_folders()
        self.refresh()

    # ------------------------------------------------------------------ setup
    def _load_history(self) -> list[str]:
        try:
            payload = json.loads(self._history_path.read_text(encoding="utf-8"))
            return [str(item) for item in payload if str(item).strip()][:20] if isinstance(payload, list) else []
        except (OSError, ValueError, json.JSONDecodeError):
            return []

    def _save_history(self) -> None:
        self._history_path.parent.mkdir(parents=True, exist_ok=True)
        temp = self._history_path.with_suffix(".tmp")
        temp.write_text(json.dumps(self._history[:20], indent=2, ensure_ascii=False), encoding="utf-8")
        temp.replace(self._history_path)

    def _remember_query(self, query: str) -> None:
        if not load_settings().get("start_history", True):
            return
        query = query.strip()
        if len(query) < 2:
            return
        self._history = [query] + [item for item in self._history if item.casefold() != query.casefold()]
        self._history = self._history[:20]
        self._save_history()

    def apply_profile(self, refresh_content=True):
        """Apply launcher geometry and styling without racing Desktop startup.

        Qt on macOS can deliver resize/style events re-entrantly while Desktop
        is still constructing its children. This method therefore tolerates
        partial initialization and only refreshes desktop-backed content when
        the required objects and methods are available.
        """
        profile = panel_profile()
        menu_w, menu_h = profile.get("menu_size", (520, 680))
        layout = str(load_settings().get("start_layout", "balanced"))
        if layout == "compact":
            menu_w, menu_h = 620, 760
        elif layout == "grid":
            menu_w, menu_h = 900, 820
        else:
            menu_w = max(780, int(menu_w))
            menu_h = max(800, int(menu_h))
        self.setFixedSize(menu_w, menu_h)
        self.title.setText(profile.get("name", "Nexora"))
        settings = load_settings()
        self.radius = self._coerce_radius(settings.get("panel_radius", 24), 24)
        try:
            transparency = int(settings.get("glass_transparency", 48))
        except (TypeError, ValueError, OverflowError):
            transparency = 78
        self.alpha = max(18, min(235, 100 - transparency))
        self.gradient = True
        self.setStyleSheet("background:transparent;border:none;")
        self.search.setStyleSheet(
            f"QLineEdit#StartSearch{{background:rgba(246,249,252,218);border:none;border-radius:28px;"
            f"padding:14px 18px;font-size:15px;color:{TEXT};}}"
            f"QLineEdit#StartSearch:hover{{background:rgba(250,252,254,232);}}"
            f"QLineEdit#StartSearch:focus{{background:rgba(252,253,255,242);border:none;}}"
        )
        self.list.setStyleSheet(
            f"QListWidget{{background:rgba(244,248,253,92);border:none;border-radius:30px;"
            f"color:{TEXT};outline:none;padding:12px;}}"
            f"QListWidget::item{{background:rgba(255,255,255,30);padding:13px 18px;"
            f"margin:0;border:none;border-radius:16px;color:{TEXT};}}"
            f"QListWidget::item:hover{{background:{HOVER};border:none;border-radius:16px;}}"
            "QListWidget::item:selected{background:rgba(91,145,235,118);border:none;border-radius:16px;}"
        )
        desktop = getattr(self, "desktop", None)
        if refresh_content and desktop is not None:
            reload_catalog = getattr(desktop, "reload_app_catalog", None)
            if callable(reload_catalog):
                reload_catalog()
        if hasattr(self, "folder_row"):
            self.refresh_folders()
        if hasattr(self, "list") and hasattr(self, "search"):
            self.refresh()

    def refresh_folders(self):
        while self.folder_row.count():
            item = self.folder_row.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        paths = self.desktop.load_pinned_folders()[:4]
        if not paths:
            paths = [NEXORA_HOME / name for name in ("Desktop", "Documents", "Downloads")]
        for path in paths:
            button = QPushButton(path.name or "Home")
            button.setToolTip(str(path))
            button.clicked.connect(lambda _=False, target=path: self.folder.emit(target))
            self.folder_row.addWidget(button)
        folder_buttons = [self.folder_row.itemAt(i).widget() for i in range(self.folder_row.count())]
        apply_connected_group(folder_buttons, "#B8C0CC", radius=13, height=38)
        self.folder_row.addStretch()

    # --------------------------------------------------------------- searching
    def _on_query_changed(self):
        self._generation += 1
        self._cancel_file_search()
        self._file_results = []
        self.refresh()
        query = self.search.text().strip()
        if query and load_settings().get("start_search_files", True):
            self.status.setText("Searching applications and settings…")
            self._search_timer.start()

    def _cancel_file_search(self):
        self._search_timer.stop()
        for worker in list(self._workers):
            if worker.isRunning():
                worker.requestInterruption()

    def _start_file_search(self):
        query = self.search.text().strip()
        if not query:
            return
        generation = self._generation
        worker = FileSearchThread(
            generation,
            NEXORA_HOME,
            query,
            show_hidden=bool(load_settings().get("files_show_hidden", False)),
            parent=self,
        )
        self._workers.append(worker)
        worker.batchReady.connect(self._accept_file_batch)
        worker.complete.connect(self._file_search_complete)
        worker.finished.connect(lambda current=worker: self._discard_worker(current))
        worker.start()
        self.status.setText("Searching files in background…")

    def _discard_worker(self, worker):
        if worker in self._workers:
            self._workers.remove(worker)
        worker.deleteLater()

    def _accept_file_batch(self, generation: int, results: list):
        if generation != self._generation:
            return
        existing = {str(item.payload) for item in self._file_results}
        for result in results:
            if str(result.payload) not in existing:
                self._file_results.append(result)
                existing.add(str(result.payload))
        self._render_results()

    def _file_search_complete(self, generation: int):
        if generation == self._generation:
            self.status.setText(f"{len(self._local_results) + len(self._file_results)} results")

    def _build_local_results(self, query: str) -> list[LauncherResult]:
        self.desktop.reload_app_catalog()
        category = self.category.currentData()
        results: list[LauncherResult] = []
        for path in self.desktop.app_paths:
            name = app_name(path)
            if category == "pinned" and not self.desktop.is_pinned(path):
                continue
            if category == "recent" and path not in self.desktop.usage_service.top(self.desktop.app_paths, 12):
                continue
            if category in APP_CATEGORIES and name not in APP_CATEGORIES[category]:
                continue
            score = fuzzy_score(query, name) if query else 50.0
            if query and score < 28:
                continue
            usage = self.desktop.usage_service.score(path)
            pin_bonus = 14 if self.desktop.is_pinned(path) else 0
            results.append(LauncherResult("app", name, "Application", path, score + usage + pin_bonus, name))

        if query and load_settings().get("start_search_settings", True):
            for destination in SETTINGS_DESTINATIONS:
                score = fuzzy_score(query, destination)
                if score >= 28:
                    results.append(LauncherResult("setting", destination, "Settings", destination, score + 8, "Settings"))

        quick_actions = {
            "Open command palette": lambda: getattr(self.desktop, "command_palette", None) and self.desktop.command_palette.show_palette(),
            "Show all windows": lambda: self.desktop.toggle_overview(),
            "Toggle Focus mode": lambda: self.desktop.toggle_focus_mode(),
            "Toggle Night Light": lambda: self.desktop.toggle_night_light(),
            "Take screenshot": self._take_screenshot,
            "Open quick settings": self._show_quick_settings,
            "Lock session": self._lock_session,
        }
        if query:
            for title, callback in quick_actions.items():
                score = fuzzy_score(query, title)
                if score >= 30:
                    results.append(LauncherResult("quick", title, "Quick action", callback, score + 5, "Settings"))
        return sorted(results, key=lambda result: result.score, reverse=True)

    def refresh(self):
        query = self.search.text().strip()
        self._local_results = self._build_local_results(query)
        self._render_results()

    def _render_results(self):
        query = self.search.text().strip()
        self.list.clear()
        if query:
            merged = sorted(self._local_results + self._file_results, key=lambda result: result.score, reverse=True)[:100]
            if not merged:
                self._add_header("No matches yet")
                self.status.setText("Searching…" if self._workers else "No results")
            else:
                last_kind = None
                headings = {"app": "Applications", "setting": "Settings", "quick": "Quick actions", "file": "Files"}
                for result in merged:
                    if result.kind != last_kind:
                        self._add_header(headings.get(result.kind, "Results"))
                        last_kind = result.kind
                    self._add_result(result)
                self.status.setText(f"{len(merged)} results" + (" · files loading…" if self._workers else ""))
            return

        category = self.category.currentData()
        if category != "all":
            title = next((label for label, value in START_TABS if value == category), str(category))
            self._add_header(f"{title} applications")
            for result in sorted(self._local_results, key=lambda item: item.title.casefold()):
                self._add_result(result)
            self.status.setText(f"{len(self._local_results)} applications")
            return

        # Home launcher view: pinned, recent, recommended, then all apps.
        pinned = [result for result in self._local_results if result.kind == "app" and self.desktop.is_pinned(result.payload)]
        recent_paths = set(self.desktop.usage_service.top(self.desktop.app_paths, 6)) if load_settings().get("start_recent_apps", True) else set()
        recent = [result for result in self._local_results if result.payload in recent_paths and result not in pinned]
        if pinned:
            self._add_header("Pinned applications")
            for result in pinned[:10]:
                self._add_result(result)
        if recent:
            self._add_header("Recently used")
            for result in recent[:6]:
                self._add_result(result)
        if load_settings().get("start_recommended", True):
            recommended = self._recommended_files()
            if recommended:
                self._add_header("Recommended files")
                for result in recommended:
                    self._add_result(result)
        self._add_header("All applications")
        for result in sorted(self._local_results, key=lambda item: item.title.casefold()):
            self._add_result(result)
        self.status.setText(f"{len(self.desktop.app_paths)} applications")

    def _recommended_files(self) -> list[LauncherResult]:
        candidates = []
        for folder_name in ("Desktop", "Documents", "Downloads", "Images"):
            folder = NEXORA_HOME / folder_name
            try:
                for path in folder.iterdir():
                    if path.is_file() and (load_settings().get("files_show_hidden") or not path.name.startswith(".")):
                        candidates.append(path)
            except OSError:
                continue
        candidates.sort(key=lambda path: path.stat().st_mtime if path.exists() else 0, reverse=True)
        return [LauncherResult("file", path.name, str(path.parent.relative_to(NEXORA_HOME)), path, 0, "Files") for path in candidates[:5]]

    def _add_header(self, text: str):
        item = QListWidgetItem(text.upper())
        item.setFlags(Qt.NoItemFlags)
        item.setForeground(QColor(MUTED))
        item.setSizeHint(QSize(0, 34))
        self.list.addItem(item)

    def _add_result(self, result: LauncherResult):
        item = QListWidgetItem(qt_icon(result.icon_name or result.kind), result.title)
        item.setToolTip(result.subtitle)
        item.setData(Qt.UserRole, result.payload)
        item.setData(Qt.UserRole + 1, result.subtitle)
        item.setData(Qt.UserRole + 4, result.kind)
        item.setSizeHint(QSize(0, 62))
        self.list.addItem(item)

    # --------------------------------------------------------------- activation
    def _activate_first(self):
        for row in range(self.list.count()):
            item = self.list.item(row)
            if item.flags() & Qt.ItemIsEnabled:
                self._activate_item(item)
                return

    def _activate_item(self, item):
        kind = item.data(Qt.UserRole + 4)
        payload = item.data(Qt.UserRole)
        if not kind:
            return
        self._remember_query(self.search.text())
        if kind == "app":
            self.launch.emit(Path(payload))
        elif kind == "file":
            path = Path(payload)
            if path.is_dir():
                self.folder.emit(path)
            else:
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
            self.hide()
        elif kind == "setting":
            settings_path = next((path for path in self.desktop.app_paths if app_name(path) == "Settings"), None)
            if settings_path:
                self.desktop.open_app(settings_path)
                destination = str(payload)

                def navigate_setting():
                    window = self.desktop.windows.get(Path(settings_path).resolve())
                    if window and destination in window.sidebar_buttons:
                        window.sidebar_buttons[destination].click()

                QTimer.singleShot(80, navigate_setting)
            self.hide()
        elif kind == "quick" and callable(payload):
            payload()
            self.hide()

    def context(self, pos):
        item = self.list.itemAt(pos)
        if not item or item.data(Qt.UserRole + 4) != "app":
            return
        path = Path(item.data(Qt.UserRole)).resolve()
        menu = create_nexora_menu(self)
        open_action = menu.addAction("Open")
        new_action = menu.addAction("New window")
        pin_action = menu.addAction("Unpin from dock" if self.desktop.is_pinned(path) else "Pin to dock")
        desktop_action = menu.addAction("Add to desktop")
        settings_action = menu.addAction("App settings")
        chosen = menu.exec(self.list.viewport().mapToGlobal(pos))
        if chosen == open_action:
            self.desktop.open_app(path)
        elif chosen == new_action:
            self.desktop.open_app_new(path)
        elif chosen == pin_action:
            self.pin.emit(path)
            self.refresh()
        elif chosen == desktop_action:
            self.desktop.add_app_to_desktop(path)
        elif chosen == settings_action:
            settings_path = next((candidate for candidate in self.desktop.app_paths if app_name(candidate) == "Settings"), None)
            if settings_path:
                self.desktop.open_app(settings_path)

    # ------------------------------------------------------------- quick actions
    def _take_screenshot(self):
        folder = NEXORA_HOME / "Images"
        folder.mkdir(parents=True, exist_ok=True)
        target = folder / f"Screenshot_{datetime.now():%Y%m%d_%H%M%S}.png"
        self.desktop.grab().save(str(target))
        self.desktop.notification_service.post("screenshots", "Screenshot saved", str(target), priority="normal")
        self.desktop.notch.notify("Screenshot saved")

    def _show_quick_settings(self):
        quick_shell = getattr(self.desktop, "quick_shell", None)
        if quick_shell is not None:
            quick_shell.show()
            quick_shell.raise_()

    def _lock_session(self):
        if hasattr(self.desktop, "session_recovery"):
            self.desktop.session_recovery.finish()
        if hasattr(self.desktop, "sound_service"):
            self.desktop.sound_service.play("logout")
        if hasattr(self.desktop, "lockRequested"):
            self.desktop.lockRequested.emit()
        else:
            QApplication.quit()

    def _profile_menu(self):
        menu = create_nexora_menu(self)
        settings_action = menu.addAction("Account settings")
        focus_action = menu.addAction("Toggle Focus mode")
        lock_action = menu.addAction("Lock session")
        chosen = menu.exec(self.profile_button.mapToGlobal(QPoint(0, self.profile_button.height())))
        if chosen == settings_action:
            result = LauncherResult("setting", "Accounts", "Settings", "Accounts", 100, "Settings")
            temp = QListWidgetItem()
            temp.setData(Qt.UserRole, result.payload)
            temp.setData(Qt.UserRole + 4, result.kind)
            self._activate_item(temp)
        elif chosen == focus_action:
            self.desktop.toggle_focus_mode()
        elif chosen == lock_action:
            self._lock_session()

    def _show_history(self):
        menu = create_nexora_menu(self)
        if not self._history:
            action = menu.addAction("No search history")
            action.setEnabled(False)
        else:
            for query in self._history[:10]:
                action = menu.addAction(query)
                action.triggered.connect(lambda _=False, value=query: self.search.setText(value))
            menu.addSeparator()
            clear = menu.addAction("Clear history")
            clear.triggered.connect(self._clear_history)
        menu.exec(self.history_button.mapToGlobal(QPoint(0, self.history_button.height())))

    def _clear_history(self):
        self._history = []
        self._save_history()

    def _category_tab_changed(self, tab_index):
        value = self.category_tabs.tabData(tab_index)
        index = self.category.findData(value)
        if index >= 0 and self.category.currentIndex() != index:
            self.category.setCurrentIndex(index)

    def _select_category(self, value):
        index = self.category.findData(value)
        if index >= 0:
            self.category.setCurrentIndex(index)
        for tab_index in range(self.category_tabs.count()):
            if self.category_tabs.tabData(tab_index) == value:
                self.category_tabs.setCurrentIndex(tab_index)
                break

    def hideEvent(self, event):
        if hasattr(self, "_search_timer"):
            self._cancel_file_search()
        super().hideEvent(event)
