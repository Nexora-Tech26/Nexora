"""Files application for Nexora 26 Beta 1 .

All operations are restricted to Nexora Home, long copy/move/delete work runs in
the shared worker pool, and destructive actions use the in-system confirmation
sheet rather than native dialogs.
"""
from __future__ import annotations

import mimetypes
import os
import shutil
from pathlib import Path

from PySide6.QtWidgets import QAbstractItemView

from .shared import *


TRASH_DIR = NEXORA_HOME / ".Trash"


class FilesApplicationMixin:
    def build_files(self):
        self.current_folder = NEXORA_HOME.resolve()
        self.files_history = []
        self.files_history_index = -1
        self.files_clipboard: tuple[str, list[Path]] = ("copy", [])
        self.files_tabs: list[dict] = []
        self.files_operation = None
        TRASH_DIR.mkdir(parents=True, exist_ok=True)

        if self.toolbar_enabled:
            for title, callback in (
                ("New folder", self.files_new_folder),
                ("New text file", self.files_new_file),
                ("Copy", lambda: self.files_copy_selected(False)),
                ("Cut", lambda: self.files_copy_selected(True)),
                ("Paste", self.files_paste),
                ("Delete", self.files_delete_selected),
                ("Refresh", lambda: self.navigate_files(self.current_folder, add_history=False)),
            ):
                self.add_toolbar(title, callback)

        nav_row = QHBoxLayout()
        nav_row.setSpacing(0)
        self.files_back = QPushButton()
        self.files_forward = QPushButton()
        self.files_up = QPushButton()
        self.files_new_tab = QPushButton()
        for button, icon_name, tip in (
            (self.files_back, "Back", "Back"),
            (self.files_forward, "Forward", "Forward"),
            (self.files_up, "Up", "Up one folder"),
            (self.files_new_tab, "NewFolder", "New tab"),
        ):
            button.setIcon(qt_icon(icon_name))
            button.setIconSize(QSize(24, 24))
            button.setToolTip(tip)
        nav_buttons = (self.files_back, self.files_forward, self.files_up, self.files_new_tab)
        for index, button in enumerate(nav_buttons):
            button.setFixedSize(40, 40)
            left = 12 if index == 0 else 0
            right = 12 if index == len(nav_buttons) - 1 else 0
            button.setStyleSheet(
                "QPushButton{background:rgba(138,180,248,92);border:none;margin:0;padding:0;"
                f"border-top-left-radius:{left}px;border-bottom-left-radius:{left}px;"
                f"border-top-right-radius:{right}px;border-bottom-right-radius:{right}px;"
                "}"
                "QPushButton:hover{background:rgba(138,180,248,132);}"
                "QPushButton:pressed{background:rgba(138,180,248,164);padding:0;margin:0;}"
            )
        self.files_back.clicked.connect(self.files_go_back)
        self.files_forward.clicked.connect(self.files_go_forward)
        self.files_up.clicked.connect(self.files_go_up)
        self.files_new_tab.clicked.connect(self.files_add_tab)
        self.files_breadcrumbs = QFrame()
        self.files_breadcrumb_layout = QHBoxLayout(self.files_breadcrumbs)
        self.files_breadcrumb_layout.setContentsMargins(4, 0, 4, 0)
        self.files_breadcrumb_layout.setSpacing(2)
        nav_row.addWidget(self.files_back)
        nav_row.addWidget(self.files_forward)
        nav_row.addWidget(self.files_up)
        nav_row.addWidget(self.files_breadcrumbs, 1)
        nav_row.addWidget(self.files_new_tab)
        self.content_layout.addLayout(nav_row)

        self.files_tab_widget = QTabWidget()
        self.files_tab_widget.setDocumentMode(True)
        self.files_tab_widget.setTabsClosable(True)
        self.files_tab_widget.setMaximumHeight(42)
        self.files_tab_widget.setMaximumWidth(360)
        self.files_tab_widget.setStyleSheet(
            "QTabWidget{background:transparent;border:none;}"
            "QTabWidget::pane{border:none;background:transparent;}"
            "QTabBar{background:transparent;border:none;}"
            "QTabBar::tab{background:rgba(255,255,255,34);border:none;border-radius:16px;"
            "min-height:28px;max-height:28px;padding:0 10px;margin:0;color:#17191F;}"
            "QTabBar::tab:first{border-top-left-radius:10px;border-bottom-left-radius:10px;}"
            "QTabBar::tab:last{border-top-right-radius:10px;border-bottom-right-radius:10px;}"
            "QTabBar::tab:selected{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,"
            "stop:0 #FFD667,stop:1 #E9A93E);color:#2B2415;}"
        )
        self.files_tab_widget.currentChanged.connect(self.files_switch_tab)
        self.files_tab_widget.tabCloseRequested.connect(self.files_close_tab)
        # Tabs belong to the integrated title bar rather than consuming a
        # separate content row.
        self.title_layout.insertWidget(max(1, self.title_layout.count() - 2), self.files_tab_widget, 1)

        controls = QHBoxLayout()
        controls.setSpacing(0)
        self.files_filter = QLineEdit()
        self.files_filter.setPlaceholderText("Filter this folder")
        self.files_filter.setClearButtonEnabled(True)
        self.files_filter.textChanged.connect(self.files_render_listing)
        self.files_sort = QComboBox()
        for label, key in (("Name", "name"), ("Type", "type"), ("Date", "date"), ("Size", "size")):
            self.files_sort.addItem(f"↕ {label}", key)
        self.files_sort.currentIndexChanged.connect(self.files_render_listing)
        self.files_view = QComboBox()
        self.files_view.addItem("☷ List", "list")
        self.files_view.addItem("▦ Icons", "icons")
        self.files_view.currentIndexChanged.connect(self.files_apply_view_mode)
        self.files_hidden = QCheckBox("◉ Hidden")
        self.files_hidden.setChecked(bool(load_settings().get("files_show_hidden", False)))
        self.files_hidden.toggled.connect(self.files_render_listing)
        controls.addWidget(self.files_filter, 1)
        controls.addWidget(self.files_sort)
        controls.addWidget(self.files_view)
        controls.addWidget(self.files_hidden)
        self.content_layout.addLayout(controls)

        self.files_splitter = QSplitter(Qt.Horizontal)
        self.files_listing = QListWidget()
        self.files_listing.setObjectName("FilesListing")
        self.files_listing.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.files_listing.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.files_listing.setContextMenuPolicy(Qt.CustomContextMenu)
        self.files_listing.customContextMenuRequested.connect(self.files_context_menu)
        self.files_listing.itemDoubleClicked.connect(self.files_activate_item)
        self.files_listing.itemSelectionChanged.connect(self.files_update_preview)
        self.files_listing.setStyleSheet(
            f"QListWidget#FilesListing{{background:rgba(255,255,255,8);border:none;"
            f"border-radius:18px;outline:none;padding:5px;}}"
            f"QListWidget#FilesListing::item{{padding:7px;border-radius:16px;color:{TEXT};}}"
            f"QListWidget#FilesListing::item:hover{{background:{HOVER};}}"
            f"QListWidget#FilesListing::item:selected{{background:{rgba(self.accent,72)};border:none;}}"
        )
        self.files_preview = QFrame()
        self.files_preview.setMinimumWidth(230)
        self.files_preview.setMaximumWidth(350)
        self.files_preview.setStyleSheet("background:rgba(255,255,255,10);border:none;border-radius:18px;")
        preview_layout = QVBoxLayout(self.files_preview)
        preview_layout.setContentsMargins(14, 14, 14, 14)
        self.files_preview_image = QLabel()
        self.files_preview_image.setAlignment(Qt.AlignCenter)
        self.files_preview_image.setMinimumHeight(130)
        self.files_preview_image.setStyleSheet("background:transparent;border:none;")
        self.files_preview_title = QLabel("Select a file")
        self.files_preview_title.setFont(font(13, True))
        self.files_preview_title.setWordWrap(True)
        self.files_preview_text = QTextEdit()
        self.files_preview_text.setReadOnly(True)
        self.files_preview_text.setStyleSheet("QTextEdit{background:transparent;border:none;}")
        preview_layout.addWidget(self.files_preview_image)
        preview_layout.addWidget(self.files_preview_title)
        preview_layout.addWidget(self.files_preview_text, 1)
        self.files_splitter.addWidget(self.files_listing)
        self.files_splitter.addWidget(self.files_preview)
        self.files_preview.hide()
        self.files_splitter.setStretchFactor(0, 1)
        self.content_layout.addWidget(self.files_splitter, 1)

        status_row = QHBoxLayout()
        self.files_status = QLabel()
        self.files_status.setStyleSheet(f"color:{MUTED};")
        self.files_progress = QProgressBar()
        self.files_progress.setMaximumWidth(220)
        self.files_progress.hide()
        status_row.addWidget(self.files_status, 1)
        status_row.addWidget(self.files_progress)
        self.content_layout.addLayout(status_row)

        folder_map = {
            "Home": NEXORA_HOME,
            "Desktop": NEXORA_HOME / "Desktop",
            "Documents": NEXORA_HOME / "Documents",
            "Downloads": NEXORA_HOME / "Downloads",
            "Images": NEXORA_HOME / "Images",
            "Music": NEXORA_HOME / "Music",
            "Videos": NEXORA_HOME / "Videos",
            "Trash": TRASH_DIR,
        }
        for label, folder in folder_map.items():
            button = self.sidebar_buttons.get(label)
            if button is not None:
                button.clicked.connect(lambda _=False, target=folder: self.navigate_files(target))

        self._install_files_shortcuts()
        self.files_add_tab(NEXORA_HOME.resolve())

    # --------------------------------------------------------------- navigation
    def files_add_tab(self, path=None):
        target = self._safe_folder(path or self.current_folder)
        tab = {"path": target, "history": [target], "index": 0}
        self.files_tabs.append(tab)
        page = QWidget()
        index = self.files_tab_widget.addTab(page, target.name or "Home")
        self.files_tab_widget.setCurrentIndex(index)
        self.navigate_files(target, add_history=False)

    def files_close_tab(self, index):
        if not 0 <= index < len(self.files_tabs):
            return
        if len(self.files_tabs) == 1:
            self.navigate_files(NEXORA_HOME, add_history=False)
            return
        self.files_tabs.pop(index)
        widget = self.files_tab_widget.widget(index)
        self.files_tab_widget.removeTab(index)
        if widget:
            widget.deleteLater()

    def files_switch_tab(self, index):
        if 0 <= index < len(self.files_tabs):
            tab = self.files_tabs[index]
            self.navigate_files(tab["path"], add_history=False, update_tab=False)

    def _current_files_tab(self):
        index = self.files_tab_widget.currentIndex()
        return self.files_tabs[index] if 0 <= index < len(self.files_tabs) else None

    def _safe_folder(self, folder):
        try:
            target = Path(folder).expanduser().resolve()
        except (OSError, RuntimeError, TypeError):
            return NEXORA_HOME.resolve()
        if not inside_home(target) or not target.is_dir():
            return NEXORA_HOME.resolve()
        return target

    def navigate_files(self, folder: Path, *, add_history=True, update_tab=True):
        target = self._safe_folder(folder)
        self.current_folder = target
        tab = self._current_files_tab()
        if tab is not None and update_tab:
            if add_history and (not tab["history"] or tab["history"][tab["index"]] != target):
                tab["history"] = tab["history"][: tab["index"] + 1]
                tab["history"].append(target)
                tab["index"] = len(tab["history"]) - 1
            tab["path"] = target
            index = self.files_tab_widget.currentIndex()
            self.files_tab_widget.setTabText(index, "Trash" if target == TRASH_DIR.resolve() else (target.name or "Home"))
        self.files_filter.clear()
        self.files_update_breadcrumbs()
        self.files_render_listing()
        self.files_update_nav_buttons()

    def files_go_back(self):
        tab = self._current_files_tab()
        if tab and tab["index"] > 0:
            tab["index"] -= 1
            tab["path"] = tab["history"][tab["index"]]
            self.navigate_files(tab["path"], add_history=False)

    def files_go_forward(self):
        tab = self._current_files_tab()
        if tab and tab["index"] + 1 < len(tab["history"]):
            tab["index"] += 1
            tab["path"] = tab["history"][tab["index"]]
            self.navigate_files(tab["path"], add_history=False)

    def files_go_up(self):
        if self.current_folder != NEXORA_HOME.resolve():
            self.navigate_files(self.current_folder.parent)

    def files_update_nav_buttons(self):
        tab = self._current_files_tab()
        self.files_back.setEnabled(bool(tab and tab["index"] > 0))
        self.files_forward.setEnabled(bool(tab and tab["index"] + 1 < len(tab["history"])))
        self.files_up.setEnabled(self.current_folder != NEXORA_HOME.resolve())

    def files_update_breadcrumbs(self):
        while self.files_breadcrumb_layout.count():
            item = self.files_breadcrumb_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        root = NEXORA_HOME.resolve()
        parts = [] if self.current_folder == root else list(self.current_folder.relative_to(root).parts)
        current = root
        locations = [("Home", root)]
        for part in parts:
            current = current / part
            locations.append(("Trash" if current == TRASH_DIR.resolve() else part, current))
        for index, (label, path) in enumerate(locations):
            button = QPushButton(label)
            button.setStyleSheet(oneui_button_css("#B8C0CC", radius=9))
            button.clicked.connect(lambda _=False, target=path: self.navigate_files(target))
            self.files_breadcrumb_layout.addWidget(button)
            if index + 1 < len(locations):
                separator = QLabel("›")
                separator.setStyleSheet(f"color:{MUTED};")
                self.files_breadcrumb_layout.addWidget(separator)
        self.files_breadcrumb_layout.addStretch()

    # ---------------------------------------------------------------- listing
    def _files_items(self):
        show_hidden = self.files_hidden.isChecked()
        query = self.files_filter.text().casefold().strip()
        try:
            items = [path for path in self.current_folder.iterdir() if show_hidden or not path.name.startswith(".")]
        except OSError as exc:
            self.files_status.setText(f"Unable to read folder: {exc}")
            return []
        if query:
            items = [path for path in items if query in path.name.casefold()]
        mode = self.files_sort.currentData() or "name"

        def safe_stat(path):
            try:
                return path.stat()
            except OSError:
                return None

        if mode == "date":
            items.sort(key=lambda path: (safe_stat(path).st_mtime if safe_stat(path) else 0), reverse=True)
        elif mode == "size":
            items.sort(key=lambda path: (0 if path.is_dir() else (safe_stat(path).st_size if safe_stat(path) else 0)), reverse=True)
        elif mode == "type":
            items.sort(key=lambda path: (not path.is_dir(), path.suffix.casefold(), path.name.casefold()))
        else:
            items.sort(key=lambda path: (not path.is_dir(), path.name.casefold()))
        return items[:1500]

    def files_render_listing(self, *_args):
        if not hasattr(self, "files_listing"):
            return
        selected = {str(path) for path in self.files_selected_paths()}
        self.files_listing.clear()
        items = self._files_items()
        for path in items:
            try:
                stat = path.stat()
                size = "Folder" if path.is_dir() else self._format_size(stat.st_size)
                modified = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
            except OSError:
                size, modified = "Unavailable", "—"
            icon_name = "Files" if path.is_dir() else self._icon_for_file(path)
            text = path.name if self.files_view.currentData() == "icons" else f"{path.name}\n{size} · {modified}"
            item = QListWidgetItem(qt_icon(icon_name), text)
            item.setData(Qt.UserRole, str(path))
            item.setToolTip(str(path))
            item.setSizeHint(QSize(116, 90) if self.files_view.currentData() == "icons" else QSize(0, 58))
            self.files_listing.addItem(item)
            if str(path) in selected:
                item.setSelected(True)
        self.files_status.setText(f"{len(items)} items · {self.current_folder.relative_to(NEXORA_HOME.resolve()) if self.current_folder != NEXORA_HOME.resolve() else 'Home'}")
        self.files_apply_view_mode()

    def files_apply_view_mode(self, *_args):
        if not hasattr(self, "files_listing"):
            return
        icon_mode = self.files_view.currentData() == "icons"
        self.files_listing.setViewMode(QListWidget.IconMode if icon_mode else QListWidget.ListMode)
        self.files_listing.setWrapping(icon_mode)
        self.files_listing.setResizeMode(QListWidget.Adjust)
        self.files_listing.setGridSize(QSize(132, 108) if icon_mode else QSize())
        self.files_listing.setIconSize(QSize(48, 48) if icon_mode else QSize(30, 30))

    @staticmethod
    def _format_size(size):
        value = float(size)
        for suffix in ("B", "KB", "MB", "GB", "TB"):
            if value < 1024 or suffix == "TB":
                return f"{value:.1f} {suffix}"
            value /= 1024
        return f"{size} B"

    @staticmethod
    def _icon_for_file(path):
        suffix = path.suffix.casefold()
        if suffix in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}:
            return "Gallery"
        if suffix in {".mp4", ".mov", ".mkv", ".webm"}:
            return "Video Editor"
        if suffix in {".mp3", ".wav", ".m4a", ".flac", ".ogg"}:
            return "Audio Editor"
        if suffix in {".py", ".js", ".html", ".css", ".json", ".yaml", ".yml"}:
            return "Code Editor"
        if suffix == ".pdf":
            return "PDF Editor"
        if suffix in {".zip", ".tar", ".gz", ".7z"}:
            return "Archives"
        return "Notepad"

    def files_selected_paths(self):
        result = []
        for item in self.files_listing.selectedItems():
            try:
                path = Path(item.data(Qt.UserRole)).resolve()
            except (OSError, TypeError):
                continue
            if inside_home(path):
                result.append(path)
        return result

    def files_activate_item(self, item):
        path = Path(item.data(Qt.UserRole)).resolve()
        if path.is_dir():
            self.navigate_files(path)
        else:
            self.open_home_file(path)

    def files_update_preview(self):
        selected = self.files_selected_paths()
        self.files_preview_image.clear()
        if not selected:
            self.files_preview_title.setText("Select a file")
            self.files_preview_text.clear()
            return
        if len(selected) > 1:
            self.files_preview_title.setText(f"{len(selected)} items selected")
            total = 0
            for path in selected:
                try:
                    total += path.stat().st_size if path.is_file() else 0
                except OSError:
                    pass
            self.files_preview_text.setPlainText(f"Combined file size: {self._format_size(total)}")
            return
        path = selected[0]
        self.files_preview_title.setText(path.name)
        try:
            stat = path.stat()
            details = [f"Location: {path.parent}", f"Modified: {datetime.fromtimestamp(stat.st_mtime):%Y-%m-%d %H:%M}"]
            if path.is_file():
                details.append(f"Size: {self._format_size(stat.st_size)}")
                details.append(f"Type: {mimetypes.guess_type(path.name)[0] or path.suffix or 'File'}")
        except OSError as exc:
            self.files_preview_text.setPlainText(str(exc))
            return
        if path.is_dir():
            try:
                details.append(f"Items: {sum(1 for _ in path.iterdir())}")
            except OSError:
                pass
        elif path.suffix.casefold() in {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"}:
            pixmap = QPixmap(str(path))
            if not pixmap.isNull():
                self.files_preview_image.setPixmap(pixmap.scaled(210, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        elif path.suffix.casefold() in {".txt", ".md", ".py", ".json", ".csv", ".log", ".html", ".css", ".js"}:
            try:
                preview = path.read_text(encoding="utf-8", errors="replace")[:6000]
                details.append("\nPreview:\n" + preview)
            except OSError:
                pass
        self.files_preview_text.setPlainText("\n".join(details))

    # -------------------------------------------------------------- operations
    def files_new_folder(self):
        self.desktop.show_text_prompt("New folder", "Folder name", lambda name: self._create_home_item(name, True))

    def files_new_file(self):
        self.desktop.show_text_prompt("New text file", "File name", lambda name: self._create_home_item(name, False), "New file.txt")

    def _create_home_item(self, name, is_folder):
        name = (name or "").strip().replace("/", "_").replace("\\", "_")
        if not name or name in {".", ".."}:
            raise ValueError("Invalid name")
        target = (self.current_folder / name).resolve()
        if not inside_home(target) or target.parent != self.current_folder:
            raise ValueError("The target must remain inside Nexora Home")
        if target.exists():
            raise FileExistsError(name)
        target.mkdir() if is_folder else target.write_text("", encoding="utf-8")
        self.files_render_listing()
        self.desktop.notch.notify("Created " + name)

    def files_copy_selected(self, cut=False):
        paths = self.files_selected_paths()
        if not paths:
            return
        self.files_clipboard = ("cut" if cut else "copy", paths)
        self.files_status.setText(f"{'Cut' if cut else 'Copied'} {len(paths)} item(s)")

    def files_paste(self):
        mode, sources = self.files_clipboard
        sources = [path for path in sources if path.exists() and inside_home(path)]
        if not sources:
            self.files_status.setText("Clipboard is empty")
            return
        destination = self.current_folder

        def operation():
            completed = []
            for source in sources:
                target = self._unique_target(destination / source.name)
                if not inside_home(target):
                    raise ValueError("Unsafe destination")
                if mode == "cut":
                    shutil.move(str(source), str(target))
                elif source.is_dir():
                    shutil.copytree(source, target)
                else:
                    shutil.copy2(source, target)
                completed.append(str(target))
            return completed

        def finished(_result):
            if mode == "cut":
                self.files_clipboard = ("copy", [])
            self.files_render_listing()

        self._run_file_operation("Pasting files", operation, finished)

    def files_delete_selected(self):
        paths = self.files_selected_paths()
        if not paths:
            return
        permanent = self.current_folder == TRASH_DIR.resolve()
        label = "permanently delete" if permanent else "move to Trash"
        self.desktop.show_confirm("Delete files", f"{label.title()} {len(paths)} selected item(s)?", lambda: self._delete_paths(paths, permanent))

    def _delete_paths(self, paths, permanent=False):
        def operation():
            for path in paths:
                if not inside_home(path):
                    continue
                if permanent:
                    shutil.rmtree(path) if path.is_dir() else path.unlink(missing_ok=True)
                else:
                    TRASH_DIR.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(path), str(self._unique_target(TRASH_DIR / path.name)))
            return len(paths)

        self._run_file_operation("Deleting files", operation, lambda _result: self.files_render_listing())

    def files_rename(self, path):
        def rename(name):
            clean = name.strip().replace("/", "_").replace("\\", "_")
            if not clean:
                raise ValueError("Name cannot be empty")
            target = (path.parent / clean).resolve()
            if not inside_home(target) or target.parent != path.parent:
                raise ValueError("Unsafe target name")
            path.rename(target)
            self.files_render_listing()
        self.desktop.show_text_prompt("Rename", "New name", rename, path.name)

    def files_duplicate(self, path):
        target = self._unique_target(path.with_name(path.stem + " copy" + path.suffix))

        def operation():
            shutil.copytree(path, target) if path.is_dir() else shutil.copy2(path, target)
            return str(target)

        self._run_file_operation("Duplicating", operation, lambda _result: self.files_render_listing())

    def files_restore(self, path):
        if path.parent != TRASH_DIR.resolve():
            return
        target = self._unique_target(NEXORA_HOME / path.name)
        self._run_file_operation("Restoring", lambda: shutil.move(str(path), str(target)), lambda _result: self.files_render_listing())

    def _unique_target(self, target):
        target = Path(target)
        if not target.exists():
            return target
        stem, suffix = target.stem, target.suffix
        for number in range(2, 10000):
            candidate = target.with_name(f"{stem} ({number}){suffix}")
            if not candidate.exists():
                return candidate
        raise FileExistsError(target)

    def _run_file_operation(self, label, function, on_success=None):
        if self.files_operation is not None:
            self.desktop.show_system_message("Files", "Another file operation is still running.")
            return
        self.files_progress.setRange(0, 0)
        self.files_progress.show()
        self.files_status.setText(label + "…")
        self.files_listing.setEnabled(False)

        def success(result):
            if on_success:
                on_success(result)
            self.files_status.setText(label + " complete")

        def failure(message):
            self.desktop.show_system_message("Files", message)
            self.files_status.setText(label + " failed")

        def done():
            self.files_operation = None
            self.files_progress.hide()
            self.files_listing.setEnabled(True)

        self.files_operation = submit(function, on_success=success, on_error=failure, on_finished=done)

    # --------------------------------------------------------------- context UI
    def files_context_menu(self, pos):
        item = self.files_listing.itemAt(pos)
        if item is None:
            menu = create_nexora_menu(self)
            new_folder = menu.addAction("New folder")
            new_file = menu.addAction("New text file")
            paste = menu.addAction("Paste")
            paste.setEnabled(bool(self.files_clipboard[1]))
            refresh = menu.addAction("Refresh")
            chosen = menu.exec(self.files_listing.viewport().mapToGlobal(pos))
            if chosen == new_folder:
                self.files_new_folder()
            elif chosen == new_file:
                self.files_new_file()
            elif chosen == paste:
                self.files_paste()
            elif chosen == refresh:
                self.files_render_listing()
            return
        if not item.isSelected():
            self.files_listing.clearSelection()
            item.setSelected(True)
        selected = self.files_selected_paths()
        path = selected[0]
        menu = create_nexora_menu(self)
        open_action = menu.addAction("Open")
        new_tab = menu.addAction("Open in new tab") if path.is_dir() else None
        menu.addSeparator()
        copy_action = menu.addAction("Copy")
        cut_action = menu.addAction("Cut")
        duplicate_action = menu.addAction("Duplicate") if len(selected) == 1 else None
        rename_action = menu.addAction("Rename") if len(selected) == 1 else None
        pin_action = menu.addAction("Pin folder to Start") if path.is_dir() and path != TRASH_DIR.resolve() else None
        restore_action = menu.addAction("Restore to Home") if path.parent == TRASH_DIR.resolve() else None
        menu.addSeparator()
        delete_action = menu.addAction("Delete permanently" if self.current_folder == TRASH_DIR.resolve() else "Move to Trash")
        properties = menu.addAction("Properties")
        chosen = menu.exec(self.files_listing.viewport().mapToGlobal(pos))
        if chosen == open_action:
            self.files_activate_item(item)
        elif new_tab is not None and chosen == new_tab:
            self.files_add_tab(path)
        elif chosen == copy_action:
            self.files_copy_selected(False)
        elif chosen == cut_action:
            self.files_copy_selected(True)
        elif duplicate_action is not None and chosen == duplicate_action:
            self.files_duplicate(path)
        elif rename_action is not None and chosen == rename_action:
            self.files_rename(path)
        elif pin_action is not None and chosen == pin_action:
            self.desktop.pin_folder(path)
        elif restore_action is not None and chosen == restore_action:
            self.files_restore(path)
        elif chosen == delete_action:
            self.files_delete_selected()
        elif chosen == properties:
            self.files_update_preview()

    def choose_folder_to_pin(self):
        self.desktop.show_system_message("Files", "Pin folders from inside Nexora Home using the context menu.")

    def open_home_file(self, path):
        path = Path(path).resolve()
        if not inside_home(path) or not path.is_file():
            return
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(path))):
            self.desktop.show_system_message("Files", "No application is available to open this file type.")

    def _install_files_shortcuts(self):
        shortcuts = (
            ("Back", "Alt+Left", self.files_go_back),
            ("Forward", "Alt+Right", self.files_go_forward),
            ("Up", "Alt+Up", self.files_go_up),
            ("New folder", "Ctrl+Shift+N", self.files_new_folder),
            ("Copy", "Ctrl+C", lambda: self.files_copy_selected(False)),
            ("Cut", "Ctrl+X", lambda: self.files_copy_selected(True)),
            ("Paste", "Ctrl+V", self.files_paste),
            ("Delete", "Delete", self.files_delete_selected),
            ("Refresh", "F5", self.files_render_listing),
        )
        self.files_actions = []
        for title, shortcut, callback in shortcuts:
            action = QAction(title, self)
            action.setShortcut(shortcut)
            action.triggered.connect(callback)
            self.addAction(action)
            self.files_actions.append(action)
