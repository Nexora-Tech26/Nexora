"""Central notification history, grouping, actions and expiry."""
from __future__ import annotations

import json
import logging
import os
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path

from PySide6.QtCore import QObject, QTimer, Signal

log = logging.getLogger("nexora.notifications")


@dataclass
class Notification:
    app_id: str
    title: str
    message: str
    priority: str = "normal"
    timestamp: float = field(default_factory=time.time)
    id: str = field(default_factory=lambda: uuid.uuid4().hex)
    actions: tuple[str, ...] = ()
    expires_ms: int = 5000
    read: bool = False


class NotificationService(QObject):
    notificationAdded = Signal(object)
    notificationRemoved = Signal(str)
    historyChanged = Signal()

    def __init__(self, path: Path, settings_store, parent=None):
        super().__init__(parent)
        self.path = Path(path)
        self.settings_store = settings_store
        self._items: list[Notification] = []
        self._callbacks: dict[str, dict] = {}
        self._load()

    def _load(self):
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(raw, list):
                raise ValueError("notification history must be a list")
            valid = []
            for item in raw[-250:]:
                if not isinstance(item, dict):
                    continue
                item["actions"] = tuple(item.get("actions", ()))
                valid.append(Notification(**item))
            self._items = valid
        except FileNotFoundError:
            self._items = []
        except (OSError, ValueError, TypeError) as exc:
            log.warning("Ignoring damaged notification history: %s", exc)
            self._items = []

    def _save(self):
        if not bool(self.settings_store.get("notification_history", True)):
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(json.dumps([asdict(item) for item in self._items[-250:]], indent=2), encoding="utf-8")
        os.replace(temp, self.path)

    def post(self, app_id, title, message, *, priority="normal", actions=(), callbacks=None, expires_ms=5000):
        settings = self.settings_store.snapshot()
        item = Notification(
            str(app_id), str(title), str(message), str(priority),
            actions=tuple(str(action) for action in actions), expires_ms=max(0, int(expires_ms)),
        )
        self._items.append(item)
        self._callbacks[item.id] = dict(callbacks or {})
        self._save(); self.historyChanged.emit()
        if bool(settings.get("notifications", True)) and (not settings.get("do_not_disturb") or priority == "critical"):
            self.notificationAdded.emit(item)
        if item.expires_ms:
            QTimer.singleShot(item.expires_ms, lambda notification_id=item.id: self.mark_read(notification_id))
        return item

    def mark_read(self, notification_id):
        for item in self._items:
            if item.id == notification_id:
                item.read = True; self._save(); self.historyChanged.emit(); return True
        return False

    def dismiss(self, notification_id):
        before = len(self._items)
        self._items = [item for item in self._items if item.id != notification_id]
        self._callbacks.pop(notification_id, None)
        if len(self._items) != before:
            self._save(); self.notificationRemoved.emit(notification_id); self.historyChanged.emit(); return True
        return False

    def clear(self):
        self._items.clear(); self._callbacks.clear(); self._save(); self.historyChanged.emit()

    def history(self):
        return tuple(reversed(self._items))

    def grouped(self):
        result = {}
        for item in self.history(): result.setdefault(item.app_id, []).append(item)
        return result

    def invoke(self, notification_id, action):
        callback = self._callbacks.get(notification_id, {}).get(action)
        if callable(callback):
            callback(); return True
        return False
