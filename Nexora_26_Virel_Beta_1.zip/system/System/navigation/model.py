"""Declarative per-application navigation models."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Iterable

@dataclass(frozen=True)
class NavigationItem:
    key: str
    label: str
    icon: str = ""
    shortcut: str = ""
    enabled: bool = True

@dataclass
class NavigationModel:
    app_id: str
    title: str = ""
    items: list[NavigationItem] = field(default_factory=list)
    selected_key: str | None = None

    def __post_init__(self):
        keys = [item.key for item in self.items]
        if len(keys) != len(set(keys)):
            raise ValueError(f"Duplicate navigation key in {self.app_id}")
        if self.selected_key is None and self.items:
            self.selected_key = self.items[0].key
        if self.selected_key is not None and self.selected_key not in keys:
            raise ValueError(f"Unknown selected navigation key: {self.selected_key}")

    def select(self, key: str) -> bool:
        if any(item.key == key and item.enabled for item in self.items):
            self.selected_key = key
            return True
        return False

    @property
    def has_sidebar(self) -> bool:
        return bool(self.items)

    @classmethod
    def for_app(cls, display_name: str) -> "NavigationModel":
        aliases = {
            "Task Manager Pro": "Task Manager",
            "Photo Editor": "Image Editor",
            "Image Studio": "Image Editor",
            "Video Studio": "Video Editor",
            "Code Studio": "Code Editor",
            "Virtual Lab": "Virtual Machine",
            "Virtual Machine Manager": "Virtual Machine",
            "Database Studio": "Database",
            "PDF Studio": "PDF Editor",
            "Audio Studio": "Audio Editor",
            "Archive Manager": "Archives",
        }
        canonical_name = aliases.get(display_name, display_name)
        definitions = {
            "Files": ("PLACES", ["Home", "Desktop", "Documents", "Downloads", "Images", "Trash"]),
            "Settings": ("SETTINGS", [
                "Appearance", "Desktop", "Dock & Taskbar",
                "Sound", "Apps", "Users", "Privacy", "Accessibility", "System",
            ]),
            "Browser": ("BROWSER", ["Start", "History", "Favorites", "Downloads"]),
            "Task Manager": ("MONITOR", ["Processes", "Performance", "Startup", "Services"]),
            "Documents": ("DOCUMENT", ["Document", "Formatting", "Export"]),
            "Code Editor": ("PROJECT", ["Explorer", "Editor", "Output", "Run"]),
            "Sheets": ("WORKBOOK", ["Sheet", "Recalculate", "Export CSV"]),
            "Spreadsheets": ("WORKBOOK", ["Sheet", "Recalculate", "Export CSV"]),
            "Presentations": ("DECK", ["Slides", "Add slide", "Delete slide", "Save"]),
            "Image Editor": ("IMAGE", ["Canvas", "Clear canvas", "Export PNG"]),
            "Video Editor": ("VIDEO", ["Timeline", "Add clip", "Remove clip", "Save project"]),
            "Virtual Machine": ("VIRTUAL LAB", ["Machines", "New profile", "Start"]),
            "Database": ("DATABASE", ["Query", "Run SQL", "Results"]),
            "PDF Editor": ("PDF", ["Document", "Export PDF"]),
            "Audio Editor": ("AUDIO", ["Tracks", "Add track", "Remove track", "Save project"]),
            "Whiteboard": ("BOARD", ["Board", "Add note", "Clear"]),
            "Archives": ("ARCHIVES", ["Archives", "Create ZIP", "Extract ZIP"]),
            "Notes": ("NOTES", ["All Notes", "Pinned", "Search"]),
            "Mail": ("MAIL", ["Compose", "Drafts", "Outbox"]),
            "Music Player": ("MUSIC", ["Library", "Playlists", "Folders"]),
            "Package Manager": ("PACKAGES", ["Installed", "Updates", "Extensions"]),
            "System Monitor": ("MONITOR", ["Overview", "Processes", "Resources"]),
            "Performance Monitor": ("PERFORMANCE", ["Overview", "Processes", "Resources"]),
            "System Health": ("HEALTH", ["Status", "Findings", "Maintenance"]),
            "Disk Manager": ("STORAGE", ["Volumes", "Usage", "Health"]),
            "Backup Manager": ("BACKUP", ["Snapshots", "Restore", "Schedule"]),
            "Clipboard Manager": ("CLIPBOARD", ["History", "Pinned", "Search"]),
            "Password Manager": ("VAULT", ["Vault", "Generator", "Security"]),
            "Download Manager": ("DOWNLOADS", ["Active", "Completed", "Failed"]),
            "Game Launcher": ("GAMING", ["Library", "Performance", "Profiles"]),
            "File Sharing": ("SHARING", ["Shared", "Activity", "Permissions"]),
            "Git Client": ("GIT", ["Status", "History", "Repository"]),
            "Spaces": ("SPACES", ["Spaces", "Applications", "Profiles"]),
            "Automation": ("AUTOMATION", ["Scenarios", "Triggers", "History"]),
            "Extensions": ("EXTENSIONS", ["Installed", "Permissions", "Developer"]),
        }
        title, labels = definitions.get(canonical_name, ("", []))
        return cls(canonical_name.casefold().replace(" ", "_"), title, [NavigationItem(label.casefold().replace(" ", "_"), label) for label in labels])
