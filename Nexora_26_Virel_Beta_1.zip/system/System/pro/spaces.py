"""Persistent Nexora Spaces: independent desktop contexts for work, study and play."""
from __future__ import annotations

import re
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable

from .storage import AtomicJsonStore


@dataclass(frozen=True)
class Space:
    key: str
    name: str
    icon: str
    theme: str
    performance: str
    apps: tuple[str, ...]
    created_at: int
    updated_at: int


class SpaceManager:
    DEFAULTS = (
        Space("work", "Work", "briefcase", "nexora_glass", "balanced", ("Files", "Notepad", "Calendar"), 0, 0),
        Space("study", "Study", "book", "nexora_glass", "balanced", ("Browser", "Notepad", "Calendar"), 0, 0),
        Space("play", "Play", "gamepad", "nexora_glass", "performance", ("Gallery", "Weather", "Calculator"), 0, 0),
    )

    def __init__(self, data_dir: Path):
        now = int(time.time())
        defaults = {s.key: {**asdict(s), "created_at": now, "updated_at": now} for s in self.DEFAULTS}
        self.store = AtomicJsonStore(Path(data_dir) / "spaces.json", {"active": "work", "items": defaults})
        self._normalize()

    @staticmethod
    def _key(name: str) -> str:
        key = re.sub(r"[^a-z0-9]+", "-", name.casefold()).strip("-")
        return key or f"space-{int(time.time())}"

    def _normalize(self):
        def mutate(data):
            if not isinstance(data, dict):
                data = {"active": "work", "items": {}}
            items = data.setdefault("items", {})
            now = int(time.time())
            for default in self.DEFAULTS:
                items.setdefault(default.key, {**asdict(default), "created_at": now, "updated_at": now})
            if data.get("active") not in items:
                data["active"] = next(iter(items), "work")
            return data
        self.store.update(mutate)

    def list(self) -> tuple[Space, ...]:
        data = self.store.snapshot()
        result = []
        for key, raw in data.get("items", {}).items():
            try:
                result.append(Space(
                    key=key,
                    name=str(raw.get("name", key.title())),
                    icon=str(raw.get("icon", "circle")),
                    theme=str(raw.get("theme", "nexora_glass")),
                    performance=str(raw.get("performance", "balanced")),
                    apps=tuple(str(x) for x in raw.get("apps", [])),
                    created_at=int(raw.get("created_at", 0)),
                    updated_at=int(raw.get("updated_at", 0)),
                ))
            except (TypeError, ValueError):
                continue
        return tuple(sorted(result, key=lambda item: (item.created_at, item.name.casefold())))

    def active(self) -> Space:
        data = self.store.snapshot()
        key = data.get("active")
        return next((space for space in self.list() if space.key == key), self.list()[0])

    def activate(self, key: str) -> Space:
        spaces = {space.key: space for space in self.list()}
        if key not in spaces:
            raise KeyError(key)
        self.store.update(lambda data: {**data, "active": key})
        return spaces[key]

    def save(self, name: str, *, theme="nexora_glass", performance="balanced", apps: Iterable[str] = (), icon="circle") -> Space:
        key = self._key(name)
        now = int(time.time())
        existing = {space.key: space for space in self.list()}.get(key)
        space = Space(key, name.strip() or key.title(), icon, theme, performance, tuple(dict.fromkeys(apps)), existing.created_at if existing else now, now)
        def mutate(data):
            data.setdefault("items", {})[key] = asdict(space)
            return data
        self.store.update(mutate)
        return space

    def delete(self, key: str) -> None:
        def mutate(data):
            items = data.setdefault("items", {})
            if key in {"work", "study", "play"}:
                raise ValueError("Built-in Spaces cannot be deleted")
            items.pop(key, None)
            if data.get("active") == key:
                data["active"] = next(iter(items), "work")
            return data
        self.store.update(mutate)
