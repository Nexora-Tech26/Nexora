"""System health, cache and release diagnostics for Nexora 26 Beta 1."""
from __future__ import annotations

import json
import os
import platform
import shutil
import time
from pathlib import Path


class CacheManager:
    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir)
        self.cache_dirs = tuple(path for path in (self.data_dir / "cache", self.data_dir / "wallpaper-cache", self.data_dir / "thumbnails") if path)

    def stats(self):
        files = 0; size = 0
        for folder in self.cache_dirs:
            if not folder.exists(): continue
            for path in folder.rglob("*"):
                if path.is_file():
                    files += 1
                    try: size += path.stat().st_size
                    except OSError: pass
        return {"files": files, "bytes": size}

    def clear(self):
        removed = 0
        for folder in self.cache_dirs:
            if not folder.exists(): continue
            for path in sorted(folder.rglob("*"), reverse=True):
                try:
                    if path.is_file() or path.is_symlink(): path.unlink(); removed += 1
                    elif path.is_dir(): path.rmdir()
                except OSError: continue
        return removed


class HealthMonitor:
    def __init__(self, project_root: Path, data_dir: Path):
        self.project_root = Path(project_root)
        self.data_dir = Path(data_dir)

    def collect(self):
        try:
            import psutil
            memory = psutil.virtual_memory(); disk = psutil.disk_usage(str(self.project_root))
            cpu = psutil.cpu_percent(interval=0.05)
            processes = len(psutil.pids())
            battery = psutil.sensors_battery()
        except Exception:
            memory = disk = battery = None; cpu = 0; processes = 0
        issues = []
        if memory and memory.percent >= 90: issues.append("Memory pressure is critical")
        if disk and disk.percent >= 92: issues.append("System drive is almost full")
        settings = self.data_dir / "settings.json"
        try:
            raw = json.loads(settings.read_text(encoding="utf-8"))
            if not isinstance(raw, dict): issues.append("Settings root is invalid")
        except (OSError, ValueError): issues.append("Settings file cannot be read")
        cache = CacheManager(self.data_dir).stats()
        if cache["bytes"] > 512 * 1024 * 1024: issues.append("Cache is larger than 512 MB")
        return {
            "timestamp": int(time.time()), "platform": platform.platform(), "python": platform.python_version(),
            "cpu_percent": cpu, "memory_percent": memory.percent if memory else None,
            "disk_percent": disk.percent if disk else None, "processes": processes,
            "battery_percent": battery.percent if battery else None, "cache": cache,
            "issues": issues, "status": "attention" if issues else "healthy",
        }
