"""Local scenario automation engine with explicit triggers and auditable actions."""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable, Mapping, Any

from .storage import AtomicJsonStore


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    name: str
    enabled: bool
    trigger: dict[str, Any]
    actions: tuple[dict[str, Any], ...]
    last_run: int = 0


class ScenarioEngine:
    SAFE_ACTIONS = {"set_setting", "open_app", "activate_space", "notify", "set_wallpaper"}

    def __init__(self, data_dir: Path):
        self.store = AtomicJsonStore(Path(data_dir) / "scenarios.json", {"items": []})

    def list(self) -> tuple[Scenario, ...]:
        result = []
        for raw in self.store.snapshot().get("items", []):
            try:
                result.append(Scenario(
                    scenario_id=str(raw["scenario_id"]), name=str(raw["name"]), enabled=bool(raw.get("enabled", True)),
                    trigger=dict(raw.get("trigger", {})), actions=tuple(dict(x) for x in raw.get("actions", [])),
                    last_run=int(raw.get("last_run", 0)),
                ))
            except (KeyError, TypeError, ValueError):
                continue
        return tuple(result)

    def save(self, name: str, trigger: Mapping[str, Any], actions, *, enabled=True, scenario_id=None) -> Scenario:
        normalized_actions = tuple(dict(action) for action in actions)
        for action in normalized_actions:
            if action.get("type") not in self.SAFE_ACTIONS:
                raise ValueError(f"Unsupported automation action: {action.get('type')}")
        item = Scenario(str(scenario_id or uuid.uuid4()), name.strip() or "Automation", bool(enabled), dict(trigger), normalized_actions)
        def mutate(data):
            items = [x for x in data.setdefault("items", []) if x.get("scenario_id") != item.scenario_id]
            items.append(asdict(item)); data["items"] = items; return data
        self.store.update(mutate)
        return item

    def delete(self, scenario_id: str):
        self.store.update(lambda data: {**data, "items": [x for x in data.get("items", []) if x.get("scenario_id") != scenario_id]})

    @staticmethod
    def matches(trigger: Mapping[str, Any], event: Mapping[str, Any]) -> bool:
        kind = trigger.get("type")
        if kind != event.get("type"):
            return False
        return all(event.get(key) == value for key, value in trigger.items() if key != "type")

    def process(self, event: Mapping[str, Any], executor: Callable[[dict[str, Any]], None]) -> list[str]:
        executed = []
        now = int(time.time())
        items = list(self.store.snapshot().get("items", []))
        changed = False
        for raw in items:
            if not raw.get("enabled", True) or not self.matches(raw.get("trigger", {}), event):
                continue
            for action in raw.get("actions", []):
                executor(dict(action))
            raw["last_run"] = now
            executed.append(str(raw.get("scenario_id")))
            changed = True
        if changed:
            self.store.replace({"items": items})
        return executed
