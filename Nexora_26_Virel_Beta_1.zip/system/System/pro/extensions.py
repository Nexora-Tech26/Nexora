"""Declarative extension discovery. Extensions are never executed during discovery."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Extension:
    extension_id: str
    name: str
    version: str
    api_version: int
    enabled: bool
    permissions: tuple[str, ...]
    path: Path


class ExtensionManager:
    API_VERSION = 1
    ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{2,80}$")

    def __init__(self, data_dir: Path):
        self.root = Path(data_dir) / "extensions"
        self.root.mkdir(parents=True, exist_ok=True)

    def discover(self) -> tuple[Extension, ...]:
        result = []
        for manifest in sorted(self.root.glob("*/manifest.json")):
            try:
                raw = json.loads(manifest.read_text(encoding="utf-8"))
                extension_id = str(raw["id"])
                api = int(raw.get("api_version", 0))
                if not self.ID_RE.fullmatch(extension_id) or api != self.API_VERSION: continue
                result.append(Extension(extension_id, str(raw.get("name", extension_id)), str(raw.get("version", "0.0.0")), api, bool(raw.get("enabled", True)), tuple(str(x) for x in raw.get("permissions", [])), manifest.parent))
            except (OSError, ValueError, TypeError, KeyError):
                continue
        return tuple(result)

    def set_enabled(self, extension_id: str, enabled: bool):
        extension = next((x for x in self.discover() if x.extension_id == extension_id), None)
        if extension is None: raise KeyError(extension_id)
        manifest = extension.path / "manifest.json"
        raw = json.loads(manifest.read_text(encoding="utf-8")); raw["enabled"] = bool(enabled)
        tmp = manifest.with_suffix(".tmp"); tmp.write_text(json.dumps(raw, indent=2, sort_keys=True), encoding="utf-8"); tmp.replace(manifest)
