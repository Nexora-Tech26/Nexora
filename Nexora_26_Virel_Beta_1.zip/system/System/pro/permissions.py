"""Application capability permissions with safe defaults."""
from __future__ import annotations

from pathlib import Path
from .storage import AtomicJsonStore


class PermissionManager:
    CAPABILITIES = ("camera", "microphone", "location", "files", "network", "clipboard", "notifications", "automation")
    DEFAULT_ALLOW = {"files", "network", "clipboard", "notifications"}

    def __init__(self, data_dir: Path):
        self.store = AtomicJsonStore(Path(data_dir) / "permissions.json", {"apps": {}})

    def get(self, app_id: str, capability: str) -> bool:
        if capability not in self.CAPABILITIES: raise KeyError(capability)
        apps = self.store.snapshot().get("apps", {})
        app = apps.get(app_id, {})
        return bool(app.get(capability, capability in self.DEFAULT_ALLOW))

    def set(self, app_id: str, capability: str, allowed: bool):
        if capability not in self.CAPABILITIES: raise KeyError(capability)
        def mutate(data):
            data.setdefault("apps", {}).setdefault(app_id, {})[capability] = bool(allowed)
            return data
        self.store.update(mutate)

    def reset(self, app_id: str):
        def mutate(data): data.setdefault("apps", {}).pop(app_id, None); return data
        self.store.update(mutate)

    def audit(self):
        data = self.store.snapshot().get("apps", {})
        return {app: {cap: bool(value) for cap, value in caps.items() if cap in self.CAPABILITIES} for app, caps in data.items()}
