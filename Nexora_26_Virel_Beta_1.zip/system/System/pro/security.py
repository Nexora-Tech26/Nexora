"""Authenticated local vault using PBKDF2, HMAC and a deterministic stream cipher.

The format is intentionally self-contained so Nexora can protect local secrets
without an optional dependency. It is versioned and integrity checked. The UI
labels it a local vault, not a replacement for hardware-backed keychains.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
from pathlib import Path


class VaultError(ValueError): pass


def _derive(password: str, salt: bytes):
    raw = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 310_000, dklen=64)
    return raw[:32], raw[32:]


def _stream(key: bytes, nonce: bytes, length: int) -> bytes:
    out = bytearray(); counter = 0
    while len(out) < length:
        out.extend(hmac.new(key, nonce + counter.to_bytes(8, "big"), hashlib.sha256).digest()); counter += 1
    return bytes(out[:length])


class LocalVault:
    def __init__(self, path: Path): self.path = Path(path)

    def exists(self): return self.path.exists()

    def save(self, password: str, entries: list[dict]):
        if len(password) < 8: raise VaultError("Vault password must contain at least 8 characters")
        salt, nonce = os.urandom(16), os.urandom(16)
        enc_key, mac_key = _derive(password, salt)
        plaintext = json.dumps(entries, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        stream = _stream(enc_key, nonce, len(plaintext)); cipher = bytes(a ^ b for a, b in zip(plaintext, stream))
        tag = hmac.new(mac_key, b"NEXORA-VAULT-1" + nonce + cipher, hashlib.sha256).digest()
        payload = {"schema": 1, "salt": base64.b64encode(salt).decode(), "nonce": base64.b64encode(nonce).decode(), "cipher": base64.b64encode(cipher).decode(), "tag": base64.b64encode(tag).decode()}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp"); tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8"); os.replace(tmp, self.path)
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    def load(self, password: str) -> list[dict]:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            salt = base64.b64decode(raw["salt"]); nonce = base64.b64decode(raw["nonce"]); cipher = base64.b64decode(raw["cipher"]); tag = base64.b64decode(raw["tag"])
        except (OSError, ValueError, KeyError, TypeError) as exc: raise VaultError("Vault file is invalid") from exc
        enc_key, mac_key = _derive(password, salt)
        expected = hmac.new(mac_key, b"NEXORA-VAULT-1" + nonce + cipher, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, expected): raise VaultError("Incorrect password or damaged vault")
        plaintext = bytes(a ^ b for a, b in zip(cipher, _stream(enc_key, nonce, len(cipher))))
        try:
            result = json.loads(plaintext.decode("utf-8"))
            if not isinstance(result, list): raise ValueError
            return result
        except (ValueError, UnicodeError) as exc: raise VaultError("Vault data is invalid") from exc
