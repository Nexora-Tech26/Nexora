"""Validated local configuration snapshots and backups."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
import uuid
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class Snapshot:
    snapshot_id: str
    name: str
    created_at: int
    size: int
    checksum: str
    file_count: int
    archive: str


class SnapshotManager:
    def __init__(self, data_dir: Path, home_dir: Path | None = None):
        self.data_dir = Path(data_dir).resolve()
        self.home_dir = Path(home_dir).resolve() if home_dir else None
        self.root = self.data_dir / "snapshots"
        self.root.mkdir(parents=True, exist_ok=True)
        self.index_path = self.root / "index.json"

    def _index(self) -> list[dict]:
        try:
            value = json.loads(self.index_path.read_text(encoding="utf-8"))
            return value if isinstance(value, list) else []
        except (OSError, ValueError):
            return []

    def _write_index(self, items: list[dict]):
        tmp = self.index_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(items, indent=2, sort_keys=True), encoding="utf-8")
        os.replace(tmp, self.index_path)

    def list(self) -> tuple[Snapshot, ...]:
        result = []
        for raw in self._index():
            try: result.append(Snapshot(**raw))
            except (TypeError, ValueError): continue
        return tuple(sorted(result, key=lambda item: item.created_at, reverse=True))

    def create(self, name="Manual snapshot", *, include_home=False) -> Snapshot:
        stamp = int(time.time())
        snapshot_id = f"{time.strftime('%Y%m%d-%H%M%S', time.localtime(stamp))}-{uuid.uuid4().hex[:8]}"
        archive = self.root / f"{snapshot_id}.nexora-snapshot.zip"
        count = 0
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for path in sorted(self.data_dir.rglob("*")):
                if not path.is_file() or path.is_symlink() or self.root in path.parents:
                    continue
                try:
                    path.resolve().relative_to(self.data_dir)
                except (OSError, ValueError):
                    continue
                rel = Path("data") / path.relative_to(self.data_dir)
                zf.write(path, rel.as_posix()); count += 1
            if include_home and self.home_dir and self.home_dir.exists():
                for path in sorted(self.home_dir.rglob("*")):
                    if not path.is_file() or path.is_symlink():
                        continue
                    try:
                        path.resolve().relative_to(self.home_dir)
                    except (OSError, ValueError):
                        continue
                    zf.write(path, (Path("home") / path.relative_to(self.home_dir)).as_posix()); count += 1
            manifest = {"schema": 1, "created_at": stamp, "name": name, "file_count": count}
            zf.writestr("manifest.json", json.dumps(manifest, indent=2))
        checksum = hashlib.sha256(archive.read_bytes()).hexdigest()
        item = Snapshot(snapshot_id, name.strip() or "Snapshot", stamp, archive.stat().st_size, checksum, count, archive.name)
        items = [raw for raw in self._index() if raw.get("snapshot_id") != snapshot_id]
        items.append(asdict(item)); self._write_index(items)
        return item

    def validate(self, snapshot_id: str) -> Snapshot:
        item = next((x for x in self.list() if x.snapshot_id == snapshot_id), None)
        if item is None: raise FileNotFoundError(snapshot_id)
        archive = self.root / item.archive
        if not archive.exists(): raise FileNotFoundError(archive)
        if hashlib.sha256(archive.read_bytes()).hexdigest() != item.checksum:
            raise ValueError("Snapshot checksum does not match")
        with zipfile.ZipFile(archive) as zf:
            for info in zf.infolist():
                path = Path(info.filename)
                if path.is_absolute() or ".." in path.parts:
                    raise ValueError("Unsafe path in snapshot")
        return item

    def restore(self, snapshot_id: str, *, restore_home=False) -> Snapshot:
        item = self.validate(snapshot_id)
        archive = self.root / item.archive
        recovery = self.data_dir / f"pre-restore-{int(time.time())}"
        recovery.mkdir(parents=True, exist_ok=True)
        for file in self.data_dir.iterdir():
            if file.is_file(): shutil.copy2(file, recovery / file.name)
        with zipfile.ZipFile(archive) as zf:
            for info in zf.infolist():
                if info.is_dir() or info.filename == "manifest.json": continue
                parts = Path(info.filename).parts
                if not parts: continue
                if parts[0] == "data": base, rel = self.data_dir, Path(*parts[1:])
                elif parts[0] == "home" and restore_home and self.home_dir: base, rel = self.home_dir, Path(*parts[1:])
                else: continue
                target = (base / rel).resolve()
                target.relative_to(base.resolve())
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, target.open("wb") as dst: shutil.copyfileobj(src, dst)
        return item

    def delete(self, snapshot_id: str):
        item = next((x for x in self.list() if x.snapshot_id == snapshot_id), None)
        if item:
            try: (self.root / item.archive).unlink()
            except OSError: pass
        self._write_index([raw for raw in self._index() if raw.get("snapshot_id") != snapshot_id])
