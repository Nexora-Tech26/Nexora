"""Small atomic JSON stores used by Nexora 26 Beta 1 services."""
from __future__ import annotations

import json
import os
import threading
from copy import deepcopy
from pathlib import Path
from typing import Any


class AtomicJsonStore:
    def __init__(self, path: Path, default: Any):
        self.path = Path(path)
        self.default = deepcopy(default)
        self._lock = threading.RLock()
        self._data = self._load()

    def _load(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
            return value
        except (OSError, ValueError, TypeError):
            return deepcopy(self.default)

    def snapshot(self):
        with self._lock:
            return deepcopy(self._data)

    def replace(self, value):
        with self._lock:
            self._data = deepcopy(value)
            self._flush_locked()
            return deepcopy(self._data)

    def update(self, mutator):
        with self._lock:
            value = deepcopy(self._data)
            updated = mutator(value)
            self._data = value if updated is None else updated
            self._flush_locked()
            return deepcopy(self._data)

    def _flush_locked(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + f".{os.getpid()}.tmp")
        tmp.write_text(json.dumps(self._data, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
        os.replace(tmp, self.path)
