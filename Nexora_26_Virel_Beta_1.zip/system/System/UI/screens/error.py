from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QFontDatabase, QLinearGradient, QPainter, QColor
from PySide6.QtWidgets import QApplication, QFrame, QLabel, QPushButton, QVBoxLayout, QWidget


def ui_font(size: int, bold: bool = False) -> QFont:
    families = set(QFontDatabase.families())
    family = "Gugi" if "Gugi" in families else QApplication.font().family()
    result = QFont(family, size)
    result.setBold(bold)
    return result


class ErrorWindow(QWidget):
    def __init__(self, code: str, description: str):
        super().__init__()
        self.code = code
        self.description = description
        self.setWindowTitle("Nexora Error")
        self.setWindowFlag(Qt.FramelessWindowHint)
        self.setMinimumSize(760, 500)
        root = QVBoxLayout(self)
        root.setContentsMargins(40, 40, 40, 40)
        root.addStretch()
        card = QFrame()
        card.setObjectName("card")
        card.setMaximumWidth(760)
        card.setStyleSheet("#card{background:rgba(96,98,106,125);border:none;border-radius:28px;}")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(44, 42, 44, 42)
        layout.setSpacing(16)
        title = QLabel("NEXORA ERROR")
        title.setFont(ui_font(25, True))
        title.setStyleSheet("color:#FF6B6B;background:transparent;")
        code_label = QLabel(code)
        code_label.setFont(ui_font(16, True))
        code_label.setStyleSheet("color:white;background:transparent;")
        text = QLabel(description)
        text.setWordWrap(True)
        text.setFont(ui_font(11))
        text.setStyleSheet("color:#E7E7EA;background:transparent;")
        close = QPushButton("ZAMKNIJ")
        close.setFont(ui_font(10, True))
        close.setStyleSheet("QPushButton{background:#FF5F57;color:white;border:none;border-radius:13px;padding:12px 20px;}QPushButton:hover{background:#FF746D;}")
        close.clicked.connect(QApplication.quit)
        layout.addWidget(title)
        layout.addWidget(code_label)
        layout.addWidget(text)
        layout.addSpacing(8)
        layout.addWidget(close, 0, Qt.AlignRight)
        root.addWidget(card, 0, Qt.AlignHCenter)
        root.addStretch()

    def paintEvent(self, event):
        painter = QPainter(self)
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        gradient.setColorAt(0, QColor("#301C28"))
        gradient.setColorAt(0.55, QColor("#1B1B1F"))
        gradient.setColorAt(1, QColor("#241D2C"))
        painter.fillRect(self.rect(), gradient)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            QApplication.quit()
            return
        super().keyPressEvent(event)


def main() -> int:
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Nexora Error")
    code = sys.argv[1] if len(sys.argv) > 1 else "0E000000"
    description = sys.argv[2] if len(sys.argv) > 2 else "Unknown error."
    window = ErrorWindow(code, description)
    window.showFullScreen()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
