from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from System.runtime.qt_ui import run
if __name__ == "__main__":
    raise SystemExit(run("desktop"))
