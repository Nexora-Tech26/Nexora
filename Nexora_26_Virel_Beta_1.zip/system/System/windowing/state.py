"""Atomic geometry persistence scaled to the current desktop viewport."""
from __future__ import annotations

import json
import os
from pathlib import Path

from PySide6.QtCore import QRect, QSize


class WindowStateStore:
    def __init__(self, path: Path):
        self.path = Path(path)
        self._data = self._load()

    def _load(self):
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError, TypeError):
            return {}

    def restore(self, app_id: str, host_size: QSize, minimum: QSize) -> tuple[QRect | None, bool]:
        value = self._data.get(str(app_id))
        if not isinstance(value, dict) or host_size.width() <= 0 or host_size.height() <= 0:
            return None, False
        try:
            source_w = max(1, int(value.get("host_width", host_size.width())))
            source_h = max(1, int(value.get("host_height", host_size.height())))
            sx, sy = host_size.width() / source_w, host_size.height() / source_h
            rect = QRect(
                round(int(value["x"]) * sx), round(int(value["y"]) * sy),
                max(minimum.width(), round(int(value["width"]) * sx)),
                max(minimum.height(), round(int(value["height"]) * sy)),
            )
            rect.setWidth(min(rect.width(), host_size.width()))
            rect.setHeight(min(rect.height(), host_size.height()))
            rect.moveLeft(max(0, min(rect.x(), host_size.width() - rect.width())))
            rect.moveTop(max(0, min(rect.y(), host_size.height() - rect.height())))
            return rect, bool(value.get("zoomed", False))
        except (KeyError, TypeError, ValueError):
            return None, False

    def save(self, app_id: str, geometry: QRect, host_size: QSize, *, zoomed: bool = False) -> None:
        if not geometry.isValid() or host_size.width() <= 0 or host_size.height() <= 0:
            return
        self._data[str(app_id)] = {
            "x": int(geometry.x()), "y": int(geometry.y()),
            "width": int(geometry.width()), "height": int(geometry.height()),
            "host_width": int(host_size.width()), "host_height": int(host_size.height()),
            "zoomed": bool(zoomed),
        }
        self._flush()

    def remove(self, app_id: str) -> None:
        if self._data.pop(str(app_id), None) is not None:
            self._flush()

    def _flush(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(json.dumps(self._data, indent=2, sort_keys=True), encoding="utf-8")
        os.replace(temp, self.path)
