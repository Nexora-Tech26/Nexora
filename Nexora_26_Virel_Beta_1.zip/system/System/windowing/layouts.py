"""Pure geometry helpers shared by Snap Layouts and tests."""
from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class Rect:
    x:int; y:int; width:int; height:int

def layout_rects(name:str,width:int,height:int,gap:int=12):
    gap=max(0,int(gap)); x=gap; y=gap; w=max(1,width-gap*2); h=max(1,height-gap*2)
    half=(w-gap)//2; third=(w-gap*2)//3
    layouts={
        "full":[Rect(x,y,w,h)],
        "halves":[Rect(x,y,half,h),Rect(x+half+gap,y,w-half-gap,h)],
        "quarters":[Rect(x,y,half,(h-gap)//2),Rect(x+half+gap,y,w-half-gap,(h-gap)//2),Rect(x,y+(h-gap)//2+gap,half,h-(h-gap)//2-gap),Rect(x+half+gap,y+(h-gap)//2+gap,w-half-gap,h-(h-gap)//2-gap)],
        "wide_left":[Rect(x,y,round(w*2/3)-gap//2,h),Rect(x+round(w*2/3)+gap//2,y,w-round(w*2/3)-gap//2,h)],
        "wide_right":[Rect(x,y,round(w/3)-gap//2,h),Rect(x+round(w/3)+gap//2,y,w-round(w/3)-gap//2,h)],
        "three":[Rect(x,y,third,h),Rect(x+third+gap,y,third,h),Rect(x+(third+gap)*2,y,w-third*2-gap*2,h)],
    }
    return layouts.get(name,layouts["halves"])
