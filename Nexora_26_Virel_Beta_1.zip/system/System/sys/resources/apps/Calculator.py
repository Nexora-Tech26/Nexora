"""Nexora application manifest: Calculator.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'calculator'
DISPLAY_NAME = 'Calculator'
API_VERSION = 1
