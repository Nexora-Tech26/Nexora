"""Nexora application manifest: Browser.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'browser'
DISPLAY_NAME = 'Browser'
API_VERSION = 1
