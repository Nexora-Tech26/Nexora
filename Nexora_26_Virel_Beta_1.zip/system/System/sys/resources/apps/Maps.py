"""Nexora application manifest: Maps.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'maps'
DISPLAY_NAME = 'Maps'
API_VERSION = 1
