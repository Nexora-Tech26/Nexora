"""Nexora application manifest: Sheets."""
APP_ID = 'sheets'
DISPLAY_NAME = 'Sheets'
API_VERSION = 1
