"""Nexora application manifest: Weather.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'weather'
DISPLAY_NAME = 'Weather'
API_VERSION = 1
