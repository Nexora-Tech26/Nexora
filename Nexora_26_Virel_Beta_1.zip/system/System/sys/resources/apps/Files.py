"""Nexora application manifest: Files.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'files'
DISPLAY_NAME = 'Files'
API_VERSION = 1
