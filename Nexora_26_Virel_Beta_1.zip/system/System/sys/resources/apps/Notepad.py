"""Nexora application manifest: Notepad.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'notepad'
DISPLAY_NAME = 'Notepad'
API_VERSION = 1
