"""Nexora application manifest: Clock.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'clock'
DISPLAY_NAME = 'Clock'
API_VERSION = 1
