"""Nexora application manifest: Presentations."""
APP_ID = 'presentations'
DISPLAY_NAME = 'Presentations'
API_VERSION = 1
