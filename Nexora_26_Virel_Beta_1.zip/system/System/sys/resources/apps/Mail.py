"""Nexora 26 Beta 1 application manifest: Mail."""
APP_ID = 'mail'
DISPLAY_NAME = 'Mail'
API_VERSION = 1
