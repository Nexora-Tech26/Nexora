"""Nexora application manifest: Welcome.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'welcome'
DISPLAY_NAME = 'Welcome'
API_VERSION = 1
