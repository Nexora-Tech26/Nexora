"""Nexora application manifest: Paint.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'paint'
DISPLAY_NAME = 'Paint'
API_VERSION = 1
