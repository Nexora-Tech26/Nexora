"""Nexora application manifest: Terminal.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'terminal'
DISPLAY_NAME = 'Terminal'
API_VERSION = 1
