"""Nexora Continuum system application descriptor."""
APP_NAME = "Continuum"
APP_VERSION = "1.0"
APP_DESCRIPTION = "Capture and restore complete work contexts locally."
