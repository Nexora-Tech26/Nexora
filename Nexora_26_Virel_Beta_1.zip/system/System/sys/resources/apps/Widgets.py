"""Nexora application manifest: Widgets.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'widgets'
DISPLAY_NAME = 'Widgets'
API_VERSION = 1
