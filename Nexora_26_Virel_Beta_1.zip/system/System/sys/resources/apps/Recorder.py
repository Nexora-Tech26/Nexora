"""Nexora 26 Beta 1 application manifest: Recorder."""
APP_ID = 'recorder'
DISPLAY_NAME = 'Recorder'
API_VERSION = 1
