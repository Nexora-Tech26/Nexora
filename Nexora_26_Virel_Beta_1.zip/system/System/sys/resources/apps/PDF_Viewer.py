"""Nexora 26 Beta 1 application manifest: PDF Viewer."""
APP_ID = 'pdf_viewer'
DISPLAY_NAME = 'PDF Viewer'
API_VERSION = 1
