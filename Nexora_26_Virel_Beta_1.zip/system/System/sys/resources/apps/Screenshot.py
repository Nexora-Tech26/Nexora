"""Nexora application manifest: Screenshot."""

APP_ID = "screenshot"
DISPLAY_NAME = "Screenshot"
API_VERSION = 1
