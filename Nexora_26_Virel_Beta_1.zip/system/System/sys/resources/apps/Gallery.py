"""Nexora application manifest: Gallery.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'gallery'
DISPLAY_NAME = 'Gallery'
API_VERSION = 1
