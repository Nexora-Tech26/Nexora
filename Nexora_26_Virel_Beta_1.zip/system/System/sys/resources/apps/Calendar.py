"""Nexora application manifest: Calendar.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'calendar'
DISPLAY_NAME = 'Calendar'
API_VERSION = 1
