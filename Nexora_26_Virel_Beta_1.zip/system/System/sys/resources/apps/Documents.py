"""Nexora application manifest: Documents."""
APP_ID = 'documents'
DISPLAY_NAME = 'Documents'
API_VERSION = 1
