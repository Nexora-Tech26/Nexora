"""Nexora application manifest: AboutPC.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'aboutpc'
DISPLAY_NAME = 'About PC'
API_VERSION = 1
