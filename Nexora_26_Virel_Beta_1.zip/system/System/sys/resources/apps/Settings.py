"""Nexora application manifest: Settings.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'settings'
DISPLAY_NAME = 'Settings'
API_VERSION = 1
