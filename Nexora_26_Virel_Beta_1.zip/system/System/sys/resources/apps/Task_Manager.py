"""Nexora application manifest: Task Manager.

The executable UI is implemented by the PySide6 application registry. Keeping
this file declarative prevents a second, stale GUI implementation.
"""

APP_ID = 'task_manager'
DISPLAY_NAME = 'Task Manager'
API_VERSION = 1
