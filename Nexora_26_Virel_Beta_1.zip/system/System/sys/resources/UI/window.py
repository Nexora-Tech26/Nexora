from __future__ import annotations

import logging
import sys
import time
from pathlib import Path
import customtkinter as ctk

SYSTEM_ROOT = Path(__file__).resolve().parents[3]
UI_HELPERS = SYSTEM_ROOT / "func" / "UI"
if str(UI_HELPERS) not in sys.path:
    sys.path.insert(0, str(UI_HELPERS))

from theme import (
    accent, accent_hover, bg, border, buttons, danger, get_font_family, hover,
    sidebar as sidebar_color, sidebar_hover, surface, surface_alt, surface_soft,
    success, warning, cyan, purple, pink, orange, text, text_muted,
)

MAC_RED = "#FF5F57"
MAC_YELLOW = "#FEBB2E"
WINDOW_RADIUS = 18
INNER_RADIUS = 13
ANIMATION_MS = 150
FRAME_MS = 16


def _ease_out_cubic(value: float) -> float:
    value = max(0.0, min(1.0, value))
    return 1.0 - (1.0 - value) ** 3


def _ease_in_cubic(value: float) -> float:
    value = max(0.0, min(1.0, value))
    return value ** 3


class NexoraWindow(ctk.CTkFrame):
    """Embedded, lightweight application window hosted by Desktop-UI."""

    def __init__(self, title="Nexora", size=(900, 620), min_size=(640, 420),
                 sidebar_width=0, toolbar=False, resizable=False,
                 master=None, on_close=None):
        if master is None:
            raise RuntimeError("NexoraWindow must be hosted by Desktop-UI")

        self.app_title = title
        self._preferred_size = size
        self._minimum_size = min_size
        self._on_close = on_close
        self._drag_x = 0
        self._drag_y = 0
        self._geometry = None
        self._animation_job = None
        self._closing = False
        self._app_path = None
        self.desktop = getattr(master, "desktop_controller", master)
        self.font_family = get_font_family(master)

        master.update_idletasks()
        host_w = max(760, master.winfo_width() or master.winfo_screenwidth())
        host_h = max(520, master.winfo_height() or master.winfo_screenheight())
        width = min(size[0], max(min_size[0], host_w - 80))
        height = min(size[1], max(min_size[1], host_h - 90))
        x = max(20, (host_w - width) // 2)
        y = max(20, (host_h - height) // 2)
        self._geometry = (x, y, width, height)

        super().__init__(
            master,
            width=width,
            height=height,
            fg_color=surface,
            border_color=border,
            border_width=1,
            corner_radius=WINDOW_RADIUS,
        )
        self.place(x=x, y=y)
        self.pack_propagate(False)
        self.grid_propagate(False)
        self.lift()

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        # Minimal title bar. Close remains on the left; pin and minimize are on the right.
        self.titlebar = ctk.CTkFrame(
            self, height=46, fg_color=surface_alt, corner_radius=INNER_RADIUS
        )
        self.titlebar.grid(row=0, column=0, sticky="ew", padx=7, pady=(7, 0))
        self.titlebar.grid_propagate(False)

        self.close_button = self._traffic_light(self.titlebar, MAC_RED, self.close)
        self.close_button.place(x=12, rely=.5, anchor="w")

        self.minimize_button = self._traffic_light(self.titlebar, MAC_YELLOW, self.minimize)
        self.minimize_button.place(relx=1, x=-14, rely=.5, anchor="e")

        self.pin_button = ctk.CTkButton(
            self.titlebar,
            text="◇",
            width=26,
            height=24,
            corner_radius=8,
            fg_color="transparent",
            hover_color=hover,
            border_width=0,
            text_color=text_muted,
            font=(self.font_family, 14, "bold"),
            command=self.toggle_pin,
        )
        self.pin_button.place(relx=1, x=-43, rely=.5, anchor="e")

        self.title_label = ctk.CTkLabel(
            self.titlebar,
            text=title,
            text_color=text,
            font=(self.font_family, 13, "bold"),
        )
        self.title_label.place(relx=.5, rely=.5, anchor="center")

        for widget in (self.titlebar, self.title_label):
            widget.bind("<ButtonPress-1>", self._drag_start)
            widget.bind("<B1-Motion>", self._drag_move)
            widget.bind("<Button-1>", lambda _e: self.lift(), add="+")

        self.toolbar = ctk.CTkFrame(
            self, height=34, fg_color=surface_alt, corner_radius=0
        )
        if toolbar:
            self.toolbar.grid(row=1, column=0, sticky="ew", padx=8)
            self.toolbar.grid_propagate(False)

        # The body is inset from the outer rounded border. Children therefore
        # never touch or visually cross the rounded shell.
        self.body = ctk.CTkFrame(
            self, fg_color=surface, corner_radius=INNER_RADIUS
        )
        self.body.grid(row=2, column=0, sticky="nsew", padx=7, pady=(0, 7))
        self.body.grid_rowconfigure(0, weight=1)
        self.body.grid_columnconfigure(1, weight=1)

        self.sidebar = None
        if sidebar_width:
            self.sidebar = ctk.CTkFrame(
                self.body,
                width=sidebar_width,
                fg_color=sidebar_color,
                corner_radius=INNER_RADIUS,
            )
            self.sidebar.grid(row=0, column=0, sticky="nsew", padx=(0, 1))
            self.sidebar.grid_propagate(False)

        self.content = ctk.CTkFrame(
            self.body, fg_color=surface, corner_radius=INNER_RADIUS
        )
        self.content.grid(row=0, column=1, sticky="nsew")
        self.bind("<Button-1>", lambda _e: self.lift(), add="+")

        self.after_idle(self.animate_open)

    def _traffic_light(self, parent, color, command):
        return ctk.CTkButton(
            parent,
            text="",
            width=13,
            height=13,
            corner_radius=7,
            fg_color=color,
            hover_color=color,
            border_width=0,
            command=command,
        )

    def _cancel_animation(self):
        if self._animation_job is not None:
            try:
                self.after_cancel(self._animation_job)
            except Exception as exc:
                logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)
            self._animation_job = None

    def _animate_geometry(self, start, end, duration_ms, easing, on_done=None):
        self._cancel_animation()
        started = time.perf_counter()

        def frame():
            if not self.winfo_exists():
                return
            elapsed = (time.perf_counter() - started) * 1000.0
            progress = min(1.0, elapsed / max(1, duration_ms))
            value = easing(progress)
            x = round(start[0] + (end[0] - start[0]) * value)
            y = round(start[1] + (end[1] - start[1]) * value)
            width = max(160, round(start[2] + (end[2] - start[2]) * value))
            height = max(100, round(start[3] + (end[3] - start[3]) * value))
            self.configure(width=width, height=height)
            self.place(x=x, y=y)
            if progress >= 1.0:
                self._animation_job = None
                self._geometry = end
                if on_done:
                    on_done()
                return
            self._animation_job = self.after(FRAME_MS, frame)

        frame()

    def animate_open(self):
        if not self.winfo_exists():
            return
        x, y, width, height = self._geometry
        start_w = max(320, int(width * 0.9))
        start_h = max(220, int(height * 0.9))
        start = (x + (width - start_w) // 2, y + (height - start_h) // 2, start_w, start_h)
        self.configure(width=start_w, height=start_h)
        self.place(x=start[0], y=start[1])
        self._animate_geometry(start, (x, y, width, height), ANIMATION_MS, _ease_out_cubic)

    def _drag_start(self, event):
        if self._animation_job is not None:
            return
        self._drag_x = event.x_root - self.winfo_rootx()
        self._drag_y = event.y_root - self.winfo_rooty()

    def _drag_move(self, event):
        if self._animation_job is not None:
            return
        parent_x = self.master.winfo_rootx()
        parent_y = self.master.winfo_rooty()
        x = event.x_root - parent_x - self._drag_x
        y = event.y_root - parent_y - self._drag_y
        max_x = max(0, self.master.winfo_width() - self.winfo_width())
        max_y = max(0, self.master.winfo_height() - self.winfo_height())
        x = max(0, min(x, max_x))
        y = max(0, min(y, max_y))
        self.place(x=x, y=y)
        self._geometry = (x, y, self.winfo_width(), self.winfo_height())

    def minimize(self):
        if self._closing or self._animation_job is not None:
            return
        current = (self.winfo_x(), self.winfo_y(), self.winfo_width(), self.winfo_height())
        self._geometry = current
        target_x = max(10, self.master.winfo_width() // 2 - 100)
        target_y = max(10, self.master.winfo_height() - 20)
        target = (target_x, target_y, 200, 100)

        def done():
            self.place_forget()
            if hasattr(self.desktop, "register_minimized_app"):
                self.desktop.register_minimized_app(self)

        self._animate_geometry(current, target, 130, _ease_in_cubic, done)

    def restore(self):
        if self.winfo_manager():
            self.lift()
            return
        x, y, width, height = self._geometry or (30, 30, *self._preferred_size)
        start = (max(10, self.master.winfo_width() // 2 - 100),
                 max(10, self.master.winfo_height() - 20), 200, 100)
        self.configure(width=start[2], height=start[3])
        self.place(x=start[0], y=start[1])
        self._animate_geometry(start, (x, y, width, height), 140, _ease_out_cubic)
        self.lift()

    def toggle_pin(self):
        if hasattr(self.desktop, "toggle_pin_for_window"):
            pinned = self.desktop.toggle_pin_for_window(self)
            self.set_pin_state(bool(pinned))

    def set_pin_state(self, pinned: bool):
        self.pin_button.configure(text="◆" if pinned else "◇", text_color=accent if pinned else text_muted)

    def close(self):
        if self._closing:
            return
        self._closing = True
        self._cancel_animation()
        current = (self.winfo_x(), self.winfo_y(), self.winfo_width(), self.winfo_height())
        width = max(220, int(current[2] * 0.82))
        height = max(160, int(current[3] * 0.82))
        target = (
            current[0] + (current[2] - width) // 2,
            current[1] + (current[3] - height) // 2,
            width,
            height,
        )

        def done():
            if self._on_close:
                try:
                    self._on_close(self)
                except Exception as exc:
                    logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)
            if self.winfo_exists():
                self.destroy()

        self._animate_geometry(current, target, 115, _ease_in_cubic, done)

    def add_toolbar_button(self, text_value, command=None, width=64):
        button = ctk.CTkButton(
            self.toolbar, text=text_value, width=width, height=25, corner_radius=7,
            fg_color="transparent", hover_color=hover, text_color=text_muted,
            font=(self.font_family, 11), command=command,
        )
        button.pack(side="left", padx=(7, 0), pady=4)
        return button

    def add_sidebar_item(self, text_value, command=None, selected=False):
        if self.sidebar is None:
            raise RuntimeError("Window has no sidebar")
        button = ctk.CTkButton(
            self.sidebar, text=text_value, anchor="w", height=34, corner_radius=8,
            fg_color=accent if selected else "transparent", hover_color=sidebar_hover,
            text_color=text, font=(self.font_family, 12), command=command,
        )
        button.pack(fill="x", padx=10, pady=2)
        return button

    def heading(self, parent, title, subtitle=None):
        ctk.CTkLabel(parent, text=title, text_color=text,
                     font=(self.font_family, 22, "bold"), anchor="w").pack(
                         fill="x", padx=22, pady=(20, 3))
        if subtitle:
            ctk.CTkLabel(parent, text=subtitle, text_color=text_muted,
                         font=(self.font_family, 11), anchor="w").pack(
                             fill="x", padx=22, pady=(0, 12))

    def card(self, parent, **kwargs):
        return ctk.CTkFrame(
            parent, fg_color=kwargs.pop("fg_color", surface_alt), corner_radius=10,
            border_color=border, border_width=kwargs.pop("border_width", 0), **kwargs,
        )

    def primary_button(self, parent, text_value, command=None, **kwargs):
        return ctk.CTkButton(
            parent, text=text_value, command=command, fg_color=accent,
            hover_color=accent_hover, text_color=text, corner_radius=8,
            font=(self.font_family, 12, "bold"), **kwargs,
        )


def run_standalone(app_class):
    root = ctk.CTk()
    root.title("Nexora App Preview")
    root.geometry("1200x800")
    root.configure(fg_color=bg)
    host = ctk.CTkFrame(root, fg_color=bg)
    host.pack(fill="both", expand=True)
    root.update_idletasks()
    app_class(master=host, on_close=root.destroy)
    root.mainloop()


__all__ = [
    "NexoraWindow", "run_standalone", "ctk", "accent", "bg", "border",
    "hover", "buttons", "danger", "success", "warning", "cyan", "purple",
    "pink", "orange", "sidebar_color", "surface", "surface_alt",
    "surface_soft", "text", "text_muted"
]
