from __future__ import annotations

import argparse
import importlib.util
import logging
import os
import sys
import traceback
from pathlib import Path
from nexora.paths import DATA_DIR, ensure_runtime_paths

CURRENT_FILE = Path(__file__).resolve()
SYSTEM_ROOT = CURRENT_FILE.parents[2]
PROJECT_ROOT = SYSTEM_ROOT.parent
FUNC_SYSTEM = SYSTEM_ROOT / "func" / "system"
ensure_runtime_paths(legacy_data=SYSTEM_ROOT / "data", legacy_home=PROJECT_ROOT / "Home" / "User")
LOG_FILE = DATA_DIR / "nexora.log"

for path in (SYSTEM_ROOT, FUNC_SYSTEM):
    value = str(path)
    if value not in sys.path:
        sys.path.insert(0, value)


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def configure_logging(debug: bool = False) -> None:
    from nexora.logging_config import configure
    configure(LOG_FILE, debug=debug)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Nexora Core")
    parser.add_argument("--debug", action="store_true", help="enable diagnostics and refresh integrity manifest")
    parser.add_argument("--skip-integrity", action="store_true", help="development only")
    parser.add_argument("--skip-requirements", action="store_true", help="development only")
    parser.add_argument("--desktop", action="store_true", help="open desktop directly")
    parser.add_argument("--windowed", action="store_true", help="run in a 1280x800 window")
    parser.add_argument("--safe-mode", action="store_true", help="disable effects and session restore for recovery")
    return parser.parse_args()


class NexoraCore:
    """Application kernel responsible for boot, state routing and failure handling."""

    def __init__(self, args: argparse.Namespace):
        self.args = args
        self.log = logging.getLogger("nexora.core")
        self.app = None
        self.current_screen = None
        self._retired_screens = []
        self._prepared_desktop = None
        self._preparing_desktop = False
        self._desktop_building = False
        self._loading_screen = None
        self.error_handle = load_module("error_handle", FUNC_SYSTEM / "error_handle.py")
        self.user_handle = load_module("user_handle", FUNC_SYSTEM / "user_handle.py")

    def boot_checks(self) -> bool:
        self.log.info("Boot sequence started")
        if self.args.debug:
            os.environ["ANTICRACK_DEBUG"] = "1"
        else:
            os.environ.pop("ANTICRACK_DEBUG", None)

        if not self.args.skip_requirements:
            req = load_module("req_core", SYSTEM_ROOT / "func" / "core" / "req_core.py")
            ok, code = req.main()
            if not ok:
                self.log.error("Boot requirements failed: %s", code)
                print(f"Nexora: kontrola wymagań nie powiodła się ({code}).", file=sys.stderr)
                return False

        if not self.args.skip_integrity:
            integrity = load_module("integrity", FUNC_SYSTEM / "antycrack.py")
            if not integrity.main(core_file=__file__):
                self.log.error("Integrity check failed: 0E000010")
                print("Nexora: kontrola integralności nie powiodła się (0E000010).", file=sys.stderr)
                return False

        self.log.info("Boot checks completed")
        return True

    def create_application(self) -> None:
        if self.args.safe_mode:
            os.environ["NEXORA_SAFE_MODE"] = "1"
        else:
            os.environ.pop("NEXORA_SAFE_MODE", None)
        from PySide6.QtCore import Qt
        from PySide6.QtGui import QFont, QFontDatabase
        from PySide6.QtWidgets import QApplication

        # Load Qt WebEngine before QApplication. On macOS, importing WebEngine
        # only when the Browser opens may terminate the native Qt process with
        # no Python traceback.
        try:
            from PySide6 import QtWebEngineCore, QtWebEngineWidgets  # noqa: F401
        except ImportError:
            QtWebEngineCore = QtWebEngineWidgets = None

        # Qt WebEngine requires shared OpenGL contexts before QApplication is created.
        # Without this, macOS may terminate the process natively with no Python traceback.
        if QApplication.instance() is None:
            try:
                QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts, True)
            except (AttributeError, RuntimeError):
                pass
        try:
            QApplication.setAttribute(Qt.ApplicationAttribute.AA_DontUseNativeMenuBar, True)
        except (AttributeError, RuntimeError):
            pass
        self.app = QApplication.instance() or QApplication(sys.argv)
        from System.foundation.version import NEXORA_VERSION
        self.app.setApplicationName("Nexora")
        self.app.setApplicationVersion(NEXORA_VERSION)
        self.app.setOrganizationName("Nexora")
        self.app.setStyle("Fusion")

        families = set(QFontDatabase.families())
        family = "Gugi" if "Gugi" in families else self.app.font().family()
        self.app.setFont(QFont(family, 10))
        self.log.info("UI font: %s", family)

        def exception_hook(exc_type, exc_value, exc_tb):
            if issubclass(exc_type, KeyboardInterrupt):
                self.log.info("Shutdown requested from terminal")
                self.app.quit()
                return
            details = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
            self.log.critical("Unhandled exception\n%s", details)
            try:
                from nexora.crash_report import write_exception
                report = write_exception(exc_type, exc_value, exc_tb)
                self.log.critical("Crash report saved: %s", report)
            except (OSError, ValueError, TypeError):
                self.log.exception("Could not save crash report")
            print(f"Nexora: krytyczny błąd: {exc_value}", file=sys.stderr)
            self._fatal_ui_shutdown(1)

        sys.excepthook = exception_hook

    def _present(self, widget, *, keep_previous: bool = False) -> None:
        """Present the next state without exposing a black compositor frame."""
        previous = self.current_screen
        self.current_screen = widget
        try:
            from System.runtime.qt_ui import load_settings
            from System.foundation.i18n import set_language, localize_widget_tree
            language = load_settings().get("language", "en")
            set_language(language)
            localize_widget_tree(widget, language)
        except Exception:
            self.log.exception("Could not apply interface language")

        # Restore the stable presentation path used before the macOS
        # fullscreen regression. Never combine frameless geometry, native
        # fullscreen and manual focus changes for the same top-level window.
        # Doing so makes AppKit reconfigure the window/Space and can expose the
        # host desktop while internal Nexora windows are opened.
        if previous is not None and previous is not widget and not keep_previous:
            shutdown = getattr(previous, "shutdown", None)
            if callable(shutdown):
                try:
                    shutdown()
                except Exception:
                    self.log.exception("Screen shutdown failed")
            previous.hide()
            previous.deleteLater()
            if self.app is not None:
                self.app.processEvents()

        if self.args.windowed or os.environ.get("NEXORA_WINDOWED") == "1":
            widget.resize(1280, 800)
            widget.show()
        elif sys.platform == "darwin":
            # Do not use QWidget.showFullScreen() on macOS: AppKit turns it
            # into a separate Space, which caused the visible desktop/Mission
            # Control jump when the pointer reached the bottom taskbar.
            from PySide6.QtCore import Qt
            from PySide6.QtWidgets import QApplication
            widget.setWindowFlag(Qt.FramelessWindowHint, True)
            screen = widget.screen() or QApplication.primaryScreen()
            if screen is not None:
                widget.setGeometry(screen.geometry().adjusted(0, 0, 3, 3))
            widget.show()
            if self.app is not None:
                self.app.processEvents()
            from System.platform_support.macos_window import apply_borderless_desktop
            if not apply_borderless_desktop(widget):
                self.log.warning("Native macOS presentation unavailable; using borderless geometry")
            if screen is not None:
                from PySide6.QtCore import QTimer
                target = screen.geometry().adjusted(0, 0, 3, 3)
                QTimer.singleShot(0, lambda w=widget, rect=target: w.setGeometry(rect))
                QTimer.singleShot(150, lambda w=widget, rect=target: w.setGeometry(rect))
        else:
            widget.showFullScreen()

        if sys.platform != "darwin":
            widget.raise_()
            widget.activateWindow()
        if self.app is not None:
            self.app.processEvents()
        if keep_previous and previous is not None and previous is not widget:
            # Keep the loading surface above the newly shown desktop until the
            # desktop has completed at least two paint/event-loop heartbeats.
            previous.show()
            previous.raise_()
            if self.app is not None:
                self.app.processEvents()

    def show_oobe(self) -> None:
        from System.runtime.auth_ui import SetupScreen
        screen = SetupScreen()
        screen.completed.connect(self.show_login)
        self._present(screen)
        self.log.info("State: OOBE")

    def show_login(self) -> None:
        from PySide6.QtCore import QTimer
        from System.runtime.auth_ui import LoginScreen

        self._prepared_desktop = None
        screen = LoginScreen()
        screen.authenticated.connect(self.show_desktop)
        self._present(screen)
        # Build the QWidget tree after the login screen has painted, not after the
        # user presses the arrow. Heavy services inside Desktop are themselves
        # staged with timers and workers.
        # Desktop prewarm disabled: it blocked the Login event loop for tens of seconds on Intel macOS.
        self.log.info("State: LOGIN")

    def _prewarm_desktop(self) -> None:
        if self._prepared_desktop is not None or self._preparing_desktop:
            return
        if self.current_screen is None or self.current_screen.__class__.__name__ != "LoginScreen":
            return
        self._preparing_desktop = True
        try:
            from System.runtime.qt_ui import Desktop
            desktop = Desktop()
            desktop.lockRequested.connect(self.show_login)
            desktop.hide()
            self._prepared_desktop = desktop
            self.log.info("Desktop prewarmed")
        except Exception:
            self.log.exception("Desktop prewarm failed")
            self._prepared_desktop = None
        finally:
            self._preparing_desktop = False

    def _create_desktop_loading_screen(self):
        """Create a loading screen using the same live design tokens as Nexora."""
        from PySide6.QtCore import QTimer, Qt
        from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen, QPixmap
        from PySide6.QtWidgets import (
            QFrame, QLabel,
            QVBoxLayout, QWidget,
        )
        from System.settings import get_settings_store

        settings = get_settings_store(DATA_DIR / "settings.json").snapshot()
        dark = str(settings.get("theme_mode", "dark")).casefold() == "dark"
        accent = QColor(str(settings.get("accent_color", "#4B8DFF")))
        if not accent.isValid():
            accent = QColor("#4B8DFF")
        text = QColor("#F4F7FC" if dark else "#172033")
        muted = QColor("#B8C1D2" if dark else "#657089")
        surface = QColor("#242A36" if dark else "#F7F9FC")
        surface.setAlpha(226)  # subtle transparency, matching the shell surfaces
        border = QColor(accent)
        border.setAlpha(92)
        panel_radius = max(12, min(16, int(settings.get("panel_radius", 14))))
        wallpaper_path = str(settings.get("wallpaper", "")).strip()
        if wallpaper_path:
            candidate = Path(wallpaper_path).expanduser()
            if not candidate.is_absolute():
                candidate = PROJECT_ROOT.parent / candidate
            wallpaper = QPixmap(str(candidate))
        else:
            wallpaper = QPixmap()
        font_family = str(settings.get("font_family", "Gugi"))

        class DesktopLoadingScreen(QWidget):
            def __init__(self):
                super().__init__()
                self.setWindowTitle("Nexora — Desktop is loading")
                self.setAttribute(Qt.WA_OpaquePaintEvent, True)
                self._phase = 0
                self._base_text = "Desktop is loading"
                self._wallpaper = wallpaper

                root = QVBoxLayout(self)
                root.setContentsMargins(32, 32, 32, 32)
                root.addStretch(1)

                self.card = QFrame(self)
                self.card.setObjectName("DesktopLoadingCard")
                self.card.setFixedSize(560, 250)
                self.card.setStyleSheet(
                    f"QFrame#DesktopLoadingCard{{background:rgba({surface.red()},{surface.green()},{surface.blue()},{surface.alpha()});"
                    f"border:none;"
                    f"border-radius:{panel_radius}px;}}"
                )
                card_layout = QVBoxLayout(self.card)
                card_layout.setContentsMargins(46, 38, 46, 36)
                card_layout.setSpacing(12)

                badge = QLabel("N", self.card)
                badge.setAlignment(Qt.AlignCenter)
                badge.setFixedSize(52, 52)
                badge.setFont(QFont(font_family, 18, QFont.Weight.Bold))
                badge.setStyleSheet(
                    f"background:{accent.name()};color:white;border:none;border-radius:26px;"
                )
                card_layout.addWidget(badge, 0, Qt.AlignHCenter)

                self.title = QLabel(self._base_text, self.card)
                self.title.setAlignment(Qt.AlignCenter)
                self.title.setFont(QFont(font_family, 22, QFont.Weight.DemiBold))
                self.title.setStyleSheet(f"color:{text.name()};background:transparent;border:none;")
                card_layout.addWidget(self.title)

                self.status = QLabel("Preparing your workspace", self.card)
                self.status.setAlignment(Qt.AlignCenter)
                self.status.setFont(QFont(font_family, 11))
                self.status.setStyleSheet(f"color:{muted.name()};background:transparent;border:none;")
                card_layout.addWidget(self.status)

                class CircularProgress(QWidget):
                    def __init__(self, parent=None):
                        super().__init__(parent)
                        self._value = 8
                        self.setFixedSize(58, 58)
                    def setValue(self, value):
                        self._value = max(0, min(100, int(value))); self.update()
                    def paintEvent(self, event):
                        painter = QPainter(self); painter.setRenderHint(QPainter.Antialiasing)
                        rect = self.rect().adjusted(6, 6, -6, -6)
                        track_pen = QPen(QColor(text.red(), text.green(), text.blue(), 34), 6, Qt.SolidLine, Qt.RoundCap)
                        painter.setPen(track_pen); painter.drawArc(rect, 0, 360 * 16)
                        arc_pen = QPen(chunk, 6, Qt.SolidLine, Qt.RoundCap)
                        painter.setPen(arc_pen); painter.drawArc(rect, 90 * 16, -round(360 * 16 * self._value / 100))
                        painter.setPen(text); painter.setFont(QFont(font_family, 9, QFont.Weight.DemiBold))
                        painter.drawText(self.rect(), Qt.AlignCenter, f"{self._value}%")

                chunk = QColor(accent); chunk.setAlpha(235)
                self.progress = CircularProgress(self.card)
                card_layout.addWidget(self.progress, 0, Qt.AlignHCenter)
                root.addWidget(self.card, 0, Qt.AlignCenter)
                root.addStretch(1)

                # Lightweight loading animation: one 80 ms timer, no blur or
                # graphics effects. This remains smooth on Intel Macs.
                self.progress.setValue(8)
                self._progress_value = 8
                self._phase = 0
                self._loading_timer = QTimer(self)
                self._loading_timer.setInterval(80)
                self._loading_timer.timeout.connect(self._animate_loading)
                self._loading_timer.start()

            def _animate_loading(self):
                self._phase = (self._phase + 1) % 4
                self.title.setText(self._base_text + "." * self._phase)
                # Monotonic visual progress. Never jump back to the beginning.
                if self._progress_value < 92:
                    self._progress_value = min(92, self._progress_value + 1)
                    self.progress.setValue(self._progress_value)

            def set_status(self, value: str, progress_value=None):
                self.status.setText(str(value))
                if progress_value is not None:
                    self._progress_value = max(self._progress_value, min(100, int(progress_value)))
                    self.progress.setValue(self._progress_value)

            def complete(self):
                self._loading_timer.stop()
                self._progress_value = 100
                self.progress.setValue(100)
                self.title.setText("Desktop is ready")
                self.status.setText("Opening your workspace")

            def paintEvent(self, event):
                painter = QPainter(self)
                painter.fillRect(self.rect(), QColor("#171C27" if dark else "#EAF0F8"))
                painter.end()


        return DesktopLoadingScreen()

    def show_desktop(self) -> None:
        if self._desktop_building:
            return
        from PySide6.QtCore import QTimer

        self._desktop_building = True
        loading = self._create_desktop_loading_screen()
        self._loading_screen = loading
        self._present(loading)
        self.log.info("State: DESKTOP_LOADING")
        QTimer.singleShot(30, self._build_desktop_after_login)

    def _build_desktop_after_login(self) -> None:
        try:
            from System.runtime.qt_ui import Desktop
            if self._loading_screen is not None:
                self._loading_screen.set_status("Building desktop components", 32)
            desktop = self._prepared_desktop
            self._prepared_desktop = None
            if desktop is None:
                desktop = Desktop()
            desktop.lockRequested.connect(self.show_login)
            desktop.startupReady.connect(lambda d=desktop: self._activate_ready_desktop(d))
            desktop.startupFailed.connect(lambda message, d=desktop: self._desktop_startup_failed(d, message))
            desktop.hide()
            if getattr(desktop, "_ui_ready", False):
                # The staged startup signal remains authoritative; this only
                # updates the visible loading message after construction.
                if self._loading_screen is not None:
                    self._loading_screen.set_status("Finalizing layout and checking responsiveness", 72)
        except Exception as exc:
            self._desktop_startup_failed(None, str(exc))

    def _activate_ready_desktop(self, desktop) -> None:
        if not self._desktop_building:
            return
        from PySide6.QtCore import QTimer

        loading = self._loading_screen
        if loading is not None:
            loading.set_status("Opening the ready desktop", 90)
        # Show the complete desktop underneath the loading surface. The loading
        # screen remains the visible top-level window until Qt/AppKit has painted
        # the desktop and processed its pending layout events.
        self._present(desktop, keep_previous=True)
        if loading is not None:
            loading.raise_()
        QTimer.singleShot(80, lambda d=desktop, l=loading: self._finish_desktop_transition(d, l, 0))

    def _finish_desktop_transition(self, desktop, loading, attempt: int) -> None:
        from PySide6.QtCore import QTimer
        try:
            if self.app is not None:
                self.app.processEvents()
            ready = bool(getattr(desktop, "_ui_ready", False)) and desktop.isVisible() and desktop.isEnabled()
            if not ready:
                if attempt < 40:
                    if loading is not None:
                        loading.set_status("Waiting for the desktop to become responsive")
                        loading.raise_()
                    QTimer.singleShot(75, lambda d=desktop, l=loading, a=attempt + 1: self._finish_desktop_transition(d, l, a))
                    return
                raise RuntimeError("Desktop was built but did not become visible and responsive")

            # A second heartbeat prevents the loading surface disappearing in
            # the same frame in which the desktop first becomes visible.
            if attempt == 0:
                if loading is not None:
                    loading.raise_()
                QTimer.singleShot(90, lambda d=desktop, l=loading: self._finish_desktop_transition(d, l, 1))
                return

            self._desktop_building = False
            self.current_screen = desktop
            if loading is not None:
                loading.complete()
                loading.raise_()
                # Keep 100% visible briefly; otherwise users only see a partial bar.
                QTimer.singleShot(180, lambda l=loading: (l.hide(), l.deleteLater()))
            self._loading_screen = None
            desktop.raise_()
            desktop.activateWindow()
            if self.app is not None:
                self.app.processEvents()
            if hasattr(desktop, "start_background_services"):
                desktop.start_background_services()
            if hasattr(desktop, "sound_service"):
                desktop.sound_service.play("login")
            self.log.info("State: DESKTOP")
        except Exception as exc:
            self._desktop_startup_failed(desktop, str(exc))

    def _fatal_ui_shutdown(self, exit_code: int = 1) -> None:
        """Close every Nexora surface and terminate the Qt event loop.

        Startup failures must never leave a fullscreen login/loading/error
        surface trapping the user. Logs and crash reports remain available.
        """
        if self.app is None:
            return
        try:
            for widget in list(self.app.topLevelWidgets()):
                try:
                    widget.hide()
                    widget.close()
                    widget.deleteLater()
                except (RuntimeError, AttributeError):
                    self.log.debug("Could not close a retired startup widget", exc_info=True)
            self.app.processEvents()
        finally:
            self.app.exit(int(exit_code))

    def _desktop_startup_failed(self, desktop, message: str) -> None:
        self._desktop_building = False
        self.log.error("Desktop startup failed: %s", message)
        # Do not open another fullscreen error UI over a broken startup UI.
        # The complete reason is already persisted in nexora.log.
        print(f"Nexora: nie udało się uruchomić pulpitu: {message}", file=sys.stderr)
        self._fatal_ui_shutdown(1)

    def run(self) -> int:
        if not self.boot_checks():
            return 1
        self.create_application()
        if self.args.desktop:
            self.show_desktop()
        elif not self.user_handle.oobe_completed():
            self.show_oobe()
        else:
            self.show_login()
        return int(self.app.exec())


def main() -> int:
    args = parse_args()
    configure_logging(args.debug)
    try:
        return NexoraCore(args).run()
    except Exception as exc:
        logging.getLogger("nexora.core").exception("Fatal core error")
        print(f"Nexora: krytyczny błąd uruchamiania: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
