import logging
import platform
import subprocess
import re
import shlex


def run_cmd(cmd, timeout=4.0):
    """Run a fixed diagnostic command without a shell or user interpolation."""
    args = shlex.split(cmd) if isinstance(cmd, str) else list(cmd)
    try:
        return subprocess.check_output(
            args,
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
        ).strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def to_gb(value):
    try:
        return round(int(value) / 1024**3, 2)
    except Exception:
        return "?"


def clean(text):
    if text is None:
        return ""
    return str(text).strip()


def print_item(category, name):
    name = clean(name)
    if name:
        print(f"{category}: {name}")


def mac_value(data, key):
    pattern = rf"{re.escape(key)}:\s*(.+)"
    match = re.search(pattern, data)
    return match.group(1).strip() if match else ""


def windows_devices():
    try:
        import wmi
    except ImportError:
        print("Brak modułu WMI. Zainstaluj: pip install wmi")
        return

    c = wmi.WMI()

    for cpu in c.Win32_Processor():
        print_item("CPU", cpu.Name)

    for gpu in c.Win32_VideoController():
        print_item("GPU", gpu.Name)

    for ram in c.Win32_PhysicalMemory():
        manufacturer = clean(ram.Manufacturer) or "Unknown"
        part = clean(ram.PartNumber)
        size = to_gb(ram.Capacity)
        speed = clean(ram.Speed or ram.ConfiguredClockSpeed)

        name = f"{manufacturer}"
        if part:
            name += f" {part}"
        name += f" {size} GB"
        if speed:
            name += f" {speed} MHz"

        print_item("RAM", name)

    for pc in c.Win32_ComputerSystem():
        if pc.TotalPhysicalMemory:
            print_item("RAM_TOTAL", f"{to_gb(pc.TotalPhysicalMemory)} GB")

    for disk in c.Win32_DiskDrive():
        model = clean(disk.Model) or "Unknown Disk"
        size = to_gb(disk.Size)
        print_item("DISK", f"{model} {size} GB")

    for board in c.Win32_BaseBoard():
        manufacturer = clean(board.Manufacturer)
        product = clean(board.Product)
        version = clean(board.Version)
        print_item("MOTHERBOARD", " ".join(x for x in [manufacturer, product, version] if x))

    for monitor in c.Win32_DesktopMonitor():
        name = clean(monitor.Name or monitor.Caption)
        if name:
            print_item("MONITOR", f"{name} (wbudowany lub zewnętrzny)")

    try:
        monitor_wmi = wmi.WMI(namespace="root\\wmi")

        for m in monitor_wmi.WmiMonitorID():
            manufacturer = "".join(chr(x) for x in m.ManufacturerName if x != 0)
            model = "".join(chr(x) for x in m.UserFriendlyName if x != 0)
            serial = "".join(chr(x) for x in m.SerialNumberID if x != 0)

            if model:
                name = f"{manufacturer} {model}".strip()
                if serial:
                    name += f" SN:{serial}"
                print_item("MONITOR", name)

    except Exception as exc:
        logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

    for keyboard in c.Win32_Keyboard():
        print_item("KEYBOARD", keyboard.Name)

    for pointer in c.Win32_PointingDevice():
        name = clean(pointer.Name)
        low = name.lower()

        if any(x in low for x in ["touchpad", "trackpad", "synaptics", "elan", "precision"]):
            print_item("TOUCHPAD", name)
        else:
            print_item("MOUSE", name)

    for pnp in c.Win32_PnPEntity():
        name = clean(pnp.Name)
        low = name.lower()

        if not name:
            continue

        if any(x in low for x in ["touchpad", "trackpad", "synaptics", "elan", "precision"]):
            print_item("TOUCHPAD", name)
        elif "keyboard" in low:
            print_item("KEYBOARD", name)
        elif "mouse" in low:
            print_item("MOUSE", name)
        elif "camera" in low or "webcam" in low:
            print_item("CAMERA", name)
        elif "bluetooth" in low:
            print_item("BLUETOOTH", name)


def linux_devices():
    cpuinfo = run_cmd("cat /proc/cpuinfo")
    cpus = sorted(set(re.findall(r"model name\s*:\s*(.+)", cpuinfo)))
    for cpu in cpus:
        print_item("CPU", cpu)

    for line in run_cmd("lspci").splitlines():
        low = line.lower()
        if any(x in low for x in ["vga", "3d controller", "display controller", "graphics"]):
            print_item("GPU", line)

    meminfo = run_cmd("cat /proc/meminfo")
    match = re.search(r"MemTotal:\s+(\d+)\s+kB", meminfo)
    if match:
        gb = round(int(match.group(1)) / 1024 / 1024, 2)
        print_item("RAM_TOTAL", f"{gb} GB")

    dmidecode = run_cmd("sudo dmidecode -t memory")
    for block in dmidecode.split("\n\n"):
        if "Memory Device" not in block:
            continue

        size = re.search(r"Size:\s*(.+)", block)
        manufacturer = re.search(r"Manufacturer:\s*(.+)", block)
        part = re.search(r"Part Number:\s*(.+)", block)
        speed = re.search(r"Speed:\s*(.+)", block)

        if size and "No Module Installed" not in size.group(1):
            name = "RAM"

            if manufacturer:
                name += f" {manufacturer.group(1).strip()}"

            if part:
                name += f" {part.group(1).strip()}"

            name += f" {size.group(1).strip()}"

            if speed:
                name += f" {speed.group(1).strip()}"

            print_item("RAM", name)

    for line in run_cmd("lsblk -d -o MODEL,SIZE,TYPE").splitlines()[1:]:
        if line.strip():
            print_item("DISK", line)

    vendor = run_cmd("cat /sys/class/dmi/id/board_vendor")
    board = run_cmd("cat /sys/class/dmi/id/board_name")
    if vendor or board:
        print_item("MOTHERBOARD", f"{vendor} {board}".strip())

    xrandr = run_cmd("xrandr --query")
    for line in xrandr.splitlines():
        if " connected" in line:
            output = line.split()[0]

            if output.lower().startswith(("edp", "lvds")):
                print_item("MONITOR", f"{output} wbudowany")
            else:
                print_item("MONITOR", f"{output} zewnętrzny")

    input_data = run_cmd("cat /proc/bus/input/devices")
    for name in re.findall(r'N:\s+Name="(.+?)"', input_data):
        low = name.lower()

        if any(x in low for x in ["touchpad", "trackpad", "synaptics", "elan"]):
            print_item("TOUCHPAD", name)
        elif "keyboard" in low:
            print_item("KEYBOARD", name)
        elif "mouse" in low:
            print_item("MOUSE", name)


def macos_devices():
    hardware = run_cmd("system_profiler SPHardwareDataType")
    graphics = run_cmd("system_profiler SPDisplaysDataType")
    memory = run_cmd("system_profiler SPMemoryDataType")
    storage = run_cmd("system_profiler SPStorageDataType")
    nvme = run_cmd("system_profiler SPNVMeDataType")
    sata = run_cmd("system_profiler SPSerialATADataType")
    usb = run_cmd("system_profiler SPUSBDataType")
    bluetooth = run_cmd("system_profiler SPBluetoothDataType")
    audio = run_cmd("system_profiler SPAudioDataType")
    camera = run_cmd("system_profiler SPCameraDataType")
    power = run_cmd("system_profiler SPPowerDataType")

    # CPU / Apple Silicon
    chip = mac_value(hardware, "Chip")
    processor = mac_value(hardware, "Processor Name")
    speed = mac_value(hardware, "Processor Speed")
    cores = mac_value(hardware, "Total Number of Cores")

    if chip:
        print_item("CPU", chip)
    elif processor:
        name = processor
        if speed:
            name += f" {speed}"
        if cores:
            name += f" {cores} cores"
        print_item("CPU", name)

    # Model Maca jako motherboard/system
    model_name = mac_value(hardware, "Model Name")
    model_id = mac_value(hardware, "Model Identifier")
    if model_name or model_id:
        print_item("MOTHERBOARD", f"{model_name} {model_id}".strip())

    # RAM total
    ram_total = mac_value(hardware, "Memory")
    if ram_total:
        print_item("RAM_TOTAL", ram_total)

    # RAM modules — głównie Intel Mac
    for block in memory.split("\n\n"):
        if "BANK" in block or "DIMM" in block:
            size = mac_value(block, "Size")
            ram_type = mac_value(block, "Type")
            speed = mac_value(block, "Speed")
            manufacturer = mac_value(block, "Manufacturer")
            part = mac_value(block, "Part Number")

            parts = [manufacturer, part, size, ram_type, speed]
            name = " ".join(x for x in parts if x and x != "Empty")

            if name:
                print_item("RAM", name)

    # GPU
    for line in graphics.splitlines():
        line = line.strip()

        if line.startswith("Chipset Model:"):
            print_item("GPU", line.replace("Chipset Model:", "").strip())

    # Monitor
    current_display = None

    for line in graphics.splitlines():
        raw = line
        line = line.strip()

        if not line:
            continue

        if raw.startswith("    ") and line.endswith(":") and not line.startswith(("Resolution:", "Main Display:", "Mirror:", "Online:", "Rotation:")):
            current_display = line.replace(":", "").strip()

        if line.startswith("Display Type:"):
            display_type = line.replace("Display Type:", "").strip()

            if current_display:
                if "built-in" in display_type.lower() or "retina" in current_display.lower():
                    print_item("MONITOR", f"{current_display} wbudowany")
                else:
                    print_item("MONITOR", f"{current_display} zewnętrzny")

        elif line.startswith("Resolution:") and current_display:
            resolution = line.replace("Resolution:", "").strip()
            print_item("MONITOR", f"{current_display} {resolution}")

    # Dyski: NVMe
    current_disk = None
    for line in nvme.splitlines():
        raw = line
        line = line.strip()

        if not line:
            continue

        if raw.startswith("    ") and line.endswith(":") and not line.startswith(("Capacity:", "Model:", "Serial Number:")):
            current_disk = line.replace(":", "").strip()

        if line.startswith("Model:"):
            current_disk = line.replace("Model:", "").strip()

        if line.startswith("Capacity:") and current_disk:
            capacity = line.replace("Capacity:", "").strip()
            print_item("DISK", f"{current_disk} {capacity}")

    # Dyski: Storage
    for block in storage.split("\n\n"):
        name = ""
        capacity = ""

        for line in block.splitlines():
            line = line.strip()

            if line.startswith("Volume Name:"):
                name = line.replace("Volume Name:", "").strip()

            elif line.startswith("Physical Drive:"):
                name = "Physical Drive"

            elif line.startswith("Device Name:"):
                name = line.replace("Device Name:", "").strip()

            elif line.startswith("Medium Type:"):
                medium = line.replace("Medium Type:", "").strip()
                if name:
                    name += f" {medium}"

            elif line.startswith("Capacity:"):
                capacity = line.replace("Capacity:", "").strip()

        if name and capacity:
            print_item("DISK", f"{name} {capacity}")

    # Dyski: SATA, starsze Maci
    for line in sata.splitlines():
        line = line.strip()

        if line.startswith("Model:"):
            print_item("DISK", line.replace("Model:", "").strip())

    # Klawiatura / touchpad / mysz / USB
    for line in usb.splitlines():
        line = line.strip()

        if not line or line.endswith(":") is False:
            continue

        name = line.replace(":", "").strip()
        low = name.lower()

        if "keyboard" in low:
            print_item("KEYBOARD", name)
        elif "trackpad" in low or "touchpad" in low:
            print_item("TOUCHPAD", name)
        elif "mouse" in low:
            print_item("MOUSE", name)
        elif "camera" in low:
            print_item("CAMERA", name)
        elif name and name not in ["USB", "USB 3.1 Bus", "USB 3.0 Bus", "USB 2.0 Bus"]:
            print_item("USB", name)

    # Bluetooth
    for line in bluetooth.splitlines():
        line = line.strip()
        if "Bluetooth Controller:" in line:
            print_item("BLUETOOTH", "Bluetooth Controller")

    # Audio
    for line in audio.splitlines():
        line = line.strip()
        if line.endswith(":") and "Audio" not in line:
            print_item("AUDIO", line.replace(":", "").strip())

    # Kamera
    for line in camera.splitlines():
        line = line.strip()
        if line.endswith(":") and "Camera" not in line:
            print_item("CAMERA", line.replace(":", "").strip())

    # Bateria
    if "Battery Information:" in power:
        print_item("BATTERY", "Internal Battery")


def main():
    system = platform.system().lower()

    if system == "windows":
        windows_devices()
    elif system == "linux":
        linux_devices()
    elif system == "darwin":
        macos_devices()
    else:
        print("Obsługiwany jest Windows, Linux i macOS.")


if __name__ == "__main__":
    main()
