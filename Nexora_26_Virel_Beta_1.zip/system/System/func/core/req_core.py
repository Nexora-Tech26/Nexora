from pathlib import Path
import platform, shutil
try:
    import psutil
except ImportError:
    psutil = None
ERROR_LOW_RAM="0E000001"; ERROR_LOW_DISK="0E000002"; ERROR_BAD_SYSTEM="0E000003"; ERROR_OK="0x000006"
def main() -> tuple[bool,str]:
    system=platform.system()
    if system not in {"Windows","Darwin","Linux"}:
        return False, ERROR_BAD_SYSTEM
    if psutil is not None and psutil.virtual_memory().available < 256*1024*1024:
        return False, ERROR_LOW_RAM
    project=Path(__file__).resolve()
    if shutil.disk_usage(project.anchor or project.parent).free < 256*1024*1024:
        return False, ERROR_LOW_DISK
    print(f"Nexora requirements: OK ({system} {platform.machine()})")
    return True, ERROR_OK
if __name__ == "__main__": print(main())
