import logging
import subprocess
import sys
import time
from pathlib import Path

from customtkinter import CTkButton, CTkEntry, CTkFrame, CTkLabel, CTkScrollableFrame

from apps_cache import AppsCache, filter_cached_apps, is_app_cache_ready, preload_apps_background
from icon_utils import load_icon, prepare_app_entry
from theme import bg, border, text

START_X = 10
START_OPEN_Y = 440
START_CLOSED_Y = 990


def _ease_out(t):
    if t >= 1:
        return 1
    return 1 - pow(1 - t, 4)


class StartMenu:
    def __init__(
        self,
        ui,
        start_btn,
        animations_handle=None,
        animations_enabled=True,
        font_name="gugi",
        apps_cache=None,
        app_launcher=None,
        pin_handler=None,
        pin_checker=None,
    ):
        self.ui = ui
        self.start_btn = start_btn
        self.animations_handle = animations_handle
        self.animations_enabled = animations_enabled
        self.font_name = font_name
        self.apps_cache = apps_cache or AppsCache(ui=ui, prepare_entry=prepare_app_entry)
        self.app_launcher = app_launcher
        self.pin_handler = pin_handler
        self.pin_checker = pin_checker
        self.start_x = START_X
        self.start_open_y = START_OPEN_Y
        self.start_closed_y = START_CLOSED_Y

        self.frame = None
        self.apps_scroll = None
        self.search_entry = None
        self.render_job = None
        self.search_job = None
        self.is_animating = False

    def set_geometry(self, open_y: int, closed_y: int, x: int = 10):
        self.start_open_y = int(open_y)
        self.start_closed_y = int(closed_y)
        self.start_x = int(x)

    def set_start_animating(self, value):
        self.is_animating = value

    def cancel_jobs(self):
        for job in (self.render_job, self.search_job):
            if job is not None:
                try:
                    self.ui.after_cancel(job)
                except Exception as exc:
                    logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)
        self.render_job = None
        self.search_job = None

    def show_loading(self):
        if self.apps_scroll is None:
            return
        try:
            for widget in self.apps_scroll.winfo_children():
                widget.destroy()
            CTkLabel(
                self.apps_scroll,
                text="Loading apps...",
                font=(self.font_name, 14, "bold"),
                text_color=text,
                fg_color=bg,
                bg_color=bg,
            ).pack(pady=10)
        except Exception as exc:
            logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

    def show_no_apps(self):
        if self.apps_scroll is None:
            return
        CTkLabel(
            self.apps_scroll,
            text="No apps found",
            font=(self.font_name, 14, "bold"),
            text_color=text,
            fg_color=bg,
            bg_color=bg,
        ).pack(pady=10)

    def create_app_button(self, entry):
        if self.apps_scroll is None:
            return

        icon_image = entry.get("icon_image")
        if entry.get("icon_path") and icon_image is None:
            icon_image = load_icon(entry["icon_path"])
            entry["icon_image"] = icon_image

        app_file = entry.get("file")
        pinned = bool(self.pin_checker(app_file)) if self.pin_checker and app_file else False
        label = f"◆  {entry.get('name', 'App')}" if pinned else entry.get("name", "App")
        button = CTkButton(
            self.apps_scroll,
            text=label,
            image=icon_image,
            compound="left",
            anchor="w",
            font=(self.font_name, 14, "bold"),
            fg_color=entry.get("button_color", "#2F3034"),
            hover_color=entry.get("button_hover", "#3A3B40"),
            border_color=entry.get("button_border", "#4A4B50"),
            border_width=1,
            text_color=entry.get("button_text", "#F4F4F5"),
            corner_radius=12,
            height=42,
            command=lambda app_file=app_file: self.launch_app(app_file),
        )
        if self.pin_handler is not None and app_file:
            button.bind("<Button-3>", lambda _e, path=app_file: self.toggle_pin(path))
            button.bind("<Button-2>", lambda _e, path=app_file: self.toggle_pin(path))
        button.icon_image = icon_image
        button.pack(fill="x", padx=8, pady=4)


    def toggle_pin(self, app_file):
        if self.pin_handler is None or not app_file:
            return
        try:
            self.pin_handler(Path(app_file).resolve())
            self.refresh_apps()
        except Exception as exc:
            print(f"Error: could not pin app: {exc}")

    def render_cached_apps(self, apps):
        if self.apps_scroll is None:
            return

        if self.is_animating:
            self.render_job = self.ui.after(60, lambda: self.render_cached_apps(apps))
            return

        if self.render_job is not None:
            try:
                self.ui.after_cancel(self.render_job)
            except Exception as exc:
                logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)
        self.render_job = None

        try:
            for widget in self.apps_scroll.winfo_children():
                widget.destroy()
        except Exception:
            return

        if not apps:
            self.show_no_apps()
            return

        batch_size = 8 if self.animations_enabled else 16
        index = 0

        def render_batch():
            nonlocal index
            if self.apps_scroll is None:
                self.render_job = None
                return
            if self.is_animating:
                self.render_job = self.ui.after(60, render_batch)
                return
            try:
                if not self.apps_scroll.winfo_exists():
                    self.render_job = None
                    return
            except Exception:
                self.render_job = None
                return

            end_index = min(index + batch_size, len(apps))
            for entry in apps[index:end_index]:
                self.create_app_button(entry)
            index = end_index

            if index >= len(apps):
                self.render_job = None
                return
            self.render_job = self.ui.after(8, render_batch)

        render_batch()

    def refresh_apps(self):
        if self.is_animating:
            self.schedule_search()
            return

        if not is_app_cache_ready():
            self.show_loading()
            preload_apps_background(
                ui=self.ui,
                on_finish=self.refresh_apps,
                prepare_entry=prepare_app_entry,
            )
            return

        query = ""
        if self.search_entry is not None:
            try:
                query = self.search_entry.get()
            except Exception:
                query = ""
        self.render_cached_apps(filter_cached_apps(query))

    def schedule_search(self, event=None):
        if self.search_job is not None:
            try:
                self.ui.after_cancel(self.search_job)
            except Exception as exc:
                logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)
        self.search_job = self.ui.after(120, self.refresh_apps)

    def run_animation(self, widget, from_y, to_y, on_done=None):
        if self.animations_handle is not None and hasattr(self.animations_handle, "animate_start_y"):
            self.animations_handle.animate_start_y(
                ui=self.ui,
                widget=widget,
                x=self.start_x,
                from_y=from_y,
                to_y=to_y,
                start_button=self.start_btn,
                animations_enabled=self.animations_enabled,
                on_state_change=self.set_start_animating,
                on_done=on_done,
            )
            return

        self.set_start_animating(True)
        if not self.animations_enabled:
            widget.place(x=self.start_x, y=to_y)
            self.set_start_animating(False)
            if on_done is not None:
                on_done()
            return

        start_time = time.perf_counter()
        duration = 0.16

        def frame():
            try:
                if not widget.winfo_exists():
                    self.set_start_animating(False)
                    return
            except Exception:
                self.set_start_animating(False)
                return
            progress = min(1, (time.perf_counter() - start_time) / duration)
            eased = _ease_out(progress)
            y = int(from_y + (to_y - from_y) * eased)
            widget.place(x=self.start_x, y=y)
            if progress >= 1:
                self.set_start_animating(False)
                if on_done is not None:
                    on_done()
                return
            self.ui.after(16, frame)

        frame()

    def launch_app(self, app_file):
        if self.is_animating or not app_file:
            return
        app_path = Path(app_file).resolve()
        if not app_path.exists():
            print(f"Error: app file not found: {app_path}")
            return
        try:
            if self.app_launcher is not None:
                self.app_launcher(app_path)
            else:
                subprocess.Popen([sys.executable, str(app_path)], cwd=str(app_path.parent))
            self.close()
        except Exception as e:
            print(f"Error: could not launch app: {e}")

    def close(self):
        self.cancel_jobs()
        if self.frame is None:
            self.apps_scroll = None
            self.search_entry = None
            self.start_btn.configure(command=self.toggle)
            return
        try:
            if not self.frame.winfo_exists():
                self.frame = None
                self.apps_scroll = None
                self.search_entry = None
                self.start_btn.configure(command=self.toggle)
                return
        except Exception:
            return

        frame_to_close = self.frame
        try:
            current_y = frame_to_close.winfo_y()
        except Exception:
            current_y = self.start_open_y

        def finish_close():
            try:
                if frame_to_close.winfo_exists():
                    frame_to_close.destroy()
            except Exception as exc:
                logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)
            if self.frame is frame_to_close:
                self.frame = None
            self.apps_scroll = None
            self.search_entry = None
            self.start_btn.configure(command=self.toggle)

        self.run_animation(frame_to_close, current_y, self.start_closed_y, finish_close)

    def toggle(self, event=None):
        if self.is_animating:
            return "break"
        try:
            if self.frame is not None and self.frame.winfo_exists():
                self.close()
            else:
                self.open()
        except Exception:
            self.open()
        return "break"

    def open(self):
        if self.frame is not None:
            try:
                if self.frame.winfo_exists():
                    self.close()
                    return
            except Exception as exc:
                logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

        self.frame = CTkFrame(
            self.ui,
            width=450,
            height=540,
            fg_color=bg,
            bg_color=bg,
            border_color=border,
            border_width=1,
            corner_radius=15,
        )
        self.frame.place(x=self.start_x, y=self.start_closed_y)

        CTkLabel(
            self.frame,
            text="Nexora",
            width=220,
            height=50,
            font=(self.font_name, 30, "bold"),
            fg_color=bg,
            bg_color=bg,
            text_color=text,
        ).place(x=20, y=20)

        self.apps_scroll = CTkScrollableFrame(
            self.frame,
            width=180,
            height=350,
            fg_color=bg,
            bg_color=bg,
            border_color=border,
            border_width=1,
            corner_radius=15,
        )
        self.apps_scroll.place(x=20, y=80)

        self.search_entry = CTkEntry(
            self.frame,
            width=180,
            height=40,
            fg_color=bg,
            bg_color=bg,
            border_color=border,
            border_width=1,
            corner_radius=12,
            text_color=text,
            placeholder_text="Search",
            placeholder_text_color=text,
            font=(self.font_name, 20, "bold"),
        )
        self.search_entry.place(x=20, y=480)
        self.search_entry.bind("<KeyRelease>", self.schedule_search)

        self.show_loading()
        self.start_btn.configure(command=self.toggle)
        self.run_animation(self.frame, self.start_closed_y, self.start_open_y, self.refresh_apps)


StartMenuController = StartMenu
