def rgb_to_hex(rgb):
    r, g, b = rgb
    return f"#{r:02x}{g:02x}{b:02x}"


def hex_to_rgb(hex_color):
    hex_color = hex_color.replace("#", "")
    return int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)


def lighten_rgb(rgb, amount=0.45):
    r, g, b = rgb
    return (
        int(r + (255 - r) * amount),
        int(g + (255 - g) * amount),
        int(b + (255 - b) * amount),
    )


def warm_mix_rgb(rgb, amount=0.12):
    r, g, b = rgb
    return (
        int(r + (255 - r) * amount),
        int(g + (155 - g) * amount),
        int(b + (56 - b) * amount),
    )


def darken_hex(hex_color, amount=0.18):
    r, g, b = hex_to_rgb(hex_color)
    return rgb_to_hex((int(r * (1 - amount)), int(g * (1 - amount)), int(b * (1 - amount))))


def get_text_color(hex_color):
    r, g, b = hex_to_rgb(hex_color)
    brightness = (r * 299 + g * 587 + b * 114) / 1000
    return "#17110d" if brightness > 150 else "#fff4e8"
