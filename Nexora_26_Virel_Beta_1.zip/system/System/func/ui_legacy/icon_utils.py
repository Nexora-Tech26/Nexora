from functools import lru_cache
from pathlib import Path

from customtkinter import CTkImage
from PIL import Image, ImageFilter

from theme import APP_BUTTON_COLORS, APP_CUSTOM_COLORS, ICON_EXTENSIONS, ICON_RENDER_SOURCE_SIZE, ICON_SIZE, buttons
from color_utils import darken_hex, get_text_color, lighten_rgb, rgb_to_hex, warm_mix_rgb


def normalize_icon_name(app_name):
    return "".join(app_name.lower().split())


def get_app_button_color(app_name, index):
    key = normalize_icon_name(app_name)
    custom_color = APP_CUSTOM_COLORS.get(key, "")
    return custom_color or APP_BUTTON_COLORS[index % len(APP_BUTTON_COLORS)]


def get_icons_folder(app_file):
    app_path = Path(app_file)
    if app_path.parent.name.lower() == "apps":
        # np. System/sys/resources/apps/app.py -> System/sys/resources/Icons
        parent_icons = app_path.parent.parent / "Icons"
        if parent_icons.exists():
            return parent_icons
        lower_icons = app_path.parent.parent / "icons"
        if lower_icons.exists():
            return lower_icons
    system_root = None
    for parent in app_path.resolve().parents:
        if parent.name == "System":
            system_root = parent
            break
    if system_root is not None:
        for folder in (
            system_root / "sys" / "resources" / "Icons",
            system_root / "sys" / "resources" / "icons",
            system_root / "Icons",
            system_root / "icons",
            system_root / "func" / "UI" / "Icons",
        ):
            if folder.exists():
                return folder
    return app_path.parent.parent / "Icons"


def get_icon_path(app_file, app_name):
    icons_folder = get_icons_folder(app_file)
    icon_name = normalize_icon_name(app_name)
    for ext in ICON_EXTENSIONS:
        path = icons_folder / f"{icon_name}{ext}"
        if path.exists():
            return path
    return None


@lru_cache(maxsize=256)
def load_icon(icon_path):
    if not icon_path:
        return None
    try:
        image = Image.open(icon_path).convert("RGBA")
        image = image.resize((ICON_RENDER_SOURCE_SIZE, ICON_RENDER_SOURCE_SIZE), Image.Resampling.LANCZOS)
        image = image.filter(ImageFilter.UnsharpMask(radius=1.2, percent=140, threshold=3))
        return CTkImage(light_image=image, dark_image=image, size=(ICON_SIZE, ICON_SIZE))
    except Exception:
        return None


def prepare_app_entry(entry):
    app_name = entry["name"]
    index = entry.get("index", 0)
    icon_path = get_icon_path(entry["file"], app_name)
    button_color = get_app_button_color(app_name, index)
    entry.update({
        "icon_path": str(icon_path) if icon_path else None,
        "icon_image": None,
        "button_color": button_color,
        "button_hover": darken_hex(button_color, 0.12),
        "button_border": darken_hex(button_color, 0.28),
        "button_text": get_text_color(button_color),
    })
    return entry
