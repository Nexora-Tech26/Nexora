import logging
# Original Nexora desktop palette. Keep this file as the single source of truth.
bg = "#1B1B1F"
bg2 = "#242428"
text = "#F4F4F5"
text_muted = "#A7A8B0"
buttons = "#2F3034"
hover = "#3A3B40"
border = "#4A4B50"
notifications = "#3A3A3E"
apps = "#25262A"
quick_settings = "#2B2C30"
accent = "#3F8CFF"
accent_hover = "#5A9DFF"
accent2 = "#78B7FF"
surface = bg2
surface_alt = apps
surface_soft = buttons
sidebar = "#2B2C30"
sidebar_hover = hover
success = "#2ECC71"
warning = "#F1C40F"
danger = "#FF6B6B"
cyan = "#00B8D9"
purple = "#7C5CFF"
pink = "#E84393"
orange = "#FF9F43"

WINDOW_RADIUS = 22
PANEL_RADIUS = 16
CONTROL_RADIUS = 12


def get_font_family(widget=None) -> str:
    try:
        import tkinter.font as tkfont
        families = set(tkfont.families(widget))
        if "Gugi" in families:
            return "Gugi"
    except Exception as exc:
        logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)
    return "Arial"

ICON_SIZE = 24
ICON_RENDER_SOURCE_SIZE = 128
APP_BUTTON_COLORS = [
    "#3F8CFF", "#7C5CFF", "#FF6B6B", "#FF9F43", "#2ECC71",
    "#00B8D9", "#E84393", "#F1C40F", "#16A085", "#8E44AD",
]
APP_CUSTOM_COLORS = {
    "aboutpc": "#6C7CF8", "backup": "#64B5F6", "calculator": "#4CAF50",
    "calendar": "#FF6B6B", "clock": "#5C6BC0", "files": "#FFB74D",
    "gallery": "#BA68C8", "maps": "#4DB6AC", "notepad": "#FFD54F",
    "paint": "#F06292", "screenshots": "#B0BEC5", "settings": "#90A4AE",
    "store": "#42A5F5", "taskmanager": "#FF7043", "terminal": "#78909C",
    "weather": "#4FC3F7", "welcome": "#00B8D4", "widgets": "#5E97F6",
}
ICON_EXTENSIONS = (".png", ".jpg", ".jpeg", ".webp", ".ico")
COMMAND_KEYS = (
    "Meta_L", "Meta_R", "Command", "Command_L", "Command_R",
    "Super_L", "Super_R", "Win_L", "Win_R",
)
