import logging
import os
import platform
import subprocess
import shutil
import re
import time
import threading
from datetime import datetime
from pathlib import Path

from customtkinter import CTkFrame, CTkLabel

try:
    import psutil
except Exception:
    psutil = None


NOTCH_WIDTH_CLOSED = 150
NOTCH_HEIGHT_CLOSED = 60

NOTCH_WIDTH_OPEN = 460
NOTCH_HEIGHT_OPEN = 190

NOTCH_Y = -25

# Stabilniejsze niż 120 FPS w Tkinterze.
# Czasowa animacja = mniej lagów pod obciążeniem.
NOTCH_ANIMATION_FPS = 60
NOTCH_ANIMATION_DURATION_MS = 150
NOTCH_ANIMATION_DELAY_MS = max(1, round(1000 / NOTCH_ANIMATION_FPS))

# Lekki pulse, bez ciężkiego 120 FPS.
PULSE_FLASH_MS = 90

CARD_WIDTH = 210
CARD_HEIGHT = 46
CARD_GAP_X = 12
CARD_GAP_Y = 8

CONTENT_X = 14
CONTENT_Y = 64

CPU_COLOR = "#8fb8c8"
GPU_COLOR = "#a998bd"
RAM_COLOR = "#99b89b"
DISK_COLOR = "#c6a86a"

DATE_COLOR = "#ff9b38"
TITLE_COLOR = "#f1e8df"
DARK_TEXT = "#111827"

POWERMETRICS_CACHE = {
    "time": 0,
    "text": "",
}

GPU_NAME_CACHE = {
    "time": 0,
    "value": "GPU",
}

SLOW_METRICS_CACHE = {
    "running": False,
    "last_update": 0,
    "cpu_temp": "--",
    "gpu": "GPU --",
}


def run_command(command, timeout=1.5):
    try:
        return subprocess.check_output(
            command,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout
        ).strip()
    except Exception:
        return ""


def run_powershell(script, timeout=1.5):
    return run_command(["powershell", "-NoProfile", "-Command", script], timeout=timeout)


def apple_ease_out(t):
    if t >= 1:
        return 1

    return 1 - pow(1 - t, 4)


def format_temperature(value):
    try:
        return f"{float(value):.0f}°C"
    except Exception:
        return "--"


def get_powermetrics_text():
    now = time.time()

    if now - POWERMETRICS_CACHE["time"] < 8:
        return POWERMETRICS_CACHE["text"]

    if platform.system().lower() != "darwin":
        return ""

    output = run_command(
        [
            "powermetrics",
            "--samplers",
            "smc,gpu_power",
            "-n",
            "1",
            "-i",
            "1000"
        ],
        timeout=2.8
    )

    if not output:
        output = run_command(
            [
                "sudo",
                "-n",
                "powermetrics",
                "--samplers",
                "smc,gpu_power",
                "-n",
                "1",
                "-i",
                "1000"
            ],
            timeout=2.8
        )

    POWERMETRICS_CACHE["time"] = now
    POWERMETRICS_CACHE["text"] = output

    return output


def parse_temperature_from_text(text, keywords):
    if not text:
        return None

    for line in text.splitlines():
        line_lower = line.lower()

        if not all(keyword.lower() in line_lower for keyword in keywords):
            continue

        match = re.search(r"(-?\d+(?:\.\d+)?)\s*(?:c|°c)", line_lower)

        if match:
            return format_temperature(match.group(1))

    return None


def get_gpu_name_text():
    now = time.time()

    if now - GPU_NAME_CACHE["time"] < 60:
        return GPU_NAME_CACHE["value"]

    system_name = platform.system().lower()
    gpu_name = "GPU"

    try:
        if system_name == "darwin":
            output = run_command(
                ["system_profiler", "SPDisplaysDataType"],
                timeout=2
            )

            for line in output.splitlines():
                line = line.strip()

                if line.startswith("Chipset Model:"):
                    name = line.replace("Chipset Model:", "").strip()
                    name = name.replace("Intel ", "")
                    name = name.replace("Graphics", "")
                    name = name.replace("GPU", "")
                    gpu_name = name.strip() or "Intel GPU"
                    break

        elif system_name == "windows":
            output = run_powershell(
                "Get-CimInstance Win32_VideoController | Select-Object -First 1 -ExpandProperty Name",
                timeout=2,
            )

            if output:
                name = output.splitlines()[0].strip()
                name = name.replace("Intel(R)", "Intel")
                name = name.replace("Graphics", "")
                name = name.replace("GPU", "")
                gpu_name = name.strip() or "GPU"

        elif system_name == "linux":
            output = run_command(["lspci"], timeout=1.5)

            for line in output.splitlines():
                lower = line.lower()

                if "vga" in lower or "3d controller" in lower:
                    if "intel" in lower:
                        gpu_name = "Intel GPU"
                        break

                    if "nvidia" in lower:
                        gpu_name = "NVIDIA GPU"
                        break

                    if "amd" in lower or "radeon" in lower:
                        gpu_name = "AMD GPU"
                        break

    except Exception:
        gpu_name = "GPU"

    GPU_NAME_CACHE["time"] = now
    GPU_NAME_CACHE["value"] = gpu_name

    return gpu_name


def get_cpu_usage_percent():
    try:
        if psutil is not None:
            return f"{psutil.cpu_percent(interval=None):.0f}%"

        if hasattr(os, "getloadavg"):
            load_1m = os.getloadavg()[0]
            cores = os.cpu_count() or 1
            percent = min(100, max(0, (load_1m / cores) * 100))
            return f"{percent:.0f}%"

    except Exception as exc:
        logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

    return "--"


def get_cpu_temperature_text():
    return SLOW_METRICS_CACHE["cpu_temp"]


def get_cpu_temperature_text_slow():
    system_name = platform.system().lower()

    try:
        if psutil is not None and hasattr(psutil, "sensors_temperatures"):
            temps = psutil.sensors_temperatures()

            if temps:
                for sensor_items in temps.values():
                    values = [
                        item.current
                        for item in sensor_items
                        if item.current is not None
                    ]

                    if values:
                        return format_temperature(max(values))

        if system_name == "darwin":
            output = run_command(["osx-cpu-temp"], timeout=0.8)

            if output:
                match = re.search(r"(\d+(?:\.\d+)?)", output)

                if match:
                    return format_temperature(match.group(1))

            powermetrics = get_powermetrics_text()

            cpu_temp = (
                parse_temperature_from_text(powermetrics, ("cpu", "die"))
                or parse_temperature_from_text(powermetrics, ("cpu", "temperature"))
                or parse_temperature_from_text(powermetrics, ("package", "temperature"))
            )

            if cpu_temp:
                return cpu_temp

        if system_name == "linux":
            hwmon_paths = list(Path("/sys/class/hwmon").glob("hwmon*/temp*_input"))

            for path in hwmon_paths:
                try:
                    value = int(path.read_text().strip())

                    if value > 1000:
                        value = value / 1000

                    if 1 <= value <= 130:
                        return format_temperature(value)

                except Exception as exc:
                    logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

            thermal_paths = list(Path("/sys/class/thermal").glob("thermal_zone*/temp"))

            for path in thermal_paths:
                try:
                    value = int(path.read_text().strip())

                    if value > 1000:
                        value = value / 1000

                    if 1 <= value <= 130:
                        return format_temperature(value)

                except Exception as exc:
                    logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

    except Exception as exc:
        logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

    return "--"


def get_cpu_usage_text():
    usage = get_cpu_usage_percent()
    temperature = get_cpu_temperature_text()

    return f"{usage}  {temperature}"


def parse_mac_gpu_from_powermetrics(text):
    if not text:
        return None

    usage = None
    temperature = None

    usage_patterns = (
        r"GPU\s+Active\s+residency\s*:\s*(\d+(?:\.\d+)?)\s*%",
        r"GPU\s+HW\s+active\s+residency\s*:\s*(\d+(?:\.\d+)?)\s*%",
        r"GPU\s+Busy\s*:\s*(\d+(?:\.\d+)?)\s*%",
        r"GPU.*?(\d+(?:\.\d+)?)\s*%",
    )

    temp_patterns = (
        r"GPU\s+die\s+temperature\s*:\s*(\d+(?:\.\d+)?)\s*C",
        r"GPU\s+temperature\s*:\s*(\d+(?:\.\d+)?)\s*C",
        r"GPU.*?temperature.*?(\d+(?:\.\d+)?)\s*C",
    )

    for pattern in usage_patterns:
        match = re.search(pattern, text, re.IGNORECASE)

        if match:
            usage = f"{float(match.group(1)):.0f}%"
            break

    for pattern in temp_patterns:
        match = re.search(pattern, text, re.IGNORECASE)

        if match:
            temperature = format_temperature(match.group(1))
            break

    if usage or temperature:
        return f"{usage or '--'}  {temperature or '--'}"

    return None


def parse_mac_gpu_from_ioreg():
    outputs = [
        run_command(["ioreg", "-r", "-n", "IGPU", "-d", "2"], timeout=1),
        run_command(["ioreg", "-r", "-n", "AppleIntelFramebuffer", "-d", "2"], timeout=1),
    ]

    usage_patterns = (
        r'"Device Utilization %"\s*=\s*(\d+)',
        r'"GPU Busy"\s*=\s*(\d+)',
        r'"GPU Core Utilization"\s*=\s*(\d+)',
        r'"Busy"\s*=\s*(\d+)',
        r'"PerformanceStatistics".*?"Device Utilization %"\s*=\s*(\d+)',
        r'Utilization.*?(\d+)\s*%',
    )

    temp_patterns = (
        r'"Temperature"\s*=\s*(\d+)',
        r'"GPU Temperature"\s*=\s*(\d+)',
        r'"temp"\s*=\s*(\d+)',
    )

    for output in outputs:
        if not output:
            continue

        usage = None
        temperature = None

        for pattern in usage_patterns:
            match = re.search(pattern, output, re.IGNORECASE | re.S)

            if match:
                raw = int(match.group(1))

                if raw > 100:
                    raw = min(100, round(raw / 100))

                usage = f"{raw}%"
                break

        for pattern in temp_patterns:
            match = re.search(pattern, output, re.IGNORECASE | re.S)

            if match:
                raw = int(match.group(1))

                if raw > 1000:
                    raw = raw / 1000

                if 1 <= raw <= 130:
                    temperature = format_temperature(raw)
                    break

        if usage or temperature:
            return f"{usage or '--'}  {temperature or '--'}"

    return None


def get_mac_intel_gpu_usage_text():
    ioreg_value = parse_mac_gpu_from_ioreg()

    if ioreg_value:
        return ioreg_value

    powermetrics_value = parse_mac_gpu_from_powermetrics(
        get_powermetrics_text()
    )

    if powermetrics_value:
        return powermetrics_value

    gpu_name = get_gpu_name_text()

    return f"{gpu_name} --"


def get_nvidia_gpu_usage_text():
    output = run_command(
        [
            "nvidia-smi",
            "--query-gpu=utilization.gpu,temperature.gpu",
            "--format=csv,noheader,nounits"
        ],
        timeout=1.2
    )

    if not output:
        return None

    first_line = output.splitlines()[0].strip()
    parts = [part.strip() for part in first_line.split(",")]

    if len(parts) >= 2:
        usage = parts[0]
        temperature = parts[1]

        if usage.isdigit() and temperature.isdigit():
            return f"{usage}%  {temperature}°C"

    if len(parts) >= 1 and parts[0].isdigit():
        return f"{parts[0]}%  --"

    return None


def get_amd_gpu_usage_text():
    system_name = platform.system().lower()

    try:
        if system_name == "linux":
            drm_paths = list(Path("/sys/class/drm").glob("card*/device"))

            for device_path in drm_paths:
                busy_path = device_path / "gpu_busy_percent"

                usage = None
                temperature = None

                if busy_path.exists():
                    value = busy_path.read_text().strip()

                    if value.isdigit():
                        usage = f"{value}%"

                hwmon_dirs = list((device_path / "hwmon").glob("hwmon*"))

                for hwmon_dir in hwmon_dirs:
                    for temp_path in hwmon_dir.glob("temp*_input"):
                        try:
                            raw_temp = int(temp_path.read_text().strip())
                            celsius = raw_temp / 1000

                            if 1 <= celsius <= 130:
                                temperature = format_temperature(celsius)
                                break

                        except Exception as exc:
                            logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

                    if temperature:
                        break

                if usage or temperature:
                    return f"{usage or '--'}  {temperature or '--'}"

        rocm_output = run_command(["rocm-smi", "--showuse", "--showtemp"], timeout=1.5)

        if rocm_output:
            usage = None
            temperature = None

            for line in rocm_output.splitlines():
                line_lower = line.lower()

                if usage is None and ("gpu use" in line_lower or "gpu busy" in line_lower):
                    match = re.search(r"(\d+(?:\.\d+)?)", line)

                    if match:
                        usage = f"{float(match.group(1)):.0f}%"

                if temperature is None and ("temperature" in line_lower or "temp" in line_lower):
                    match = re.search(r"(\d+(?:\.\d+)?)", line)

                    if match:
                        temperature = format_temperature(match.group(1))

            if usage or temperature:
                return f"{usage or '--'}  {temperature or '--'}"

        radeontop_output = run_command(["radeontop", "-d", "-", "-l", "1"], timeout=1.5)

        if radeontop_output:
            match = re.search(r"gpu\s+(\d+(?:\.\d+)?)%", radeontop_output.lower())

            if match:
                return f"{float(match.group(1)):.0f}%  --"

    except Exception as exc:
        logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

    return None


def get_intel_gpu_usage_text():
    system_name = platform.system().lower()

    try:
        if system_name == "darwin":
            return get_mac_intel_gpu_usage_text()

        if system_name == "linux":
            intel_gpu_top = run_command(
                ["intel_gpu_top", "-J", "-s", "1000", "-o", "-"],
                timeout=1.5
            )

            if intel_gpu_top:
                match = re.search(
                    r'"Render/3D/0".*?"busy"\s*:\s*(\d+(?:\.\d+)?)',
                    intel_gpu_top,
                    re.S
                )

                if match:
                    return f"{float(match.group(1)):.0f}%  --"

    except Exception as exc:
        logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

    return None


def get_windows_gpu_usage_text():
    try:
        output = run_shell_command(
            'powershell -NoProfile -Command '
            '"$c=(Get-Counter \'\\GPU Engine(*)\\Utilization Percentage\' -ErrorAction SilentlyContinue).CounterSamples '
            '| Where-Object {$_.CookedValue -gt 0} '
            '| Measure-Object CookedValue -Sum; '
            'if ($c.Sum -ne $null) {[math]::Round([math]::Min($c.Sum,100))}"',
            timeout=1.8
        )

        if output:
            first_line = output.splitlines()[0].strip()

            if first_line.replace(".", "", 1).isdigit():
                return f"{float(first_line):.0f}%  --"

    except Exception as exc:
        logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

    return None


def get_gpu_usage_text():
    return SLOW_METRICS_CACHE["gpu"]


def get_gpu_usage_text_slow():
    system_name = platform.system().lower()
    gpu_name = get_gpu_name_text().lower()

    try:
        if system_name == "darwin":
            if "iris" in gpu_name or "intel" in gpu_name or "uhd" in gpu_name:
                return get_intel_gpu_usage_text() or f"{get_gpu_name_text()} --"

            if "amd" in gpu_name or "radeon" in gpu_name:
                return get_amd_gpu_usage_text() or f"{get_gpu_name_text()} --"

            if "nvidia" in gpu_name:
                return get_nvidia_gpu_usage_text() or f"{get_gpu_name_text()} --"

            return get_intel_gpu_usage_text() or f"{get_gpu_name_text()} --"

        value = (
            get_nvidia_gpu_usage_text()
            or get_amd_gpu_usage_text()
            or get_intel_gpu_usage_text()
            or get_windows_gpu_usage_text()
        )

        if value:
            return value

    except Exception as exc:
        logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

    return f"{get_gpu_name_text()} --"


def refresh_slow_metrics_background():
    now = time.time()

    if SLOW_METRICS_CACHE["running"]:
        return

    if now - SLOW_METRICS_CACHE["last_update"] < 6:
        return

    SLOW_METRICS_CACHE["running"] = True

    def worker():
        try:
            cpu_temp = get_cpu_temperature_text_slow()
            gpu_text = get_gpu_usage_text_slow()

            SLOW_METRICS_CACHE["cpu_temp"] = cpu_temp
            SLOW_METRICS_CACHE["gpu"] = gpu_text
            SLOW_METRICS_CACHE["last_update"] = time.time()

        finally:
            SLOW_METRICS_CACHE["running"] = False

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()


def get_ram_usage_text():
    try:
        if psutil is not None:
            ram = psutil.virtual_memory()
            used_gb = ram.used / 1024 / 1024 / 1024
            total_gb = ram.total / 1024 / 1024 / 1024

            return f"{used_gb:.1f}/{total_gb:.0f}GB {ram.percent:.0f}%"

        system_name = platform.system().lower()

        if system_name == "windows":
            import ctypes

            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            memory_status = MEMORYSTATUSEX()
            memory_status.dwLength = ctypes.sizeof(MEMORYSTATUSEX)

            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory_status))

            total = memory_status.ullTotalPhys
            available = memory_status.ullAvailPhys
            used = total - available
            percent = used / total * 100

            used_gb = used / 1024 / 1024 / 1024
            total_gb = total / 1024 / 1024 / 1024

            return f"{used_gb:.1f}/{total_gb:.0f}GB {percent:.0f}%"

        if system_name == "linux":
            meminfo = Path("/proc/meminfo").read_text(encoding="utf-8")
            values = {}

            for line in meminfo.splitlines():
                parts = line.split()

                if len(parts) >= 2:
                    key = parts[0].replace(":", "")
                    values[key] = int(parts[1])

            total = values.get("MemTotal")
            available = values.get("MemAvailable")

            if total and available:
                used = total - available
                percent = used / total * 100

                used_gb = used / 1024 / 1024
                total_gb = total / 1024 / 1024

                return f"{used_gb:.1f}/{total_gb:.0f}GB {percent:.0f}%"

    except Exception as exc:
        logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

    return "--"


def get_disk_usage_text():
    try:
        disk_path = Path.home().anchor or "/"
        disk = shutil.disk_usage(disk_path)

        used_gb = disk.used / 1024 / 1024 / 1024
        total_gb = disk.total / 1024 / 1024 / 1024
        percent = disk.used / disk.total * 100

        return f"{used_gb:.0f}/{total_gb:.0f}GB {percent:.0f}%"

    except Exception:
        return "--"


class NotchAnimator:
    def __init__(
        self,
        ui,
        bg,
        bg2,
        text,
        border,
        animations_enabled=True,
        font_name="gugi"
    ):
        self.ui = ui
        self.bg = bg
        self.bg2 = bg2
        self.text = text
        self.border = border
        self.animations_enabled = animations_enabled
        self.font_name = font_name

        self.notch = None
        self.content = None
        self.title_label = None
        self.date_label = None

        self.labels = {}
        self.cards = {}
        self.previous_values = {}
        self.pulse_jobs = {}

        self.animation_job = None
        self.update_job = None

        self.is_open = False
        self.is_animating = False

        self.pending_close_after_animation = False
        self.last_geometry = None

        self.ui.update_idletasks()

        self.screen_width = self.ui.winfo_screenwidth()

        self.closed_x = int((self.screen_width - NOTCH_WIDTH_CLOSED) / 2)
        self.open_x = int((self.screen_width - NOTCH_WIDTH_OPEN) / 2)

    def create(self):
        self.notch = CTkFrame(
            self.ui,
            fg_color="Black",
            bg_color=self.bg,
            corner_radius=20,
            width=NOTCH_WIDTH_CLOSED,
            height=NOTCH_HEIGHT_CLOSED
        )
        self.notch.place(x=self.closed_x, y=NOTCH_Y)

        self.build_content()
        self.bind_hover(self.notch)

        self.notch.notch_animator = self

        return self.notch

    def build_content(self):
        self.title_label = CTkLabel(
            self.notch,
            text="System",
            width=120,
            height=24,
            anchor="w",
            font=(self.font_name, 16, "bold"),
            text_color=TITLE_COLOR,
            fg_color="transparent",
            bg_color="transparent"
        )

        self.date_label = CTkLabel(
            self.notch,
            text="--:-- --.--.----",
            width=190,
            height=24,
            anchor="e",
            font=(self.font_name, 12, "bold"),
            text_color=DATE_COLOR,
            fg_color="transparent",
            bg_color="transparent"
        )

        self.content = CTkFrame(
            self.notch,
            width=NOTCH_WIDTH_OPEN - 28,
            height=110,
            fg_color="transparent",
            bg_color="transparent"
        )

        items = (
            ("CPU", "cpu", CPU_COLOR),
            ("GPU", "gpu", GPU_COLOR),
            ("RAM", "ram", RAM_COLOR),
            ("Disk", "disk", DISK_COLOR),
        )

        max_columns = 2

        for index, item in enumerate(items):
            name, key, color = item

            row = index // max_columns
            column = index % max_columns

            x = column * (CARD_WIDTH + CARD_GAP_X)
            y = row * (CARD_HEIGHT + CARD_GAP_Y)

            self.create_card(
                x=x,
                y=y,
                name=name,
                key=key,
                color=color
            )

        self.hide_content()

    def create_card(self, x, y, name, key, color):
        card = CTkFrame(
            self.content,
            width=CARD_WIDTH,
            height=CARD_HEIGHT,
            fg_color=color,
            bg_color="transparent",
            border_width=0,
            corner_radius=13
        )
        card.place(x=x, y=y)
        card.pack_propagate(False)
        card.grid_propagate(False)

        name_label = CTkLabel(
            card,
            text=name,
            width=52,
            height=18,
            anchor="w",
            font=(self.font_name, 11, "bold"),
            text_color=DARK_TEXT,
            fg_color="transparent"
        )
        name_label.place(x=10, y=4)

        value_label = CTkLabel(
            card,
            text="...",
            width=CARD_WIDTH - 20,
            height=20,
            anchor="w",
            font=(self.font_name, 11, "bold"),
            text_color=DARK_TEXT,
            fg_color="transparent"
        )
        value_label.place(x=10, y=22)

        self.cards[key] = card
        self.labels[key] = value_label

    def show_content(self):
        if self.title_label is not None:
            self.title_label.place(x=18, y=31)

        if self.date_label is not None:
            self.date_label.place(x=NOTCH_WIDTH_OPEN - 208, y=31)

        if self.content is not None:
            self.content.place(x=CONTENT_X, y=CONTENT_Y)

    def hide_content(self):
        if self.title_label is not None:
            self.title_label.place_forget()

        if self.date_label is not None:
            self.date_label.place_forget()

        if self.content is not None:
            self.content.place_forget()

    def bind_hover(self, widget):
        widget.bind("<Enter>", self.open)
        widget.bind("<Leave>", self.schedule_close)

        for child in widget.winfo_children():
            self.bind_hover(child)

    def stop_animation(self):
        if self.animation_job is not None:
            try:
                self.ui.after_cancel(self.animation_job)
            except Exception as exc:
                logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

        self.animation_job = None
        self.is_animating = False

    def apply_geometry(self, x, width, height):
        geometry = (x, width, height)

        if geometry == self.last_geometry:
            return

        self.last_geometry = geometry
        self.notch.configure(width=width, height=height)
        self.notch.place(x=x, y=NOTCH_Y)

    def animate_geometry(
        self,
        from_x,
        from_width,
        from_height,
        to_x,
        to_width,
        to_height,
        on_done=None
    ):
        self.stop_animation()

        if not self.animations_enabled:
            self.apply_geometry(to_x, to_width, to_height)

            if on_done is not None:
                on_done()

            if self.pending_close_after_animation:
                self.pending_close_after_animation = False
                self.ui.after(1, self.close_if_pointer_outside)

            return

        self.is_animating = True

        start_time = time.perf_counter()
        duration_seconds = NOTCH_ANIMATION_DURATION_MS / 1000

        def finish_animation():
            self.apply_geometry(to_x, to_width, to_height)

            self.animation_job = None
            self.is_animating = False

            if on_done is not None:
                on_done()

            if self.pending_close_after_animation:
                self.pending_close_after_animation = False
                self.ui.after(1, self.close_if_pointer_outside)

        def animation_frame():
            if not self.notch.winfo_exists():
                self.animation_job = None
                self.is_animating = False
                self.pending_close_after_animation = False
                return

            elapsed = time.perf_counter() - start_time
            progress = min(1, elapsed / duration_seconds)
            eased_progress = apple_ease_out(progress)

            current_x = int(from_x + (to_x - from_x) * eased_progress)
            current_width = int(from_width + (to_width - from_width) * eased_progress)
            current_height = int(from_height + (to_height - from_height) * eased_progress)

            self.apply_geometry(current_x, current_width, current_height)

            if progress >= 1:
                finish_animation()
                return

            self.animation_job = self.ui.after(
                NOTCH_ANIMATION_DELAY_MS,
                animation_frame
            )

        animation_frame()

    def animate_value_change(self, key):
        if not self.animations_enabled:
            return

        card = self.cards.get(key)

        if card is None:
            return

        if key in self.pulse_jobs:
            try:
                self.ui.after_cancel(self.pulse_jobs[key])
            except Exception as exc:
                logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

        original_color = {
            "cpu": CPU_COLOR,
            "gpu": GPU_COLOR,
            "ram": RAM_COLOR,
            "disk": DISK_COLOR,
        }.get(key, self.bg2)

        flash_color = "#f8fafc"

        try:
            card.configure(fg_color=flash_color)
        except Exception:
            return

        def restore():
            try:
                if card.winfo_exists():
                    card.configure(fg_color=original_color)
            except Exception as exc:
                logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

            self.pulse_jobs.pop(key, None)

        self.pulse_jobs[key] = self.ui.after(PULSE_FLASH_MS, restore)

    def update_metric_value(self, key, value):
        label = self.labels.get(key)

        if label is None:
            return

        previous_value = self.previous_values.get(key)

        label.configure(text=value)

        if previous_value is not None and previous_value != value:
            self.animate_value_change(key)

        self.previous_values[key] = value

    def open(self, event=None):
        if self.is_animating:
            return "break"

        if self.is_open:
            return "break"

        self.is_open = True
        self.pending_close_after_animation = False

        try:
            current_x = self.notch.winfo_x()
            current_width = self.notch.winfo_width()
            current_height = self.notch.winfo_height()
        except Exception:
            current_x = self.closed_x
            current_width = NOTCH_WIDTH_CLOSED
            current_height = NOTCH_HEIGHT_CLOSED

        def show_content_fast():
            if self.is_open:
                self.show_content()

        def finish_open():
            if self.is_open:
                self.start_updates()

        self.ui.after(20, show_content_fast)

        self.animate_geometry(
            from_x=current_x,
            from_width=current_width,
            from_height=current_height,
            to_x=self.open_x,
            to_width=NOTCH_WIDTH_OPEN,
            to_height=NOTCH_HEIGHT_OPEN,
            on_done=finish_open
        )

        return "break"

    def schedule_close(self, event=None):
        if self.is_animating:
            self.pending_close_after_animation = True
            return "break"

        self.ui.after(140, self.close_if_pointer_outside)

        return "break"

    def close_if_pointer_outside(self):
        if self.notch is None:
            return

        if self.is_animating:
            self.pending_close_after_animation = True
            return

        if self.pointer_inside_notch():
            return

        self.close()

    def close(self):
        if self.is_animating:
            self.pending_close_after_animation = True
            return "break"

        if not self.is_open:
            return "break"

        self.is_open = False
        self.pending_close_after_animation = False

        self.stop_updates()
        self.ui.after(30, self.hide_content)

        try:
            current_x = self.notch.winfo_x()
            current_width = self.notch.winfo_width()
            current_height = self.notch.winfo_height()
        except Exception:
            current_x = self.open_x
            current_width = NOTCH_WIDTH_OPEN
            current_height = NOTCH_HEIGHT_OPEN

        self.animate_geometry(
            from_x=current_x,
            from_width=current_width,
            from_height=current_height,
            to_x=self.closed_x,
            to_width=NOTCH_WIDTH_CLOSED,
            to_height=NOTCH_HEIGHT_CLOSED
        )

        return "break"

    def pointer_inside_notch(self):
        try:
            pointer_x = self.notch.winfo_pointerx()
            pointer_y = self.notch.winfo_pointery()

            root_x = self.notch.winfo_rootx()
            root_y = self.notch.winfo_rooty()

            width = self.notch.winfo_width()
            height = self.notch.winfo_height()

            return (
                root_x <= pointer_x <= root_x + width
                and root_y <= pointer_y <= root_y + height
            )

        except Exception:
            return False

    def start_updates(self):
        if self.update_job is not None:
            try:
                self.ui.after_cancel(self.update_job)
            except Exception as exc:
                logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

        self.update_info()

    def stop_updates(self):
        if self.update_job is not None:
            try:
                self.ui.after_cancel(self.update_job)
            except Exception as exc:
                logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

        self.update_job = None

    def update_info(self):
        if not self.is_open and not self.is_animating:
            self.update_job = None
            return

        if self.is_animating:
            self.update_job = self.ui.after(120, self.update_info)
            return

        refresh_slow_metrics_background()

        now = datetime.now()

        self.update_metric_value("cpu", get_cpu_usage_text())
        self.update_metric_value("gpu", get_gpu_usage_text())
        self.update_metric_value("ram", get_ram_usage_text())
        self.update_metric_value("disk", get_disk_usage_text())

        if self.date_label is not None:
            self.date_label.configure(text=now.strftime("%H:%M %d.%m.%Y"))

        self.update_job = self.ui.after(1000, self.update_info)


def create_notch(
    ui,
    bg,
    bg2,
    text,
    border,
    animations_enabled=True,
    font_name="gugi"
):
    animator = NotchAnimator(
        ui=ui,
        bg=bg,
        bg2=bg2,
        text=text,
        border=border,
        animations_enabled=animations_enabled,
        font_name=font_name
    )

    return animator.create()
# Animacja menu Start używana przez start_menu.py.
START_ANIMATION_FPS = 60
START_ANIMATION_DURATION_MS = 160
START_ANIMATION_DELAY_MS = max(1, round(1000 / START_ANIMATION_FPS))


def animate_start_y(
    ui,
    widget,
    x,
    from_y,
    to_y,
    start_button=None,
    animations_enabled=True,
    on_state_change=None,
    on_done=None,
):
    if on_state_change is not None:
        on_state_change(True)

    def finish():
        try:
            widget.place(x=x, y=to_y)
        except Exception as exc:
            logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)
        if on_state_change is not None:
            on_state_change(False)
        if start_button is not None:
            try:
                start_button.configure(state="normal")
            except Exception as exc:
                logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)
        if on_done is not None:
            on_done()

    if start_button is not None:
        try:
            start_button.configure(state="disabled")
        except Exception as exc:
            logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

    if not animations_enabled:
        finish()
        return

    start_time = time.perf_counter()
    duration_seconds = START_ANIMATION_DURATION_MS / 1000

    def frame():
        try:
            if not widget.winfo_exists():
                if on_state_change is not None:
                    on_state_change(False)
                return
        except Exception:
            if on_state_change is not None:
                on_state_change(False)
            return

        elapsed = time.perf_counter() - start_time
        progress = min(1, elapsed / duration_seconds)
        eased = apple_ease_out(progress)
        current_y = int(from_y + (to_y - from_y) * eased)

        try:
            widget.place(x=x, y=current_y)
        except Exception as exc:
            logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)

        if progress >= 1:
            finish()
            return

        ui.after(START_ANIMATION_DELAY_MS, frame)

    frame()
