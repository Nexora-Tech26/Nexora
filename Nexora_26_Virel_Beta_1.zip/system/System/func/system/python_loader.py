import importlib.util
from pathlib import Path


def load_python_file(module_name: str, module_path):
    module_path = Path(module_path).resolve()
    if not module_path.exists():
        print(f"Error: file not found: {module_path}")
        return None

    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        print(f"Error: cannot load module: {module_path}")
        return None

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
