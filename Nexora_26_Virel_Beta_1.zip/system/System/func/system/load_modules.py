from pathlib import Path

APP_EXTENSIONS = (".py",)


def _parents(path):
    path = Path(path).resolve()
    yield path
    yield from path.parents


def find_system_root(start_file=None):
    if start_file is None:
        start_file = __file__
    for parent in _parents(start_file):
        if parent.name == "System":
            return parent
        if (parent / "sys" / "resources" / "apps").exists():
            return parent
    # fallback: func/system/load_modules.py -> System
    return Path(__file__).resolve().parents[2]


def find_apps_folder(start_file=None):
    system_root = find_system_root(start_file)
    possible = [
        system_root / "sys" / "resources" / "apps",
        system_root / "sys" / "resources" / "Apps",
        system_root / "Apps",
        system_root / "apps",
        system_root / "func" / "Apps",
        system_root / "func" / "apps",
        system_root / "func" / "system" / "Apps",
        system_root / "func" / "system" / "apps",
    ]
    for folder in possible:
        if folder.exists() and folder.is_dir():
            return folder
    return possible[0]


def get_apps():
    apps_folder = find_apps_folder()
    if not apps_folder.exists():
        print(f"Apps folder not found: {apps_folder}")
        return []
    return sorted(
        str(path)
        for path in apps_folder.iterdir()
        if path.is_file() and path.suffix.lower() in APP_EXTENSIONS and not path.name.startswith("__")
    )


def get_app_name(file):
    path = Path(file)
    return path.stem.replace("_", " ").replace("-", " ").title()


def search_apps(query):
    query = query.strip().lower()
    apps = get_apps()
    if not query:
        return apps
    return [app for app in apps if query in get_app_name(app).lower()]
