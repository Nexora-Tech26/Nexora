from __future__ import annotations
from pathlib import Path
import hashlib, hmac, json, secrets, re, os, time, shutil
from collections import defaultdict, deque
from nexora.paths import DATA_DIR, ensure_runtime_paths

SYSTEM_ROOT = Path(__file__).resolve().parents[2]
ensure_runtime_paths(legacy_data=SYSTEM_ROOT / "data", legacy_home=SYSTEM_ROOT.parent / "Home" / "User")
USERS_FILE = DATA_DIR / "users.json"
LEGACY_PROFILE_FILE = DATA_DIR / "user.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
MAX_USERS = None
MIN_PASSWORD_LENGTH = 10
_LOGIN_FAILURES: dict[str, deque[float]] = defaultdict(deque)
_LOGIN_WINDOW_SECONDS = 300
_LOGIN_MAX_ATTEMPTS = 5


def _atomic_write(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    temporary.replace(path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _load_json(path: Path, default):
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default


def hash_password(password: str, salt: bytes | None = None) -> tuple[str, str]:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 240_000)
    return salt.hex(), digest.hex()


def _clean_username(username: str) -> str:
    username = " ".join(username.strip().split())
    if not username:
        raise ValueError("Nazwa użytkownika nie może być pusta.")
    if len(username) > 40:
        raise ValueError("Nazwa użytkownika jest za długa.")
    return username


def _new_id(username: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", username.lower()).strip("-") or "user"
    return f"{slug}-{secrets.token_hex(3)}"


def _migrate_legacy() -> None:
    if USERS_FILE.exists() or not LEGACY_PROFILE_FILE.exists():
        return
    legacy = _load_json(LEGACY_PROFILE_FILE, None)
    if not isinstance(legacy, dict) or not legacy.get("username"):
        return
    user = {
        "id": _new_id(str(legacy.get("username", "User"))),
        "username": str(legacy.get("username", "User")),
        "salt": legacy.get("salt", ""),
        "password_hash": legacy.get("password_hash", ""),
        "passwordless": not bool(legacy.get("password_hash")),
        "avatar_color": "#3F8CFF",
    }
    _atomic_write(USERS_FILE, {"users": [user], "last_user_id": user["id"]})


def list_users() -> list[dict]:
    _migrate_legacy()
    data = _load_json(USERS_FILE, {"users": []})
    users = data.get("users", []) if isinstance(data, dict) else []
    return [u for u in users if isinstance(u, dict) and u.get("id") and u.get("username")]


def get_last_user_id() -> str | None:
    _migrate_legacy()
    data = _load_json(USERS_FILE, {})
    value = data.get("last_user_id") if isinstance(data, dict) else None
    return str(value) if value else None


def set_last_user(user_id: str) -> None:
    users = list_users()
    if not any(u["id"] == user_id for u in users):
        return
    _atomic_write(USERS_FILE, {"users": users, "last_user_id": user_id})


def load_user(user_id: str | None = None) -> dict | None:
    users = list_users()
    if not users:
        return None
    user_id = user_id or get_last_user_id()
    return next((u for u in users if u.get("id") == user_id), users[0])


def _build_user(username: str, password: str, avatar_color: str = "#3F8CFF", avatar_path: str = "") -> dict:
    username = _clean_username(username)
    passwordless = password == ""
    if not passwordless and len(password) < MIN_PASSWORD_LENGTH:
        raise ValueError(f"Hasło musi mieć co najmniej {MIN_PASSWORD_LENGTH} znaków albo wybierz konto bez hasła.")
    if not passwordless and password.casefold() in {username.casefold(), "password", "haslo12345", "1234567890"}:
        raise ValueError("Hasło jest zbyt łatwe do odgadnięcia.")
    if passwordless:
        salt, digest = "", ""
    else:
        salt, digest = hash_password(password)
    stored_avatar = ""
    if avatar_path:
        source = Path(avatar_path).expanduser()
        if source.is_file() and source.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}:
            avatars = DATA_DIR / "avatars"
            avatars.mkdir(parents=True, exist_ok=True)
            avatar_digest = hashlib.sha256(source.read_bytes()).hexdigest()[:16]
            target = avatars / f"{avatar_digest}{source.suffix.lower()}"
            if not target.exists():
                shutil.copy2(source, target)
            stored_avatar = str(target)
    return {
        "id": _new_id(username),
        "username": username,
        "salt": salt,
        "password_hash": digest,
        "passwordless": passwordless,
        "avatar_color": avatar_color,
        "avatar_path": stored_avatar,
    }


def create_users(accounts) -> list[dict]:
    """Create any number of local users from tuples or account dictionaries."""
    if not accounts:
        raise ValueError("Utwórz co najmniej jednego użytkownika.")
    normalized = []
    for index, account in enumerate(accounts):
        if isinstance(account, dict):
            normalized.append({
                "username": str(account.get("username", "")),
                "password": str(account.get("password", "")),
                "avatar_color": str(account.get("avatar_color", "#3F8CFF")),
                "avatar_path": str(account.get("avatar_path", "")),
            })
        else:
            name, password = account
            normalized.append({"username": str(name), "password": str(password), "avatar_color": "", "avatar_path": ""})
    names = [_clean_username(account["username"]).casefold() for account in normalized]
    if len(set(names)) != len(names):
        raise ValueError("Nazwy użytkowników muszą być różne.")
    colors = ("#3F8CFF", "#B876E8", "#45C4B0", "#FFB84D", "#F06FA7", "#6D7CFF")
    users = [
        _build_user(
            account["username"],
            account["password"],
            account["avatar_color"] or colors[index % len(colors)],
            account["avatar_path"],
        )
        for index, account in enumerate(normalized)
    ]
    _atomic_write(USERS_FILE, {"users": users, "last_user_id": users[0]["id"]})
    settings = _load_json(SETTINGS_FILE, {})
    if not isinstance(settings, dict): settings = {}
    settings.update({"oobe_completed": True})
    _atomic_write(SETTINGS_FILE, settings)
    try: LEGACY_PROFILE_FILE.unlink()
    except FileNotFoundError: pass
    return users


def add_user(username: str, password: str) -> dict:
    users = list_users()
    clean = _clean_username(username)
    if any(u.get("username", "").casefold() == clean.casefold() for u in users):
        raise ValueError("Użytkownik o tej nazwie już istnieje.")
    palette = ("#3F8CFF", "#B876E8", "#45C4B0", "#FFB84D", "#F06FA7", "#6D7CFF")
    user = _build_user(clean, password, palette[len(users) % len(palette)])
    users.append(user)
    _atomic_write(USERS_FILE, {"users": users, "last_user_id": get_last_user_id() or user["id"]})
    return user


def delete_user(user_id: str) -> None:
    users = list_users()
    if len(users) <= 1:
        raise ValueError("Nie można usunąć jedynego użytkownika.")
    remaining = [u for u in users if u.get("id") != user_id]
    if len(remaining) == len(users):
        raise ValueError("Nie znaleziono użytkownika.")
    last = get_last_user_id()
    if last == user_id: last = remaining[0]["id"]
    _atomic_write(USERS_FILE, {"users": remaining, "last_user_id": last})


def user_requires_password(user_id: str | None = None) -> bool:
    user = load_user(user_id)
    if not user:
        return True
    if user.get("passwordless") is True:
        return False
    return bool(user.get("password_hash"))


def _rate_limit_key(user_id: str | None) -> str:
    return user_id or "<unknown>"


def _is_rate_limited(user_id: str | None) -> bool:
    now = time.monotonic()
    failures = _LOGIN_FAILURES[_rate_limit_key(user_id)]
    while failures and now - failures[0] > _LOGIN_WINDOW_SECONDS:
        failures.popleft()
    return len(failures) >= _LOGIN_MAX_ATTEMPTS


def verify_password(password: str, user_id: str | None = None) -> bool:
    if _is_rate_limited(user_id):
        time.sleep(1.0)
        return False
    user = load_user(user_id)
    if not user:
        return False
    if not user_requires_password(user.get("id")):
        set_last_user(user["id"])
        return True
    try:
        salt = bytes.fromhex(user["salt"])
        _, digest = hash_password(password, salt)
        ok = hmac.compare_digest(digest, user["password_hash"])
        if ok:
            _LOGIN_FAILURES.pop(_rate_limit_key(user_id), None)
            set_last_user(user["id"])
        else:
            _LOGIN_FAILURES[_rate_limit_key(user_id)].append(time.monotonic())
            time.sleep(min(0.8, 0.15 * len(_LOGIN_FAILURES[_rate_limit_key(user_id)])))
        return ok
    except (KeyError, TypeError, ValueError):
        return False


def save_user(username: str, password: str, theme: str = "light") -> None:
    create_users([(username, password)])


def oobe_completed() -> bool:
    settings = _load_json(SETTINGS_FILE, {})
    return bool(isinstance(settings, dict) and settings.get("oobe_completed") and list_users())


def reset_profile() -> None:
    for path in (USERS_FILE, LEGACY_PROFILE_FILE, SETTINGS_FILE):
        try: path.unlink()
        except FileNotFoundError: pass
