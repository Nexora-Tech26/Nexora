import logging
import os
import platform
import re
import subprocess
import time
from pathlib import Path


def run_command(command):
    try:
        return subprocess.check_output(command, stderr=subprocess.DEVNULL, text=True, timeout=1).strip()
    except Exception:
        return ""


def get_computer_model():
    system_name = platform.system().lower()
    if system_name == "darwin":
        model = run_command(["sysctl", "-n", "hw.model"])
        if model:
            return model
    if system_name == "windows":
        output = run_command(["wmic", "computersystem", "get", "model"])
        lines = [line.strip() for line in output.splitlines() if line.strip() and line.strip().lower() != "model"]
        if lines:
            return lines[0]
    if system_name == "linux":
        for path in ("/sys/devices/virtual/dmi/id/product_name", "/sys/class/dmi/id/product_name"):
            try:
                value = Path(path).read_text(encoding="utf-8").strip()
                if value:
                    return value
            except Exception as exc:
                logging.getLogger(__name__).debug("Non-critical operation failed: %s", exc)
    return platform.machine() or "Unknown"


def get_total_ram_gb():
    system_name = platform.system().lower()
    try:
        if system_name == "darwin":
            return int(run_command(["sysctl", "-n", "hw.memsize"])) / 1024 / 1024 / 1024
        if system_name == "windows":
            import ctypes
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong),("dwMemoryLoad", ctypes.c_ulong),("ullTotalPhys", ctypes.c_ulonglong),("ullAvailPhys", ctypes.c_ulonglong),("ullTotalPageFile", ctypes.c_ulonglong),("ullAvailPageFile", ctypes.c_ulonglong),("ullTotalVirtual", ctypes.c_ulonglong),("ullAvailVirtual", ctypes.c_ulonglong),("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            memory_status = MEMORYSTATUSEX()
            memory_status.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory_status))
            return memory_status.ullTotalPhys / 1024 / 1024 / 1024
        if system_name == "linux":
            meminfo = Path("/proc/meminfo").read_text(encoding="utf-8")
            for line in meminfo.splitlines():
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) / 1024 / 1024
    except Exception:
        return None
    return None


def is_modern_mac_model(model):
    model = model.strip()
    mac_new_format = re.match(r"Mac(\d+),", model)
    if mac_new_format:
        return int(mac_new_format.group(1)) >= 13
    match = re.match(r"(MacBookPro|MacBookAir|iMac|Macmini|MacPro)(\d+),", model)
    if not match:
        return False
    device, generation = match.group(1), int(match.group(2))
    return {
        "MacBookAir": generation >= 10,
        "MacBookPro": generation >= 16,
        "iMac": generation >= 20,
        "Macmini": generation >= 9,
        "MacPro": generation >= 7,
    }.get(device, False)


def quick_cpu_benchmark():
    start_time = time.perf_counter()
    result = 0
    for i in range(450_000):
        result += (i * i) % 97
    return time.perf_counter() - start_time


def detect_animation_profile():
    model = get_computer_model()
    ram_gb = get_total_ram_gb()
    cpu_cores = os.cpu_count() or 1
    benchmark_time = quick_cpu_benchmark()
    weak_reasons = []
    if ram_gb is not None and ram_gb < 6:
        weak_reasons.append(f"RAM {ram_gb:.1f} GB")
    if cpu_cores < 4:
        weak_reasons.append(f"CPU cores {cpu_cores}")
    if benchmark_time > 0.35:
        weak_reasons.append(f"benchmark {benchmark_time:.3f}s")
    if weak_reasons:
        return False, model, "animations OFF: " + ", ".join(weak_reasons)
    if ram_gb is not None and ram_gb >= 8 and cpu_cores >= 4 and benchmark_time <= 0.35:
        return True, model, f"animations ON: RAM {ram_gb:.1f} GB, CPU cores {cpu_cores}, benchmark {benchmark_time:.3f}s"
    if is_modern_mac_model(model) and cpu_cores >= 4 and benchmark_time <= 0.50:
        return True, model, f"animations ON: modern Mac model {model}, benchmark {benchmark_time:.3f}s"
    return False, model, f"animations OFF: unknown/low profile, CPU cores {cpu_cores}, benchmark {benchmark_time:.3f}s"
