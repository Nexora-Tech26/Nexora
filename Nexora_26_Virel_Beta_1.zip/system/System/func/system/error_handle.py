from pathlib import Path
import subprocess
import sys


ERROR_DESCRIPTIONS = {
    "0E000000": "Unknown error.",
    "0E000001": "Not enough free RAM.",
    "0E000002": "Not enough free disk space.",
    "0E000003": "Unsupported operating system.",
    "0E000004": "CPU does not meet the requirements.",
    "0E000005": "Could not load antycrack.py.",
    "0E000006": "antycrack.py does not contain a main() function.",
    "0E000007": "BLOCK file detected. The program has been blocked.",
    "0E000008": "Could not load req_core.py.",
    "0E000009": "req_core.py does not contain a main() function.",
    "0E000010": "Integrity check detected a file change.",
    "0E000011": "Could not start the desktop interface.",
    "0E000012": "Nexora Core encountered an unexpected error.",
}


def normalize_error_code(error_code: str) -> str:
    if not error_code:
        return "0E000000"

    error_code = str(error_code).strip().upper()

    if error_code.startswith("0X"):
        return "0E000000"

    if error_code.startswith("0E"):
        return "0E" + error_code[2:]

    return "0E000000"


def get_error_description(error_code: str) -> str:
    normalized_code = normalize_error_code(error_code)

    return ERROR_DESCRIPTIONS.get(
        normalized_code,
        "No description available for this error code."
    )


def get_error_ui_path() -> Path:
    current_file = Path(__file__).resolve()

    # error_handle.py is in ../../func/system/error_handle.py.
    # From here go back to System, then UI/screens/error.py.
    base_path = (current_file.parent / ".." / ".." ).resolve()

    return base_path / "UI" / "screens" / "error.py"


def show_error(error_code: str, details: str | None = None):
    normalized_code = normalize_error_code(error_code)
    description = get_error_description(normalized_code)
    if details:
        description = f"{description}\n\nDetails: {details}"
    error_ui_path = get_error_ui_path()

    print(f"ErrorHandle: code = {normalized_code}")
    print(f"ErrorHandle: description = {description}")
    print(f"ErrorHandle: UI = {error_ui_path}")

    if not error_ui_path.exists():
        print(f"ErrorHandle: error.py not found: {error_ui_path}")
        return

    try:
        subprocess.Popen(
            [
                sys.executable,
                str(error_ui_path),
                normalized_code,
                description,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception as error:
        print(f"ErrorHandle: could not start error.py: {error}")
