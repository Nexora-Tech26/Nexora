"""Small, deterministic arithmetic evaluator used by Nexora Calculator."""
from __future__ import annotations

import ast
import math
import operator

MAX_EXPRESSION_LENGTH = 256
MAX_ABS_RESULT = 10**100
MAX_POWER = 1000

_BINARY = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_UNARY = {ast.UAdd: operator.pos, ast.USub: operator.neg}


class CalculatorError(ValueError):
    pass


def evaluate(expression: str) -> int | float:
    text = expression.strip()
    if not text:
        raise CalculatorError("Enter an expression")
    if len(text) > MAX_EXPRESSION_LENGTH:
        raise CalculatorError("Expression is too long")
    try:
        tree = ast.parse(text, mode="eval")
    except SyntaxError as exc:
        raise CalculatorError("Invalid expression") from exc

    def visit(node: ast.AST, depth: int = 0):
        if depth > 32:
            raise CalculatorError("Expression is too complex")
        if isinstance(node, ast.Expression):
            return visit(node.body, depth + 1)
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            return node.value
        if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY:
            return _UNARY[type(node.op)](visit(node.operand, depth + 1))
        if isinstance(node, ast.BinOp) and type(node.op) in _BINARY:
            left = visit(node.left, depth + 1)
            right = visit(node.right, depth + 1)
            if isinstance(node.op, ast.Pow) and abs(right) > MAX_POWER:
                raise CalculatorError("Exponent is too large")
            try:
                result = _BINARY[type(node.op)](left, right)
            except (ArithmeticError, OverflowError) as exc:
                raise CalculatorError(str(exc) or "Calculation failed") from exc
            if isinstance(result, complex) or not math.isfinite(float(result)):
                raise CalculatorError("Result is not finite")
            if abs(result) > MAX_ABS_RESULT:
                raise CalculatorError("Result is too large")
            return result
        raise CalculatorError("Unsupported operation")

    result = visit(tree)
    return int(result) if isinstance(result, float) and result.is_integer() else result
