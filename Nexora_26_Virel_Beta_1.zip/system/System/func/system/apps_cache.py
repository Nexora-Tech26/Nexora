import threading
from load_modules import get_apps, get_app_name

app_cache = []
app_cache_ready = False
app_cache_loading = False


def is_app_cache_ready():
    return app_cache_ready


def get_cached_apps():
    return app_cache


def filter_cached_apps(query=""):
    query = (query or "").strip().lower()
    if not query:
        return app_cache
    return [entry for entry in app_cache if query in entry.get("name", "").lower()]


def preload_apps_background(ui=None, on_finish=None, prepare_entry=None):
    global app_cache_ready, app_cache_loading

    if app_cache_ready or app_cache_loading:
        if on_finish is not None:
            if ui is not None:
                ui.after(0, on_finish)
            else:
                on_finish()
        return

    app_cache_loading = True

    def worker():
        global app_cache, app_cache_ready, app_cache_loading
        entries = []
        try:
            for index, file in enumerate(get_apps()):
                entry = {"file": file, "name": get_app_name(file), "index": index}
                if prepare_entry is not None:
                    entry = prepare_entry(entry)
                entries.append(entry)
        except Exception as e:
            print(f"Error: could not preload apps: {e}")

        def finish():
            global app_cache, app_cache_ready, app_cache_loading
            app_cache = entries
            app_cache_ready = True
            app_cache_loading = False
            if on_finish is not None:
                on_finish()

        if ui is not None:
            try:
                ui.after(0, finish)
            except Exception:
                finish()
        else:
            finish()

    threading.Thread(target=worker, daemon=True).start()


class AppsCache:
    def __init__(self, ui=None, prepare_entry=None, on_finish=None):
        self.ui = ui
        self.prepare_entry = prepare_entry
        self.on_finish = on_finish

    def preload(self):
        preload_apps_background(ui=self.ui, prepare_entry=self.prepare_entry, on_finish=self.on_finish)

    def is_ready(self):
        return is_app_cache_ready()

    def filter(self, query=""):
        return filter_cached_apps(query)

    def get_all(self):
        return get_cached_apps()
