"""Integrity verification for packaged Nexora files.

The verifier is deliberately fail-open for recoverable packaging mistakes: it logs
changes and returns a clear status instead of permanently bricking an installation.
Release builds can opt into strict mode with NEXORA_INTEGRITY_STRICT=1.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import sys
from pathlib import Path

SAVE_FILE_NAME = "AC-SAVE.txt"
IGNORED_NAMES = {".DS_Store", SAVE_FILE_NAME, "BLOCK"}
IGNORED_DIRS = {"__pycache__", ".git", ".pytest_cache"}


def is_debug_mode() -> bool:
    return os.environ.get("ANTICRACK_DEBUG") == "1" or sys.gettrace() is not None


def should_ignore_relative_path(relative_path: str) -> bool:
    path = Path(relative_path)
    return (
        path.name in IGNORED_NAMES
        or any(part in IGNORED_DIRS for part in path.parts)
        or (path.parts and path.parts[0] == "data")
    )


def hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def get_paths(core_file: str):
    system_path = Path(__file__).resolve().parents[2]
    data_path = Path(core_file).resolve().parents[2] / "data"
    return system_path, data_path, data_path / SAVE_FILE_NAME, data_path / "BLOCK"


def scan_system_folder(system_path: Path) -> dict:
    result = {}
    for path in sorted(system_path.rglob("*")):
        if path.is_file():
            relative = path.relative_to(system_path).as_posix()
            if not should_ignore_relative_path(relative):
                result[relative] = {"path": relative, "size": path.stat().st_size, "sha256": hash_file(path)}
    return result


def save_snapshot(save_path: Path, snapshot: dict) -> None:
    save_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"version": 2, "algorithm": "sha256", "files": snapshot}
    temp = save_path.with_suffix(".tmp")
    temp.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    temp.replace(save_path)


def load_snapshot(save_path: Path) -> dict:
    data = json.loads(save_path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Integrity manifest must be an object")
    files = data.get("files", data)  # migration from the legacy flat mapping
    if not isinstance(files, dict):
        raise ValueError("Integrity manifest has no valid files section")
    normalized = {}
    for name, value in files.items():
        if should_ignore_relative_path(name):
            continue
        if isinstance(value, str):
            normalized[name] = {"path": name, "size": None, "sha256": value}
        elif isinstance(value, dict) and isinstance(value.get("sha256"), str):
            normalized[name] = {"path": name, "size": value.get("size"), "sha256": value["sha256"]}
        else:
            raise ValueError(f"Invalid manifest entry: {name}")
    return normalized


def compare_snapshots(saved: dict, current: dict):
    deleted = sorted(set(saved) - set(current))
    added = sorted(set(current) - set(saved))
    changed = []
    for name in sorted(set(saved) & set(current)):
        old, new = saved[name], current[name]
        size_changed = old.get("size") is not None and old.get("size") != new.get("size")
        if old.get("sha256") != new.get("sha256") or size_changed:
            changed.append(name)
    return deleted, added, changed


def main(core_file: str) -> bool:
    log = logging.getLogger("nexora.integrity")
    system_path, data_path, save_path, block_path = get_paths(core_file)
    data_path.mkdir(parents=True, exist_ok=True)
    block_path.unlink(missing_ok=True)  # migrate away from obsolete permanent lockouts
    if not system_path.is_dir():
        log.error("System directory is missing: %s", system_path)
        return False
    current = scan_system_folder(system_path)
    if is_debug_mode() or not save_path.exists():
        save_snapshot(save_path, current)
        log.info("Integrity manifest generated (%d files)", len(current))
        return True
    try:
        saved = load_snapshot(save_path)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        log.warning("Invalid integrity manifest; regenerating: %s", exc)
        save_snapshot(save_path, current)
        return True
    deleted, added, changed = compare_snapshots(saved, current)
    if deleted or added or changed:
        log.warning("Integrity differences: deleted=%s added=%s changed=%s", deleted, added, changed)
        if os.environ.get("NEXORA_INTEGRITY_STRICT") == "1":
            return False
        save_snapshot(save_path, current)
    return True
