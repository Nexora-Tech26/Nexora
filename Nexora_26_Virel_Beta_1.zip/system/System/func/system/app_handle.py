from pathlib import Path


def get_nexora_root():
    current_file = Path(__file__).resolve()

    for parent in current_file.parents:
        if parent.name == "Nexora":
            return parent

    raise FileNotFoundError("Nie znaleziono folderu Nexora")


def get_apps_folder():
    nexora_root = get_nexora_root()
    return nexora_root / "System" / "sys" / "resources" / "apps"


def get_apps():
    apps_folder = get_apps_folder()

    if not apps_folder.exists():
        return []

    return [
        file for file in apps_folder.glob("*.py")
        if file.name != "app_handle.py"
    ]


def get_app_name(file):
    return file.stem.replace("_", " ")


def search_apps(query):
    query = query.lower().strip()

    if query == "":
        return get_apps()

    return [
        file for file in get_apps()
        if query in get_app_name(file).lower()
    ]