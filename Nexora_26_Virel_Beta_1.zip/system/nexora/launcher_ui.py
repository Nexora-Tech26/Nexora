"""Mouse-first graphical boot and recovery launcher styled as Nexora."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Callable

from PySide6.QtCore import QEasingCurve, QPropertyAnimation, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QKeySequence, QLinearGradient, QPainter, QPixmap, QShortcut
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QDialog, QFrame, QGraphicsDropShadowEffect,
    QHBoxLayout, QLabel, QMainWindow, QMessageBox, QPushButton, QScrollArea,
    QSizePolicy, QStackedWidget, QVBoxLayout, QWidget,
)

from .recovery import RecoveryManager


class LaunchCard(QPushButton):
    def __init__(self, title: str, description: str, badge: str = "", parent=None):
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(92)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 14, 20, 14)
        layout.setSpacing(4)
        row = QHBoxLayout()
        title_label = QLabel(title)
        title_label.setObjectName("cardTitle")
        row.addWidget(title_label)
        row.addStretch(1)
        if badge:
            badge_label = QLabel(badge)
            badge_label.setObjectName("badge")
            row.addWidget(badge_label)
        layout.addLayout(row)
        desc = QLabel(description)
        desc.setObjectName("cardDescription")
        desc.setWordWrap(True)
        layout.addWidget(desc)


class ConfirmResetDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Przywracanie fabryczne")
        self.setModal(True)
        self.setMinimumWidth(520)
        root = QVBoxLayout(self)
        root.setContentsMargins(26, 24, 26, 24)
        root.setSpacing(14)
        title = QLabel("Przywrócić Nexorę do ustawień fabrycznych?")
        title.setObjectName("dialogTitle")
        root.addWidget(title)
        info = QLabel(
            "Zostaną usunięte ustawienia, zapisana sesja, stan aplikacji i lokalne dane Nexory. "
            "Przed resetem zostanie automatycznie utworzony snapshot odzyskiwania. Twoje zwykłe pliki poza katalogiem Nexory nie zostaną usunięte."
        )
        info.setWordWrap(True)
        root.addWidget(info)
        self.check = QCheckBox("Rozumiem, że lokalne dane Nexory zostaną zresetowane")
        root.addWidget(self.check)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Anuluj")
        cancel.clicked.connect(self.reject)
        self.reset = QPushButton("Przywróć fabryczne")
        self.reset.setObjectName("dangerButton")
        self.reset.setEnabled(False)
        self.reset.clicked.connect(self.accept)
        self.check.toggled.connect(self.reset.setEnabled)
        buttons.addWidget(cancel)
        buttons.addWidget(self.reset)
        root.addLayout(buttons)


class LauncherWindow(QMainWindow):
    launch_requested = Signal(list)

    def __init__(self, root: Path, data_dir: Path):
        super().__init__()
        self.root = Path(root)
        self.manager = RecoveryManager(data_dir)
        self.setWindowTitle("Centrum uruchamiania Nexory")
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self.wallpaper_path = self.root / "system" / "System" / "UI" / "Wallpapers" / "Nexora Aurora Contrast 4K.png"
        if not self.wallpaper_path.exists():
            self.wallpaper_path = self.root / "system" / "System" / "UI" / "wallpaper.png"
        self._wallpaper = QPixmap(str(self.wallpaper_path))
        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)
        self.stack.addWidget(self._build_boot_page())
        self.stack.addWidget(self._build_recovery_page())
        self.stack.addWidget(self._build_advanced_page())
        self._apply_style()
        QShortcut(QKeySequence(Qt.Key.Key_Escape), self, activated=self._go_back_or_close)
        QTimer.singleShot(20, self._animate_in)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        if not self._wallpaper.isNull():
            scaled = self._wallpaper.scaled(
                self.size(), Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation,
            )
            x = (scaled.width() - self.width()) // 2
            y = (scaled.height() - self.height()) // 2
            painter.drawPixmap(self.rect(), scaled, scaled.rect().adjusted(x, y, -x, -y))
        else:
            painter.fillRect(self.rect(), QColor(8, 15, 31))
        overlay = QLinearGradient(0, 0, self.width(), self.height())
        overlay.setColorAt(0.0, QColor(7, 14, 29, 118))
        overlay.setColorAt(0.55, QColor(10, 20, 42, 154))
        overlay.setColorAt(1.0, QColor(5, 10, 24, 205))
        painter.fillRect(self.rect(), overlay)
        super().paintEvent(event)

    def _shell(self, title: str, subtitle: str) -> tuple[QWidget, QVBoxLayout]:
        page = QWidget()
        root = QVBoxLayout(page)
        root.setContentsMargins(64, 42, 64, 46)
        root.setSpacing(18)
        top = QHBoxLayout()
        brand = QLabel("NEXORA")
        brand.setObjectName("brand")
        top.addWidget(brand)
        top.addStretch(1)
        version = QLabel("26 Virel Beta 1")
        version.setObjectName("version")
        top.addWidget(version)
        root.addLayout(top)
        heading = QLabel(title)
        heading.setObjectName("heading")
        root.addWidget(heading)
        sub = QLabel(subtitle)
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        root.addWidget(sub)
        return page, root

    def _build_boot_page(self) -> QWidget:
        page, root = self._shell(
            "Centrum uruchamiania",
            "Wybierz sposób uruchomienia Nexory. Wszystkie opcje są dostępne myszką i klawiaturą.",
        )
        cards = QVBoxLayout()
        cards.setSpacing(12)
        normal = LaunchCard("Uruchom Nexorę", "Normalny start ze wszystkimi funkcjami, efektami i przywracaniem sesji.", "ZALECANE")
        normal.clicked.connect(lambda: self._launch([]))
        safe = LaunchCard("Tryb awaryjny", "Uruchomienie ratunkowe bez poprzedniej sesji, ciężkich efektów i automatyzacji.", "AWARYJNY")
        safe.clicked.connect(lambda: self._launch(["--safe-mode", "--no-webengine"]))
        recovery = LaunchCard("Tryb odzyskiwania", "Naprawa systemu, diagnostyka, kopie odzyskiwania oraz reset ustawień i sesji.")
        recovery.clicked.connect(lambda: self.stack.setCurrentIndex(1))
        advanced = LaunchCard("Opcje zaawansowane", "Tryb offline, start bez WebEngine, diagnostyka i bezpośredni start.")
        advanced.clicked.connect(lambda: self.stack.setCurrentIndex(2))
        for card in (normal, safe, recovery, advanced):
            cards.addWidget(card)
        root.addLayout(cards)
        root.addStretch(1)
        footer = QHBoxLayout()
        status = QLabel("Sterowanie: mysz • Enter • strzałki • Esc")
        status.setObjectName("footer")
        footer.addWidget(status)
        footer.addStretch(1)
        quit_button = QPushButton("Wyjdź")
        quit_button.clicked.connect(self.close)
        footer.addWidget(quit_button)
        root.addLayout(footer)
        return page

    def _build_recovery_page(self) -> QWidget:
        page, root = self._shell(
            "Tryb odzyskiwania",
            "Bezpieczne narzędzia naprawy Nexory. Przed każdą zmianą tworzona jest lokalna kopia odzyskiwania.",
        )
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        body = QWidget()
        items = QVBoxLayout(body)
        items.setContentsMargins(0, 0, 6, 0)
        items.setSpacing(12)
        actions: list[tuple[str, str, Callable[[], None], str]] = [
            ("Uruchom tryb awaryjny", "Otwórz Nexorę z bezpiecznymi ustawieniami bez poprzedniej sesji.", lambda: self._launch(["--safe-mode", "--no-webengine"]), "START"),
            ("Zresetuj ustawienia UI", "Przywróć domyślny motyw, skalę, szkło, kolory i animacje.", self._reset_settings, "SNAPSHOT"),
            ("Wyczyść zapisaną sesję", "Usuń stan okien, aplikacji i workspace bez kasowania innych ustawień.", self._reset_session, "SNAPSHOT"),
            ("Wyczyść pamięć podręczną", "Usuń miniatury, cache WebEngine i pliki tymczasowe.", self._clear_cache, "SNAPSHOT"),
            ("Przywróć ostatni snapshot", "Odtwórz najnowszy automatyczny snapshot odzyskiwania.", self._restore_latest, "ODZYSKIWANIE"),
            ("Diagnostyka systemu", "Pokaż raport środowiska, zależności i katalogów danych.", self._show_diagnostics, "RAPORT"),
            ("Ustawienia fabryczne", "Zresetuj wszystkie lokalne dane Nexory po utworzeniu kopii bezpieczeństwa.", self._factory_reset, "OSTROŻNIE"),
        ]
        for title, desc, handler, badge in actions:
            card = LaunchCard(title, desc, badge)
            card.clicked.connect(handler)
            if title == "Ustawienia fabryczne":
                card.setObjectName("dangerCard")
            items.addWidget(card)
        items.addStretch(1)
        scroll.setWidget(body)
        root.addWidget(scroll, 1)
        root.addLayout(self._back_row())
        return page

    def _build_advanced_page(self) -> QWidget:
        page, root = self._shell("Opcje zaawansowane", "Warianty uruchamiania przeznaczone do diagnostyki i ograniczonych środowisk.")
        options = [
            ("Tryb offline", "Uruchom bez funkcji wymagających połączenia sieciowego.", ["--offline"]),
            ("Bez WebEngine", "Uruchom bez silnika Chromium i aplikacji Browser.", ["--no-webengine"]),
            ("Offline + Safe Mode", "Najbardziej ograniczony start ratunkowy.", ["--offline", "--safe-mode", "--no-webengine"]),
            ("Czysty start", "Uruchom po wyczyszczeniu zapisanej sesji, ale zachowaj ustawienia.", ["--reset-session"]),
        ]
        for title, desc, args in options:
            card = LaunchCard(title, desc)
            card.clicked.connect(lambda checked=False, value=args: self._launch(value))
            root.addWidget(card)
        root.addStretch(1)
        root.addLayout(self._back_row())
        return page

    def _back_row(self) -> QHBoxLayout:
        row = QHBoxLayout()
        back = QPushButton("← Wróć")
        back.clicked.connect(lambda: self.stack.setCurrentIndex(0))
        row.addWidget(back)
        row.addStretch(1)
        return row

    def _launch(self, flags: list[str]) -> None:
        command = [sys.executable, str(self.root / "Nexora.py"), "run", "--direct", *flags]
        try:
            subprocess.Popen(command, cwd=self.root)
        except OSError as exc:
            QMessageBox.critical(self, "Nie można uruchomić Nexory", str(exc))
            return
        QApplication.instance().quit()

    def _result(self, result) -> None:
        detail = result.message
        if result.snapshot:
            detail += f"\n\nSnapshot: {result.snapshot}"
        if result.success:
            QMessageBox.information(self, "Tryb odzyskiwania", detail)
        else:
            QMessageBox.critical(self, "Tryb odzyskiwania", detail)

    def _reset_settings(self): self._result(self.manager.reset_settings())
    def _reset_session(self): self._result(self.manager.reset_session())
    def _clear_cache(self): self._result(self.manager.clear_cache())

    def _restore_latest(self) -> None:
        snapshots = self.manager.list_snapshots()
        if not snapshots:
            QMessageBox.information(self, "Tryb odzyskiwania", "Nie znaleziono żadnych snapshotów odzyskiwania.")
            return
        answer = QMessageBox.question(self, "Przywrócić kopię odzyskiwania?", f"Przywrócić najnowszą kopię odzyskiwania?\n\n{snapshots[0].name}")
        if answer == QMessageBox.StandardButton.Yes:
            self._result(self.manager.restore_snapshot(snapshots[0]))

    def _factory_reset(self) -> None:
        dialog = ConfirmResetDialog(self)
        dialog.setStyleSheet(self.styleSheet())
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self._result(self.manager.factory_reset())

    def _show_diagnostics(self) -> None:
        command = [sys.executable, str(self.root / "Nexora.py"), "diagnostics"]
        try:
            result = subprocess.run(command, cwd=self.root, text=True, capture_output=True, timeout=20, check=False)
            text = result.stdout or result.stderr or "Brak danych diagnostycznych."
        except (OSError, subprocess.SubprocessError) as exc:
            text = str(exc)
        box = QMessageBox(self)
        box.setWindowTitle("Diagnostyka Nexory")
        box.setText("Raport diagnostyczny")
        box.setDetailedText(text)
        box.setIcon(QMessageBox.Icon.Information)
        box.exec()

    def _go_back_or_close(self) -> None:
        if self.stack.currentIndex() != 0:
            self.stack.setCurrentIndex(0)
        else:
            self.close()

    def _animate_in(self) -> None:
        self.setWindowOpacity(0.0)
        animation = QPropertyAnimation(self, b"windowOpacity", self)
        animation.setDuration(220)
        animation.setStartValue(0.0)
        animation.setEndValue(1.0)
        animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        animation.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped)

    def _apply_style(self) -> None:
        self.setFont(QFont(self.font().family(), 11))
        self.setStyleSheet("""
            QWidget { color: #F7F9FF; background: transparent; }
            QLabel#brand { font-size: 18px; font-weight: 800; letter-spacing: 4px; color: #8FB7FF; }
            QLabel#version { color: rgba(232,239,255,155); font-size: 13px; }
            QLabel#heading { font-size: 34px; font-weight: 750; margin-top: 8px; }
            QLabel#subtitle { color: rgba(232,239,255,180); font-size: 14px; margin-bottom: 8px; }
            QLabel#footer { color: rgba(232,239,255,125); font-size: 12px; }
            QLabel#cardTitle { font-size: 17px; font-weight: 700; }
            QLabel#cardDescription { color: rgba(232,239,255,170); font-size: 13px; }
            QLabel#badge { background: rgba(78,137,255,45); color: #AFCBFF; border-radius: 9px; padding: 3px 9px; font-size: 10px; font-weight: 700; }
            QLabel#dialogTitle { font-size: 20px; font-weight: 750; }
            QPushButton { background: rgba(255,255,255,18); border: 1px solid rgba(255,255,255,20); border-radius: 14px; padding: 10px 18px; font-weight: 650; }
            QPushButton:hover { background: rgba(255,255,255,30); border-color: rgba(122,170,255,85); }
            QPushButton:pressed { background: rgba(91,143,255,55); }
            QPushButton:focus { border-color: rgba(125,174,255,180); }
            QPushButton LaunchCard, LaunchCard { text-align: left; background: rgba(18,30,55,172); border-radius: 24px; border: 1px solid rgba(255,255,255,34); padding: 0px; }
            LaunchCard:hover { background: rgba(68,112,205,150); border-color: rgba(158,194,255,165); }
            LaunchCard:pressed { background: rgba(76,126,225,58); }
            LaunchCard#dangerCard:hover { background: rgba(255,80,100,35); border-color: rgba(255,110,130,100); }
            QPushButton#dangerButton { background: rgba(220,55,80,120); }
            QPushButton#dangerButton:hover { background: rgba(235,65,90,155); }
            QScrollArea { background: transparent; }
            QScrollBar:vertical { width: 8px; background: transparent; }
            QScrollBar::handle:vertical { background: rgba(255,255,255,40); border-radius: 4px; min-height: 40px; }
            QDialog, QMessageBox { background: rgba(13,24,45,245); }
            QCheckBox { spacing: 10px; }
        """)


def run_launcher(root: Path, data_dir: Path, *, recovery: bool = False) -> int:
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Centrum uruchamiania Nexory")
    window = LauncherWindow(root, data_dir)
    if recovery:
        window.stack.setCurrentIndex(1)
    window.showFullScreen()
    window.raise_()
    window.activateWindow()
    return app.exec()
