"""Allow ``python -m nexora``."""
from nexora.app import main

raise SystemExit(main())
