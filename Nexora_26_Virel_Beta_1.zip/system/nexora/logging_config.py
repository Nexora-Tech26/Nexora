"""Central rotating logging configuration for Nexora."""
from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path


def configure(log_file: Path, *, debug: bool = False) -> logging.Logger:
    log_file = Path(log_file)
    log_file.parent.mkdir(parents=True, exist_ok=True)
    level = logging.DEBUG if debug else logging.INFO
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")
    file_handler = RotatingFileHandler(log_file, maxBytes=2 * 1024 * 1024, backupCount=4, encoding="utf-8")
    file_handler.setFormatter(formatter); file_handler.setLevel(level)
    stream_handler = logging.StreamHandler(sys.stderr)
    stream_handler.setFormatter(formatter); stream_handler.setLevel(level)
    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)
        try: handler.close()
        except OSError as exc:
            logging.getLogger(__name__).debug("Handler close failed: %s", exc)
    root.setLevel(level); root.addHandler(file_handler); root.addHandler(stream_handler)
    logging.captureWarnings(True)
    return logging.getLogger("nexora")
