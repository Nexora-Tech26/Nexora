"""Privacy-conscious local crash report writer."""
from __future__ import annotations

import json
import platform
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Type

from nexora.paths import DATA_DIR


def write_exception(exc_type: Type[BaseException], exc: BaseException, tb) -> Path:
    crash_dir = DATA_DIR / "crashes"
    crash_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    target = crash_dir / f"crash-{stamp}.json"
    payload = {
        "timestamp_utc": stamp,
        "python": sys.version,
        "platform": platform.platform(),
        "exception": exc_type.__name__,
        "message": str(exc),
        "traceback": "".join(traceback.format_exception(exc_type, exc, tb)),
    }
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return target
