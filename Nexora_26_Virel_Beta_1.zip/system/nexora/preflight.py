from __future__ import annotations

import importlib
import platform
import sys

MIN_PYTHON = (3, 10)
MAX_PYTHON = (3, 13)
REQUIRED = ("PySide6", "PIL", "psutil")

def check() -> list[str]:
    errors: list[str] = []
    version = sys.version_info[:2]
    if version < MIN_PYTHON or version > MAX_PYTHON:
        errors.append(f"Python {version[0]}.{version[1]} is unsupported; use Python 3.10-3.13.")
    if platform.system() not in {"Windows", "Darwin", "Linux"}:
        errors.append(f"Unsupported operating system: {platform.system()}.")
    for module in REQUIRED:
        try:
            importlib.import_module(module)
        except Exception as exc:
            errors.append(f"Missing or broken dependency {module}: {exc}")
    return errors

def main() -> int:
    errors = check()
    if errors:
        print("Nexora preflight failed:")
        for error in errors:
            print(f" - {error}")
        return 1
    print("Nexora preflight passed.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
