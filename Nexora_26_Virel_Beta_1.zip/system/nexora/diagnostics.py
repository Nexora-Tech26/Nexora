"""Portable diagnostics that do not import the graphical interface."""
from __future__ import annotations

import importlib.util
import json
import os
import platform
import shutil
import sys
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(frozen=True)
class DiagnosticResult:
    name: str
    passed: bool
    detail: str
    severity: str = "required"


def _module(name: str, *, required: bool = True) -> DiagnosticResult:
    spec = importlib.util.find_spec(name)
    return DiagnosticResult(
        name,
        spec is not None or not required,
        "installed" if spec else "missing",
        "required" if required else "optional",
    )


def collect() -> list[DiagnosticResult]:
    version_ok = (3, 10) <= sys.version_info[:2] <= (3, 13)
    writable = os.access(Path.home(), os.W_OK)
    free = shutil.disk_usage(Path.home()).free
    results = [
        DiagnosticResult("python", version_ok, platform.python_version()),
        DiagnosticResult("platform", platform.system() in {"Windows", "Darwin", "Linux"}, platform.platform()),
        DiagnosticResult("home-writable", writable, str(Path.home())),
        DiagnosticResult("disk-space", free >= 512 * 1024 * 1024, f"{free / 1024**3:.2f} GiB free"),
        _module("PySide6"),
        _module("PIL"),
        _module("psutil"),
        _module("PySide6.QtWebEngineWidgets", required=False),
        _module("objc", required=False),
    ]
    return results


def all_passed() -> bool:
    return all(item.passed for item in collect() if item.severity == "required")


def as_json() -> str:
    return json.dumps({"passed": all_passed(), "results": [asdict(x) for x in collect()]}, indent=2)


def main() -> int:
    print(as_json())
    return 0 if all_passed() else 1


if __name__ == "__main__":
    raise SystemExit(main())
