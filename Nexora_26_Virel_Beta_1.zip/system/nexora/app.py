"""Stable public application entry point for Nexora."""
from __future__ import annotations

import importlib


def main() -> int:
    """Validate the runtime and start the application kernel.

    The kernel is imported normally so debuggers, type checkers and test
    runners see one canonical module instead of an isolated isolated execution namespace.
    """
    from nexora.preflight import check

    errors = check()
    if errors:
        raise RuntimeError("\n".join(errors))

    core = importlib.import_module("System.sys.core.core")
    return int(core.main())
