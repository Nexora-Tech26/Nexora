"""Writable, platform-appropriate runtime locations for Nexora."""
from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path


def _application_root() -> Path:
    override = os.environ.get("NEXORA_DATA_HOME", "").strip()
    if override:
        return Path(override).expanduser().resolve()
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        return base / "Nexora"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Nexora"
    base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "nexora"


APP_DATA_ROOT = _application_root()
DATA_DIR = APP_DATA_ROOT / "data"
HOME_DIR = APP_DATA_ROOT / "Home" / "User"


def ensure_runtime_paths(*, legacy_data: Path | None = None, legacy_home: Path | None = None) -> None:
    """Create writable locations and copy legacy state once without overwriting data."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for name in ("Desktop", "Documents", "Downloads", "Images", "Music", "Videos", "Shared", "Cloud Drive", ".Trash"):
        (HOME_DIR / name).mkdir(parents=True, exist_ok=True)

    marker = APP_DATA_ROOT / ".migrated-v26"
    if marker.exists():
        return
    if legacy_data and legacy_data.is_dir() and legacy_data.resolve() != DATA_DIR.resolve():
        for source in legacy_data.iterdir():
            if not source.is_file() or source.suffix in {".tmp", ".log"}:
                continue
            target = DATA_DIR / source.name
            if not target.exists():
                try:
                    shutil.copy2(source, target)
                except OSError:
                    pass
    if legacy_home and legacy_home.is_dir() and legacy_home.resolve() != HOME_DIR.resolve():
        try:
            shutil.copytree(legacy_home, HOME_DIR, dirs_exist_ok=True)
        except OSError:
            pass
    try:
        marker.touch(exist_ok=True)
    except OSError:
        pass
