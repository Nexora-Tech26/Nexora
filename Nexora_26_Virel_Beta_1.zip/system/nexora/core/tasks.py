"""Reusable non-blocking Qt task runner."""
from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from PySide6.QtCore import QObject, QRunnable, QThreadPool, Signal, Slot

LOG = logging.getLogger("nexora.tasks")


class TaskSignals(QObject):
    succeeded = Signal(object)
    failed = Signal(str)
    finished = Signal()


class Task(QRunnable):
    def __init__(self, function: Callable[..., Any], *args: Any, **kwargs: Any) -> None:
        super().__init__()
        self.function = function
        self.args = args
        self.kwargs = kwargs
        self.signals = TaskSignals()
        self.setAutoDelete(True)

    @Slot()
    def run(self) -> None:
        try:
            self.signals.succeeded.emit(self.function(*self.args, **self.kwargs))
        except Exception as exc:  # boundary: convert worker failures into UI-safe signals
            LOG.exception("Background task failed")
            self.signals.failed.emit(str(exc))
        finally:
            self.signals.finished.emit()


def submit(
    function: Callable[..., Any],
    *args: Any,
    on_success: Callable[[Any], None] | None = None,
    on_error: Callable[[str], None] | None = None,
    on_finished: Callable[[], None] | None = None,
    **kwargs: Any,
) -> Task:
    task = Task(function, *args, **kwargs)
    if on_success:
        task.signals.succeeded.connect(on_success)
    if on_error:
        task.signals.failed.connect(on_error)
    if on_finished:
        task.signals.finished.connect(on_finished)
    QThreadPool.globalInstance().start(task)
    return task
