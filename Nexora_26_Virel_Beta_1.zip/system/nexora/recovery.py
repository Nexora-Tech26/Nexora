"""Recovery operations for Nexora's graphical boot launcher.

All destructive operations create a local recovery snapshot first. The module
uses only the standard library, so it can be tested without importing Qt.
"""
from __future__ import annotations

import json
import os
import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class RecoveryResult:
    action: str
    success: bool
    message: str
    snapshot: Path | None = None


class RecoveryManager:
    """Perform controlled reset and restoration operations in the data folder."""

    SETTINGS_NAMES = ("settings.json", "settings.json.bak")
    SESSION_NAMES = (
        "session.json", "session.json.bak", "session_layout.json",
        "workspace_context.json", "workspace_context.json.bak", "session.active",
    )
    CACHE_NAMES = ("cache", "thumbnails", "webengine", "tmp")
    PRESERVE_NAMES = ("logs", "recovery_snapshots")

    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir).expanduser().resolve()
        self.snapshots_dir = self.data_dir / "recovery_snapshots"

    def ensure(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.snapshots_dir.mkdir(parents=True, exist_ok=True)

    def create_snapshot(self, label: str = "manual") -> Path:
        self.ensure()
        safe_label = "".join(ch for ch in label.lower() if ch.isalnum() or ch in "-_") or "snapshot"
        stamp = time.strftime("%Y%m%d-%H%M%S")
        target = self.snapshots_dir / f"{stamp}-{safe_label}"
        suffix = 1
        while target.exists():
            target = self.snapshots_dir / f"{stamp}-{safe_label}-{suffix}"
            suffix += 1
        target.mkdir(parents=True)
        for item in self.data_dir.iterdir():
            if item.name in self.PRESERVE_NAMES or item == target:
                continue
            destination = target / item.name
            try:
                if item.is_dir():
                    shutil.copytree(item, destination, symlinks=True)
                elif item.is_file():
                    shutil.copy2(item, destination)
            except OSError:
                continue
        manifest = {
            "schema": 1,
            "created_at": time.time(),
            "label": safe_label,
            "source": str(self.data_dir),
        }
        (target / "snapshot.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        return target

    def list_snapshots(self) -> tuple[Path, ...]:
        self.ensure()
        return tuple(sorted((p for p in self.snapshots_dir.iterdir() if p.is_dir()), reverse=True))

    def restore_snapshot(self, snapshot: Path) -> RecoveryResult:
        self.ensure()
        snapshot = Path(snapshot).resolve()
        try:
            snapshot.relative_to(self.snapshots_dir.resolve())
        except ValueError:
            return RecoveryResult("restore_snapshot", False, "Nieprawidłowa lokalizacja snapshotu.")
        if not snapshot.is_dir():
            return RecoveryResult("restore_snapshot", False, "Snapshot nie istnieje.")
        safety = self.create_snapshot("before-restore")
        self._clear_user_state(preserve_snapshots=True)
        for item in snapshot.iterdir():
            if item.name == "snapshot.json":
                continue
            destination = self.data_dir / item.name
            try:
                if item.is_dir():
                    shutil.copytree(item, destination, dirs_exist_ok=True, symlinks=True)
                elif item.is_file():
                    shutil.copy2(item, destination)
            except OSError as exc:
                return RecoveryResult("restore_snapshot", False, f"Nie udało się odtworzyć: {exc}", safety)
        return RecoveryResult("restore_snapshot", True, "Snapshot został przywrócony.", safety)

    def reset_settings(self) -> RecoveryResult:
        snapshot = self.create_snapshot("before-settings-reset")
        self._remove_names(self.SETTINGS_NAMES)
        return RecoveryResult("reset_settings", True, "Ustawienia wyglądu i zachowania przywrócono do domyślnych.", snapshot)

    def reset_session(self) -> RecoveryResult:
        snapshot = self.create_snapshot("before-session-reset")
        self._remove_names(self.SESSION_NAMES)
        return RecoveryResult("reset_session", True, "Zapisane okna, aplikacje i sesja zostały wyczyszczone.", snapshot)

    def clear_cache(self) -> RecoveryResult:
        snapshot = self.create_snapshot("before-cache-clean")
        self._remove_names(self.CACHE_NAMES)
        return RecoveryResult("clear_cache", True, "Pamięć podręczna Nexory została wyczyszczona.", snapshot)

    def factory_reset(self) -> RecoveryResult:
        snapshot = self.create_snapshot("before-factory-reset")
        self._clear_user_state(preserve_snapshots=True)
        marker = self.data_dir / "factory_reset.json"
        marker.write_text(json.dumps({"schema": 1, "reset_at": time.time()}, indent=2), encoding="utf-8")
        return RecoveryResult(
            "factory_reset", True,
            "Dane Nexory przywrócono do stanu fabrycznego. Kopia poprzedniego stanu została zachowana.",
            snapshot,
        )

    def _remove_names(self, names: Iterable[str]) -> None:
        for name in names:
            path = self.data_dir / name
            try:
                if path.is_dir():
                    shutil.rmtree(path)
                else:
                    path.unlink(missing_ok=True)
            except OSError:
                continue

    def _clear_user_state(self, *, preserve_snapshots: bool) -> None:
        self.ensure()
        for item in tuple(self.data_dir.iterdir()):
            if item.name == "logs":
                continue
            if preserve_snapshots and item.name == "recovery_snapshots":
                continue
            try:
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink(missing_ok=True)
            except OSError:
                continue
