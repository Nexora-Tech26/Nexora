from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from System.settings.store import DEFAULTS, SettingsStore, migrate_settings, validate_settings


class SettingsTests(unittest.TestCase):
    def test_release_defaults(self) -> None:
        self.assertEqual(DEFAULTS["language"], "pl")
        self.assertEqual(DEFAULTS["update_channel"], "preview")
        self.assertGreaterEqual(DEFAULTS["ui_scale"], 1.0)
        self.assertLessEqual(DEFAULTS["blur_radius"], 48)
        self.assertFalse(any(key.startswith("ai_") for key in DEFAULTS))

    def test_validation_clamps_values(self) -> None:
        settings = validate_settings({"ui_scale": 99, "blur_radius": 999, "battery_saver_threshold": 0})
        self.assertEqual(settings["ui_scale"], 2.0)
        self.assertEqual(settings["blur_radius"], 48)
        self.assertEqual(settings["battery_saver_threshold"], 5)

    def test_migration_removes_unknown_ai_defaults(self) -> None:
        settings = migrate_settings({"schema_version": 1, "ai_model": "old"})
        self.assertNotIn("ai_local_only", settings)
        self.assertEqual(settings["ui_scale"], 1.0)

    def test_atomic_round_trip(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "settings.json"
            store = SettingsStore(path, debounce_ms=0)
            store.update({"language": "pl", "accent_color": "#123456"}, save=False)
            store.flush()
            payload = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(payload["language"], "pl")
            self.assertEqual(SettingsStore(path).get("accent_color"), "#123456")


if __name__ == "__main__":
    unittest.main()
