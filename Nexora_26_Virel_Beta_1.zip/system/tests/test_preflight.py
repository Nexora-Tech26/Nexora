from __future__ import annotations

import unittest
from unittest.mock import patch

from nexora import preflight


class PreflightTests(unittest.TestCase):
    def test_supported_platform_set(self) -> None:
        with patch("platform.system", return_value="Plan9"):
            errors = preflight.check()
        self.assertTrue(any("Unsupported operating system" in error for error in errors))

    def test_required_modules_do_not_include_webengine(self) -> None:
        self.assertNotIn("PySide6.QtWebEngineWidgets", preflight.REQUIRED)


if __name__ == "__main__":
    unittest.main()
