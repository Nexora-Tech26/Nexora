from pathlib import Path

from System.foundation.i18n_catalog import completeness, tr_key
from System.services.action_registry import Action, ActionRegistry
from System.services.crash_center import CrashCenter
from System.services.workspace_context import WorkspaceContextStore


def test_action_registry_alias_search_and_execute():
    seen = []
    registry = ActionRegistry()
    registry.register(Action("nexora.files.open", "Open Files", lambda: seen.append("ok"), aliases=("pliki", "otwórz pliki")))
    assert registry.search("pliki")[0].action_id == "nexora.files.open"
    registry.execute("nexora.files.open")
    assert seen == ["ok"]


def test_action_registry_rejects_unstable_id():
    registry = ActionRegistry()
    try:
        registry.register(Action("files", "Files", lambda: None))
    except ValueError:
        pass
    else:
        raise AssertionError("unstable action id accepted")


def test_crash_center_persists_and_summarizes(tmp_path: Path):
    center = CrashCenter(tmp_path)
    center.record("nexora.files", "OSError", "cannot read")
    center.record("nexora.files", "OSError", "cannot read")
    center.record("nexora.paint", "ValueError", "bad image")
    assert center.summary() == {"nexora.files": 2, "nexora.paint": 1}
    center.clear("nexora.files")
    assert center.summary() == {"nexora.paint": 1}


def test_workspace_context_backup_recovery(tmp_path: Path):
    store = WorkspaceContextStore(tmp_path)
    store.save({"open_apps": ["nexora.files"], "workspace": "work", "private_secret": "drop"})
    store.save({"open_apps": ["nexora.files", "nexora.documents"], "workspace": "school"})
    store.path.write_text("broken", encoding="utf-8")
    restored = store.load()
    assert restored["workspace"] == "work"
    assert "private_secret" not in restored


def test_keyed_i18n_is_complete_for_pl_en():
    assert tr_key("common.save", "pl") == "Zapisz"
    assert tr_key("common.save", "en") == "Save"
    assert completeness("pl") == 1.0
    assert tr_key("unknown.key", "pl") == "unknown.key"
