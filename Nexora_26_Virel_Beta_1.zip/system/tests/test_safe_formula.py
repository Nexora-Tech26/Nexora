import pytest
from System.services.safe_formula import FormulaError, SafeFormulaEvaluator, iter_range


def evaluator(values=None):
    values = values or {}
    return SafeFormulaEvaluator(lambda ref: values.get(ref, 0.0))


def test_arithmetic_and_references():
    assert evaluator({"A1": 4, "B1": 3}).evaluate("=A1*2+B1") == 11


def test_range_functions():
    ev = evaluator({"A1": 1, "A2": 2, "A3": 3})
    assert ev.evaluate("=SUM(A1:A3)") == 6
    assert ev.evaluate("=AVERAGE(A1:A3)") == 2
    assert ev.evaluate("=MIN(A1:A3)") == 1
    assert ev.evaluate("=MAX(A1:A3)") == 3


def test_does_not_execute_python():
    with pytest.raises(FormulaError):
        evaluator().evaluate("=__import__('os').system('echo unsafe')")


def test_range_supports_multiple_columns():
    assert list(iter_range("Z1:AA2")) == ["Z1", "AA1", "Z2", "AA2"]
