from pathlib import Path


def test_connected_helpers_present_and_start_uses_them():
    shared = Path('system/System/gui/shared.py').read_text(encoding='utf-8')
    start = Path('system/System/gui/start_menu.py').read_text(encoding='utf-8')
    assert 'def apply_connected_group' in shared
    assert 'def connected_tabbar_css' in shared
    assert 'apply_connected_group((self.all_apps, self.power_button)' in start
    assert 'self.folder_row.setSpacing(0)' in start
    assert 'connected_tabbar_css' in start


def test_connected_middle_segments_have_no_outer_radius():
    shared = Path('system/System/gui/shared.py').read_text(encoding='utf-8')
    assert 'left = radius if position in {"single", "first"} else 0' in shared
    assert 'right = radius if position in {"single", "last"} else 0' in shared
