from __future__ import annotations

import unittest

from System.widgets.registry import create_default_registry


class WidgetRegistryTests(unittest.TestCase):
    def test_no_ai_widget(self) -> None:
        keys = {item.key for item in create_default_registry().all()}
        self.assertNotIn("ai", keys)
        self.assertIn("clipboard", keys)
        self.assertIn("system_health", keys)


if __name__ == "__main__":
    unittest.main()
