from pathlib import Path

from System.services.activity import ActivityService
from System.services.recent_items import RecentItemsStore
from System.services.session_profiles import apply_profile, profile_changes
from System.services.settings_history import SettingsHistory


def test_recent_items_are_deduplicated(tmp_path: Path):
    store = RecentItemsStore(tmp_path / "recent.json")
    store.add("file", "/tmp/demo.txt")
    store.add("file", "/tmp/demo.txt")
    assert len(store.load()) == 1


def test_settings_history_ignores_secrets(tmp_path: Path):
    history = SettingsHistory(tmp_path / "history.json")
    history.record({"theme": "light", "api_token": "old"}, {"theme": "dark", "api_token": "new"})
    changes = history.load()[0]["changes"]
    assert changes == {"theme": {"before": "light", "after": "dark"}}
    assert history.restore({"theme": "dark"})["theme"] == "light"


def test_activity_lifecycle():
    service = ActivityService()
    item = service.create("Copy", "file")
    service.update(item.identifier, progress=2.0, status="paused")
    assert service.items()[0].progress == 1.0
    assert service.items()[0].status == "paused"
    service.remove(item.identifier)
    assert service.items() == []


def test_session_profile_reports_and_applies_changes():
    current = {"performance_mode": "balanced", "ui_scale": 1.0}
    assert "performance_mode" in profile_changes("performance", current)
    updated = apply_profile("accessibility", current)
    assert updated["ui_scale"] == 1.2
    assert updated["session_profile"] == "accessibility"
