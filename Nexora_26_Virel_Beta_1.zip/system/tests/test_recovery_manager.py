from pathlib import Path

from nexora.recovery import RecoveryManager


def test_reset_settings_creates_snapshot(tmp_path: Path):
    (tmp_path / "settings.json").write_text('{"theme":"dark"}', encoding="utf-8")
    manager = RecoveryManager(tmp_path)
    result = manager.reset_settings()
    assert result.success
    assert result.snapshot and result.snapshot.is_dir()
    assert not (tmp_path / "settings.json").exists()
    assert (result.snapshot / "settings.json").is_file()


def test_reset_session_keeps_settings(tmp_path: Path):
    (tmp_path / "settings.json").write_text("{}", encoding="utf-8")
    (tmp_path / "session_layout.json").write_text("{}", encoding="utf-8")
    manager = RecoveryManager(tmp_path)
    result = manager.reset_session()
    assert result.success
    assert (tmp_path / "settings.json").exists()
    assert not (tmp_path / "session_layout.json").exists()


def test_factory_reset_preserves_logs_and_snapshot(tmp_path: Path):
    (tmp_path / "settings.json").write_text("{}", encoding="utf-8")
    logs = tmp_path / "logs"
    logs.mkdir()
    (logs / "launcher.log").write_text("log", encoding="utf-8")
    manager = RecoveryManager(tmp_path)
    result = manager.factory_reset()
    assert result.success
    assert not (tmp_path / "settings.json").exists()
    assert (tmp_path / "logs" / "launcher.log").exists()
    assert result.snapshot and result.snapshot.exists()
    assert (tmp_path / "factory_reset.json").exists()


def test_restore_latest_snapshot_roundtrip(tmp_path: Path):
    manager = RecoveryManager(tmp_path)
    (tmp_path / "settings.json").write_text('{"value":1}', encoding="utf-8")
    snapshot = manager.create_snapshot("roundtrip")
    (tmp_path / "settings.json").write_text('{"value":2}', encoding="utf-8")
    result = manager.restore_snapshot(snapshot)
    assert result.success
    assert (tmp_path / "settings.json").read_text(encoding="utf-8") == '{"value":1}'
