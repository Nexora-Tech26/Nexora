"""Nexora 26 Virel Beta 1 launcher.

Normal startup never installs packages or creates a virtual environment. Use
``python Nexora.py setup`` explicitly when dependencies must be installed.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import platform
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP_DIR = ROOT / "system"
SUPPORTED_PYTHON = ((3, 10), (3, 13))
REQUIRED = {"PySide6": "PySide6", "Pillow": "PIL", "psutil": "psutil"}
OPTIONAL = {"Qt WebEngine": "PySide6.QtWebEngineWidgets"}


def data_root() -> Path:
    override = os.environ.get("NEXORA_DATA_HOME", "").strip()
    if override:
        return Path(override).expanduser()
    if os.name == "nt":
        return Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local")) / "Nexora"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Nexora"
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "nexora"


def log_file() -> Path:
    path = data_root() / "logs" / "launcher.log"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def module_available(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ModuleNotFoundError, AttributeError, ValueError):
        return False


def diagnostics() -> dict[str, object]:
    root = data_root()
    writable = False
    try:
        root.mkdir(parents=True, exist_ok=True)
        probe = root / ".write-test"
        probe.write_text("ok", encoding="utf-8")
        probe.unlink()
        writable = True
    except OSError:
        writable = False
    return {
        "product": "Nexora 26 Virel Beta 1",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version.split()[0],
        "python_supported": SUPPORTED_PYTHON[0] <= sys.version_info[:2] <= SUPPORTED_PYTHON[1],
        "platform": platform.platform(),
        "executable": sys.executable,
        "project": str(ROOT),
        "data_directory": str(root),
        "data_directory_writable": writable,
        "required_dependencies": {label: module_available(module) for label, module in REQUIRED.items()},
        "optional_dependencies": {label: module_available(module) for label, module in OPTIONAL.items()},
    }


def print_diagnostics() -> int:
    report = diagnostics()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    required = report["required_dependencies"]
    return 0 if report["python_supported"] and report["data_directory_writable"] and all(required.values()) else 1


def setup_runtime() -> int:
    requirements = APP_DIR / "requirements.txt"
    command = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-r", str(requirements)]
    print("Explicit setup requested. Installing Nexora dependencies...")
    return subprocess.call(command, cwd=APP_DIR)


def clear_runtime_file(name: str) -> None:
    target = data_root() / name
    if target.is_file():
        target.unlink()
    elif target.is_dir():
        import shutil
        shutil.rmtree(target)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="Nexora", description="Nexora 26 Virel Beta 1 launcher")
    parser.add_argument("command", nargs="?", choices=("run", "setup", "diagnostics", "recovery"), default="run")
    parser.add_argument("--offline", action="store_true")
    parser.add_argument("--safe-mode", action="store_true")
    parser.add_argument("--reset-ui", action="store_true")
    parser.add_argument("--reset-session", action="store_true")
    parser.add_argument("--no-webengine", action="store_true")
    parser.add_argument("--direct", action="store_true", help="Start Nexora without the graphical boot center")
    parser.add_argument("--launcher", action="store_true", help="Force the graphical boot center")
    parser.add_argument("--recovery-mode", action="store_true", help="Open graphical Recovery Mode")
    return parser.parse_args()


def start(args: argparse.Namespace) -> int:
    report = diagnostics()
    missing = [name for name, ok in report["required_dependencies"].items() if not ok]
    if not report["python_supported"]:
        raise RuntimeError(f"Python {report['python']} is unsupported. Use Python 3.10–3.13.")
    if missing:
        raise RuntimeError("Missing dependencies: " + ", ".join(missing) + ". Run: python Nexora.py setup")
    if not report["data_directory_writable"]:
        raise RuntimeError(f"Nexora data directory is not writable: {report['data_directory']}")

    if args.reset_ui:
        clear_runtime_file("settings.json")
    if args.reset_session:
        clear_runtime_file("session.json")

    env = os.environ.copy()
    env["PYTHONPATH"] = str(APP_DIR) + os.pathsep + env.get("PYTHONPATH", "")
    if args.offline:
        env["NEXORA_OFFLINE"] = "1"
    if args.safe_mode:
        env["NEXORA_SAFE_MODE"] = "1"
    if args.no_webengine:
        env["NEXORA_NO_WEBENGINE"] = "1"
    return subprocess.call([sys.executable, "-m", "nexora"], cwd=APP_DIR, env=env)


def run_graphical_launcher(*, recovery: bool = False) -> int:
    report = diagnostics()
    if not report["required_dependencies"].get("PySide6", False):
        raise RuntimeError("PySide6 is required for Nexora Boot Center. Run: python Nexora.py setup")
    sys.path.insert(0, str(APP_DIR))
    from nexora.launcher_ui import run_launcher
    return run_launcher(ROOT, data_root(), recovery=recovery)


def main() -> int:
    args = parse_args()
    if args.command == "setup":
        return setup_runtime()
    if args.command == "diagnostics":
        return print_diagnostics()
    path = log_file()
    try:
        open_recovery = args.command == "recovery" or args.recovery_mode
        use_launcher = open_recovery or args.launcher or not args.direct
        if use_launcher:
            return run_graphical_launcher(recovery=open_recovery)
        return start(args)
    except KeyboardInterrupt:
        return 130
    except (OSError, RuntimeError, subprocess.SubprocessError) as exc:
        path.write_text(traceback.format_exc(), encoding="utf-8")
        print(f"Nexora could not start: {exc}", file=sys.stderr)
        print(f"Technical log: {path}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
