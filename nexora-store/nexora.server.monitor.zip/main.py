import tkinter as tk
from tkinter import ttk, filedialog
from pathlib import Path
import os, platform, time

root = tk.Tk()
root.title('Server Monitor' + " · Nexora Virel")
root.geometry("740x520")
root.configure(bg="#161323")
heading = tk.Label(root, text='Server Monitor', font=("Arial", 22, "bold"), bg="#161323", fg="#F0D6FF")
heading.pack(pady=22)
text = tk.Text(root, bg="#282137", fg="#FFFFFF", insertbackground="#FFFFFF", font=("Arial", 12), relief="flat")
text.pack(fill="both", expand=True, padx=20, pady=(0,12))
path = Path.home() / ".nexora" / 'nexora.server.monitor'.replace(".", "_")
path.parent.mkdir(parents=True, exist_ok=True)
try: text.insert("1.0", path.read_text(encoding="utf-8"))
except OSError: pass
if 'Server' == "Server":
    text.insert("1.0", f"Machine: {platform.node()}\nOS: {platform.platform()}\nPython: {platform.python_version()}\n\n")
def save():
    path.write_text(text.get("1.0", "end-1c"), encoding="utf-8")
bar = tk.Frame(root, bg="#161323"); bar.pack(fill="x", padx=20, pady=(0,15))
tk.Button(bar, text="Save to Nexora data", command=save, bg="#7847E8", fg="white", relief="flat", padx=16, pady=9).pack(side="right")
root.mainloop()
