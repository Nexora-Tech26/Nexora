"""NexoraScript: explicit, tiny Python-derived syntax. Not a sandbox."""
from __future__ import annotations
import io, tokenize

ALIASES = {'task': 'def', 'use': 'import', 'fromuse': 'from', 'show': 'print', 'yes': 'True', 'no': 'False', 'none': 'None', 'otherwise': 'else', 'repeat': 'while', 'each': 'for', 'inside': 'in', 'when': 'if', 'orwhen': 'elif', 'give': 'return', 'make': 'class', 'attempt': 'try', 'excepton': 'except', 'withopen': 'with'}

def compile_source(source: str) -> str:
    """Translate NAME tokens only; never mutate string literals or comments."""
    toks=[]
    for tok in tokenize.generate_tokens(io.StringIO(source).readline):
        if tok.type==tokenize.NAME and tok.string in ALIASES:
            tok=tokenize.TokenInfo(tok.type, ALIASES[tok.string], tok.start, tok.end, tok.line)
        toks.append(tok)
    return tokenize.untokenize(toks)

EXAMPLE='''# NexoraScript 1.0 — Python-compatible source\nuse math\n\ntask greet(name):\n    show("Hello from Nexora, " + name)\n\nwhen __name__ == "__main__":\n    greet("Developer")\n'''
