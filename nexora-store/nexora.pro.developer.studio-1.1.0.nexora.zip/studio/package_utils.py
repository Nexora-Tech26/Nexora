"""Safe structure validation for Nexora ZIP projects and exporter."""
from __future__ import annotations
import json, re, shutil, tempfile, zipfile
from pathlib import Path, PurePosixPath
from .nexorascript import compile_source

MAX_FILES=600; MAX_TOTAL=80*1024*1024; MAX_SINGLE=20*1024*1024

def verify_archive(file: Path):
    with zipfile.ZipFile(file) as archive:
        infos=archive.infolist()
        if len(infos)>MAX_FILES or sum(i.file_size for i in infos)>MAX_TOTAL: raise ValueError('Archive too large')
        for info in infos:
            p=PurePosixPath(info.filename)
            if not info.filename or p.is_absolute() or '..' in p.parts or '\\' in info.filename or info.file_size>MAX_SINGLE:raise ValueError('Unsafe ZIP entry')
            if info.external_attr >> 16 & 0o170000 == 0o120000:raise ValueError('Symlink not permitted')
        return [i.filename for i in infos if not i.is_dir()]

def extract_project(archive: Path, folder: Path):
    names=verify_archive(archive)
    folder.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        for name in names:
            dest=folder.joinpath(*PurePosixPath(name).parts)
            dest.parent.mkdir(parents=True, exist_ok=True)
            with z.open(name) as src, dest.open('wb') as dst:shutil.copyfileobj(src,dst)
    return folder

def export_app(source: Path, destination: Path, main_file: str, app_id: str, name: str, version='1.0.0'):
    if not re.fullmatch(r'[a-z0-9][a-z0-9._-]{1,63}',app_id):raise ValueError('Invalid app ID')
    main=PurePosixPath(main_file)
    if main.is_absolute() or '..' in main.parts or main.suffix.lower() not in ('.py','.nxpy'):raise ValueError('Invalid startup script')
    if any(p.is_symlink() for p in source.rglob('*')): raise ValueError('Project symlinks are not supported')
    files=[p for p in source.rglob('*') if p.is_file()]
    if len(files)>MAX_FILES or sum(p.stat().st_size for p in files)>MAX_TOTAL:raise ValueError('Project exceeds export limits')
    if not (source / main_file).is_file():raise ValueError('Startup file missing')
    output_main=main.with_suffix('.py') if main.suffix=='.nxpy' else main
    payload={'schema_version':1,'id':app_id,'name':name,'version':version,'description':'Application exported from Nexora Developer Studio','category':'Developer','type':'app','publisher':'Nexora Developer','entrypoint':str(output_main),'permissions':['files']}
    destination.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        z.writestr('manifest.json',json.dumps(payload,indent=2))
        for p in files:
            relative=p.relative_to(source).as_posix()
            if relative=='manifest.json' or p.is_symlink() or '__pycache__' in p.parts:continue
            if p.suffix=='.nxpy':
                translated=compile_source(p.read_text(encoding='utf-8'))
                z.writestr(str(PurePosixPath(relative).with_suffix('.py')),translated)
            else:
                z.write(p,relative)
    verify_archive(destination)
    return destination
