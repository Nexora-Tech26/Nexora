"""Nexora Developer Studio: Python/NexoraScript multi-file project IDE.

Projects are ordinary folders. Exported ZIP files have a manifest at the ZIP
root and a user-selected Python entrypoint. Executing projects is never silent.
"""
from __future__ import annotations

import ast
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from PySide6.QtCore import Qt, QProcess, QTimer
from PySide6.QtGui import QColor, QFont, QSyntaxHighlighter, QTextCharFormat
from PySide6.QtWidgets import (
    QApplication, QComboBox, QFileDialog, QHBoxLayout, QInputDialog, QLabel,
    QMainWindow, QMessageBox, QPlainTextEdit, QPushButton, QSplitter,
    QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
)

from .nexorascript import EXAMPLE, compile_source
from .package_utils import extract_project, export_app

STYLE = '''
QWidget { background:#100E1B; color:#F0EAF8; font-size:13px; }
QPlainTextEdit,QTreeWidget { background:#171427;color:#EEEAF7;border:1px solid #46385F;border-radius:14px;padding:10px;selection-background-color:#7248AC; }
QPlainTextEdit {font-family:Menlo,Consolas,monospace;font-size:13px;}
QPushButton {background:#29213E;color:#F4EDF8;border:1px solid #594A78;border-radius:14px;padding:9px 14px;min-height:24px;}
QPushButton:hover {background:#43305E;border-color:#AD79C9;}
QPushButton:pressed {background:#69448B;}
QPushButton#PrimaryAction {background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #673FA7,stop:0.5 #994C92,stop:1 #B97755);border-color:#AA73A5;}
QComboBox {background:#29213E;border:1px solid #594A78;border-radius:10px;padding:8px;}
QLabel#Title {font-size:24px;font-weight:700;color:#F2E8FF;}
QLabel#Muted {color:#AA9DBE;}
'''


class Highlighter(QSyntaxHighlighter):
    def highlightBlock(self, text):
        import re
        groups = (
            (r'\b(?:task|use|show|when|otherwise|orwhen|each|inside|repeat|give|make|attempt|excepton|yes|no|none)\b', '#D6A0F7'),
            (r'\b(?:def|import|from|print|if|elif|else|for|while|return|class|try|except|with|async|await)\b', '#AF8CF8'),
            (r'#[^\n]*', '#8896AD'),
            (r'\b\d+(?:\.\d+)?\b', '#EEB17C'),
            (r'\b(?:True|False|None)\b', '#A4D2E7'),
        )
        for pattern, color in groups:
            fmt = QTextCharFormat()
            fmt.setForeground(QColor(color))
            for match in re.finditer(pattern, text):
                self.setFormat(match.start(), len(match.group()), fmt)


class Studio(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Nexora Developer Studio PRO')
        self.resize(1320, 850)
        self.workdir = Path(tempfile.mkdtemp(prefix='nexora-studio-')).resolve()
        self.file = self.workdir / 'main.nxpy'
        self.file.write_text(EXAMPLE, encoding='utf-8')
        self.modified = False
        self.process = None
        self._build_ui()
        self._reload_tree()
        self._load_file(self.file)

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(16, 14, 16, 12)
        outer.setSpacing(10)
        heading = QHBoxLayout()
        title = QLabel('Developer Studio PRO')
        title.setObjectName('Title')
        heading.addWidget(title)
        heading.addStretch()
        self.language = QComboBox()
        self.language.addItems(['NexoraScript', 'Python'])
        self.language.currentIndexChanged.connect(self._change_language)
        heading.addWidget(self.language)
        outer.addLayout(heading)

        toolbar = QHBoxLayout()
        for text, handler in (
            ('New Project', self.new_project), ('Open Folder', self.open_folder),
            ('Open ZIP', self.open_zip), ('New File', self.new_file),
            ('Save', self.save), ('Check Code', self.check_code),
            ('Run', self.run), ('Stop', self.stop),
            ('Export Nexora ZIP', self.export), ('Store Release', self.prepare_store_release), ('Publish Guide', self.publish_guide),
        ):
            button = QPushButton(text)
            if text in ('Run', 'Export Nexora ZIP'):
                button.setObjectName('PrimaryAction')
            button.clicked.connect(handler)
            toolbar.addWidget(button)
        toolbar.addStretch()
        outer.addLayout(toolbar)

        workspace = QSplitter(Qt.Horizontal)
        outer.addWidget(workspace, 1)
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 8, 0)
        left_heading = QLabel('PROJECT FILES')
        left_heading.setObjectName('Muted')
        left_layout.addWidget(left_heading)
        self.tree = QTreeWidget()
        self.tree.setHeaderHidden(True)
        self.tree.itemActivated.connect(self._file_selected)
        self.tree.itemClicked.connect(self._file_selected)
        left_layout.addWidget(self.tree)
        workspace.addWidget(left)

        right = QSplitter(Qt.Vertical)
        editor_wrap = QWidget()
        editor_layout = QVBoxLayout(editor_wrap)
        editor_layout.setContentsMargins(0, 0, 0, 0)
        self.file_label = QLabel('main.nxpy')
        self.file_label.setObjectName('Muted')
        editor_layout.addWidget(self.file_label)
        self.editor = QPlainTextEdit()
        self.editor.setTabStopDistance(32)
        self.editor.textChanged.connect(self._changed)
        self.highlighter = Highlighter(self.editor.document())
        editor_layout.addWidget(self.editor, 1)
        right.addWidget(editor_wrap)
        output_wrap = QWidget()
        output_layout = QVBoxLayout(output_wrap)
        output_layout.setContentsMargins(0, 0, 0, 0)
        output_layout.addWidget(QLabel('BUILD / RUN OUTPUT'))
        self.output = QPlainTextEdit()
        self.output.setReadOnly(True)
        output_layout.addWidget(self.output)
        right.addWidget(output_wrap)
        right.setSizes([610, 180])
        workspace.addWidget(right)
        workspace.setSizes([245, 1000])
        self.status = QLabel('Ready · Python and NexoraScript projects')
        self.status.setObjectName('Muted')
        outer.addWidget(self.status)
        self.setStyleSheet(STYLE)
        self._lint_timer = QTimer(self)
        self._lint_timer.setSingleShot(True)
        self._lint_timer.setInterval(700)
        self._lint_timer.timeout.connect(self._silent_lint)

    def _changed(self):
        self.modified = True
        self.file_label.setText(self.file.name + '  • unsaved')
        self._lint_timer.start()

    def _check_source(self, source, suffix):
        python_source = compile_source(source) if suffix == '.nxpy' else source
        ast.parse(python_source, filename=self.file.name)
        return python_source

    def _silent_lint(self):
        try:
            self._check_source(self.editor.toPlainText(), self.file.suffix)
            self.status.setText('Syntax OK · ' + self.file.name)
        except (SyntaxError, ValueError, IndentationError) as exc:
            self.status.setText(f'Line {getattr(exc,"lineno","?")}: {exc.msg if isinstance(exc,SyntaxError) else exc}')

    def check_code(self):
        try:
            compiled = self._check_source(self.editor.toPlainText(), self.file.suffix)
            self.output.setPlainText(f'Syntax OK\nFile: {self.file.name}\nPython output: {len(compiled.splitlines())} lines')
        except Exception as exc:
            self.output.setPlainText('Syntax error: ' + str(exc))

    def save(self):
        self.file.parent.mkdir(parents=True, exist_ok=True)
        self.file.write_text(self.editor.toPlainText(), encoding='utf-8')
        self.modified = False
        self.file_label.setText(self.file.relative_to(self.workdir).as_posix())
        self.status.setText('Saved · ' + str(self.file))
        self._reload_tree()

    def _confirm_leave(self):
        if not self.modified:
            return True
        reply = QMessageBox.question(self, 'Unsaved changes', 'Save the current file?',
                                     QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
                                     QMessageBox.StandardButton.Save)
        if reply == QMessageBox.StandardButton.Cancel:
            return False
        if reply == QMessageBox.StandardButton.Save:
            self.save()
        return True

    def _load_file(self, path):
        path = Path(path).resolve()
        if path.suffix.lower() not in ('.py', '.nxpy') or not path.is_file():
            return
        if not path.is_relative_to(self.workdir):
            return
        if not self._confirm_leave():
            return
        self.file = path
        self.editor.blockSignals(True)
        self.editor.setPlainText(path.read_text(encoding='utf-8'))
        self.editor.blockSignals(False)
        self.modified = False
        self.language.blockSignals(True)
        self.language.setCurrentIndex(0 if self.file.suffix == '.nxpy' else 1)
        self.language.blockSignals(False)
        self.file_label.setText(self.file.relative_to(self.workdir).as_posix())
        self._silent_lint()

    def _reload_tree(self):
        self.tree.clear()
        root = QTreeWidgetItem([self.workdir.name])
        self.tree.addTopLevelItem(root)
        nodes = {Path('.'): root}
        for path in sorted(self.workdir.rglob('*')):
            if '__pycache__' in path.parts or path.is_symlink():
                continue
            relative = path.relative_to(self.workdir)
            parent = nodes.get(relative.parent, root)
            if path.is_dir():
                node = QTreeWidgetItem(parent, [relative.name])
                nodes[relative] = node
            elif path.suffix.lower() in ('.py', '.nxpy', '.json', '.txt', '.md'):
                node = QTreeWidgetItem(parent, [relative.name])
                node.setData(0, Qt.ItemDataRole.UserRole, str(path))
        root.setExpanded(True)
        self.tree.expandToDepth(1)

    def _file_selected(self, item, _column=0):
        path = item.data(0, Qt.ItemDataRole.UserRole)
        if path:
            self._load_file(Path(path))

    def new_project(self):
        folder = QFileDialog.getExistingDirectory(self, 'Choose new project location')
        if not folder or not self._confirm_leave():
            return
        name, ok = QInputDialog.getText(self, 'Project name', 'Folder name:')
        if not ok or not name.strip() or any(c in name for c in '/\\'):
            return
        target = Path(folder) / name.strip()
        if target.exists():
            QMessageBox.warning(self, 'Project exists', 'Choose another project name')
            return
        target.mkdir(parents=True)
        (target / 'main.nxpy').write_text(EXAMPLE, encoding='utf-8')
        self.workdir = target.resolve()
        self.modified = False
        self._reload_tree()
        self._load_file(self.workdir / 'main.nxpy')

    def open_folder(self):
        folder = QFileDialog.getExistingDirectory(self, 'Open Nexora project')
        if not folder or not self._confirm_leave():
            return
        target = Path(folder).resolve()
        files = sorted([p for p in target.rglob('*') if p.is_file() and p.suffix.lower() in ('.py', '.nxpy') and not p.is_symlink()])
        if not files:
            QMessageBox.warning(self, 'No code', 'This folder contains no Python or NexoraScript files')
            return
        self.workdir = target
        self.modified = False
        self._reload_tree()
        self._load_file(files[0])

    def open_zip(self):
        name, _ = QFileDialog.getOpenFileName(self, 'Open ZIP project', '', 'ZIP files (*.zip)')
        if not name or not self._confirm_leave():
            return
        try:
            target = Path(tempfile.mkdtemp(prefix='nexora-project-')).resolve()
            extract_project(Path(name), target)
            files = sorted([p for p in target.rglob('*') if p.is_file() and p.suffix.lower() in ('.py', '.nxpy')])
            if not files:
                raise ValueError('No source files in archive')
            self.workdir = target
            self.modified = False
            self._reload_tree()
            self._load_file(files[0])
        except Exception as exc:
            QMessageBox.warning(self, 'ZIP error', str(exc))

    def new_file(self):
        name, ok = QInputDialog.getText(self, 'New source file', 'Relative file name (e.g. ui/main.nxpy):')
        if not ok or not name:
            return
        target = (self.workdir / name).resolve()
        if not target.is_relative_to(self.workdir) or target.suffix not in ('.py', '.nxpy') or target.exists():
            QMessageBox.warning(self, 'Invalid name', 'Choose a new .py or .nxpy file inside this project')
            return
        if not self._confirm_leave():
            return
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text('', encoding='utf-8')
        self._reload_tree()
        self._load_file(target)

    def _change_language(self, index):
        expected = '.nxpy' if index == 0 else '.py'
        if self.file.suffix != expected:
            self.status.setText(f'{self.file.name} is still {self.file.suffix}. Save under a matching extension to switch languages.')

    def run(self):
        if self.process and self.process.state() != QProcess.ProcessState.NotRunning:
            return
        if QMessageBox.question(self, 'Run source code', 'This executes Python with your account permissions. Run only trusted projects.',
                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return
        try:
            self.save()
            translated = self._check_source(self.editor.toPlainText(), self.file.suffix)
            runner = self.file
            if self.file.suffix == '.nxpy':
                runner = self.workdir / '.nexora_run.py'
                runner.write_text(translated, encoding='utf-8')
            self.output.clear()
            self.process = QProcess(self)
            self.process.setWorkingDirectory(str(self.workdir))
            self.process.setProgram(sys.executable)
            self.process.setArguments(['-B', str(runner)])
            self.process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
            self.process.readyReadStandardOutput.connect(lambda: self.output.insertPlainText(bytes(self.process.readAllStandardOutput()).decode('utf-8', 'replace')))
            self.process.finished.connect(lambda code, _status: self.status.setText(f'Run completed · exit {code}'))
            self.process.start()
        except Exception as exc:
            QMessageBox.warning(self, 'Execution failed', str(exc))

    def stop(self):
        if self.process and self.process.state() != QProcess.ProcessState.NotRunning:
            self.process.terminate()
            QTimer.singleShot(1500, lambda: self.process.kill() if self.process and self.process.state() != QProcess.ProcessState.NotRunning else None)

    def export(self):
        try:
            self.save()
            files = sorted([p for p in self.workdir.rglob('*') if p.is_file() and p.suffix in ('.nxpy', '.py') and p.name != '.nexora_run.py'])
            if not files:
                raise ValueError('No executable source files')
            choices = [p.relative_to(self.workdir).as_posix() for p in files]
            selected, ok = QInputDialog.getItem(self, 'Application entrypoint', 'Choose the MAIN startup file:', choices, choices.index(self.file.relative_to(self.workdir).as_posix()) if self.file in files else 0, False)
            if not ok:
                return
            name, ok = QInputDialog.getText(self, 'Application name', 'Display name:')
            if not ok or not name.strip():
                return
            app_id, ok = QInputDialog.getText(self, 'Store application ID', 'Unique lowercase ID:', text='com.example.app')
            if not ok:
                return
            version, ok = QInputDialog.getText(self, 'App version', 'Version:', text='1.0.0')
            if not ok:
                return
            target, _ = QFileDialog.getSaveFileName(self, 'Export Nexora app', f'{name.strip().replace(" ", "_")}.nexora.zip', 'Nexora package (*.zip)')
            if not target:
                return
            export_app(self.workdir, Path(target), selected, app_id, name.strip(), version=version)
            self.status.setText('Package ready · ' + target)
            QMessageBox.information(self, 'Export successful', 'Nexora ZIP created. Install locally in Store, or publish it through your Store repository.')
        except Exception as exc:
            QMessageBox.warning(self, 'Export failed', str(exc))

    def prepare_store_release(self):
        """Prepare verified Store metadata; publication needs repository credentials."""
        archive, _ = QFileDialog.getOpenFileName(self, 'Choose exported Nexora app', '', 'ZIP archives (*.zip)')
        if not archive:
            return
        try:
            from .package_utils import verify_archive
            import zipfile
            verify_archive(Path(archive))
            with zipfile.ZipFile(archive) as bundle:
                manifest = json.loads(bundle.read('manifest.json').decode('utf-8'))
            url, ok = QInputDialog.getText(self, 'Public package URL', 'HTTPS URL that will host this ZIP:')
            if not ok:
                return
            if not url.startswith('https://'):
                raise ValueError('A public HTTPS package URL is required')
            record = dict(id=manifest['id'], name=manifest['name'], version=manifest['version'],
                          description=manifest['description'], category=manifest['category'],
                          publisher=manifest.get('publisher','Nexora Developer'), url=url,
                          sha256=hashlib.sha256(Path(archive).read_bytes()).hexdigest())
            output = Path(archive).with_suffix('.store-entry.json')
            output.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
            self.status.setText('Store metadata generated: '+str(output))
            QMessageBox.information(self,'Store release prepared',
                'The package and verified catalog entry are ready.\n'
                'Upload the ZIP to its public URL, then add the entry to catalog.json.\n'
                'Publishing was NOT performed automatically.')
        except Exception as exc:
            QMessageBox.warning(self,'Store release failed',str(exc))

    def publish_guide(self):
        QMessageBox.information(self, 'Publish to Nexora Store',
            '1. Export your application ZIP with a unique ID and version.\n'
            '2. Upload the ZIP to your public Store repository.\n'
            '3. Add or update its ID, version, HTTPS URL and SHA-256 in catalog.json.\n'
            '4. Store → Refresh catalog. Installed older versions appear under Updates.\n\n'
            'Publishing requires repository write permission; this editor does not silently upload code.')

    def closeEvent(self, event):
        if not self._confirm_leave():
            event.ignore()
            return
        self.stop()
        super().closeEvent(event)


def main():
    app = QApplication(sys.argv)
    window = Studio()
    window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
